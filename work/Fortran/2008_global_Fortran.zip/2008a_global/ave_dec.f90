program ave_dec
! decadal (or longer) averages of IPCC climate reconstructions

implicit none

integer, parameter  :: begyr=-20, endyr=2005

real(4)             :: year(begyr:endyr),var(begyr:endyr),varin
real(4)             :: varmiss,mean,ave

integer             :: i,ii,age,iyr,npts,nyr,begave,endave

character(80)       :: header

open (1,file="e:\Projects\igbpfire\hstick\figs\fig01\fig6.10b_ave.csv")
open (2,file="e:\Projects\igbpfire\hstick\figs\fig01\fig6.10b_ave_20.csv")
write (2,'(a)') "Year, ave_tmp"

varmiss=-9999.0
nyr=20
begave=10; endave=1990

read (1,*) header
ii=0
do while (.not. eof(1))
    read (1,*) iyr,varin
    year(iyr)=iyr
    var(iyr)=varin
end do

do i=begave,endave,nyr
    ave=varmiss
    mean=0.0; npts=0
    do ii=i-(nyr/2)+1,i+(nyr/2)
        if (var(ii).ne.varmiss) then
            mean=mean+var(ii)
            npts=npts+1
            !write (*,*) i,ii,var(ii),mean,npts
        end if
    end do
    if (npts.gt.0) then
        mean=mean/sngl(npts)
        ave=mean
    end if
    write (2,'(i4,",",f14.6)') i,ave
    write (*,*) i,ave
    !pause
end do

end
