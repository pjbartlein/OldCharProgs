program site_smooth_hs5
! gets lowess-smoothed values for an individual site

use lowess

implicit none

integer, parameter  :: maxdata=50000, maxsites=5000 

integer(4)      :: site_sample,id_sample
real(4)         :: depth,age,var,varmnx,tall,t4k,t2k
real(4)         :: varin,varmiss
character(8)    :: site_num_label

real(4)         :: begyr,endyr

real(8)         :: xin(maxdata),yin(maxdata),xtarg(maxdata),yfit(maxdata),param,stage1
real(8)         :: targbeg,targend,targstep
integer(4)      :: order,nrobust,ntarg
character(1)    :: wintype

integer         :: i,j,npts,nctrl

character(32)   :: int_to_string2
character(256)  :: transpath,smoothpath,allfile,transfile,smoothfile
character(80)   :: header
character(1)    :: dum
character(4)    :: site_num_char,char_s1
character(32)   :: vname

stage1=10.0
vname="sedrate"
char_s1="sm"//int_to_string2(int(stage1),2)
allfile="e:\Projects\igbpfire\charsum\data\current_hs5\files\HS_5a_all_"//trim(adjustl(vname))//"_"//char_s1//".csv"
write (*,*) allfile

smoothpath="e:\Projects\igbpfire\charsum\data\current_hs5\sites\smooth_"//trim(adjustl(vname))//"_csv\"
transpath="e:\Projects\igbpfire\charsum\data\current_hs5\sites\trans_"//trim(adjustl(vname))//"_csv\"
open (3,file=allfile)
write (3,'("site, xtarg, yfit")')

varmiss=-9999.0

! lowess parameters
param=dble(stage1); wintype='w'; order=0; nrobust=0

! target point definitions
targend=2000.0d0; targbeg=-60.0d0; targstep=2.0*sngl(param)

! overall age range of data
begyr=2020.0; endyr=-60.0
               
! generate target points
ntarg=int((targend-targbeg)/targstep)+1
write (*,*) stage1,param,targstep,ntarg
do i=1,ntarg
    xtarg(i)=targend-dble(i-1)*targstep
    !write (*,*) i,sngl(xtarg(i))
end do

! loop over sites
do j=1,1000

    site_num_char=int_to_string2(j,4)
    
    ! try to open a file
    site_num_char=int_to_string2(j,4)
    transfile=trim(adjustl(transpath))//trim(adjustl(site_num_char))//"_trans_"//trim(adjustl(vname))//".csv"
    smoothfile=trim(adjustl(smoothpath))//trim(adjustl(site_num_char))//"_smooth_"//trim(adjustl(vname))//"_"//char_s1//".csv"
    open (1,file=transfile, status='old', err=100)
    open (2,file=smoothfile) 
    write (2,'("site",a4,", xtarg, yfit")') site_num_char
    write (*,*) site_num_char
    
    ! read data, and save age and variable to be smoothed
    read (1,*) header
    i=0
    do while (.not. eof(1))
        read (1,*) site_num_label,site_sample,id_sample,age,depth,var,varmnx,tall,t4k,t2k
        varin=t2k 
        !write (*,*) i,varin
        if (varin.ne.varmiss) then
            i=i+1
            xin(i)=age
            yin(i)=varin
            !write (2,'(i5," ,",a8," ,",i4,2(",",f14.6))') i,site_num_label,site_sample,xin(i),yin(i)         
        end if
    end do
    nctrl=i
    
    call lowess_curve(nctrl,xin,yin,ntarg,xtarg,wintype,param,order,nrobust,yfit)

    do i=1,ntarg
        if (.not. isnan(yfit(i))) then
            write (2,'(i4,2(",",f14.6))') i,xtarg(i),yfit(i)
            write (3,'("site",a4,","f14.3,",",f14.6)') site_num_char,xtarg(i),yfit(i)
        end if
    end do
    
    write (*,*) nctrl
    close(1)
    close(2)
    
100 continue

end do

end

function int_to_string(inum)

	implicit none
	character(32)	:: int_to_string
	character(32)	:: buffer, str
	integer			:: inum

	write (buffer,*) inum
	read (buffer,*) str

	int_to_string=trim(adjustl(str))

end function int_to_string


function int_to_string2(inum,numlen)

	implicit none
	character(32)	:: int_to_string,int_to_string2
	character(32)	:: buffer, str
	character(8)	:: ifmt,iedit
	integer			:: inum,numlen

	iedit=int_to_string(numlen)
	ifmt="(i"//trim(adjustl(iedit))//"."//trim(adjustl(iedit))//")"

	write (buffer,ifmt) inum
	read (buffer,*) str

	int_to_string2=trim(adjustl(str))

end function int_to_string2

