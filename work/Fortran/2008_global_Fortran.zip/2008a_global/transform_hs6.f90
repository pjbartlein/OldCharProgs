program transform
! transforms and z-scores of individual charcoal records

use summarize_subs

implicit none

integer(4)      :: site_sample(maxdata),id_sample(maxdata)
real(4)         :: depth(maxdata),age(maxdata),var(maxdata),varmnx(maxdata)
real(4)         :: tall(maxdata),t4k(maxdata),t2k(maxdata)
real(4)         :: sedrate_in,quant_in,conc_in,influx_in,conc2_in,influx2_in
real(4)         :: vartemp(maxdata),sage(maxdata),svar(maxdata),varmiss

real(4)         :: begbase_all,endbase_all,begbase_4k,endbase_4k,begbase_2k,endbase_2k
real(4)         :: firstyr,lastyr

real(4)         :: lambda_all,shift_all,lhmax_all,lambda_4k,shift_4k,lhmax_4k,lambda_2k,shift_2k,lhmax_2k
real(4)         :: vmean_all,vstdev_all,vmin_all,vmax_all,vrng_all 
real(4)         :: vmean_4k,vstdev_4k,vmin_4k,vmax_4k,vrng_4k 
real(4)         :: vmean_2k,vstdev_2k,vmin_2k,vmax_2k,vrng_2k 

integer(4)      :: i,j,npts,npts_all,npts_4k,npts_2k

character(4)    :: source(maxdata)
character(4)    :: quant_source_in,conc_source_in,influx_source_in,conc2_source_in,influx2_source_in

character(4)    :: site_num_char
character(8)    :: site_num_label
character(256)  :: datapath,transpath,lambdafile,allsamplesfile,debugfile 

datapath="e:\Projects\igbpfire\charsum\data\current_hs6\sites\site_csv\"
transpath="e:\Projects\igbpfire\charsum\data\current_hs6\sites\trans_influx2_csv\"  ! ######
lambdafile="e:\Projects\igbpfire\charsum\data\current_hs6\files\hs6a_influx2_lambda.dat" ! ###### 
allsamplesfile="e:\Projects\igbpfire\charsum\data\current_hs6\files\hs6a_all_influx2.csv" ! ######
debugfile="e:\Projects\igbpfire\charsum\data\current_hs6\files\hs6a_debug2.dat"

begbase_4k=100.0; endbase_4k=4000.0; endbase_2k=2000.0
varmiss=-9999.0 
shift_all=0.01; shift_4k=0.01; shift_2k=0.01

open (3,file=lambdafile)
write (3,'(a)') "site, npts, npts_all, lambda_all, shift_all, lhmax_all, " &
                    //"npts_4k, lambda_4k, shift_4k, lhmax_4k, npts_2k, lambda_2k, shift_2k, lhmax_2k"
open (4,file=allsamplesfile)
write (4,'(a)') "site, site_sample, id_sample, est_age, depth, influx, influxmnx, " & ! ######
                    // "tall, t4k, t2k, source"
open (10,file=debugfile)

do j=1,maxsites
    ! try to open a file
    site_num_char=int_to_string2(j,4)
    open (1,file=trim(datapath)//trim(adjustl(site_num_char))//"_data.csv", status='old', err=100)
    open (2,file=trim(transpath)//trim(adjustl(site_num_char))//"_trans_influx2.csv") ! ######
    write (2,'(a)') "site, site_sample, id_sample, est_age, depth, influx, influxmnx, " & ! ######
                    // "tall, t4k, t2k, source"
    
    read (1,*) site_num_label
    
    ! initialize 
    depth=0.0; age=0.0; var=varmiss; varmnx=varmiss
    vmean_all=varmiss; vstdev_all=varmiss; vmin_all=varmiss; vmax_all=varmiss; vrng_all=varmiss
    npts_all=0; tall=varmiss; lambda_all=-9.0; lhmax_all=-99999.0
    npts_4k=0;  t4k=varmiss;  lambda_4k=-9.0;  lhmax_4k=-99999.0
    npts_2k=0;  t2k=varmiss;  lambda_2k=-9.0;  lhmax_2k=-99999.0
 
    i=0
    lastyr=-99999.0; firstyr=99999.0
    do while (.not. eof(1))
        i=i+1
        read (1,*) site_sample(i),id_sample(i),depth(i),age(i),sedrate_in,quant_in,conc_in,influx_in,conc2_in,influx2_in, &
            quant_source_in,conc_source_in,influx_source_in,conc2_source_in,influx2_source_in
        var(i)=influx2_in  ! ######
        source(i)=influx2_source_in ! ######
        if (age(i).gt.lastyr) lastyr=age(i)
        if (age(i).lt.firstyr) firstyr=age(i)
    end do
    npts=i
    
    write (*,*) lastyr,firstyr
    begbase_all=firstyr; endbase_all=lastyr; begbase_2k=firstyr
    
    write (10,'(i5,1x,a4,1x,a8,1x,i4,2f10.2)') j,site_num_char,site_num_label,npts,firstyr,lastyr
    write (*,'(i5,1x,a4,1x,a8,1x,i4,2f10.2)') j,site_num_char,site_num_label,npts,firstyr,lastyr
    
    ! transformations 
    
    ! stats for whole record
    call stats(npts,age,var,varmiss,begbase_all,endbase_all,npts_all,vmean_all,vstdev_all,vmin_all,vmax_all,vrng_all)
    
    ! qmnx -- minimax transformation of var for whole record
    call minimax(npts_all,var,varmiss,vmin_all,vmax_all,varmnx)
    
    ! Box-Cox transformation -- whole record
    call boxcox_lambda(npts_all,var,varmiss,shift_all,lambda_all,lhmax_all)    
    call boxcox_trans(npts_all,lambda_all,shift_all,var,varmiss,tall)
    
    ! select points in the range 4000 to 100 (e.g. DP 1)
    write (*,*) npts_all,begbase_4k,endbase_4k
    call selectage(npts_all,begbase_4k,endbase_4k,age,var,npts_4k,sage,svar)
       
    ! get Box-Cox parameters for selection of points
    if (npts_4k.gt.0) then
        call boxcox_lambda(npts_4k,svar,varmiss,shift_4k,lambda_4k,lhmax_4k)    
        ! transform whole record with 4k parameters  
        call boxcox_trans(npts_all,lambda_4k,shift_4k,var,varmiss,vartemp)
        ! minimax of transformed data using 4ka parameters
        call stats(npts,age,vartemp,varmiss,begbase_4k,endbase_4k,npts_4k,vmean_4k,vstdev_4k,vmin_4k,vmax_4k,vrng_4k)
        call minimax(npts_all,vartemp,varmiss,vmin_4k,vmax_4k,t4k)
    end if   
    
    ! select points in the range 2000 to firstyr
    write (*,*) npts_all,begbase_2k,endbase_2k
    call selectage(npts_all,begbase_2k,endbase_2k,age,var,npts_2k,sage,svar)
    
    ! get Box-Cox parameters for selection of points
    if (npts_2k.gt.0) then
        call boxcox_lambda(npts_2k,svar,varmiss,shift_2k,lambda_2k,lhmax_2k)    
        ! transform whole record with 2k parameters
        call boxcox_trans(npts_all,lambda_2k,shift_2k,var,varmiss,t2k)
        ! minimax of transformed data using 2ka parameters
        call stats(npts,age,vartemp,varmiss,begbase_2k,endbase_2k,npts_2k,vmean_2k,vstdev_2k,vmin_2k,vmax_2k,vrng_2k)
        call minimax(npts_all,vartemp,varmiss,vmin_2k,vmax_2k,t2k)
    end if    
    
    do i=1,npts
        write (2,'(a8,",",i8,",",i8,",",f10.2,",",f10.2,5(",",f14.3),", ","""",a4,"""" )') &
            site_num_label,site_sample(i),id_sample(i),age(i),depth(i),var(i),varmnx(i), &
            tall(i),t4k(i),t2k(i),source(i)
        write (4,'(a8,",",i8,",",i8,",",f10.2,",",f10.2,5(",",f14.3),", ","""",a4,"""" )') &
            site_num_label,site_sample(i),id_sample(i),age(i),depth(i),var(i),varmnx(i), &
            tall(i),t4k(i),t2k(i),source(i)
    end do
    
    write (3,'(a8,1x,i5,1x,3(i5,2f8.2,f10.2))') &
        site_num_label,npts,npts_all,lambda_all,shift_all,lhmax_all,  &
            npts_4k,lambda_4k,shift_4k,lhmax_4k,npts_2k,lambda_2k,shift_2k,lhmax_2k 
   
100 continue
    
end do

end


