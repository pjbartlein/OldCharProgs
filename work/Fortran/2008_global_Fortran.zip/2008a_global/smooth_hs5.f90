program smooth_hs5
! fits a smooth lowess-type curve to transformed/standardized charcoal data

use lowess      ! use the lowess module

implicit none

integer, parameter  :: maxdata=100000
integer(4)      :: site_sample,id_sample
real(4)         :: depth,age,var,varmnx,tall,t4k,t2k
real(4)         :: varin,varmiss
character(8)    :: site_num_label

real(4)         :: begyr,endyr

real(8)         :: xin(maxdata),yin(maxdata),xtarg(maxdata),yfit(maxdata),param
real(8)         :: targbeg,targend,targstep
integer(4)      :: order,nrobust,ntarg
character(1)    :: wintype,header

integer         :: i,ii,ndata,npts
character(256)  :: datapath,plotpath,infile,ptsfile,lowfile,labelfile,lowcsvfile

datapath="\Projects\igbpfire\charsum\data\current_hs5\files\"
infile="hs5_all_influx.csv"   ! ############
!infile="HS_5a_all_influx_sm10.csv"   ! ############

plotpath="\Projects\igbpfire\charsum\data\plots03\"
ptsfile=   "t2k_influx.dat"      ! ############
lowfile=   "t2k_influx_sm50.dat"  
lowcsvfile="t2k_influx_sm50.csv"
labelfile= "t2k_influx_sm50.txt"
!ptsfile=   "t2k_influx_sm10.dat"      ! ############
!lowfile=   "t2k_influx_sm10_50.dat"  
!lowcsvfile="t2k_influx_sm10_50.csv"
!labelfile= "t2k_influx_sm10_50.txt"
open (1,file=trim(adjustl(plotpath))//trim(adjustl(ptsfile)))
open (2,file=trim(adjustl(plotpath))//trim(adjustl(lowfile)))
open (3,file=trim(adjustl(plotpath))//trim(adjustl(labelfile)))
open (5,file=trim(adjustl(datapath))//trim(adjustl(lowcsvfile)))
!write (5,'("  targ_age,  t2k_influx_sm10_50")') 
write (5,'("  targ_age,  t2k_influx_50")') 

!!!!!!!!!! change varin too

! lowess parameters
param=50.0d0; wintype='w'; order=1; nrobust=0     ! ############

! target point definitions
targend=2000.0d0; targbeg=-60.0d0; targstep=10.0d0

! overall age range of data
begyr=2020.0; endyr=-60.0

varmiss=-9999.0

! read data, and save age and variable to be smoothed
open (10,file="\Projects\igbpfire\charsum\data\current_hs5\files\HS_5a_debug_low.dat")
open (4,file=trim(adjustl(datapath))//trim(adjustl(infile)))
read (4,*) header
i=0
do while (.not. eof(4))
    read (4,*) site_num_label,site_sample,id_sample,age,depth,var,varmnx,tall,t4k,t2k   ! #######
    varin=t2k
    !read (4,*) site_num_label,age,varin
    if (age.le.begyr .and. age.ge.endyr .and. varin.ne.varmiss) then
        i=i+1
        xin(i)=dble(age)              ! x-variable for lowess
        yin(i)=dble(varin)            ! y-variable for lowess
        write (10,*) i,site_num_label,sngl(xin(i)),sngl(yin(i))
    end if
end do
npts=i
write (*,*) npts
close(4)
               
! generate target points
ntarg=int((targend-targbeg)/targstep)+1
do i=1,ntarg
    xtarg(i)=targend-dble(i-1)*targstep
    write (10,*) i,sngl(xtarg(i))
end do

! get the lowess curve
call lowess_curve(npts,xin,yin,ntarg,xtarg,wintype,param,order,nrobust,yfit)

! write data and curve for plotting, plus some labels
do i=1,npts
    write (1,'(f10.2,f12.4)') xin(i),yin(i)
end do
do i=1,ntarg
    write (2,'(f10.2,f12.4)') xtarg(i),yfit(i)
    write (5,'(f10.2,",",f12.4)') xtarg(i),yfit(i)
end do
write (3,'("""",a24,"; param=",f5.1,"; wintype=",a1,"; order=",i1,"; nrobust=",i1,"""")') &
    trim(adjustl(lowfile)),param,wintype,order,nrobust
close(1)
close(2)
close(3)

end program smooth_hs5