program site_summary
! gets some summaries for individual sites

implicit none

integer, parameter  :: maxdata=50000, maxsites=5000 

integer(4)      :: site_sample(maxdata),id_sample(maxdata)
real(4)         :: depth(maxdata),age(maxdata),sedrate(maxdata),quant(maxdata),agemiss
character(8)    :: site_num_label

real(4)         :: begage,endage,endyr,beg20th
integer         :: i,j,npts,n20th

character(32)   :: int_to_string2
character(256)  :: datapath,sumfile
character(80)   :: header
character(1)    :: dum
character(4)    :: site_num_char,char_s1
character(32)   :: vname

datapath="\Projects\igbpfire\charsum\data\current_hs6\sites\site_csv\"
sumfile="\Projects\igbpfire\charsum\data\current_hs6\files\site_sum.csv" 

open (4,file=sumfile)
write (4,'(a)') "site, begage, endage, endyr, topsedrate, n20th"

beg20th=50.0
agemiss=-9999.0

do j=1,maxsites
    ! try to open a file
    site_num_char=int_to_string2(j,4)
    open (1,file=trim(datapath)//trim(adjustl(site_num_char))//"_data.csv", status='old', err=100)
    
    read (1,*) site_num_label
    
    i=0
    n20th=0
    endage=99999.0; begage=-99999.0
    do while (.not. eof(1))
        i=i+1
        read (1,*) site_sample(i),id_sample(i),depth(i),age(i),sedrate(i),quant(i)
        !if (age(i).ne.agemiss) then
            if (age(i).gt.begage) begage=age(i)
            if (age(i).lt.endage) endage=age(i)
            if (age(i).lt.beg20th) n20th=n20th+1
        !end if
    end do
    npts=i
    
    endyr=1950.0-endage
    if (endyr.lt.0) endyr=endyr+1
    
    write (4,'(a4,3(", ",f8.1),", ",f10.4,", ",i4)') site_num_char,begage,endage,endyr,sedrate(1),n20th
    
100 continue

end do

end

function int_to_string(inum)

	implicit none
	character(32)	:: int_to_string
	character(32)	:: buffer, str
	integer			:: inum

	write (buffer,*) inum
	read (buffer,*) str

	int_to_string=trim(adjustl(str))

end function int_to_string


function int_to_string2(inum,numlen)

	implicit none
	character(32)	:: int_to_string,int_to_string2
	character(32)	:: buffer, str
	character(8)	:: ifmt,iedit
	integer			:: inum,numlen

	iedit=int_to_string(numlen)
	ifmt="(i"//trim(adjustl(iedit))//"."//trim(adjustl(iedit))//")"

	write (buffer,ifmt) inum
	read (buffer,*) str

	int_to_string2=trim(adjustl(str))

end function int_to_string2

