program make_csv
! reads an all-sites, all-data query and
! writes individual .csv files for sites

implicit none

integer, parameter  :: maxsamples=3000,maxsites=1000
integer(4)      :: site_num(maxsites),sitenum2          ! site id's
integer(4)      :: current,site_num_in                  ! current and next site id's
integer(4)      :: nsamples(maxsites),nsamp             ! number of samples at each site
integer(4)      :: id_sample(maxsamples)                ! sample id's
integer(4)      :: nsites                               ! number of sites
real(8)         :: lat,lon                              ! lat and lon
real(4)         :: depth(maxsamples),age(maxsamples)    ! depth and age
real(4)         :: quant(maxsamples)                    ! charcoal quantity
real(4)         :: thickness(maxsamples)                ! sample thickness (cm)
real(4)         :: dep_time(maxsamples)                 ! sample deposition time (yr)
real(4)         :: unit_dep_time(maxsamples)            ! unit depositional time or inverse dep rate (yr cm-1)
real(4)         :: sed_rate(maxsamples)                 ! sample sed rate (cm yr-1)
real(4)         :: conc(maxsamples)                     ! concentration (c cm-3) 
real(4)         :: influx(maxsamples)                   ! influx (c cm-2 yr-1)
real(4)         :: conc2(maxsamples)                    ! concentration plus other
real(4)         :: influx2(maxsamples)                  ! influx plus other
real(4)         :: miss                                 ! missing value
character(72)   :: site_name                            ! site name
character(4)    :: pref_units,id_status,dep_env         ! pref_units, id_status
character(4)    :: xst_level(maxsamples)                ! xst_level (influx, concentration, etc.) 
character(4)    :: conc_source(maxsamples)              ! source of concentration data  
character(4)    :: influx_source(maxsamples)            ! source of influx data    
character(4)    :: conc2_source(maxsamples)             ! source of concentration plus other data    
character(4)    :: influx2_source(maxsamples)           ! source of influx plus other data    
  

integer         :: i,j,outflag,sedrateflag,maxnsamples
character(256)  :: csvpath,infile,sitelist,xstfile,debugfile
character(4)    :: site_num_char
character(80)   :: dum
character(32)   :: int_to_string2

infile="e:\Projects\igbpfire\charsum\data\current_hs6\files\HS_6a_samples.txt"
csvpath="e:\Projects\igbpfire\charsum\data\current_hs6\sites\site_csv\"
sitelist="e:\Projects\igbpfire\charsum\data\current_hs6\files\HS_6b_sites.txt"
xstfile="e:\Projects\igbpfire\charsum\data\current_hs6\files\HS_6b_xst.csv"
debugfile="e:\Projects\igbpfire\charsum\data\current_hs6\files\HS_6b_debug.dat"

miss=-9999.0
maxnsamples=0

! open the input data set, and count number of sites and number of samples for each site
write (*,'(a)') "Counting number of sites, and samples..."
open (1,file=infile)
open (10,file=debugfile)
open (4,file=xstfile)

i=0; j=1
read (1,*) site_num_in  ! read first record
current=site_num_in
do while (.not.eof(1))
    read (1,*) site_num_in ! read next record
    if (site_num_in .eq. current) then 
        ! same site
        i=i+1
    else
        ! new site
        site_num(j)=current
        nsamples(j)=i+1
        current=site_num_in
        !write (*,*) j,site_num(j),nsamples(j)
        i=0
        j=j+1
    end if
end do
nsites=j; site_num(j)=current; nsamples(j)=i+1
!write (*,*) j,site_num(j),nsamples(j)
!write (*,'("nsites=",i5)') nsites
write (4,'("site_num,xst_level,conc_source,influx_source,conc2_source,influx2_source,sedrateflag,site_name")')

open (2,file=sitelist)

! read the data again, and write individual .csv files
rewind(1)   ! rewind the input file

do j=1,nsites   ! loop over the sites

    ! read the data for the j-th site
    depth=miss; age=miss; quant=miss; conc=miss; influx=miss
    do i=1,nsamples(j)
        read (1,*) site_num_in,pref_units,id_sample(i),depth(i),age(i),quant(i),id_status,dep_env,xst_level(i)    
        !write (*,*) site_num_in,pref_units,id_sample(i),depth(i),age(i),quant(i),id_status,dep_env,xst_level(i)    
    end do
    if (nsamples(j).gt.maxnsamples) maxnsamples=nsamples(j)
    
    ! also read the sitelist file
    read (2,*) sitenum2,site_name
    write (10,'(4i5,1x,a72)') j,sitenum2,site_num(j)
    !write (*,'(2i5,1x,a72)') j,site_num(j),site_name
    
    !write (*,*) j,site_num(j),site_num_in
    if (site_num(j).ne.site_num_in) stop "site_num problem"
    
    !write (*,*) j,site_num(j),depth(1)
    
    ! sample thickness, sed rate, and unit_dep_time -- used to convert quantities
    thickness=miss; dep_time=miss; sed_rate=miss; unit_dep_time=miss
    ! check for missing sed rates
    
    ! fixups for first (top) sample
    if (depth(1).ne.miss .and. depth(2).ne.miss) then
        thickness(1)=(depth(2)-depth(1))*100.0 ! depths are in meters, concentrations and influx in cm
        dep_time(1)=age(2)-age(1)
        if (dep_time(1).gt.0.0) sed_rate(1)=thickness(1)/dep_time(1)
        if (sed_rate(1).ne.miss) unit_dep_time(1)=1.0/sed_rate(1)
    end if 
    do i=2,nsamples(j)-1
        if (depth(i).ne.miss .and. depth(i+1).ne.miss) then 
            thickness(i)=(depth(i+1)-depth(i))*100.0
            dep_time(i)=((age(i+1)+age(i))/2.0)-((age(i)+age(i-1))/2.0)  ! no ages should be missing
            if (dep_time(i).gt.0.0) sed_rate(i)=thickness(i)/dep_time(i)
            if (sed_rate(i).ne.miss) unit_dep_time(i)=1.0/sed_rate(i)           
        end if     
    end do
    ! fixups for last (bottom) sample
    if (depth(nsamples(j)).ne.miss .and. depth(nsamples(j)-1).ne.miss) then
        thickness(nsamples(j))=thickness(nsamples(j)-1)
        dep_time(nsamples(j))=age(nsamples(j))-age(nsamples(j)-1)
        sed_rate(nsamples(j))=sed_rate(nsamples(j)-1)
        unit_dep_time(nsamples(j))=unit_dep_time(nsamples(j)-1)
    end if
    
    sedrateflag=1
    do i=1,nsamples(j)
        if (sed_rate(i).eq.miss) sedrateflag=0
    end do
    
    
    write (*,'(i3,1x,i3,1x,i2,1x,a72)') j,site_num(j),sedrateflag,site_name
    
    ! calculate alternative quantities
    influx_source="none"; conc_source="none"; influx2_source="none"; conc2_source="none"
    
    !if (sedrateflag.eq.1) then
        
        select case (xst_level(1))
            case ("INFL") ! quant is influx, calculate concentration               
                do i=1,nsamples(j)
                    influx(i)=quant(i)
                    influx_source(i)="data"
                    influx2(i)=influx(i)
                    influx2_source(i)=influx_source(i)
                    if (unit_dep_time(i).ne.miss .and. sed_rate(i).ne.0.0) then
                        conc(i)=influx(i)*unit_dep_time(i)
                        conc_source(i)="infl"
                    end if
                    conc2(i)=conc(i)
                    conc2_source(i)=conc_source(i)
                end do    
                if (sedrateflag.eq.0) then
                    do i=1,nsamples(j)
                        conc2(i)=quant(i)
                        conc2_source(i)="copy"
                    end do
                end if       
            case ("CONC") ! quant is conc, calculate influx               
                do i=1,nsamples(j)                  
                    conc(i)=quant(i)
                    conc_source(i)="data"
                    conc2(i)=conc(i)
                    conc2_source(i)=conc_source(i)
                    if (sed_rate(i).ne.miss .and. sed_rate(i).ne.0.0) then
                        influx(i)=conc(i)*sed_rate(i)
                        influx_source(i)="conc"
                    end if
                    influx2(i)=influx(i)
                    influx2_source(i)=influx_source(i)
                end do        
                if (sedrateflag.eq.0) then
                    do i=1,nsamples(j)
                        influx2(i)=quant(i)
                        influx2_source(i)="copy"
                    end do
                end if
            case ("C0P0") ! C0P0 assume quantity is concentration-like         
                do i=1,nsamples(j)
                    conc(i)=quant(i)
                    conc_source(i)="c0p0"
                    conc2(i)=conc(i)
                    conc2_source(i)=conc_source(i)
                    if (sed_rate(i).ne.miss .and. sed_rate(i).ne.0.0) then
                        influx(i)=quant(i)*sed_rate(i)
                        influx_source(i)="c0p0"
                    end if
                    influx2(i)=influx(i)
                    influx2_source(i)=influx_source(i)                   
                end do  
                if (sedrateflag.eq.0) then
                    do i=1,nsamples(i)
                        influx2(i)=quant(i)
                        influx2_source(i)="copy"
                    end do
                end if
            case ("OTHE") ! just copy           
                do i=1,nsamples(j)               
                    conc2(i)=quant(i)
                    conc2_source(i)="copy"
                    influx2(i)=quant(i)
                    influx2_source(i)="copy"                 
                end do   
            case default
                stop "xst" 
        end select
    
    write (4,'(i4,",",5("""",a4,"""",","),i2,", ",a72)') &
        site_num(j),xst_level(1),conc_source(1),influx_source(1),conc2_source(1),influx2_source(1),sedrateflag,(adjustl(site_name))
                            
    ! create the .csv file for j-th site and write out data
    site_num_char=int_to_string2(site_num(j),4)
    open (3,file=trim(csvpath)//trim(adjustl(site_num_char))//"_data.csv")
    ! first column label is site number:
    write (3,'(a)') "site"//site_num_char//",id_sample,depth,est_age,sed_rate,quant,conc,influx," &
        //"conc2,influx2,xst_level,conc_source,influx_source,conc2_source,influx2_source"
    do i=1,nsamples(j)
        write (3,'(i4,",",i8,",",f10.4,",",f10.3,", ",f10.3,5(", ",f15.3),5(","1x,"""",a4,""""))') &
            i,id_sample(i),depth(i),age(i),sed_rate(i),quant(i),conc(i),influx(i),conc2(i),influx2(i), &
            xst_level(i),conc_source(i),influx_source(i),conc2_source(i),influx2_source(i)
    end do
    close(3)     
    
end do

write (*,'("nsites, maxnsamples: ",2i6)') nsites,maxnsamples

end program make_csv

function int_to_string(inum)

	implicit none
	character(32)	:: int_to_string
	character(32)	:: buffer, str
	integer			:: inum

	write (buffer,*) inum
	read (buffer,*) str

	int_to_string=trim(adjustl(str))

end function int_to_string

        
function int_to_string2(inum,numlen)

	implicit none
	character(32)	:: int_to_string,int_to_string2
	character(32)	:: buffer, str
	character(8)	:: ifmt,iedit
	integer			:: inum,numlen

	iedit=int_to_string(numlen)
	ifmt="(i"//trim(adjustl(iedit))//"."//trim(adjustl(iedit))//")"

	write (buffer,ifmt) inum
	read (buffer,*) str

	int_to_string2=trim(adjustl(str))

end function int_to_string2
  
    







            