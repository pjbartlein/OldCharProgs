program gaussian
! applies a gaussian filter

implicit none

integer, parameter  :: maxpts=20000, nf=101
real                :: varin(maxpts),varout(maxpts),rdate(maxpts)
real(8)             :: mu,sigma,pi,z,zmin,zstep,pdf(nf),wsum
integer             :: yr(maxpts),mon(maxpts)
integer             :: i,ii,npts,j,hww,ibeg,iend
character(1)        :: dum

!open (1,file="e:\Projects\igbpfire\hstick\data\ccsm\Bern2.5CC_bard25_volcCrow_CO2_nonCO2_1000-1998_ar4.dat")
!open (2,file="e:\Projects\igbpfire\hstick\data\ccsm\bern_annt.dat")
open (1,file="e:\Projects\igbpfire\hstick\data\ccsm\land_tmp_sextr_ann_anm.dat")
open (2,file="e:\Projects\igbpfire\hstick\data\ccsm\land_tmp_sextr_ann_anm_sm.dat")
open (10,file="e:\Projects\igbpfire\hstick\data\ccsm\debug.dat")

! parameters
mu=0.0d0; sigma=1.0d0; zmin=-4.0d0
zstep=(dabs(2.0*zmin)/dble(nf-1))
pi=3.14159265358979d0
hww=nf/2

! weights
do j=1,nf
    z=zmin+dble(j-1)*zstep
    pdf(j)=(1.0d0/dsqrt(2.0d0*pi*sigma**2.0d0))*dexp(-0.5d0*(z/sigma)**2.0d0)
    !write (*,*) j,z,pdf(j)
end do

! read data
read (1,*) dum
i=0
do while (.not. eof(1))
    i=i+1
    read (1,*) yr(i),varin(i)
    !read (1,*) rdate(i),varin(i)
end do
npts=i
close(1)

! smooth
varout=0.0
do i=1,npts
    ibeg=i-hww
    if (ibeg.lt.1) ibeg=1
    iend=i+hww
    if (iend.gt.npts) iend=npts
    !write (*,*) i,ibeg,iend

    wsum=0.0
    do ii=ibeg,iend
        j=nf-((i-ii)+hww)
        !write (*,*) i,ii,j,pdf(j)
        varout(i)=varout(i)+varin(ii)*pdf(j)
        wsum=wsum+pdf(j)       
    end do
    varout(i)=varout(i)/wsum
end do    

! write data
do i=1,npts
    !write (2,'(i4,f10.2,f10.3)') yr(i),varin(i),varout(i)
    write (2,'(i4,f10.3,f10.4)') yr(i),varin(i),varout(i)
    !write (2,'(i4,f10.3,f10.4)') int(rdate(i)),varin(i),varout(i)
end do
close (2)
    

end