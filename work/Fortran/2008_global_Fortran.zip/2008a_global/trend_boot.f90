program spline
real reg
character(1) sh

write (*,*) "Spline fit to CH4"

end