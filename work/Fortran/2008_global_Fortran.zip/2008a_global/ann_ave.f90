program ann_ave
! gets annual averages of charcoal data

implicit none

integer, parameter  :: maxdata=70000, maxsitedata=2500, maxsites=1000, maxtarg=3000, maxreps=2000
integer, parameter  :: begage=-55, endage=1949

integer(4)      :: site_sample,id_sample
real(4)         :: age,depth,influx2,influxmnx,tall,ztall,zt21k,zt4k,zt2k,year
real(4)         :: varin,varmiss
integer         :: site_num,usesitenum,usesite(maxsites)
character(16)   :: site_num_label,region,timeprefix,ww
character(4)    :: site_num_char
real(4)         :: xin(maxdata),yin(maxdata)

character(32)   :: vname
real(8)         :: xsite(maxsitedata,maxsites),ysite(maxsitedata,maxsites)
integer         :: nrecs(maxsites),idsite(maxsites),nsel(maxsites)

real(4)         :: ann(begage:endage)
integer         :: npts(begage:endage)

integer         :: i,j,k,ntot,jsite,nsites,ii,intype,iyr

character(32)   :: int_to_string2
character(256)  :: infilepath,infile,datapath,avecsvfile,regionfile
character(80)   :: header
character(1)    :: dum

vname="influx2"
region="nhemis"
timeprefix="zts"
intype=2

select case (intype)
    case (1)
        infilepath="\Projects\igbpfire\charsum\data\current_hs6\sites\trans_"//trim(adjustl(vname))//"_zts_csv\"
    case (2)
        infilepath="\Projects\igbpfire\charsum\data\current_hs6\sites\smooth_"//trim(adjustl(vname))// &
            "_"//trim(adjustl(timeprefix))//"_csv\"
end select
write (*,'(a80)') infilepath
datapath="\Projects\igbpfire\charsum\data\current_hs6\files\"
write (*,'(a80)') datapath

select case (intype)
    case (1)
        avecsvfile=trim(adjustl(timeprefix))//"_influx2_"//"ann_ave_"//trim(adjustl(region))//".csv"
    case (2)
        avecsvfile=trim(adjustl(timeprefix))//"_influx2_10_"//"_ann_ave_"//trim(adjustl(region))//".csv"
end select
regionfile="\Projects\igbpfire\charsum\data\current_hs6\sites\regions\"//trim(adjustl(region))//".csv"
write (*,'(a80)') avecsvfile
write (*,'(a80)') regionfile

open (7,file=trim(adjustl(datapath))//trim(adjustl(avecsvfile)))
open (8,file=regionfile) 

open (10,file=trim(adjustl(datapath))//"debug_boot.dat")
  
open (11,file=trim(adjustl(datapath))//"yfit_"//trim(adjustl(ww))//"_boot.dat")
select case (intype)
    case (1)
        write (7,'(a)') "age, year, npts,"//trim(adjustl(timeprefix))//"_influx2_ann_ave"
    case (2)
        write (7,'(a)') "age, year, npts,"//trim(adjustl(timeprefix))//"_influx2_10_ann_ave"
end select

varmiss=-9999.0

! read the region site file
usesite=0
read (8,*) header
do while (.not. eof(8))
    read (8,*) usesitenum
    !write (*,*) usesitenum
    usesite(usesitenum)=1
end do 
!write (*,*) usesite
!pause

! read data, store individual sites in array

nsel=0
jsite=0
xsite=0.0; ysite=0.0
do j=1,1000

    site_num_char=int_to_string2(j,4)
    
    ! try to open a file
    site_num_char=int_to_string2(j,4)   ! ############
    select case (intype)
        case (1)
            infile=trim(adjustl(infilepath))//trim(adjustl(site_num_char))//"_trans_"//trim(adjustl(vname))//"_zts.csv"
        case (2)
            infile=trim(adjustl(infilepath))//trim(adjustl(site_num_char))//"_smooth_"//trim(adjustl(vname))//"_"// &
                trim(adjustl(timeprefix))//"_sm10.csv"
    end select
    !write (*,'(a96)') infile
    open (1,file=infile, status='old', err=100)
    ! if site file exists:
    write (*,*) site_num_char
    if (usesite(j).eq.1) then    
        jsite=jsite+1
        idsite(jsite)=j    
           
        ! read data, and save age and variable to be smoothed
        read (1,*) header
        i=0
        do while (.not. eof(1))   ! ############
            select case (intype)
                case (1)
                    read (1,*) site_num_label,site_sample, id_sample, age, depth,  influxmnx, tall, ztall,  zt4k, zt2k
                        varin=zt2k
                case (2)
                    read (1,*) site_sample,age,varin
            end select

            if (age.le.endage .and. age.ge.begage .and. varin.ne.varmiss) then
                i=i+1
                xsite(i,jsite)=age
                ysite(i,jsite)=varin        
!                write (*,*) i,age,varin
            end if
        end do
        nrecs(jsite)=i
        close(1)
        
    end if
    
100 continue

end do
nsites=jsite
write (*,*) nsites

! concatenate sites -- no bootstrap
ii=0
do j=1,nsites
    write (*,*) j,nrecs(j)
    do i=1,nrecs(j)
        ii=ii+1
        xin(ii)=xsite(i,j)
        yin(ii)=ysite(i,j)
        ! write (*,*) j,ii,xin(ii),yin(ii)
    end do
end do
ntot=ii
write (*,*) ntot

! annual averages
ann=0.0; npts=0
do i=1,ntot
    ii=int(xin(i))
    ann(ii)=ann(ii)+yin(i)
    npts(ii)=npts(ii)+1
end do

do i=endage,begage,-1
    iyr=1950-i
    write (*,*) i,iyr,npts(i)
    if (npts(i).ne.0) then
        ann(i)=ann(i)/sngl(npts(i))
        write (7,'(3(i5,", "),f14.6)') i,iyr,npts(i),ann(i)
    else
        !write (7,'(3(i5,", "),f14.6)') i,iyr,npts(i),varmiss
    end if
end do

end

function int_to_string(inum)

	implicit none
	character(32)	:: int_to_string
	character(32)	:: buffer, str
	integer			:: inum

	write (buffer,*) inum
	read (buffer,*) str

	int_to_string=trim(adjustl(str))

end function int_to_string


function int_to_string2(inum,numlen)

	implicit none
	character(32)	:: int_to_string,int_to_string2
	character(32)	:: buffer, str
	character(8)	:: ifmt,iedit
	integer			:: inum,numlen

	iedit=int_to_string(numlen)
	ifmt="(i"//trim(adjustl(iedit))//"."//trim(adjustl(iedit))//")"

	write (buffer,ifmt) inum
	read (buffer,*) str

	int_to_string2=trim(adjustl(str))

end function int_to_string2
