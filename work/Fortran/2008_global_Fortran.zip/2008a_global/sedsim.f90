program sedsim
! simulates sedimentation and charcoal deposition

implicit none

integer, parameter  :: ny=1000, maxdep=500, ndw=500
real(4) :: tstep                ! time step (yr)
real(4) :: annsedinc            ! annual increment of sediment (solid + water) (cm)
real(4) :: annseddep(ny)        ! sediment deposited in i-th year (solid+water) (cm)
real(4) :: sedwaterprop         ! proportion of sediment that is water
real(4) :: seddep(ny)           ! solid sediment deposited in i-th year (cm)
real(4) :: sedwaterdep(ny)      ! sediment water deposited in i-th year (cm) 
real(4) :: sedwater(ny,ny)      ! in i-th year, sediment water deposited in j-th year still remaining  (cm)
real(4) :: sedthick(ny,ny)      ! in i-th year, thickness of sediment deposited in j-th year (cm)
real(4) :: totalsedthick(ny)    ! total thickness of sediment in i-th year
real(4) :: depth,seddepth(ny)   ! depth in sediment stack (cm)
real(4) :: sedrate(ny)          ! sedimentation rate (cm yr-1)

real(4) :: anncharinc           ! annual increment of charcoal deposition (pieces cm-2 yr-1)
real(4) :: annchardep(ny)       ! annual charcoal deposition (pieces cm-2 yr-1)
real(4) :: conc(ny)             ! charcoal concentration in i-th year (pieces cm-3)
real(4) :: influx(ny)           ! calculated charcoal influx (pieces cm-2 yr-1)

real(4) :: a_dw,b_dw            ! dewatering rate parameters
real(4) :: year(ny)

real(4) :: coredep(maxdep)      ! target depths in core (cm) 
real(4) :: coreage(maxdep)      ! interpolated age in core (yr)
real(4) :: coreconc(maxdep)     ! interpolated concentration in core (pieces cm-3)
real(4) :: corethick(maxdep)    ! thickness of sample (cm)
real(4) :: coredeptime(maxdep)  ! sample deposional time (yr)
real(4) :: coresedrate(maxdep)  ! sed rate in core
real(4) :: coreunitdt(maxdep)   ! unit dep time in core
real(4) :: coreinflux(maxdep)   ! influx in core

real(4) :: y(ndw),t(ndw)        ! dewatering curve 

integer :: i,j,ii,ns,rng1,rng2

open (1,file="e:\Projects\igbpfire\sedsim\data\annsed01.csv")
open (2,file="e:\Projects\igbpfire\sedsim\data\simsed01.csv")
open (3,file="e:\Projects\igbpfire\sedsim\data\core01.csv")
open (4,file="e:\Projects\igbpfire\sedsim\data\dewater.csv")

! initialize
seddep=0.0; sedwaterdep=0.0; sedwater=0.0; sedthick=0.0; totalsedthick=0.0; annseddep=0.0
tstep=1.0 ! yrs

! dewatering rate parameters
a_dw=1.0; b_dw=0.01

! sedimentation parameters
annsedinc=0.5 ! cm
sedwaterprop=0.60 ! proportion

! charcoal parameters
anncharinc=5.0 ! pieces cm-2 yr-1

! generate annual sed dep values
rng1=800
do i=1,rng1
    annseddep(i)=annsedinc
end do
do i=rng1+1,ny
    annseddep(i)=annsedinc-(sngl(i-rng1)/sngl(ny-rng1+1))*annsedinc
end do    

! generate annual charcoal deposition values
ii=0
do i=1,ny-150
    ii=ii+1
    annchardep(ii)=anncharinc 
end do
do i=1,150
    ii=ii+1
    annchardep(ii)=anncharinc-(sngl(i)/sngl(150))*anncharinc
end do

! begin
write (1,'(a)') "simyear,annseddep,sedthick,totalsedthick,annchardep"

do i=1,ny

    ! this year's deposition of sediment and water
    seddep(i)=(1.0-sedwaterprop)*annseddep(i)
    sedwaterdep(i)=sedwaterprop*annseddep(i)
    
    ! dewater 
    do j=1,i
        sedwater(i,j)=sedwaterdep(i)*(a_dw*exp(-1.0*b_dw*(sngl(i-j))))
        sedthick(i,j)=seddep(i)+sedwater(i,j)
    end do
    
    ! sed thickness
    totalsedthick(i)=0.0
    do j=1,i
        totalsedthick(i)=totalsedthick(i)+sedthick(i,j)
    end do
    
    write (1,'(i5,5(", ",f9.4))') i,annseddep(i),sedthick(i,i),totalsedthick(i),annchardep(i)
    !write (*,'(i5,1x,5(3f6.3,1x),2x,f6.3)') i,(seddep(i),sedwater(i,j),sedthick(i,j),j=1,5),totalsedthick(i)
    
end do

! sedrate, concentration, and influx
do i=1,ny

    ! sediment rate
    sedrate(i)=sedthick(ny,i)/tstep 
    
    ! charcoal concentration
    conc(i)=annchardep(i)/sedthick(ny,i)
    
    ! charcoal influx
    influx(i)=conc(i)*sedrate(i)  
    !write (*,*) i,sedrate(i) 
    
end do

depth=0.0
do i=ny,1,-1
    ii=ny-i+1
    year(i)=sngl(i)
       
    ! depth
    seddepth(i)=depth
    depth=depth+sedrate(i)
       
    !write (*,*) i,year(i),seddepth(i)
    !pause
end do

write (2,'(a)') "simyear,seddepth,totalsedthick,sedrate,annchardep,conc,influx"
do i=ny,1,-1
    write (2,'(f5.0,6(", ",f9.4))') year(i),seddepth(i),totalsedthick(i),sedrate(i),annchardep(i),conc(i),influx(i)
end do

! simulate a sample

! number of samples
ns=int(totalsedthick(ny))
write (*,*) ns
do i=1,ns
    coredep(i)=sngl(i-1)
    call vint(ny, coredep(i), seddepth, year,coreage(i))
    call vint(ny, coredep(i), seddepth, conc,coreconc(i))
    !write (*,*) i,coredep(i),coreage(i)
end do

! first sample
corethick(1)=(coredep(2)-coredep(1))
coredeptime(1)=-1.0*(coreage(2)-coreage(1))
if (coredeptime(1).gt.0.0) coresedrate(1)=corethick(1)/coredeptime(1)
coreunitdt(1)=1.0/coresedrate(1)
coreinflux(1)=coreconc(1)*coresedrate(1)
do i=2,ns       
    corethick(i)=(coredep(i+1)-coredep(i))
    coredeptime(i)=-1.0*(((coreage(i+1)+coreage(i))/2.0)-((coreage(i)+coreage(i-1))/2.0)) 
    if (coredeptime(i).gt.0.0) coresedrate(i)=corethick(i)/coredeptime(i)
    coreunitdt(i)=1.0/coresedrate(i) 
    coreinflux(i)=coreconc(i)*coresedrate(i)               
end do
! fixups for last (bottom) sample
corethick(ns)=corethick(ns-1)
coredeptime(ns)=coreage(ns-1)-coreage(ns)
coresedrate(ns)=coresedrate(ns-1)
coreunitdt(ns)=coreunitdt(ns-1)
coreinflux(ns)=coreinflux(ns-1)

write (3,'(a)') "i,coredep,coreage,corethick,coredeptime,coresedrate,coreconc,coreinflux"
do i=1,ns
    write (3,'(i6,", ",f5.0,8(", ",f9.4))') i,coredep(i),coreage(i),corethick(i),coredeptime(i),coresedrate(i),coreconc(i),coreinflux(i)
end do

! write dewatering curve
write (4,'(a)') "t,y"
do i=1,ndw
    t(i)=sngl(i)
    y(i)=(a_dw*exp(-1.0*b_dw*(t(i))))
    write (4,'(f5.0,", ",f7.4)') t(i),y(i)
end do

end
    
subroutine vint (n, vin, v1, v2, vout)
! simple interpolation -- control points are assumed to be in descending order

implicit none
integer, intent(in)		:: n			! number of points
real(4), intent(in)		:: v1(n),v2(n)	! control data
real(4), intent(in)		:: vin			! target value
real(4), intent(out)	:: vout			! interpolated value

real(4) prop
integer jl,ju,jm,j

if (vin.ge.v1(1)) then
	vout = v2(1)
elseif (vin.le.v1(n)) then
	vout = v2(n)
else
	jl = 0
	ju = n + 1
	do while (ju-jl.gt.1)
		jm = int((ju + jl)/2)
		if ((v1(n).gt.v1(1)).eqv.(vin.gt.v1(jm))) then
			jl = jm
		else
			ju = jm
		end if
	end do
	j = jl
	prop = (vin - v1(j)) / (v1(j + 1) - v1(j))
	vout = prop * v2(j + 1) + (1 - prop) * v2(j)
endif
!write (*,'(3f14.6)') vin,vout

end subroutine vint
    