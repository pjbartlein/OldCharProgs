module loquant

contains

subroutine quantile_curve(nctrl,xin,yin,ntarg,xt,param,np,yfit)

! manages computation of a quantile "curve"

    implicit none

    integer             :: nctrl,ntarg,minpts
    real(8)             :: xin(nctrl),yin(nctrl),xt(ntarg),param,yfit(ntarg)
    real(8)             :: xs(nctrl),ys(nctrl),targ,fitval
    real(8)             :: y,q0,q01,q05,q10,q25,q50,q75,q90,q95,q99,q100
    integer             :: n,np(nctrl),npfit(ntarg) 
    
    integer             :: i,ii,iii,j,k

    ! loop over target points, calling localfit for each target point
    yfit=0.0d0
    do ii=1,ntarg   
        n=0   
        do i=1,nctrl
            if (xin(i).ge.xt(ii)-param .and. xin(i).le.xt(ii)+param) then
                n=n+1
                ys(n)=yin(i)
            end if
        end do
        call quantiles(n,ys,q0,q01,q05,q10,q25,q50,q75,q90,q95,q99,q100)
        !write (10,'(i4,11f8.3)') n,q0,q01,q05,q10,q25,q50,q75,q90,q95,q99,q100
        np(ii)=n
        yfit(ii)=q50
    end do  
   
end subroutine quantile_curve


subroutine quantiles(n,y,q0,q01,q05,q10,q25,q50,q75,q90,q95,q99,q100)
! usual quantile values

    use lowess

    implicit none
    
    integer, parameter  :: nq=9
    integer     :: n
    real(8)     :: y(n),ys(n),p(n)
    real(8)     :: q0,q01,q05,q10,q25,q50,q75,q90,q95,q99,q100
    real(8)     :: pval(nq),q(nq)
    integer     :: i,k
    
    data pval/0.01d0,0.05d0,0.10d0,0.25d0,0.50d0,0.75d0,0.90d0,0.95d0,0.99d0/
    
    call sortx(n,y,ys)
    do k=1,n
        p(k)=float(k-1)/float(n-1)
        !write (*,'(i4,3f10.3)') k,y(k),ys(k),p(k)
    end do
    
    do i=1,nq
        q(i)=-9999.0
        if (n.ge.2) then
            do k=1,n-1
                if (pval(i).gt.p(k) .and. pval(i).le.p(k+1)) exit
            end do
            q(i)=ys(k)+(ys(k+1)-ys(k))*(pval(i)-p(k))/(p(k+1)-p(k))
        else
            q(i)=ys(1)
        end if
        !write (*,'(i2,2f10.3)') i,pval(i),q(i)
    end do
    q0=ys(1); q01=q(1); q05=q(2); q10=q(3); q25=q(4); q50=q(5); q75=q(6); q90=q(7); q95=q(8); q99=q(9); q100=ys(n)
    
end subroutine quantiles



end module loquant