program lowess_boot
! fits a smooth lowess-type curve time-series data
! gets bootstrap estimates of confidence intervals of lowess curve

use lowess
use ifport

implicit none

integer, parameter  :: maxdata=100000, maxtarg=10000, maxreps=1000

real(4)         :: a,b,c,d,e,f,g,h,p
real(4)         :: rdatein,varin,var(maxdata),realdate(maxdata),varmiss

real(8)         :: xin(maxdata),yin(maxdata)

real(4)         :: begyr,endyr
real(8)         :: xtarg(maxtarg),yfit(maxtarg),yfitse(maxtarg),fit_cu95(maxtarg),fit_cl95(maxtarg),ypredse(maxtarg)
real(8)         :: param,xspan(maxtarg)
real(8)         :: targbeg,targend,targstep
integer(4)      :: npfit(maxtarg),minpts,order,nrobust,ntarg,nnum
character(1)    :: wintype

real(8)         :: ranseed,randval
real(8)         :: yfit_reps(maxtarg,maxreps),temp(maxreps),sorttemp(maxreps)
real(8)         :: yfit_boot(maxtarg),yfit_boot_median(maxtarg),yfit_boot_stdev(maxtarg),yfit_boot_se(maxtarg)
real(8)         :: yfit_boot_cu95(maxtarg),yfit_boot_cl95(maxtarg)
integer         :: jsel(maxdata,maxreps),jmax,jmin,ncl95,ncu95,n50

integer         :: i,j,k,npts,nctrl,jsite,nsites,ii,nreps

character(256)  :: infilepath,infile,outfilepath,outfile,debugfile
character(80)   :: header
character(1)    :: dum
character(8)    :: variable,region,atype

!infilepath="e:\Projects\igbpfire\hstick\tseries\ipcc_ch6\source\"
!outfilepath="e:\Projects\igbpfire\hstick\tseries\ipcc_ch6\source\"
!infile= "fig6.10b_ave_b.csv"
!outfile="fig6.10b_ave_b_low50_boot.csv"

!infilepath="e:\Projects\paleovar\data\Cariaco\"
!outfilepath="e:\Projects\paleovar\data\Cariaco\"
!infile= "cariaco_ti.csv"
!outfile="cariaco_ti_500_boot.csv"

!infilepath="e:\Projects\igbpfire\hstick\tseries\ipcc_ch6\"
!outfilepath="e:\Projects\igbpfire\hstick\tseries\ipcc_ch6\"
!infile= "fig610_maxover.csv"
!outfile="fig610_maxover_low50_boot.csv"

!infilepath="e:\Projects\igbpfire\hstick\figs\fig01\"
!outfilepath="e:\Projects\igbpfire\hstick\figs\fig01\"
!infile= "mj2003sh.csv"
!outfile="mj2003sh_low50_boot.csv"

!infilepath="e:\Projects\igbpfire\hstick\figs\fig_suppl\"
!outfilepath="e:\Projects\igbpfire\hstick\figs\fig_suppl\"
!outfilepath="e:\Projects\GPWG\projects\wus\figs\"
!infile= "jm4a_wus.csv"
!outfile="jm4a_wus_low_boot_100.csv"

!infilepath="e:\Projects\igbpfire\charsum\data\current_hs6\files\"
!outfilepath="e:\Projects\igbpfire\charsum\data\current_hs6\files\"
!infile= "ferretti.csv"
!outfile="ferretti_low_boot.csv"

!infilepath="e:\Projects\igbpfire\hstick\tseries\jonesmann\"
!outfilepath="e:\Projects\igbpfire\hstick\tseries\jonesmann\"
!infile= "jm_sh.csv"
!outfile="jm_sh_low_boot.csv"

!variable="tmp"; region="WNA"; atype="mxn"
!infilepath="e:\Projects\igbpfire\hstick\data\ccsm\"
!outfilepath="e:\Projects\igbpfire\hstick\data\ccsm\"
!infile= "land_"//trim(adjustl(variable))//"_"//trim(adjustl(region))//"_"//trim(adjustl(atype))//"_anm.dat"
!outfile="land_"//trim(adjustl(variable))//"_"//trim(adjustl(region))//"_"//trim(adjustl(atype))//"_anm_low100_boot.csv"
!write (*,*) infile

!infilepath="e:\Projects\igbpfire\hstick\data\ccsm\"
!outfilepath="e:\Projects\igbpfire\hstick\data\ccsm\"
!infile= "VolcanicForcing_Global.dat"
!outfile="VF_low_boot.csv"

!infilepath="e:\Projects\igbpfire\hstick\tseries\jonesmann\source\"
!outfilepath="e:\Projects\igbpfire\hstick\tseries\jonesmann\source\"
!infile= "mj2003gl.csv"
!outfile="mj2003gl_low_boot.csv"

!infilepath="e:\Projects\igbpfire\hstick\tseries\samer_ice\"
!outfilepath="e:\Projects\igbpfire\hstick\tseries\samer_ice\"
!infile= "q83o18.csv"
!outfile="q83o18_100.csv"

!infilepath="e:\Projects\igbpfire\hstick\tseries\misc\"
!outfilepath="e:\Projects\igbpfire\hstick\tseries\misc\"
!infile= "gisp2_d18O_20.csv"
!outfile="gisp2_d18O_100_boot.csv"

!infilepath="e:\Projects\paleovar\data\EDC\"
!outfilepath=infilepath
!infile= "edc3temp2007.csv"
!outfile="edc3temp2007_500_boot.csv"

!infilepath="e:\Projects\paleovar\data\NGRIP\"
!outfilepath=infilepath
!infile= "NGRIP_WC.csv"
!outfile="NGRIP_WC_200.csv"

!infilepath="e:\Projects\paleovar\data\EDC\"
!outfilepath=infilepath
!infile= "edc3deut2007.csv"
!outfile="edc3deut2007_250.csv"

!infilepath="e:\Projects\GPWG\work\global\figs\controls\"
!outfilepath=infilepath
!infile="ngrip-gicc05-60ka-20yr.csv"
!outfile="ngrip-gicc05-60ka-20yr_boot_500.csv"

!infilepath="e:\Projects\paleovar\data\EDC\"
!outfilepath=infilepath
!infile="edc-co2-2008.csv"
!outfile="edc-co2-2008_500_boot.csv"

!infilepath="e:\Projects\paleovar\data\EDC\"
!outfilepath=infilepath
!infile="edc-ch4-2008.csv"
!outfile="edc-ch4-2008_500_boot.csv"

!infilepath="e:\Projects\paleovar\data\GISP2\"
!outfilepath=infilepath
!infile="gisp2-ch4.csv"
!outfile="gisp2-ch4_250_boot.csv"

infilepath="e:\Projects\paleovar\data\Quelccaya\"
outfilepath=infilepath
infile="qeulccaya_d18O.csv"
outfile="qeulccaya_d18O_500_boot.csv"

debugfile=trim(adjustl(outfilepath))//"debug_lowess.dat"

open (2,file=trim(adjustl(infilepath))//trim(adjustl(infile)))
open (3,file=trim(adjustl(outfilepath))//trim(adjustl(outfile)))
open (10,file=trim(adjustl(debugfile)))

write (3,'(a)') "targ_age_BP1950,  ts_500, sefit, fitcu95, fitcl95, np, "// &
  "ts_500_boot, yfit_boot_median, yfit_boot_se, yfit_boot_cu95, yfit_boot_cl95, xspan"   ! ############

! lowess parameters
param=500.0d0; wintype='w'; minpts=10; order=1; nrobust=1     ! ############

! target point definitions
targbeg=-60.0d0; targend=1480.0d0; targstep=20.0d0
!targbeg=-30.0d0; targend=122300.0d0; targstep=20.0d0
!targbeg=-60.0d0; targend=122300.0d0; targstep=20.0d0

! overall age range of data
begyr=-60.0; endyr=122280.0

! number of bootstrap samples
nreps=1000

! random number seed
call srand(100)

! generate target points
ntarg=int((targend-targbeg)/targstep)+1
write (*,*) param,targstep,ntarg,order,nrobust,wintype
do i=ntarg,1,-1
    xtarg(i)=targbeg+dble(i-1)*targstep !targend-dble(i-1)*targstep
    !write (*,*) i,sngl(xtarg(i))
end do

varmiss=-9999.0

! read data
read (2,*) header
write (*,*) header
i=0
do while (.not. eof(2))
    read (2,*) a,b,c, d,e,f,g,h,p
    rdatein=p
    varin=f ! b !c ! d
    if (rdatein.ge.begyr .and. rdatein.le.endyr) then
        i=i+1
        realdate(i)=rdatein
        var(i)=varin
        !write(*,*) i,realdate(i),var(i)
        !pause
    end if
end do
npts=i
close(2)

! bootstrap sampling and fitting

yfit_reps=0.0d0
!nreps=10

do k=1,nreps
    jmax=-99999; jmin=99999
    ii=0
    do j=1,npts

        ! select a point at random
        randval=rand(0)
        jsel(j,k)=int(randval*sngl(npts))+1
        if (jmax.lt.jsel(j,k)) jmax=jsel(j,k)
        if (jmin.gt.jsel(j,k)) jmin=jsel(j,k)
        !jsel(j,k)=j       
        
        ii=ii+1
        xin(ii)=realdate(jsel(j,k))
        yin(ii)=var(jsel(j,k))
        !write (2,'(4i6,2f14.6)') ii,j,idsite(jsel(j,k)),i,xin(ii),yin(ii)
    end do
    nctrl=ii
    
    !write (*,*) k,npts,ntarg
    if (mod(k,10).eq.0) write (*,'(i5,\)') k
    yfit=0.0d0; yfitse=0.0d0; fit_cu95=0.0d0; fit_cl95=0.0d0
    call lowess_curve(npts,xin,yin,ntarg,xtarg,wintype,param,minpts,order,nrobust,yfit,yfitse,ypredse,npfit,xspan)

    
    ! save fitted values
    do i=1,ntarg
        yfit_reps(i,k)=yfit(i)
    end do
       
end do

200 continue

! one more fit to get standard (unresampled) values
ii=0
do j=1,npts
    ii=ii+1
    xin(ii)=realdate(j)
    yin(ii)=var(j)
end do
nctrl=ii
    
write (*,*) npts,ntarg
yfit=0.0d0; yfitse=0.0d0; fit_cu95=0.0d0; fit_cl95=0.0d0
call lowess_curve(npts,xin,yin,ntarg,xtarg,wintype,param,minpts,order,nrobust,yfit,yfitse,ypredse,npfit,xspan)

do i=1,ntarg
    if (.not. isnan(yfit(i))) then
        fit_cu95(i)=yfit(i)+2.0d0*yfitse(i)
        fit_cl95(i)=yfit(i)-2.0d0*yfitse(i)
    end if
end do

! get bootstrap estimates

ncl95=int(sngl(nreps)*0.025)
if (ncl95.le.0) ncl95=1
ncu95=int(sngl(nreps)*0.975)
if (ncu95.ge.nreps) ncu95=nreps
n50=int(sngl(nreps)/2.0)
write (*,*) ncl95,ncu95,n50

yfit_boot=0.0d0; yfit_boot_stdev=0.0d0; yfit_boot_se=0.0d0; yfit_boot_cu95=0.0d0; yfit_boot_cl95=0.0d0
do i=1,ntarg
    nnum=0
    do k=1,nreps
        if (.not. isnan(yfit_reps(i,k))) then
            yfit_boot(i)=yfit_boot(i)+yfit_reps(i,k)
            nnum=nnum+1
            !write (*,*) i,k,yfit_boot(i),yfit_reps(i,k)
        end if
    end do
    if (nnum.gt.0) yfit_boot(i)=yfit_boot(i)/dble(nnum)
    !write (*,*) i,yfit_boot(i)
    nnum=0
    do k=1,nreps
        if (.not. isnan(yfit_reps(i,k))) then
            yfit_boot_stdev(i)=yfit_boot_stdev(i)+(yfit_reps(i,k)-yfit_boot(i))*(yfit_reps(i,k)-yfit_boot(i))
            nnum=nnum+1
            !write (*,*) i,k,yfit_reps(i,k),yfit_boot_stdev(i)
        end if
    end do
    !write (*,*) i,yfit_boot_stdev(i)
    if (nnum.gt.1) yfit_boot_stdev(i)=dsqrt(yfit_boot_stdev(i)/dble(nreps-1))
    if (nnum.gt.0) yfit_boot_se(i)=yfit_boot_stdev(i)/dsqrt(dble(nreps))
    !write (*,*) i,yfit_boot_stdev(i),yfit_boot_se(i)
    temp(:)=yfit_reps(i,:)
    call sortx(nreps,temp,sorttemp)
    yfit_boot_cu95(i)=sorttemp(ncu95)
    yfit_boot_cl95(i)=sorttemp(ncl95)
    yfit_boot_median(i)=sorttemp(n50)
    
    write (3,'(f10.2,4(",",f14.6),", ",i8,5(",",f14.6),",",f10.2)') & 
        xtarg(i),yfit(i),yfitse(i),fit_cu95(i),fit_cl95(i),npfit(i), &
        yfit_boot(i),yfit_boot_median(i),yfit_boot_se(i),yfit_boot_cu95(i),yfit_boot_cl95(i),xspan(i)
    
    !pause
  
end do
    
end

