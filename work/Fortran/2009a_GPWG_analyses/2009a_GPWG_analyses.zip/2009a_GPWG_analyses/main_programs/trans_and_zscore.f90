program trans_and_zscore
! transforms and z-scores of individual charcoal records

use summarize_subs
use ifport

implicit none

integer(4)      :: site_sample(maxdata)
integer(8)      :: id_sample(maxdata)
real(4)         :: depth(maxdata),age(maxdata),var(maxdata),varmnx(maxdata)
real(4)         :: tall(maxdata)
real(4)         :: zt(maxdata)
real(4)         :: sedrate_in,quant_in,conc_in,influx_in
real(4)         :: vartemp(maxdata),varmiss

real(4)         :: begbase,endbase,begbase_all,endbase_all
real(4)         :: firstyr,lastyr

real(4)         :: lambda_all,shift_all,lhmax_all
real(4)         :: vmean_all,vstdev_all,vmin_all,vmax_all,vrng_all
real(4)         :: vmean,vstdev,vmin,vmax,vrng

integer(4)      :: i,j,npts,npts_all,npts_base

character(4)    :: source(maxdata)
character(64)    :: quant_source_in,conc_source_in,influx_source_in

character(4)    :: site_num_char
character(8)    :: site_num_label
character(256)  :: datapath,transpath,statspath,lambdafile,debugfile,statsfile,infofile,outfile,baseperiodfile
character(16)   :: queryname,varname,ztname

integer             :: pathlen
character(3)        :: drive
character(256)      :: dir,name,ext,file
logical             :: fileexists, direxists, fileresult

! read the info file
call get_command_argument(1,infofile)
open (99,file=trim(adjustl(infofile)))
    read (99,*) datapath
    read (99,*) transpath
    read (99,*) statspath
    read (99,*) debugfile
    read (99,*) queryname
    read (99,*) varname
    read (99,*) baseperiodfile
close (99)

! check for existence of input data path (.csv files)
pathlen=splitpathqq(datapath, drive, dir, name, ext)
inquire (directory=dir, exist=direxists)
if (.not. direxists) stop "Input .csv file directory does not exist, or is specified wrong, stopping..."

! check for existence of an output .csv folder
pathlen=splitpathqq(transpath, drive, dir, name, ext)
inquire (directory=dir, exist=direxists)
if (.not. direxists) then
    write (*,'(a)') "Output folder for transformed .csv files does not exist, creating..."
    fileresult=makedirqq(dir)
end if

! check for existence of an output stats folder
pathlen=splitpathqq(statspath, drive, dir, name, ext)
inquire (directory=dir, exist=direxists)
if (.not. direxists) then
    write (*,'(a)') "Output folder for transformation statistics does not exist, creating..."
    fileresult=makedirqq(dir)
end if

lambdafile=trim(adjustl(statspath))//trim(adjustl(queryname))//"_"//trim(adjustl(varname))//"_lambda.dat"
open (3,file=lambdafile)
write (3,'(a)') "site, npts, npts_all, lambda_all, shift_all, lhmax_all"

statsfile=trim(adjustl(statspath))//trim(adjustl(queryname))//"_"//trim(adjustl(varname))//"_stats.dat"
open (9,file=statsfile)

! debug file folder
pathlen=splitpathqq(debugfile, drive, dir, name, ext)
inquire (directory=dir, exist=direxists)
if (.not. direxists) then
    write (*,'(a)') "debugfile directory does not exist, creating..."
    fileresult=makedirqq(dir)
end if
open (10,file=debugfile)

! check for existence of baseperiod file
inquire (file=baseperiodfile, exist=fileexists)
if (.not. fileexists) stop "baseperiod file does not exist, stopping..." 
open (8,file=baseperiodfile)

read (8,*) ztname
read (8,*) begbase
read (8,*) endbase

varmiss=-9999.0 
shift_all=0.01

do j=1,maxsites
    ! try to open a file
    site_num_char=int_to_string2(j,4)
    open (1,file=trim(datapath)//trim(adjustl(site_num_char))//"_data.csv", status='old', err=100)
    outfile=trim(transpath)//trim(adjustl(site_num_char))//"_trans_"//trim(adjustl(varname))//"_"//trim(adjustl(ztname))//".csv"
    write (*,'(a)') outfile
    open (2,file=outfile)
    write (2,'(a)') "site, site_sample, id_sample, est_age, depth, "//trim(adjustl(varname))//", "//trim(adjustl(varname))//"mnx, tall, " &
        //trim(adjustl(ztname))
    
    read (1,*) site_num_label
    
    ! initialize 
    depth=0.0; age=0.0; var=varmiss; varmnx=varmiss
    vmean=varmiss; vstdev=varmiss; vmin=varmiss; vmax=varmiss; vrng=varmiss
    npts_all=0; tall=varmiss; lambda_all=-9.0; lhmax_all=-99999.0
    vmean_all=varmiss; vstdev_all=varmiss; vmin_all=varmiss; vmax_all=varmiss; vrng_all=varmiss
    zt=varmiss
 
    i=0
    lastyr=-99999.0; firstyr=99999.0
    do while (.not. eof(1))
        i=i+1
        read (1,*) site_sample(i),id_sample(i),depth(i),age(i),sedrate_in,quant_in,conc_in,influx_in
        select case (varname)
            case ("quant")
                var(i)=quant_in
            case ("conc")
                var(i)=conc_in
            case ("influx")
                var(i)=influx_in
        end select
        if (age(i).gt.lastyr) lastyr=age(i)
        if (age(i).lt.firstyr) firstyr=age(i)
        if (var(i).eq.varmiss) then
            write (*,*) j,i,age(i),var(i)
            write (10,*) j,i,age(i),var(i)
        end if
    end do
    npts=i
    
    write (*,*) lastyr,firstyr
    begbase_all=firstyr; endbase_all=lastyr
    
    write (10,'(i5,1x,a4,1x,a8,1x,i4,2f10.2)') j,site_num_char,site_num_label,npts,firstyr,lastyr
    write (*,'(i5,1x,a4,1x,a8,1x,i4,2f10.2)') j,site_num_char,site_num_label,npts,firstyr,lastyr
    
    ! transformations -- NOTE:  one transformation, all data (z-scores are still separate)
    
    ! stats for whole record
    call stats(npts,age,var,varmiss,begbase_all,endbase_all,npts_all,vmean_all,vstdev_all,vmin_all,vmax_all,vrng_all)

    ! qmnx -- minimax transformation of var for whole record
    call minimax(npts,var,varmiss,vmin_all,vmax_all,varmnx)
    
    ! Box-Cox transformation -- whole record
    call boxcox_lambda(npts,var,varmiss,shift_all,lambda_all,lhmax_all)    
    ! transform record with whole-record parameters
    call boxcox_trans(npts,lambda_all,shift_all,var,varmiss,vartemp)
    ! minimax of transformed data using whole record parameters
    call stats(npts,age,vartemp,varmiss,begbase_all,endbase_all,npts_all,vmean_all,vstdev_all,vmin_all,vmax_all,vrng_all)
    write (9,'(i6,2f9.2,i6,2f14.4)') npts,firstyr,lastyr,npts_all,vmean_all,vstdev_all
    
    ! minimax rescaling, whole record
    call minimax(npts,vartemp,varmiss,vmin_all,vmax_all,tall)
    
    ! z-scores for the specified base period
    call stats(npts,age,vartemp,varmiss,begbase,endbase,npts_base,vmean,vstdev,vmin,vmax,vrng)
    call zscores(npts,vartemp,varmiss,vmean,vstdev,zt)
    write (9,'(i6,2f9.2,i6,2f14.4)') npts_base,begbase,endbase,npts,vmean,vstdev
    
    do i=1,npts
        write (2,'(a8,",",i8,",",i10,",",f10.2,",",f10.2,9(",",g12.6),", ","""",a4,"""" )') &
            site_num_label,site_sample(i),id_sample(i),age(i),depth(i),var(i),varmnx(i), &
            tall(i),zt(i)
    end do
    
    write (3,'(a8,1x,i5,1x,3(i5,2f8.2,f10.2))') &
        site_num_label,npts,npts_all,lambda_all,shift_all,lhmax_all
            
    close(1)
    close(2)
   
100 continue
    
end do

end


