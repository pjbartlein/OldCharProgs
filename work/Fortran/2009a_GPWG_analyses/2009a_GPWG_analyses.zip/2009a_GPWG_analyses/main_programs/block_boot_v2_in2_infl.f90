program block_boot_v2_in2_infl
! gets block statistics and bootstrap CI's for transformed and standardized charcoal data

use block_stats
use ifport

implicit none

integer, parameter  :: maxdata=100000, maxsitedata=9000, maxsites=2000, maxblocks=30, maxreps=2000, nparam=4

integer(4)      :: site_sample
integer(8)      :: id_sample
real(4)         :: age,depth,influx2,influx2mnx,tall,ztall,zt21k,zt4k,zt2k,ztpi2,ztpi4
real(4)         :: conc2,conc2mnx,zt15132k,zt132k,zt40k,zt1583k

real(4)         :: varin,varmiss
integer         :: site_num,usesitenum,usesite(maxsites)
character(16)   :: site_num_label,timeprefix,ww
character(4)    :: site_num_char

character(32)   :: vname

real(8)         :: blkbeg(maxblocks),blkend(maxblocks)
real(8)         :: xsite(maxsitedata,maxsites),ysite(maxsitedata,maxsites)
integer         :: nrecs(maxsites),idsite(maxsites),nsel(maxsites)

real(8)         :: xin(maxdata),yin(maxdata)

real(8)         :: meanblk(maxblocks),medianblk(maxblocks),q90blk(maxblocks),q75blk(maxblocks)
real(8)         :: q25blk(maxblocks),q10blk(maxblocks),stddevblk(maxblocks),iqrblk(maxblocks)
integer         :: npblk(maxblocks)

real(8)         :: meanrep(maxreps,maxblocks),medianrep(maxreps,maxblocks),q90rep(maxreps,maxblocks),q75rep(maxreps,maxblocks)
real(8)         :: q25rep(maxreps,maxblocks),q10rep(maxreps,maxblocks),stddevrep(maxreps,maxblocks),iqrrep(maxreps,maxblocks)
integer         :: nprep(maxreps,maxblocks)

real(8)         :: meanout(nparam,maxblocks),medianout(nparam,maxblocks),q90out(nparam,maxblocks),q75out(nparam,maxblocks)
real(8)         :: q25out(nparam,maxblocks),q10out(nparam,maxblocks),stddevout(nparam,maxblocks),iqrout(nparam,maxblocks)
integer         :: npout(nparam,maxblocks)

real(4)         :: begyr,endyr

real(8)         :: ranseed,randval
integer         :: jsel(maxsites,maxreps),jmax,jmin

real(8)         :: q0,q01,q05,q10,q25,q50,q75,q90,q95,q99,q100

integer         :: i,j,k,m,n,npts,nctrl,jsite,nsites,ii,nreps,intype,nblks

character(32)   :: int_to_string2,int_to_string
character(256)  :: infofile,blkname(maxblocks)
character(256)  :: infilepath,infile,outpath,outcsvfile,plotcsvfile
character(256)  :: region,regionpath,regionfile,blocks,blockfile
character(16)   :: query, sww

character(80)   :: header
character(1)    :: dum

logical         :: yfitnan,nan 

! read the info file
call get_command_argument(1,infofile)
open (99,file=trim(adjustl(infofile)))

do while (.not. eof(99))
    read (99,*) infilepath
    read (99,*) outpath
    read (99,*) regionpath
    read (99,*) region
    read (99,*) blocks

regionfile=trim(adjustl(regionpath))//trim(adjustl(region))//".csv"
blockfile=trim(adjustl(regionpath))//trim(adjustl(blocks))//".csv"
open (10,file=trim(adjustl(outpath))//"debug_boot.dat")  

vname="influx2" !"conc2" ! 
timeprefix="zt21k" ! "conc2mnx" ! "tall" ! "zt132k" ! "ztall" ! "zt15132k" ! "ztall" ! "ztpi4" ! "ztpi2" ! "ztall" ! 
!sww="10"
intype=1 ! 2 ! 

!! overall age range of data
begyr=22000.0; endyr=-60.0
!begyr=165000.0; endyr=-60.0

! number of bootstrap samples
nreps=10

write (*,'("outpath:"/a80)') outpath 
!write (*,'("plotpath:"/a80)') plotpath
write (*,'("infilepath:"/a80)') infilepath

select case (intype)
    case (1)
        outcsvfile=trim(adjustl(region))//"_blk_"//trim(adjustl(vname))//"_"//trim(adjustl(timeprefix))// &
            "_"//trim(adjustl(blocks))//"_stats.csv" 
        plotcsvfile=trim(adjustl(region))//"_blk_"//trim(adjustl(vname))//"_"//trim(adjustl(timeprefix))// &
            "_"//trim(adjustl(blocks))//"_plot.csv" 
    case (2)
        outcsvfile=trim(adjustl(region))//"_blk_"//trim(adjustl(vname))//"_"//trim(adjustl(timeprefix))// &
            "_"//trim(adjustl(sww))//trim(adjustl(blocks))//"_stats.csv"
        plotcsvfile=trim(adjustl(region))//"_blk_"//trim(adjustl(vname))//"_"//trim(adjustl(timeprefix))// &
            "_"//trim(adjustl(sww))//trim(adjustl(blocks))//"_plot.csv"
end select
write (*,'("regionfile:"/a80)') regionfile
write (*,'("blockfile:"/a80)') blockfile
write (*,'("outcsvfile:"/a80)') outcsvfile
write (*,'("plotcsvfile:"/a80)') plotcsvfile

open (5,file=trim(adjustl(blockfile)))
open (7,file=trim(adjustl(outpath))//trim(adjustl(outcsvfile)))
open (6,file=trim(adjustl(outpath))//trim(adjustl(plotcsvfile)))
open (8,file=regionfile) 
!open (10,file=trim(adjustl(outpath))//"debug_block.dat")  

select case (intype)
    case (1)
        write (7,'(a)') "beg, end,  npts, bnpts, npts05, npts95, "// &
            "mean_"//trim(adjustl(timeprefix))//"_"//trim(adjustl(vname))//", mean50, mean05, mean95,"// & 
            "median_"//trim(adjustl(timeprefix))//"_"//trim(adjustl(vname))//", median50, median05, median95, "// &
            "stddev, stddev50, stddev05, stddev95, iqr, iqr50, iqr05, iqr95," // &
            "q10, q10_50, q10_05, q10_95, q25, q25_50, q25_05, q25_95, q75, q75_50, q75_05, q75_95, q90, q90_50, q90_05, q90_95"
        write (6,'(a)') "beg,  npts, bnpts, npts05, npts95, "// &
            "mean_"//trim(adjustl(timeprefix))//"_"//trim(adjustl(vname))//", mean50, mean05, mean95,"// & 
            "median_"//trim(adjustl(timeprefix))//"_"//trim(adjustl(vname))//", median50, median05, median95, "// &
            "stddev, stddev50, stddev05, stddev95, iqr, iqr50, iqr05, iqr95," // &
            "q10, q10_50, q10_05, q10_95, q25, q25_50, q25_05, q25_95, q75, q75_50, q75_05, q75_95, q90, q90_50, q90_05, q90_95"
    case (2)
        write (7,'(a)') "beg, npts, bnpts, npts05, npts95, "// &
            trim(adjustl(timeprefix))//"_"//trim(adjustl(vname))//"_"//trim(adjustl(sww))//"_mean, mean50, mean05, mean95,"// & 
            "median_"//trim(adjustl(timeprefix))//"_"//trim(adjustl(vname))//", median50, median05, median95, "// &
            "stddev, stddev50, stddev05, stddev95, iqr, iqr50, iqr05, iqr95," // &
            "q10, q10_50, q10_05, q10_95, q25, q25_50, q25_05, q25_95, q75, q75_50, q75_05, q75_95, q90, q90_50, q90_05, q90_95"
        write (7,'(a)') "beg, end,  npts, bnpts, npts05, npts95, "// & 
            trim(adjustl(timeprefix))//"_"//trim(adjustl(vname))//"_"//trim(adjustl(sww))//"_mean, mean50, mean05, mean95,"// & 
            "median_"//trim(adjustl(timeprefix))//"_"//trim(adjustl(vname))//", median50, median05, median95, "// &
            "stddev, stddev50, stddev05, stddev95, iqr, iqr50, iqr05, iqr95," // &
            "q10, q10_50, q10_05, q10_95, q25, q25_50, q25_05, q25_95, q75, q75_50, q75_05, q75_95, q90, q90_50, q90_05, q90_95"
end select

! random number seed
call srand(100)

varmiss=-9999.0

! read the region site file
usesite=0
read (8,*) header
do while (.not. eof(8))
    read (8,*) usesitenum
    !write (*,*) usesitenum
    usesite(usesitenum)=1
end do 
!write (*,'(20i5)') usesite
!pause

! read the block info file
read (5,*) header
n=0
do while (.not.eof(5))
    n=n+1
    read (5,*) blkbeg(n),blkend(n),blkname(n)
end do
nblks=n

! read data, store individual sites in array

nsel=0
jsite=0
xsite=0.0; ysite=0.0
do j=1,maxsites

    site_num_char=int_to_string2(j,4)
    
    ! try to open a file
    site_num_char=int_to_string2(j,4)   ! ############
    select case (intype)
        case (1)
            infile=trim(adjustl(infilepath))//trim(adjustl(site_num_char))//"_trans_"//trim(adjustl(vname))//".csv"
        case (2)
            infile=trim(adjustl(infilepath))//trim(adjustl(site_num_char))//"_smooth_"//trim(adjustl(vname))//"_"// &
                trim(adjustl(timeprefix))//"_sm"//trim(adjustl(sww))//".csv"
    end select
    
    !if (usesite(j).eq.1) then
    !    !write (*,*) site_num_char, usesite(j)
    !    write (*,'(a256)') infile
    !end if
    
    open (1,file=infile, status='old', err=100)
    ! if site file exists:
     
    if (usesite(j).eq.1) then    
        jsite=jsite+1
        idsite(jsite)=j    
        
        !write (*,*) site_num_char, usesite(j)
        !write (*,'(a96)') infile
        
        ! read data, and save age and variable to be smoothed
        read (1,*) header
        i=0
        do while (.not. eof(1))   ! ############
            select case (intype)
                case (1) ! allfile input
                    read (1,*) site_num_label,site_sample, id_sample, age, depth, influx2, influx2mnx, tall, ztall, zt21k, zt4k, zt2k, ztpi2, ztpi4                    
                    !read (1,*) site_num_label,site_sample, id_sample, age,depth,conc2,conc2mnx,tall,ztall,zt21k,zt15132k,zt132k,zt40k,zt1583k
                        select case (timeprefix)
                            case ("zt21k")
                                varin=zt21k    
                            case ("ztpi2")
                                varin=ztpi2
                            case ("ztpi4")
                                varin=ztpi4
                            case ("zt15132k")
                                varin=zt15132k
                            case ("ztall")
                                varin=ztall
                            case ("zt132k")
                                varin=zt132k
                            case ("tall")
                                varin=tall
                            case ("conc2mnx")
                                varin=conc2mnx
                        end select
                case (2) ! 1st stage smoothing file
                    read (1,*) site_sample,age,varin
            end select
            if (age.le.begyr .and. age.ge.endyr .and. age.ne.varmiss .and. varin.ne.varmiss) then
                i=i+1
                xsite(i,jsite)=age
                ysite(i,jsite)=varin        
                !write (10,'(i5,f10.2,f8.3)') i,age,varin
            end if
        end do
        nrecs(jsite)=i
        close(1)
        
        !write (10,'("j,jsite,idsite,nrecs,site_num_char:",4i5,1x,a4)') j,jsite,idsite(jsite),nrecs(jsite),site_num_char
        !write (*,'("j,jsite,idsite,nrecs,site_num_char:",4i5,1x,a4)') j,jsite,idsite(jsite),nrecs(jsite),site_num_char
        !write (10,'(i4,1x,3000i1)') jsite,(ndec(i,jsite),i=1,ntarg)
        !write (*,'(i4,1x,3000i1)') jsite,(ndec(i,jsite),i=1,ntarg)

    end if
    go to 101
    
100 continue
!write (*,'(a)') "file not found"

101 continue

end do
nsites=jsite
write (*,'("nsites= ",i6)') nsites

! bootstrap sampling and fitting

nsel=0
do k=1,nreps
    if (mod(k,10).eq.0) write (*,'(i5,\)') k
    jmax=-99999; jmin=99999
    ii=0
    do j=1,nsites

        ! select a site at random
        randval=rand(0)
        jsel(j,k)=int(randval*sngl(nsites))+1
        nsel(jsel(j,k))=nsel(jsel(j,k))+1
        if (jmax.lt.jsel(j,k)) jmax=jsel(j,k)
        if (jmin.gt.jsel(j,k)) jmin=jsel(j,k)
        ! jsel(j,k)=j ! sample all points every time
     
        ! concatenate records
        if (nrecs(jsel(j,k)).gt.1) then
            do i=1,nrecs(jsel(j,k))
                ii=ii+1
                xin(ii)=xsite(i,jsel(j,k))
                yin(ii)=ysite(i,jsel(j,k))
                !write (2,'(4i6,2f14.6)') ii,j,idsite(jsel(j,k)),i,xin(ii),yin(ii)
            end do
        end if
    end do
    npts=ii
    
    !write (*,'(i5,\)') k !,npts,ntarg
    
    npblk=0.0d0; meanblk=0.0d0; medianblk=0.0d0; q90blk=0.0d0; q75blk=0.0d0
    q25blk=0.0d0; q10blk=0.0d0; stddevblk=0.0d0; iqrblk=0.0d0
        
    call block(nblks,blkbeg,blkend,npts,xin,yin,npblk,meanblk,medianblk, &
        q90blk,q75blk,q25blk,q10blk,stddevblk,iqrblk)
    
    meanrep(k,:)=meanblk(:); medianrep(k,:)=medianblk(:); q90rep(k,:)=q90blk(:); q75rep(k,:)=q75blk(:)
    q25rep(k,:)=q25blk(:); q10rep(k,:)=q10blk(:); stddevrep(k,:)=stddevblk(:); iqrrep(k,:)=iqrblk(:)
    nprep(k,:)=npblk(:)
    
    !write (*,*) " "
    !do n=1,nblks
    !    write (*,'(2i4,2f8.0,i5,8f8.3)') k,n,blkbeg(1),blkend(1),nprep(k,1),meanrep(k,1),medianrep(k,1), &
    !   stddevrep(k,1),iqrrep(k,1),q10rep(k,1),q25rep(k,1),q75rep(k,1),q90rep(k,1)
    !end do
    write (10,'(2i4,2f8.0,i5,8f8.3)') k,1,blkbeg(1),blkend(1),nprep(k,1),meanrep(k,1),medianrep(k,1), &
        stddevrep(k,1),iqrrep(k,1),q10rep(k,1),q25rep(k,1),q75rep(k,1),q90rep(k,1)
    
end do
    
! one more fit to get "original (unresampled) values
ii=0
do j=1,nsites
    ! concatenate records
    if (nrecs(j).gt.1) then
        do i=1,nrecs(j)
            ii=ii+1
            xin(ii)=xsite(i,j)
            yin(ii)=ysite(i,j)
            !write (2,'(4i6,2f14.6)') ii,j,idsite(j),i,xin(ii),yin(ii)
        end do
    end if
end do
npts=ii

call block(nblks,blkbeg,blkend,npts,xin,yin,npblk,meanblk,medianblk, &
    q90blk,q75blk,q25blk,q10blk,stddevblk,iqrblk)
    
meanout(1,:)=meanblk(:); medianout(1,:)=medianblk(:); q90out(1,:)=q90blk(:); q75out(1,:)=q75blk(:)
q25out(1,:)=q25blk(:); q10out(1,:)=q10blk(:); stddevout(1,:)=stddevblk(:); iqrout(1,:)=iqrblk(:)
npout(1,:)=npblk(:)

write (*,*) " "
do n=1,nblks
    write (*,'(i4,2f8.0,i5,8f8.3)') n,blkbeg(n),blkend(n),npout(1,n),meanout(1,n), medianout(1,n), &
        stddevout(1,n),iqrout(1,n),q10out(1,n),q25out(1,n),q75out(1,n),q90out(1,n)
end do

! bootstrap estimates of statistics and their confidence intervals
do n=1,nblks
    call quantiles(nreps,dble(nprep(:,n)),q0,q01,q05,q10,q25,q50,q75,q90,q95,q99,q100)
    npout(2,n)=int(q50); npout(3,n)=int(q05); npout(4,n)=int(q95)
    call quantiles(nreps,meanrep(:,n),q0,q01,q05,q10,q25,q50,q75,q90,q95,q99,q100)
    meanout(2,n)=q50; meanout(3,n)=q05; meanout(4,n)=q95
    call quantiles(nreps,medianrep(:,n),q0,q01,q05,q10,q25,q50,q75,q90,q95,q99,q100) 
    medianout(2,n)=q50; medianout(3,n)=q05; medianout(4,n)=q95
    call quantiles(nreps,stddevrep(:,n),q0,q01,q05,q10,q25,q50,q75,q90,q95,q99,q100)
    stddevout(2,n)=q50; stddevout(3,n)=q05; stddevout(4,n)=q95
    call quantiles(nreps,iqrrep(:,n),q0,q01,q05,q10,q25,q50,q75,q90,q95,q99,q100)
    iqrout(2,n)=q50; iqrout(3,n)=q05; iqrout(4,n)=q95
    call quantiles(nreps,q10rep(:,n),q0,q01,q05,q10,q25,q50,q75,q90,q95,q99,q100)
    q10out(2,n)=q50; q10out(3,n)=q05; q10out(4,n)=q95
    call quantiles(nreps,q25rep(:,n),q0,q01,q05,q10,q25,q50,q75,q90,q95,q99,q100)
    q25out(2,n)=q50; q25out(3,n)=q05; q25out(4,n)=q95
    call quantiles(nreps,q75rep(:,n),q0,q01,q05,q10,q25,q50,q75,q90,q95,q99,q100)
    q75out(2,n)=q50; q75out(3,n)=q05; q75out(4,n)=q95
    call quantiles(nreps,q90rep(:,n),q0,q01,q05,q10,q25,q50,q75,q90,q95,q99,q100)
    q90out(2,n)=q50; q90out(3,n)=q05; q90out(4,n)=q95
    write (*,'(i4,4f8.3)') n,(meanout(m,n),m=1,nparam)
    write (7,'(f8.0,", ",f8.0,4(", ",i5),32(", ",f8.3))') blkbeg(n),blkend(n),npout(:,n),meanout(:,n),stddevout(:,n),medianout(:,n),iqrout(:,n), &
        q10out(:,n),q25out(:,n),q75out(:,n),q90out(:,n)
end do

! write out plotting file
n=1
    write (6,'(f8.0,4(", ",i5),32(", ",f8.3))') blkbeg(n),npout(:,n),meanout(:,n),medianout(:,n),stddevout(:,n),iqrout(:,n), &
        q10out(:,n),q25out(:,n),q75out(:,n),q90out(:,n)
do n=2,nblks
    write (6,'(f8.0,4(", ",i5),32(", ",f8.3))') blkbeg(n),npout(:,n-1),meanout(:,n-1),medianout(:,n-1),stddevout(:,n-1), &   
        iqrout(:,n-1),q10out(:,n-1),q25out(:,n-1),q75out(:,n-1),q90out(:,n-1)
    write (6,'(f8.0,4(", ",i5),32(", ",f8.3))') blkbeg(n),npout(:,n),meanout(:,n),medianout(:,n),stddevout(:,n), & 
        iqrout(:,n),q10out(:,n),q25out(:,n),q75out(:,n),q90out(:,n)
end do
n=nblks
    write (6,'(f8.0,4(", ",i5),32(", ",f8.3))') blkend(n),npout(:,n),meanout(:,n),medianout(:,n),stddevout(:,n), &
        iqrout(:,n),q10out(:,n),q25out(:,n),q75out(:,n),q90out(:,n)


end do
    
end

function int_to_string(inum)

	implicit none
	character(32)	:: int_to_string
	character(32)	:: buffer, str
	integer			:: inum

	write (buffer,*) inum
	read (buffer,*) str

	int_to_string=trim(adjustl(str))

end function int_to_string


function int_to_string2(inum,numlen)

	implicit none
	character(32)	:: int_to_string,int_to_string2
	character(32)	:: buffer, str
	character(8)	:: ifmt,iedit
	integer			:: inum,numlen

	iedit=int_to_string(numlen)
	ifmt="(i"//trim(adjustl(iedit))//"."//trim(adjustl(iedit))//")"

	write (buffer,ifmt) inum
	read (buffer,*) str

	int_to_string2=trim(adjustl(str))

end function int_to_string2

