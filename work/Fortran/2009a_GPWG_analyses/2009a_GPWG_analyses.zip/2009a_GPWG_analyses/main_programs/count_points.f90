program count_points
! counts the number of data points that ultimately contribute to a fitted value

use ifport

implicit none

integer, parameter  :: maxsitedata=9000, maxsites=2000, maxtarg=10000, nwin=6
integer(4)      :: site_sample
integer(8)      :: id_sample
real(4)         :: age,depth,influx2,influx2mnx,tall,ztall,zt21k,zt4k,zt2k,ztpi2,ztpi4
real(4)         :: conc2,conc2mnx,zt15132k,zt132k,zt40k,zt1583k

real(4)         :: varin,varmiss
integer         :: site_num,usesitenum,usesite(maxsites)
character(16)   :: site_num_label,timeprefix,ww
character(4)    :: site_num_char

character(32)   :: vname

integer         :: idsite(maxsites)
integer         :: nsamp(maxsites,maxtarg,nwin),nsamp_tot(maxtarg,nwin)
integer         :: nrecs(maxsites,maxtarg,nwin),nrecs_tot(maxtarg,nwin)
integer         :: tot(maxtarg)

real(8)         :: hw(nwin)

real(4)         :: begyr,endyr
real(8)         :: xtarg(maxtarg),targbeg,targend,targstep

integer         :: i,j,k,l,ntarg,jsite,nsites

character(32)   :: int_to_string2,int_to_string
character(256)  :: infofile
character(256)  :: infilepath,infile,outpath,outfile
character(256)  :: region,regionpath,regionfile
character(256)  :: outheader
character(16)   :: base, query, sww

character(80)   :: header
character(1)    :: dum

logical         :: yfitnan,nan 

data hw/100.0,250.0,500.0,1000.0,2000.0,400.0/

! read the info file
!call get_command_argument(1,infofile)
infofile="e:\Projects\GPWG\data\regions\v2n_lat01_count.inf"
open (99,file=trim(adjustl(infofile)))

do while (.not. eof(99))
    read (99,*) infilepath
    read (99,*) outpath
    read (99,*) regionpath
    read (99,*) region

    vname="influx2" ! "conc2" ! 
    timeprefix="zt21k" ! "ztpi4" ! "ztpi2" ! "zt15132k" ! "tall" ! 

    !! target point definitions
    targend=24000.0d0; targbeg=-60.0d0; targstep=20.0d0
    !targend=140000.0d0; targbeg=-30.0d0; targstep=20.0d0

    !! overall age range of data
    begyr=26000.0; endyr=-60.0
    !begyr=145000.0; endyr=-60.0

    write (*,'("infilepath:"/a80)') infilepath
    write (*,'("outpath:"/a80)') outpath 
    write (*,'("regionpath:"/a80)') regionpath 

    regionfile=trim(adjustl(regionpath))//trim(adjustl(region))//".csv"
    write (*,'("regionfile:"/a80)') regionfile

    outfile=trim(adjustl(outpath))//trim(adjustl(region))//"_count_"//trim(adjustl(vname)) &
        //"_"//trim(adjustl(timeprefix))//".csv"
    write (*,'("outfile:"/a80)') outfile

    open (8,file=regionfile) 
    open (9,file=outfile)
    outheader="target"
    do l=1,nwin
        outheader=trim(outheader)//", npts_"//trim(int_to_string2(int(hw(l)),4))//", nsites_"//trim(int_to_string2(int(hw(l)),4))
    end do
    write (9,'(a)') outheader

    ! generate target points
    ntarg=int((targend-targbeg)/targstep)+1
    do i=1,ntarg
        !xtarg(i)=targend-dble(i-1)*targstep
        xtarg(i)=targbeg+dble(i-1)*targstep
        !write (10,*) i,sngl(xtarg(i))
    end do

    varmiss=-9999.0

    ! read the region site file
    usesite=0
    read (8,*) header
    do while (.not. eof(8))
        read (8,*) usesitenum
        !write (*,*) usesitenum
        usesite(usesitenum)=1
    end do 
    !write (*,'(20i5)') usesite
    !pause

    ! read data, store individual sites in array

    nsamp=0; nsamp_tot=0; nrecs=0; nrecs_tot=0; jsite=0
    do j=1,maxsites

        site_num_char=int_to_string2(j,4)
        
        ! try to open a file
        site_num_char=int_to_string2(j,4)   ! ############
        infile=trim(adjustl(infilepath))//trim(adjustl(site_num_char))//"_trans_"//trim(adjustl(vname))//".csv"
        
        !if (usesite(j).eq.1) then
        !    !write (*,*) site_num_char, usesite(j)
        !    write (*,'(a256)') infile
        !end if
        
        open (1,file=infile, status='old', err=100)
        ! if site file exists:
         
        if (usesite(j).eq.1) then    
            jsite=jsite+1
            idsite(jsite)=j
            !write (*,*) jsite,idsite(jsite) 
            !write (*,'(a72)') infile   
            
            !write (*,*) site_num_char, usesite(j)
            !write (*,'(a96)') infile
            
            ! read data, and save age and variable to be smoothed
            read (1,*) header
            i=0
            do while (.not. eof(1))   ! ############
                !read (1,*) site_num_label,site_sample, id_sample, age,depth,influx2,influx2mnx,tall,ztall,zt21k,zt15132k,zt132k,zt40k,zt1583k
                read (1,*) site_num_label,site_sample,id_sample,age,depth,influx2,influx2mnx,tall,ztall,zt21k,zt4k,zt2k,ztpi2,ztpi4
                select case (timeprefix)    
                    case ("zt21k")
                        varin=zt21k
                    case ("ztpi4")
                        varin=ztpi4
                    
                end select
                    
                if (age.lt.begyr .and. age.ge.endyr .and. varin.ne.varmiss) then
                    i=i+1
                    ! loop over target years and window widths
                    do k=1,ntarg
                        do l=1,nwin
                            if (age.ge.xtarg(k)-hw(l) .and. age.lt.xtarg(k)+hw(l)) then
                                nsamp(jsite,k,l)=nsamp(jsite,k,l)+1
                                nrecs(jsite,k,l)=1
                            end if
                        end do
                    end do
                end if
                
            end do
            close(1)
            

        end if
        go to 101
        
    100 continue
    !write (*,'(a)') "file not found"
    101 continue
    
    
    end do
    nsites=jsite
    write (*,'(i6,1x,a72)') nsites,region
    
    do k=1,ntarg
        do l=1,nwin
            do j=1,nsites
                nsamp_tot(k,l)=nsamp_tot(k,l)+nsamp(j,k,l)
                nrecs_tot(k,l)=nrecs_tot(k,l)+nrecs(j,k,l)
            end do
        end do
        write (9,'(f10.2,30(", ",i6))') xtarg(k),(nsamp_tot(k,l),nrecs_tot(k,l),l=1,nwin)
    end do 
    close(8); close(9)

end do

end


function int_to_string(inum)

	implicit none
	character(32)	:: int_to_string
	character(32)	:: buffer, str
	integer			:: inum

	write (buffer,*) inum
	read (buffer,*) str

	int_to_string=trim(adjustl(str))

end function int_to_string


function int_to_string2(inum,numlen)

	implicit none
	character(32)	:: int_to_string,int_to_string2
	character(32)	:: buffer, str
	character(8)	:: ifmt,iedit
	integer			:: inum,numlen

	iedit=int_to_string(numlen)
	ifmt="(i"//trim(adjustl(iedit))//"."//trim(adjustl(iedit))//")"

	write (buffer,ifmt) inum
	read (buffer,*) str

	int_to_string2=trim(adjustl(str))

end function int_to_string2

