program trend
! fits a simple trend line to charcoal data

use summarize_subs
use lowess

implicit none
!integer, parameter  :: maxdata=9000, maxsites=2000
integer(4)      :: site_sample
integer(8)      :: id_sample
real(4)         :: age,depth,influx2,influx2mnx,tall,ztall,zt21k,zt4k,zt2k,ztpi2,ztpi4

real(4)         :: varin,varmiss
integer         :: site_num(maxsites),usesitenum,usesite(maxsites)
real(8)         :: lat(maxsites), lon(maxsites), fdp(maxsites)
real(8)         :: x(maxdata),y(maxdata),w(maxdata),b0,b1,yhat(maxdata),resid(maxdata)
real(8)         :: xm,ym,wsum,sxx,sxy,sse,sst,mse,stderr,rsq,b0se,b1se,t0,t1
character(16)   :: site_num_label,timeprefix,ww
character(4)    :: site_num_char

character(32)   :: vname,tname

real(4)         :: begyr,endyr

integer         :: i,j,k,nsites,npts

character(256)  :: infilepath,infile,outpath,datfile,outcsvfile
character(256)  :: regionfile
character(80)   :: header,site_name(maxsites)

infilepath="e:\Projects\GPWG\data\csv_files\v2n\v2n_trans_influx2\"
outpath="e:\Projects\GPWG\data\files\v2n\curves\"
regionfile="e:\Projects\GPWG\data\regions\v2n\v2n_globe_gi.csv"

vname="influx2" ! "conc2" ! 
timeprefix="zt21k" ! "ztpi4" ! "ztpi2" ! "zt15132k" ! "tall" ! 
tname="tr06_20"

begyr=6000.0; endyr=500.0

open (6,file=regionfile)
outcsvfile=trim(adjustl(outpath))//"/"//trim(adjustl(tname))//"_"//trim(adjustl(timeprefix))//"_"//trim(adjustl(vname))//".csv"
open (7,file=outcsvfile)
write (7,'(a)') "site_num, lat, lon, fdp_scalar, npts, b0, b1, b0se, b1se, t0, t1, mse, stderr, rsq, sitename"
datfile=trim(adjustl(outpath))//"/"//trim(adjustl(tname))//"_"//trim(adjustl(timeprefix))//"_"//trim(adjustl(vname))//".dat"
open (8,file=datfile)

varmiss=-9999.0

! read the region site file
usesite=0
read (6,*) header
do while (.not. eof(6))
    read (6,*) j,lat(j),lon(j),fdp(j),site_name(j)
    !write (*,*) j
    usesite(j)=1
    site_num(j)=j
end do 
!write (*,'(20i5)') usesite

! loop over sites

    do j=1,maxsites

        site_num_char=int_to_string2(j,4)
        
        ! try to open a file
        site_num_char=int_to_string2(j,4)   ! ############
        infile=trim(adjustl(infilepath))//trim(adjustl(site_num_char))//"_trans_"//trim(adjustl(vname))//".csv"
        
        !if (usesite(j).eq.1) then
        !    !write (*,*) site_num_char, usesite(j)
        !    write (*,'(a256)') infile
        !end if
        
        open (1,file=infile, status='old', err=100)
        ! if site file exists:
         
        if (usesite(j).eq.1) then    
            
            write (*,*) site_num_char, usesite(j)
            write (*,'(a96)') infile
            
            ! read data, and save age and variable for trend
            read (1,*) header
            i=0
            do while (.not. eof(1))   ! ############
                !read (1,*) site_num_label,site_sample, id_sample, age,depth,influx2,influx2mnx,tall,ztall,zt21k,zt15132k,zt132k,zt40k,zt1583k
                read (1,*) site_num_label,site_sample,id_sample,age,depth,influx2,influx2mnx,tall,ztall,zt21k,zt4k,zt2k,ztpi2,ztpi4
                select case (timeprefix)    
                    case ("zt21k")
                        varin=zt21k
                    case ("ztpi4")
                        varin=ztpi4                  
                end select
                if (age.le.begyr .and. age.ge.endyr .and. varin.ne.varmiss) then
                    i=i+1
                    x(i)=age
                    y(i)=varin   
                end if
            end do
            npts=i            
            write (*,*) j, npts
            
            ! initialize variables
            w=1.0d0; b0=varmiss; b1=varmiss; yhat=varmiss; resid=varmiss
            xm=varmiss; ym=varmiss; wsum=varmiss; sxx=varmiss; sxy=varmiss; sse=varmiss; sst=varmiss; mse=varmiss 
            stderr=varmiss; rsq=varmiss; b0se=varmiss; b1se=varmiss; t0=varmiss; t1=varmiss
            
            ! linear regression for trend (b1)
            if (npts.gt.20) then
                call fitline(npts,x,y,w,b0,b1,yhat,resid,mse,stderr,rsq,xm,sxx,wsum)
                ! standard errors and t-statistics of coefficients
                if (sxx.ne.0.0 .and. npts.ne.0.0) then
                    b0se=dsqrt(mse*((1.0d0/dble(npts) + (xm**2.0d0)/sxx)))
                    t0=b0/b0se
                    b1se=stderr/dsqrt(sxx)
                    t1=b1/b1se
                end if
            end if
       
            write (7,'(i4,2(",",f12.6),", ",f7.4,",",i6,8(",",g12.5),",",f12.6,", ",a80)') &
                site_num(j),lat(j),lon(j),fdp(j),npts,b0,b1,b0se,b1se,t0,t1,mse,stderr,rsq, &
                quote(site_name(j))
            write (8,'(2f12.6,i6,f8.4,i6,8g13.5,f12.6,1x,a80)') &
                lat(j),lon(j),site_num(j),fdp(j),npts,b0,b1,b0se,b1se,t0,t1,mse,stderr,rsq, &
                quote(site_name(j))
              
            
        end if

    100 continue
    end do

end




