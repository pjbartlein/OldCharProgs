module block_stats

contains

subroutine block(nblks,blkbeg,blkend,npts,xin,yin,npblk,meanblk,medianblk, &
    q90blk,q75blk,q25blk,q10blk,stddevblk,iqrblk)
    
    implicit none
    
    integer     :: nblks,npts
    real(8)     :: blkbeg(nblks),blkend(nblks)
    real(8)     :: xin(npts),yin(npts),varmiss,y(npts)
    real(8)     :: meanblk(nblks),medianblk(nblks),q90blk(nblks),q75blk(nblks),q25blk(nblks)
    real(8)     :: q10blk(nblks),stddevblk(nblks),iqrblk(nblks),qmedian(nblks)
    real(8)     :: q0,q01,q05,q10,q25,q50,q75,q90,q95,q99,q100
    integer     :: npblk(nblks)
    
    integer     :: i,n,ii
    
    do n=1,nblks
        ii=0; npblk(n)=0
        do i=1,npts
            if (xin(i).gt.blkbeg(n) .and. xin(i).le.blkend(n)) then
                ii=ii+1
                y(ii)=yin(i)
                npblk(n)=npblk(n)+1
            end if
        end do
        call desc(npblk(n),y,meanblk(n),stddevblk(n))
        call quantiles(npblk(n),y,q0,q01,q05,q10,q25,q50,q75,q90,q95,q99,q100)
        ! write (*,'(11f8.3)') q0,q01,q05,q10,q25,q50,q75,q90,q95,q99,q100
        
        medianblk(n)=q50
        q90blk(n)=q90
        q75blk(n)=q75
        q25blk(n)=q25
        q10blk(n)=q10
        iqrblk(n)=q75-q25
    end do
    
end subroutine block


subroutine desc(npts,y,mean,stdev)
! mean and standard deviation of a variable

    implicit none

    integer     :: npts
    real(8)     :: y(npts),mean,stdev
    integer     :: i

    mean=0.0d0
    do i=1,npts
        mean=mean+y(i)
    end do
    if (npts.gt.0) mean=mean/dble(npts)
    stdev=0.0d0
    do i=1,npts
        stdev=stdev+(y(i)-mean)*(y(i)-mean)
    end do
    if (stdev.gt.0.0d0) stdev=(sqrt(stdev/dble(npts-1)))

end subroutine desc


subroutine quantiles(n,y,q0,q01,q05,q10,q25,q50,q75,q90,q95,q99,q100)
! usual quantile values

    implicit none
    
    integer, parameter  :: nq=9
    integer     :: n
    real(8)     :: y(n),ys(n),p(n)
    real(8)     :: q0,q01,q05,q10,q25,q50,q75,q90,q95,q99,q100
    real(8)     :: pval(nq),q(nq)
    integer     :: i,k
    
    data pval/0.01d0,0.05d0,0.10d0,0.25d0,0.50d0,0.75d0,0.90d0,0.95d0,0.99d0/
    
    call sortx(n,y,ys)
    do k=1,n
        p(k)=float(k-1)/float(n-1)
        !write (*,'(i4,3f10.3)') k,y(k),ys(k),p(k)
    end do
    
    do i=1,nq
        q(i)=-9999.0
        do k=1,n-1
            if (pval(i).gt.p(k) .and. pval(i).le.p(k+1)) exit
        end do
        q(i)=ys(k)+(ys(k+1)-ys(k))*(pval(i)-p(k))/(p(k+1)-p(k))
        !write (*,'(i2,2f10.3)') i,pval(i),q(i)
    end do
    q0=ys(1); q01=q(1); q05=q(2); q10=q(3); q25=q(4); q50=q(5); q75=q(6); q90=q(7); q95=q(8); q99=q(9); q100=ys(n)
    
end subroutine quantiles


subroutine sortx(npts,x,xs)
! sorts x

    implicit none

    integer         :: npts
    real(8)         :: x(npts),xs(npts+1),tx
    integer         :: i,j,k,kp1
    logical         :: flag
    
    do i=1,npts
        xs(i)=x(i)
    end do

    i=0
    flag=.true.
    do 
        i=i+1
        j=npts-i
        flag=.false.
        do k=1,j
            kp1=k+1
            if (xs(k).gt.xs(kp1)) then
                tx=xs(kp1)
                xs(kp1)=xs(k)
                xs(k)=tx
                flag=.true.
            end if
        end do
        if (.not.flag) exit
    end do

end subroutine sortx


subroutine medianx(npts,x,median)
! finds median of x

    implicit none

    integer         :: npts
    real(8)         :: x(npts),xs(npts+1),tx,median
    integer         :: i,j,k,kp1
    logical         :: flag

    do i=1,npts
        xs(i)=x(i)
    end do

    i=0
    flag=.true.
    do 
        i=i+1
        j=npts-i
        flag=.false.
        do k=1,j
            kp1=k+1
            if (xs(k).gt.xs(kp1)) then
                tx=xs(kp1)
                xs(kp1)=xs(k)
                xs(k)=tx
                flag=.true.
            end if
        end do
        if (.not.flag) exit
    end do

    ! xs contains sorted values of x

    select case (npts)
        case (0)
            median=0.0d0
        case (1)
            median=xs(1)
        case (2)
            ! crude definition
            median=xs(int(npts/2))
        case default
            ! statistical definition
            median=(xs(int(npts/2)+1) + xs(npts - int(npts/2) +2))/2.0d0
    end select

end subroutine medianx



end module block_stats