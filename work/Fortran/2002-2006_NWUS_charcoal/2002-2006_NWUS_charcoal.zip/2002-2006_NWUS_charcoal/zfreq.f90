program zfreq
! calculates a weighted average of frequencies across sites

implicit none

integer, parameter	:: maxrec=2000, nl=15, yrbeg=-60, yrend=14000, yrstep=10, maxsm=2000
real				:: age(nl,maxrec),pstart(nl,maxrec),freq(nl,maxrec)
real				:: age1000,influx,mean,stddev,ar1,ratio,peak,pend,pflux
real				:: mag,dev,posdev,tslp,tbtwp,mntbtwp
real				:: freqzsm(maxrec),psum,w,wsum,hw,d,real_age,zbase
real				:: fmean(nl),fstddev(nl),freqz(nl,maxrec)

integer				:: nrec(nl),l,i,ii,n,npts(nl)

character*72		:: filename,basefolder,statfile,zfile
character*1			:: dum

hw=200.0
zbase=4000.0

basefolder="E:\Projects\peaks\2005_Apr\standardized\"

open(1,file="E:\Projects\peaks\2005_Apr\peakfreq\statfiles.inf")
open(2,file="E:\Projects\peaks\2005_Apr\peakfreq\freqz_temp.dat")
open(10,file="E:\Projects\peaks\2005_Apr\peakfreq\debug.dat")

l=0
do while(.not.eof(1))
	l=l+1
	read (1,*) filename
	statfile=trim(adjustl(basefolder))//trim(adjustl(filename))//".dat"
	write (*,*) statfile
	open(3,file=statfile)
	read(3,*) dum

	i=0
	do while(.not.eof(3))
		i=i+1
		read (3,*,err=100) age(l,i),age1000,influx,mean,stddev,ar1,ratio,peak,pstart(l,i),pend,pflux, &
			freq(l,i),mag,dev,posdev,tslp,tbtwp,mntbtwp
		write (10,'(i3,f10.1,f10.3,3f10.3,2f10.3,3f10.0,f10.1,f10.3,f10.1,2f10.3,3f10.1)') &
			l,age(l,i),age1000,influx,mean,stddev,ar1,ratio,peak,pstart(l,i),pend,pflux, &
			freq(l,i),mag,dev,posdev,tslp,tbtwp,mntbtwp
		go to 200
100		continue
			! skip record 
			! write (*,*) l,i
			i=i-1
200		continue
	end do
	nrec(l)=i	
	write (*,*) l,nrec(l)
	close(3)
end do

! z-scores of freq

fmean=0.0
fstddev=0.0
npts=0
do l=1,nl
	do i=1,nrec(l)
		if (age(l,i).lt.zbase) then
			fmean(l)=fmean(l)+freq(l,i)
			npts(l)=npts(l)+1
		end if
	end do
	fmean(l)=fmean(l)/real(npts(l))
	do i=1,nrec(l)
		if (age(l,i).lt.zbase) then
			fstddev(l)=fstddev(l)+(freq(l,i)-fmean(l))**2.0
		end if
	end do
	fstddev(l)=sqrt(fstddev(l)/real(npts(l)-1))
	do i=1,nrec(l)
		freqz(l,i)=(freq(l,i)-fmean(l))/fstddev(l)
	end do
end do

rewind(1)
do l=1,nl
	read (1,*) filename
	zfile=trim(adjustl(basefolder))//trim(adjustl(filename))//"_freqz.dat"
	write (*,*) zfile
	open(3,file=zfile)
	write (3,'("     Age    Freq   ZFreq")')
	do i=1,nrec(l)
		write (3,'(f8.1,2f8.3)') age(l,i),freq(l,i),freqz(l,i)
	end do
	close(3)
end do

! weighted mean of freqz

freqzsm=0.0
ii=0
do n=yrbeg,yrend,yrstep
	ii=ii+1
	real_age=real(n)
	psum=0.0
	wsum=0.0
	do l=1,nl
		do i=1,nrec(l)
			d=abs(age(l,i)-real_age)/hw
			if (d.le.1.0) then
				w=(1.0-d**3.0)**3.0
				psum=psum+freqz(l,i)*w
				wsum=wsum+w
			end if
		end do
	end do
	freqzsm(ii)=psum/wsum

	write(2,'(2i6,f8.1,2f11.5,f8.4)') ii,n,real_age,psum,wsum,freqzsm(ii)
end do

end
