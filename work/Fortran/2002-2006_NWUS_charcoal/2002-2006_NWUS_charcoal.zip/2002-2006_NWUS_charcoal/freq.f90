program freq

implicit none
integer, parameter	:: nl=13,nb=1700,dmax=2000
real				:: intfreq(nb,nl),age(dmax),pfreq(dmax)
real				:: ain,ain1000,influx,mean,stddev,ar1,ratio,peak,pstart,pend,pflux
real				:: fin,mag,dev,posdev,tslp,tbtwp,mntbtwp
real				:: ageout,targ,amax
integer				:: firstyr,lastyr,step,nlvls
integer				:: i,j,l
character(1)		:: dummy
character(64)		:: lake(nl)

data lake/ &
	'E:\peaks\charcoal\stats\bak25a.dat',	&	! 1	
	'E:\peaks\charcoal\stats\pin08a.dat', &	! 2
	'E:\peaks\charcoal\stats\slo10a.dat', &	! 3
	'E:\peaks\charcoal\stats\hoo10a.dat', &	! 4
	'E:\peaks\charcoal\stats\bur30a.dat', &	! 5
	'E:\peaks\charcoal\stats\cyg10a.dat', &	! 6
	'E:\peaks\charcoal\stats\tra10a.dat', &	! 7
	'E:\peaks\charcoal\stats\los10a.dat', &	! 8
	'E:\peaks\charcoal\stats\tay10a.dat', &	! 9
	'E:\peaks\charcoal\stats\lit10a.dat', &	! 10
	'E:\peaks\charcoal\stats\cra12a.dat', &	! 11
	'E:\peaks\charcoal\stats\ced26a.dat', &	! 12
	'E:\peaks\charcoal\stats\blu12a.dat' /	! 13

firstyr=0; lastyr=16900; step=10

open (2,file="E:\peaks\data\freq10.dat")

intfreq=-99.0
do j=1,nl
	open (1,file=lake(j))
	read (1,*) dummy 
	i=0
	do while (.not.eof(1)) 
		read (1,*) ain,ain1000,influx,mean,stddev,ar1,ratio,peak,pstart,pend,pflux, &
			fin,mag,dev,posdev,tslp,tbtwp,mntbtwp
!		write (*,*) ain,peak,pstart,fin
		i=i+1
		pfreq(i)=fin
		age(i)=ain
	end do
	close(1)
	nlvls=i
	amax=age(nlvls)

	do i=1,nb
		targ=firstyr+(i-1)*step
		if (targ.lt.amax) then
			call hunt(age,nlvls,targ,l)
			if (l.le.1) then
			  intfreq(i,j)=pfreq(1)
			else if (l.eq.nlvls) then
			  intfreq(i,j)=pfreq(nlvls)
			else
			  intfreq(i,j)=pfreq(l)+((targ-age(l))/(age(l+1)-age(l)))*(pfreq(l+1)-pfreq(l))
			endif
		end if
	end do
!	pause
end do

do i=1,nb
	ageout=(i-1)*step
	write (2,'(f7.0,13f10.3)') ageout,(intfreq(i,j),j=1,nl)
end do
close(2)

stop
end


      SUBROUTINE hunt(xx,n,x,jlo)
      INTEGER jlo,n
      REAL x,xx(n)
      INTEGER inc,jhi,jm
      LOGICAL ascnd
      ascnd=xx(n).gt.xx(1)
      if(jlo.le.0.or.jlo.gt.n)then
        jlo=0
        jhi=n+1
        goto 3
      endif
      inc=1
      if(x.ge.xx(jlo).eqv.ascnd)then
1       jhi=jlo+inc
        if(jhi.gt.n)then
          jhi=n+1
        else if(x.ge.xx(jhi).eqv.ascnd)then
          jlo=jhi
          inc=inc+inc
          goto 1
        endif
      else
        jhi=jlo
2       jlo=jhi-inc
        if(jlo.lt.1)then
          jlo=0
        else if(x.lt.xx(jlo).eqv.ascnd)then
          jhi=jlo
          inc=inc+inc
          goto 2
        endif
      endif
3     if(jhi-jlo.eq.1)return
      jm=(jhi+jlo)/2
      if(x.gt.xx(jm).eqv.ascnd)then
        jlo=jm
      else
        jhi=jm
      endif
      goto 3
      END
!  (C) Copr. 1986-92 Numerical Recipes Software D04'%1'i0(95.)61j'1..	
