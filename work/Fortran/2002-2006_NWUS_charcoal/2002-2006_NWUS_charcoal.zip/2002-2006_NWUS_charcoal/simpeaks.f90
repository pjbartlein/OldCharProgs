program simpeaks

use dflib

implicit none
integer, parameter	:: nl=13,nb=170,nsim=2000
integer				:: dout(nb,nl),npeaks(nb,nl),age,peak,pstart,binwidth
real				:: freq,ageout,percent(nb)
integer				:: ntpeaks(nl),rstart(nl),rend(nl),lvec(nb*nl),lvecend
integer				:: nsites(nb),tpeaks(nb,nsim)
real				:: tpeaks2(nsim),tmean(nb),tstd(nb),tupper(nb),tlower(nb),tmedian(nb),tplo(nb),tphi(nb)
integer				:: swet(nb),sdry(nb),ore(nb),cal(nb)
real				:: ranpeak,lnum
integer				:: i,j,k,m,mm,jj
character(1)		:: dummy
character(64)		:: lake(nl)

data lake/ &
	'E:\peaks\data\CHAPSOUT\baker.dat',	&	! 1	
	'E:\peaks\data\CHAPSOUT\pintlar.dat', &	! 2
	'E:\peaks\data\CHAPSOUT\slough.dat', &	! 3
	'E:\peaks\data\CHAPSOUT\hoodoo.dat', &	! 4
	'E:\peaks\data\CHAPSOUT\burnt.dat', &	! 5
	'E:\peaks\data\CHAPSOUT\cygnet.dat', &	! 6
	'E:\peaks\data\CHAPSOUT\trail.dat', &	! 7
	'E:\peaks\data\CHAPSOUT\lost.dat', &	! 8
	'E:\peaks\data\CHAPSOUT\taylor.dat', &	! 9
	'E:\peaks\data\CHAPSOUT\little.dat', &	! 10
	'E:\peaks\data\CHAPSOUT\crater.dat', &	! 11
	'E:\peaks\data\CHAPSOUT\cedar.dat', &	! 12
	'E:\peaks\data\CHAPSOUT\bluff.dat' /	! 13

dout=9; npeaks=0; binwidth=100
nsites=0; tpeaks=0; percent=0.0
sdry=0; swet=0; ore=0; cal=0
ntpeaks=0

open (2,file="E:\peaks\data\peaksim.dat")
open (9,file="E:\peaks\data\debug.dat")
do j=1,nl
	open (1,file=lake(j))
	read (1,*) dummy 
	do while (.not.eof(1)) 
		read (1,*) age,peak,pstart,freq
		i=(age/float(binwidth))+1
		dout(i,j)=1
		if (pstart.eq.1.0) then
			write (9,*) j,age,i	
			ntpeaks(j)=ntpeaks(j)+1
		end if			
	end do
	close(1)
	write (*,*) j,ntpeaks(j)
end do

do j=1,nl
	do i=1,nb
		if (dout(i,j).ne.9) exit
	end do
	rstart(j)=i
	do i=nb,1,-1
		if (dout(i,j).ne.9) exit
	end do
	rend(j)=i
	write (*,*) j,rstart(j),rend(j)
end do

jj=0
do j=1,nl
	do i=1,rend(j)-rstart(j)+1
		jj=jj+1
		lvec(jj)=j
	end do
end do
lvecend=jj

do m=1,nsim
npeaks=0
do j=1,nl
	do k=1,ntpeaks(j)
		call random(ranpeak)
		i=rstart(j)+(ranpeak*(rend(j)-rstart(j)+1))
		call random(lnum)
		jj=lvec(lnum*lvecend + 1)
!		npeaks(i,j)=npeaks(i,j)+1
		npeaks(i,jj)=npeaks(i,jj)+1
	end do
end do
	
do i=1,nb
	tpeaks(i,m)=0
	do j=1,nl
		tpeaks(i,m)=tpeaks(i,m)+npeaks(i,j)		
	end do
!	if (i.eq.1) write (*,*) m,i,tpeaks(i,m)
end do
end do

tmean=0.0; tstd=0.0
do i=1,nb
	do m=1,nsim
		tmean(i)=tmean(i)+tpeaks(i,m)
		tpeaks2(m)=tpeaks(i,m)
	end do
	tmean(i)=tmean(i)/float(nsim)
	do m=1,nsim
		tstd(i)=tstd(i)+(tpeaks(i,m)-tmean(i))**2
	end do
	tstd(i)=sqrt(tstd(i)/float(nsim-1))
	tupper(i)=tmean(i)+1.0*tstd(i)
	tlower(i)=tmean(i)-1.0*tstd(i)
!	write (*,*) tpeaks2
!	pause
	call SORTQQ (LOC(tpeaks2), nsim, SRT$REAL4)
!	write (*,*) tpeaks2
!	pause
	mm=nsim*.5
	tmedian(i)=tpeaks2(mm)
	mm=nsim*.25
	tplo(i)=tpeaks2(mm)
	mm=nsim*.75
	tphi(i)=tpeaks2(mm)
	write (*,*) i,tmean(i),tstd(i)
end do

do i=1,nb
	ageout=(i-1)*binwidth
	write (2,'(f7.0,7f10.4)') ageout,tmean(i),tstd(i),tupper(i),tlower(i),tmedian(i),tplo(i),tphi(i)
end do
close(2)

stop
end
