program wave
! calculates a weighted average of something across sites

implicit none

integer, parameter	:: maxrec=2000, nl=15, yrbeg=-60, yrend=14000, yrstep=10, maxsm=2000
real				:: age(nl,maxrec),rdum1,rdum2,rdum3,var(nl,maxrec)
real				:: real_age,mean(maxrec),varsum,w,wsum,hw,d

integer				:: nrec(nl),l,i,ii,n,npts(nl)

character*72		:: filename,basefolder,statfile,zfile
character*1			:: dum

hw=200.0

basefolder="E:\Projects\peaks\Hol06_SedRate\"

open(1,file="E:\Projects\peaks\Hol06_SedRate\lakes.inf")
open(2,file="E:\Projects\peaks\Hol06_SedRate\sedrt_wave.dat")
open(10,file="E:\Projects\peaks\Hol06_SedRate\debug.dat")

l=0
do while(.not.eof(1))
	l=l+1
	read (1,*) filename
	statfile=trim(adjustl(basefolder))//trim(adjustl(filename))//"_sr.csv"
	write (*,*) statfile
	open(3,file=statfile)
	read(3,*) dum

	i=0
	do while(.not.eof(3))
		i=i+1
		read (3,*,err=100) age(l,i),rdum1,rdum2,rdum2,var(l,i)
		write (10,'(i3,f10.1,4f10.3)') l,age(l,i),rdum1,rdum2,rdum2,var(l,i)
		go to 200
100		continue
			! skip record 
			! write (*,*) l,i
			i=i-1
200		continue
	end do
	nrec(l)=i	
	write (*,*) l,nrec(l)
	close(3)
end do

! weighted mean of var

mean=0.0
ii=0
do n=yrbeg,yrend,yrstep
	ii=ii+1
	real_age=real(n)
	varsum=0.0
	wsum=0.0
	do l=1,nl
		do i=1,nrec(l)
			d=abs(age(l,i)-real_age)/hw
			if (d.le.1.0) then
				w=(1.0-d**3.0)**3.0
				varsum=varsum+var(l,i)*w
				wsum=wsum+w
			end if
		end do
	end do
	mean(ii)=varsum/wsum

	write(2,'(2i6,f8.1,2f11.5,f8.4)') ii,n,real_age,varsum,wsum,mean(ii)
end do

end
