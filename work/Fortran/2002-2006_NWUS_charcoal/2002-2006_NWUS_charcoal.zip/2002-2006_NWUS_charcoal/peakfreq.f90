program peakfreq
! calculates a weighted peak frequency across multiple sites

implicit none

integer, parameter	:: maxrec=2000, nl=15, yrbeg=-60, yrend=14000, yrstep=10, maxsm=2000
real				:: age(nl,maxrec),pstart(nl,maxrec)
real				:: age1000,influx,mean,stddev,ar1,ratio,peak,pend,pflux
real				:: fin,mag,dev,posdev,tslp,tbtwp,mntbtwp
real				:: peaksm(maxrec),psum,w,wsum,hw,d,duration,real_age

integer				:: nrec(nl),l,i,ii,n

character*72		:: filename,basefolder,statfile
character*1			:: dum

hw=750.0
duration=1000.0

basefolder="E:\Projects\peaks\2005_Apr\standardized\"

open(1,file="E:\Projects\peaks\2005_Apr\peakfreq\statfiles.inf")
open(2,file="E:\Projects\peaks\2005_Apr\peakfreq\peakfreq.dat")
open(4,file="E:\Projects\peaks\2005_Apr\peakfreq\allpeaks.dat")
open(10,file="E:\Projects\peaks\2005_Apr\peakfreq\debug.dat")

l=0
do while(.not.eof(1))
	l=l+1
	read (1,*) filename
	statfile=trim(adjustl(basefolder))//trim(adjustl(filename))//".dat"
	write (*,*) statfile
	open(3,file=statfile)
	read(3,*) dum

	i=0
	do while(.not.eof(3))
		i=i+1
		read (3,*,err=100) age(l,i),age1000,influx,mean,stddev,ar1,ratio,peak,pstart(l,i),pend,pflux, &
			fin,mag,dev,posdev,tslp,tbtwp,mntbtwp
		write (10,'(i3,f10.1,f10.3,3f10.3,2f10.3,3f10.0,f10.1,f10.3,f10.1,2f10.3,3f10.1)') &
			l,age(l,i),age1000,influx,mean,stddev,ar1,ratio,peak,pstart(l,i),pend,pflux, &
			fin,mag,dev,posdev,tslp,tbtwp,mntbtwp
		go to 200
100		continue
			! skip record 
			! write (*,*) l,i
			i=i-1
200		continue
	end do
	nrec(l)=i	
	write (*,*) l,nrec(l)
	close(3)
end do

! weighted peak frequency

peaksm=0.0
ii=0
do n=yrbeg,yrend,yrstep
	ii=ii+1
	real_age=real(n)
	psum=0.0
	wsum=0.0
	do l=1,nl
		do i=1,nrec(l)
			d=abs(age(l,i)-real_age)/hw
			if (d.le.1.0) then
				w=(1.0-d**3.0)**3.0
				psum=psum+pstart(l,i)*w
				wsum=wsum+w
			end if
		end do
	end do
	peaksm(ii)=(psum/wsum)*(duration/real(yrstep))

	write(2,'(2i6,f8.1,2f11.5,f8.4)') ii,n,real_age,psum,wsum,peaksm(ii)
end do

do l=1,nl
	do i=1,nrec(l)
!	write (*,*) l,i,pstart(l,i)
		if (pstart(l,i).eq.1.0) then
			write(4,'(f8.1,i3)') age(l,i),l
		end if
	end do
end do

end
