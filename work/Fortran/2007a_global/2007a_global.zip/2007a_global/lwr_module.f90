module lwr

contains

subroutine lowess(nctrl,xin,yin,ntarg,xt,wintype,param,order,nrobust,yfit)
! manages computation of a lowess "curve"

implicit none

integer             :: nctrl,ntarg
real(8)             :: xin(nctrl),yin(nctrl),xt(ntarg),param,yfit(ntarg),y0
real(8)             :: xs(nctrl),ys(nctrl),targ,fitval,lwmean1,lwmean2,newparam
integer             :: order,nrobust
integer             :: np 
character(1)        :: wintype
logical             :: monotonic,yfitnan

integer             :: i,ii,iii,j,k,dblvl

dblvl=1
y0=0.0

if (dblvl.eq.1) then
    write (10,'("nctrl,ntarg,wintype,param,order,nrobust",2i6,a2,f8.2,2i4)') nctrl,ntarg,wintype,param,order,nrobust
    write (10,'("xin")')
    write (10,'(10f8.1)') (xin(i),i=1,nctrl)
    write (10,'("yin")')
    write (10,'(10f8.2)') (yin(i),i=1,nctrl)
    write (10,'("xt")')
    write (10,'(10f8.1)') (xt(i),i=1,ntarg)
end if

xs=xin; ys=yin
! sort the input data by x-values if necessary
monotonic=.true.
do i=2,nctrl
    if (xs(i).lt.xs(i-1)) then
        monotonic=.false.
        write (*,'("xs(i),xs(i-1) non-monotonic: ",i6,2f14.6)') i,xs(i),xs(i-1)
    end if
end do
if (.not. monotonic) then
    write (*,'(a)') "Note:  input x's were not monotonic"
    write (10,'(a)') "Note:  input x's were not monotonic"
    call sortxy(nctrl,xin,yin,xs,ys)
end if

! loop over target points
do ii=1,ntarg

    if (mod(ii,100).eq.0) write (*,'(i5,\)') ii
    
    targ=xt(ii)    
    call localfit(nctrl,xs,ys,targ,wintype,param,order,nrobust,np,fitval,lwmean1)
    yfit(ii)=fitval
    
    if (dblvl.eq.1) then
        !write (*,'("ii,nctrl,param,targ,np,fitval,lwmean1    ",2i6,2f10.2,i6,2f10.2))') ii,nctrl,param,targ,np,fitval,lwmean1
        write (10,'("ii,nctrl,param,targ,np,fitval,lwmean1    ",2i6,2f10.2,i6,2f10.2))') ii,nctrl,param,targ,np,fitval,lwmean1
    end if
    
    ! check for NaN of fitted value 
    yfitnan=.false.
    if (isnan(yfit(ii))) then 
        yfitnan=.true.       
    end if
            
    ! if NaN, try expanding window first
    if (yfitnan) then
        if (wintype.eq.'s') then
            newparam=param*1.5d0
            if (newparam.gt.1.0d0) newparam=1.0d0
        else
            newparam=param*2.0d0
        end if      
        call localfit(nctrl,xs,ys,targ,wintype,newparam,order,nrobust,np,fitval,lwmean2)
        yfit(ii)=fitval
        write (10,'("ii,nctrl,newparam,targ,np,fitval,lwmean1 ",2i6,2f10.2,i6,2f10.2))') ii,nctrl,newparam,targ,np,fitval,lwmean1
        ! check Nan
        if (isnan(yfit(ii))) then
            yfitnan=.true.
        else
            yfitnan=.false.
        end if    
    end if
        
    ! if still Nan, expand window again
    if (yfitnan) then  
        if (wintype.eq.'s') then
            newparam=param*2.0d0
            if (newparam.gt.1.0d0) newparam=1.0d0
        else
            newparam=param*4.0d0
        end if     
        call localfit(nctrl,xs,ys,targ,wintype,newparam,order,nrobust,np,fitval,lwmean2)
        yfit(ii)=fitval
        write (10,'("ii,nctrl,newparam,targ,np,fitval,lwmean1 ",2i6,2f10.2,i6,2f10.2))') ii,nctrl,newparam,targ,np,fitval,lwmean1
        ! check Nan
        if (isnan(yfit(ii))) then
            yfitnan=.true.
        else
            yfitnan=.false.
        end if    
     end if       
        
    ! if still Nan, substitute locally-weighted mean
    if (yfitnan) then 
        if (.not. isnan(lwmean1)) then
            if (dabs(lwmean1).gt.0.000000001d0) then
                yfit(ii)=lwmean1
            else
                yfit(ii)=0.0d0
            end if
            write (10,'("ii,nctrl,newparam,targ,np,fitval,lwmean1 ",2i6,2f10.2,i6,2f10.2))') ii,nctrl,newparam,targ,np,fitval,lwmean1
        end if
        ! check Nan
        if (isnan(yfit(ii))) then
            yfitnan=.true.
        else
            yfitnan=.false.
        end if    
    end if
      
    ! if yfit(ii) still NaN, then set equal to previous value (except if ii=1)
    if (yfitnan) then           
        if (ii.eq.1) then
            yfit(ii)=y0
        else
            yfit(ii)=yfit(ii-1)
        end if
        !write (*,'("previous value or 0 substituted, yfit=",g14.6)') yfit(ii)
        write (10,'("previous value or 0 substituted, yfit=",g14.6)') yfit(ii)
    end if
    ! check Nan
    if (isnan(yfit(ii))) then
        yfitnan=.true.
    else
        yfitnan=.false.
    end if  
    
    ! if yfit(ii) is still NaN, give up
    if (isnan(yfit(ii))) yfit(ii)=0.0d0    

end do  
   
    
write (*,'(a)') " "
   
end subroutine lowess


subroutine localfit(nctrl,xs,ys,targval,wintype,param,order,nrobust,np,fitval,lwmean)
! gets a lowess-type fitted value at a particular target point

implicit none

integer             :: nctrl
real(8)             :: targval,param,fitval,lwmean
real(8)             :: xs(nctrl),ys(nctrl),x(nctrl),y(nctrl)
real(8)             :: w(nctrl),wsum,ywm,ym,ystd
real(8)             :: b0,b1,b2,yhat(nctrl),resid(nctrl),mse,stderr,rsq
real(8)             :: dmax,diff,u,ul,ll
real(8)             :: r(nctrl),median,rmedx6,ru,rw(nctrl)
integer             :: order,nrobust
integer             :: np,np2,npts,low,high,nonzero
character(1)        :: wintype
integer             :: i,ii,iii,j

! write (*,*) param

! select data to use for a specific fitted value
if (wintype.eq.'s') then 
 
    ! find observations in param proportion of data
    npts=int(param*nctrl)
    np2=npts/2
    low=ii-np2
    high=ii+np2
    if (low.lt.1) then
        low=1
        high=low+npts
    end if
    if (high.gt.nctrl) then
        high=nctrl
        low=nctrl-npts
    end if
    np=high-low+1
    !write (*,*) low,high,np
    i=0
    do iii=low,high
        i=i+1
        x(i)=xs(iii)
        y(i)=ys(iii)
    end do
    
    ! get distance weights
    dmax=0.0d0
    do i=1,np
        diff=x(i)-targval
        if (dabs(diff).gt.dmax) dmax=dabs(diff)
    end do
    do i=1,np
        u=dabs(x(i)-targval)/dmax
        if (u.gt.1.0d0) u=1.0d0
        w(i)=(1.0d0-u**3.0d0)**3.0d0
    end do
    
else if (wintype.eq.'w') then

    ! find observations within plus or minus window half-width (param)
    ul=targval+param
    ll=targval-param
    i=0
    do iii=1,nctrl
        if (xs(iii).ge.ll .and. xs(iii).le.ul) then
            i=i+1
            x(i)=xs(iii)
            y(i)=ys(iii)
        end if
    end do
    np=i   
    
    ! get distance weights
    dmax=param
    do i=1,np
        u=dabs(x(i)-targval)/dmax
        if (u.gt.1.0d0) u=1.0d0
        w(i)=(1.0d0-u**3.0d0)**3.0d0
    end do         
end if

! data for this target value    
!do i=1,np
!    write (10,'(i6,3f15.8)') i,x(i),y(i),w(i)
!end do
!pause

! get a locally weighted mean
call wm(np,y,w,lwmean,resid)
!write (*,*) lwmean
!pause

fitval=0.0d0/0.0d0 ! set to NaN initially

! set initial robustness weights equal to distance weights
nonzero=0
do i=1,np
    rw(i)=w(i)
    if (rw(i).ne.0.0d0) nonzero=nonzero+1
!    write (10,'("i,rw: ",i6,f12.4)') i,rw(i)
end do

! robustness iterations
do j=0,nrobust

    ! lowess regressions
    select case (order)
        
        case (0)
            ! (distance) weighted mean
            call wm(np,y,rw,ywm,resid)
            fitval=ywm

        case (1)       
            ! distance-weighted linear regression
            if (nonzero.gt.3) then
                call fitline(np,x,y,rw,b0,b1,yhat,resid,mse,stderr,rsq)
                fitval=b0+b1*targval
            end if
            
        case (2)
            ! distance-weighted quadratic regression
            if (nonzero.gt.8) then
                call fitquad(np,x,y,rw,b0,b1,b2,yhat,resid,mse,stderr,rsq)
                fitval=b0+b1*targval+b2*targval*targval
            end if
   
        case default
            write (*,*) "Polynomial order not supported...."
            stop 
            
    end select
    
    ! robustness weights
    if (nrobust.ne.0 .and. j.lt.nrobust) then
    
        ! median of absolute values of current residuals
        call medianx(np,dabs(resid),median)
        rmedx6=median*6.0d0
!        write (10,'("median,rmedx6: ",2f12.4)') median,rmedx6
    
        ! bisquare weights (r) and new robustness weights (rw)
        nonzero=0
        do i=1,np
            ru=dabs(resid(i)/rmedx6)    
            if (ru.gt.1.0d0) ru=1.0d0
            r(i)=(1.0d0-ru**2.0d0)**2.0d0
            rw(i)=w(i)*r(i)
            if (rw(i).ne.0.0d0) nonzero=nonzero+1
!            write (10,'("i,ru,r,rw: ",i6,3f12.4)') i,ru,r(i),rw(i)
        end do
      
    end if      
    
end do

end subroutine localfit


subroutine wm(npts,y,w,ywm,dev)
! weighted mean

implicit none

integer     :: npts
real(8)     :: y(npts),w(npts),dev(npts)
real(8)     :: wsum,ywm,ym
integer     :: i

ym=0.0d0
ywm=0.0d0
wsum=0.0d0
do i=1,npts
    ym=ym+y(i)
    ywm=ywm+y(i)*w(i)
    wsum=wsum+w(i)
    !write (10,*) i,y(i),ym
end do
!write (*,*) ym,ywm,wsum
if (wsum.gt.0.0) then
    ywm=ywm/wsum
else
    ywm=ym/dble(npts)
end if
!write (10,'("in wm: npts,ym,ywm,wsum ",i6,3f12.4)') npts,ym,ywm,wsum
!pause

do i=1,npts
    dev(i)=y(i)-ywm
end do

end subroutine wm


subroutine fitline(npts,x,y,w,b0,b1,yhat,resid,mse,stderr,rsq)
! simple weighted linear regression

implicit none

integer         :: npts
real(8)         :: x(npts),y(npts),w(npts),b0,b1,yhat(npts),resid(npts)
real(8)         :: xm,ym,wsum,sxx,sxy,sse,sst,mse,stderr,sratio,rsq
integer         :: i

xm=0.0d0; ym=0.0d0; wsum=0.0d0; sxx=0.0d0; sxy=0.0d0

do i=1,npts
    wsum=wsum+w(i)
    xm=xm+x(i)*w(i)
    ym=ym+y(i)*w(i)
end do
xm=xm/wsum
ym=ym/wsum

do i=1,npts
    sxx=sxx+((x(i)-xm)**2.0d0)*w(i)
    sxy=sxy+(x(i)-xm)*(y(i)-ym)*w(i)
end do

b1=sxy/sxx
b0=ym-(b1*xm)

sse=0.0d0; sst=0.0d0
do i=1,npts
    yhat(i)=b0+b1*x(i)
    resid(i)=y(i)-yhat(i)
    sse=sse+(resid(i)*dsqrt(w(i)))**2.0d0
    sst=sst+((y(i)-ym)*dsqrt(w(i)))**2.0d0
end do

mse=sse/dble(npts-2)
stderr=dsqrt(mse)
rsq=-1.0d0
sratio=sse/sst
!write (*,*) mse,sse,sst
if (sratio.le.1.0d0 .and. sratio.ge.0.0d0) rsq=1.0d0-sratio

end subroutine fitline


subroutine fitquad(npts,x1,y,w,b0,b1,b2,yhat,resid,mse,stderr,rsq)
! simple weighted quadratic regression

implicit none

integer         :: npts
real(8)         :: x1(npts),x2(npts),y(npts),w(npts),b0,b1,b2,yhat(npts),resid(npts)
real(8)         :: x1m,x2m,ym,wsum,sx1x1,sx2x2,sx1x2,sx1y,sx2y,sse,sst,mse,stderr,sratio,rsq
real(8)         :: bx1y,bx2y,bx2x1,bx1x2
integer         :: i

x1m=0.0d0; x2m=0.0d0; ym=0.0d0; wsum=0.0d0
sx1x1=0.0d0; sx2x2=0.0d0; sx1x2=0.0d0; sx1y=0.0d0; sx2y=0.0d0

do i=1,npts
    x2(i)=x1(i)**2.0d0
    wsum=wsum+w(i)
    x1m=x1m+x1(i)*w(i)
    x2m=x2m+x2(i)*w(i)
    ym=ym+y(i)*w(i)
end do
x1m=x1m/wsum
x2m=x2m/wsum
ym=ym/wsum
!write (*,*) ym,x1m,x2m

do i=1,npts
    sx1x1=sx1x1+((x1(i)-x1m)**2.0d0)*w(i)
    sx2x2=sx2x2+((x2(i)-x2m)**2.0d0)*w(i)
    sx1x2=sx1x2+(x1(i)-x1m)*(x2(i)-x2m)*w(i)
    sx1y=sx1y+(x1(i)-x1m)*(y(i)-ym)*w(i)
    sx2y=sx2y+(x2(i)-x2m)*(y(i)-ym)*w(i)
end do
!write (*,*) sx1x1,sx2x2,sx1x2,sx1y,sx2y

bx1y=sx1y/sx1x1    ! b12
bx2y=sx2y/sx2x2    ! b13
bx2x1=sx1x2/sx2x2  ! b32
bx1x2=sx1x2/sx1x1  ! b23
!write (*,*) bx1y,bx2y,bx2x1,bx1x2 

b1=(bx1y-bx2y*bx1x2)/(1.0d0-bx1x2*bx2x1)
b2=(bx2y-bx1y*bx2x1)/(1.0d0-bx1x2*bx2x1)

b0=ym-(b1*x1m)-(b2*x2m)
!write (*,*) b0,b1,b2

sse=0.0d0; sst=0.0d0
do i=1,npts
    yhat(i)=b0+b1*x1(i)+b2*x2(i)
    resid(i)=y(i)-yhat(i)
    sse=sse+(resid(i)*dsqrt(w(i)))**2.0d0
    sst=sst+((y(i)-ym)*dsqrt(w(i)))**2.0d0
end do

mse=sse/dble(npts-2)
stderr=dsqrt(mse)
rsq=-1.0d0
sratio=sse/sst
if (sratio.le.1.0d0 .and. sratio.ge.0.0d0) rsq=1.0d0-sratio

end subroutine fitquad


subroutine sortxy(npts,x,y,xs,ys)
! sorts x,y pairs by values of x

implicit none

integer         :: npts
real(8)         :: x(npts),y(npts),xs(npts+1),ys(npts+1),tx,ty
integer         :: i,j,k,kp1
logical         :: flag

do i=1,npts
    xs(i)=x(i)
    ys(i)=y(i)
end do

i=0
flag=.true.
do 
    i=i+1
    j=npts-i
    flag=.false.
    do k=1,j
!    write (*,*) i,j,k
        kp1=k+1
        if (xs(k).gt.xs(kp1)) then
            tx=xs(kp1)
            ty=ys(kp1)
            xs(kp1)=xs(k)
            ys(kp1)=ys(k)
            xs(k)=tx
            ys(k)=ty
            flag=.true.
        end if
    end do
    if (.not.flag) exit
end do

end subroutine sortxy


subroutine medianx(npts,x,median)
! finds median of x

implicit none

integer         :: npts
real(8)         :: x(npts),xs(npts+1),tx,median
integer         :: i,j,k,kp1
logical         :: flag

do i=1,npts
    xs(i)=x(i)
end do

i=0
flag=.true.
do 
    i=i+1
    j=npts-i
    flag=.false.
    do k=1,j
!    write (*,*) i,j,k
        kp1=k+1
        if (xs(k).gt.xs(kp1)) then
            tx=xs(kp1)
            xs(kp1)=xs(k)
            xs(k)=tx
            flag=.true.
        end if
    end do
    if (.not.flag) exit
end do

! xs contains sorted values of x

select case (npts)
    case (0)
        median=0.0d0
    case (1)
        median=xs(1)
    case (2)
        ! crude definition
        median=xs(int(npts/2))
    case default
        ! statistical definition
        median=(xs(int(npts/2)+1) + xs(npts - int(npts/2) +2))/2.0d0
end select

end subroutine medianx


subroutine desc(npts,y,mean,stdev)

implicit none

integer     :: npts
real(8)     :: y(npts),mean,stdev
integer     :: i

mean=0.0d0
do i=1,npts
    mean=mean+y(i)
end do
mean=mean/dble(npts)
stdev=0.0d0
do i=1,npts
    stdev=stdev+(y(i)-mean)*(y(i)-mean)
end do
stdev=(sqrt(stdev/dble(npts-1)))

end subroutine desc

end module lwr