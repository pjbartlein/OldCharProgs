program slice_maps2	
! maps of paleofire indicators

use psc_inf

implicit none

integer, parameter	:: maxsites=1000, ns=43

real(8)		    :: lat,lon
real(8)		    :: y(maxsites),x(maxsites)
real            :: indata(ns)
integer         :: iyr,begyr,delyr
character(5)    :: stryr
character(2)    :: str
character(1)    :: plottype
character(128)  :: plottitle,extratext
character(1)    :: datatype
character(256)  :: version,transform,mapdate

character(14)   :: colorfile1,colorfile2,colorfile11,colorfile22
integer         :: nclr1,nclr2

integer		    :: i,j,npts,ntree,nice,nvars,nvrs

datapath="E:\Projects\igbpfire\charsum\data\work06\"

version="Database query:  b13.txt -- 1 Mar 2007"
transform="Data treatment:  Rescaled (whole record), Box-Cox transformed, Z-Scores (4000-100 cal yr BP base period)"
mapdate="20 Apr 2007"

datatype="a"

select case(datatype)

    case ('m')
        open (4,file="E:\Projects\igbpfire\charsum\data\work06\1kmeans.dat")
        datafile="1kmeans.dat"
        baseout="m"
        nvars=ns
        colorfile="zs03c.clr"; nclr=3 
        colorfile11="zs03c1.clr"; nclr1=1; colorfile22="zs03c2.clr"; nclr2=2
        plottitle="Mean Z-Scores of Charcoal Values (1000-yr Window)  "
        extratext=" (500 to 100 yr BP)"
    case ('a')
        open (4,file="E:\Projects\igbpfire\charsum\data\work06\1kanms.dat")
        datafile="1kanms.dat"
        baseout= "a" 
        nvars=ns-1
        colorfile="zs03ct.clr"; nclr=3 
        colorfile11="zs03ct1.clr"; nclr1=1; colorfile22="zs03ct2.clr"; nclr2=2
        plottitle="Anomalies of Z-Scores of Charcoal Values (1000-yr Window)  "
        extratext=" (1000 to 100 yr BP)"
    case ('s')
        open (4,file="E:\Projects\igbpfire\charsum\data\work06\1kstdev.dat")
        datafile="1kstdev.dat"
        baseout="s"
        nvars=ns
        colorfile="stddot6.clr"; nclr=6
        plottitle="Standard Deviation of Z-Scores of Charcoal Values (1000-yr Window)  "
        extratext=" (500 to 100 yr BP)"
        
end select

! constant parameters across maps -- global Robinson
!xorig=0.25; yorig=0.5; xlen=10.0; ylen=5.0
!xmin=-2.6662; xmax=2.6662; ymin=-1.3523 ; ymax=1.3523
!xleg=0.75; yleg=1.65
!res=300; frwide=10.5; frhigh=5.8

! constant parameters across maps -- NA Albers
xorig=0.75; yorig=2.0; xlen=7.00; ylen=7.78
xmin=-0.538000; xmax=0.635000; ymin=-1.051000; ymax=0.366000
xleg=0.75; yleg=1.65
res=300; frwide=8.5; frhigh=11.0

! get .mxy file
open (5,file="E:\Projects\igbpfire\charsum\data\work06\1kpts.mxy")
i=0
do while(.not.eof(4))
    i=i+1
    read (4,*) lat,lon,(indata(j),j=1,nvars)
    ! call robinson(lat,lon,x(i),y(i),1.0d0,0.0d0)
    call albers(1.0d0,66.6667d0,33.3333d0,-100.0d0,70.0d0,lat,lon,x(i),y(i))
    write (5,'(2f12.4,2f10.4)') lat,lon,x(i),y(i)
end do
nobs=i
write (*,*) i
close(4)
close(5)

begyr=21000
delyr=500
plottype="S"

locfile="1kpts.mxy"

do j=20,20 !1,nvars

    ! begin page

	iyr=begyr-(j-1)*delyr
	
	str=int_to_string3(j,2)
	str=trim(str)
	stryr=int_to_string3(iyr,5)
	
	write (*,'(i4,1x,a2,1x,2a6)') j,str,stryr

	infofile=trim(adjustl(baseout))//trim(stryr)//".inf"

	write (*,'(a128)') infofile

	orient="P"
	call psc_init(infofile,orient,1,0.0,0.0,1.0,datapath)
	call psc_comment("1 panel")

    ! panel
    xpanel=xorig; ypanel=yorig      
    call psc_panel (xpanel,ypanel,xlen,ylen,xmin,xmax,ymin,ymax)

    ! frame and basemap -- Robinson
    !mr=0.80; mg=0.80; mb=0.80; fr=-1.0; fg=-1.0; fb=-1.0; lwidth=0.25
    !mr=1.00; mg=1.00; mb=1.00; fr=-1.0; fg=-1.0; fb=-1.0; lwidth=0.25
    !mapfile="gl_frmxy.dat"; cornerfile="rob_00k.cnr "
    !call psc_map (mr,mg,mb,fr,fg,fb,lwidth,mapfile,cornerfile)
    !mr=-1.0; mg=-1.0; mb=-1.0; fr=0.80; fg=0.80; fb=0.80; lwidth=1.0
    !mapfile="gl_grtxy.dat"; cornerfile="rob_00k.cnr "
    !call psc_map (mr,mg,mb,fr,fg,fb,lwidth,mapfile,cornerfile)

    !mr=-1.0; mg=-1.0; mb=-1.0; fr=0.80; fg=0.80; fb=0.80; lwidth=1.0; cornerfile="rob_00k.cnr"
    !mapfile="robcost.dat"
    !call psc_map (mr,mg,mb,fr,fg,fb,lwidth,mapfile,cornerfile)
    !mapfile="robcntry.dat"
    !call psc_map (mr,mg,mb,fr,fg,fb,lwidth,mapfile,cornerfile)
    !mapfile="islnpoly.dat"
    !call psc_map (mr,mg,mb,fr,fg,fb,lwidth,mapfile,cornerfile)
    !mapfile="lakepoly.dat"
    !call psc_map (mr,mg,mb,fr,fg,fb,lwidth,mapfile,cornerfile)
    !mapfile="gl_frmxy.dat"
    !call psc_map (mr,mg,mb,fr,fg,fb,lwidth,mapfile,cornerfile)
    
    !  basemap -- NA Albers 
    mr=-1.0; mg=-1.0; mb=-1.0; fr=0.80; fg=0.80; fb=0.80; lwidth=1.0; cornerfile="na25.cnr"
    mapfile="atlasmap.dat"
    call psc_map (mr,mg,mb,fr,fg,fb,lwidth,mapfile,cornerfile)
    mapfile="lakes.dat"
    call psc_map (mr,mg,mb,fr,fg,fb,lwidth,mapfile,cornerfile)

    
    select case (plottype)

    case ("S")
        ! symbols
        isym=j; nvrs=nvars
        !call psc_symbol (isym,nvrs,nobs,datafile,nclr,colorfile,locfile)
        call psc_symbol (isym,nvrs,nobs,datafile,nclr1,colorfile11,locfile)
        call psc_symbol (isym,nvrs,nobs,datafile,nclr2,colorfile22,locfile)

        ! legend
        mr=1.0; mg=1.0; mb=1.0; fr=1.0; fg=1.0; fb=1.0; lwidth=0.25
        mapfile="legbox.dat"
        ! call psc_map (mr,mg,mb,fr,fg,fb,lwidth,mapfile,cornerfile)

        fmt=0.0; fsize=8.0; font="N"
        !ltype="S"; lorient="V"; xleg=xpanel+0.2; yleg=ypanel+0.2 ! yleg=ypanel+1.2
        ltype="S"; lorient="V"; xleg=xpanel+0.2; yleg=ypanel+1.0 
        xlbox=0.0; ylbox=0.125
        call psc_legend (fmt,fsize,font,ltype,lorient,xleg,yleg,xlbox,ylbox,nclr,colorfile)
    
    !case ("T")
    !    ! strings
    !    isym=j-2; nvrs=nvars-2; 
    !    locfile="b7_site.mxy"; fmt=0.0; fsize=5.0; font="H"; torient="H"; just="L"
    !    call psc_string (isym,nvrs,nobs,string,xpanel,ypanel,xlen,ylen,xmin,xmax,ymin,ymax, &
    !        x,y,fmt,fsize,font,torient,just)
        
    end select

    ! text	
    fmt=0.0; fsize=14.0; font="H"
    !xtext=xorig; ytext=yorig+ylen+0.05; torient="H"; just="L"
    xtext=xorig; ytext=yorig+ylen+0.05; torient="H"; just="L"
    text=trim(adjustl(plottitle))
    if (j.eq.nvars) text=trim(adjustl(text))//extratext
    call psc_text (fmt,fsize,font,xtext,ytext,torient,just,text)
    
    ! text	
    !fmt=0.0; fsize=14.0; font="H"
    !xtext=10.5; ytext=yorig+ylen+0.05; torient="H"; just="R"
    !text="n="//int_to_string(nobs)
    !call psc_text (fmt,fsize,font,xtext,ytext,torient,just,text)	
    
    ! text	
    fmt=0.0; fsize=14.0; font="H"
    !xtext=xorig+xlen; ytext=yorig+ylen+0.05; torient="H"; just="R"
    xtext=10.5; ytext=yorig+ylen+0.05; torient="H"; just="R"
    text=stryr//" cal yr BP"
    call psc_text (fmt,fsize,font,xtext,ytext,torient,just,text)	
     
    ! text	
    fmt=0.0; fsize=8.0; font="H"
    !xtext=2.5; ytext=0.3; torient="H"; just="L"
    xtext=xpanel; ytext=ypanel-0.1; torient="H"; just="L"
    call psc_text (fmt,fsize,font,xtext,ytext,torient,just,version)
    
    ! text	
    fmt=0.0; fsize=8.0; font="H"
    !xtext=xpanel; ytext=ypanel-0.2; torient="H"; just="L"    
    xtext=xpanel; ytext=ypanel-0.2; torient="H"; just="L"
    call psc_text (fmt,fsize,font,xtext,ytext,torient,just,transform)
    
    ! text	
    fmt=0.0; fsize=8; font="H"
    !xtext=10.0; ytext=0.5; torient="H"; just="R"
    xtext=xpanel; ytext=ypanel-0.3; torient="H"; just="L"
    call psc_text (fmt,fsize,font,xtext,ytext,torient,just,mapdate)	
    
    ! box
	r=0.0; g=0.0; b=0.0; bwidth=0.72
	call psc_box(r,g,b,bwidth)
        
    call psc_close
    pngfile=trim(adjustl(baseout))//trim(stryr)//".png"
	 psfile=trim(adjustl(baseout))//trim(stryr)//".ps"
	
	write (*,*) pngfile
	write (*,*) psfile
    call psc_ps (datapath,infofile)
    call psc_png (datapath,pngfile,psfile,frwide,frhigh,res)
	
end do

stop
end
