module chaps_subs

implicit none

contains

subroutine transform(n,trans,shift,quant,qmiss,tquant)

    implicit none

    integer, intent(in)     :: n
    real(4), intent(in)     :: trans
    real(4), intent(in)     :: quant(n),qmiss
    real(4), intent(out)    :: tquant(n)
    real(4)                 :: shift

    integer(4)              :: i

    ! transformation
    
    tquant=qmiss
    if (trans .eq. 1.0) then        ! no transformation
        do i=1,n
            if (quant(i).ne.qmiss) tquant(i)=quant(i)
        end do
        
    elseif (trans .eq. 0.5) then    ! square-root transformation
        do i=1,n
            if (quant(i).ne.qmiss) tquant(i)=sqrt(quant(i))
        end do 
        
    elseif (trans .eq. 0.0) then    ! log transformation
        
        do i=1,n
            if (quant(i) .ne. qmiss) tquant(i)=log(quant(i)+shift)
        end do
    
    else                            ! other (power) transformation
        do i=1,n
            if (quant(i) .ne. qmiss) tquant(i)=quant(i)**trans
        end do
    end if
    
end subroutine transform


subroutine untransform(n,trans,shift,tquant,qmiss,quant)

    implicit none

    integer, intent(in)     :: n
    real(4), intent(in)     :: trans
    real(4), intent(in)     :: tquant(n),qmiss
    real(4), intent(out)    :: quant(n)
    real(4)                 :: shift

    integer(4)              :: i

    ! untransformation
    
    quant=qmiss
    if (trans .eq. 1.0) then        ! no transformation
        do i=1,n
            if (tquant(i).ne.qmiss) quant(i)=tquant(i)
        end do
        
    elseif (trans .eq. 0.5) then    ! square-root transformation
        do i=1,n
            if (tquant(i).ne.qmiss) quant(i)=tquant(i)*tquant(i)
        end do 
        
    elseif (trans .eq. 0.0) then    ! log transformation
        
        do i=1,n
            !if (tquant(i) .ne. qmiss) quant(i)=exp(tquant(i)+(tquant(i)/2.0))-shift
            if (tquant(i) .ne. qmiss) quant(i)=exp(tquant(i))-shift
        end do
    
    else                            ! other (power) transformation
        do i=1,n
            if (quant(i) .ne. qmiss) quant(i)=tquant(i)**(1.0/trans)
        end do
    end if
    
end subroutine untransform


subroutine meanfit(n,yinsngl,qmsngl,xinsngl,wintype,widthsngl,order,nrobust,yfitsngl)

    use lwr         ! lwr_module.f90

    implicit none

    integer             :: n,nt
    real(4)             :: xinsngl(n),qmsngl,yinsngl(n),widthsngl,yfitsngl(n)
    real(8)             :: xin(n),yin(n),xt(n),param,yfit(n)
    integer             :: order,nrobust,ntarg,i
    character(1)        :: wintype
    logical             :: yfitnan
    
    write (10,'("in meanfit...")')

    ! note that lowess expects real(8) values, so convert types
    xin=dble(xinsngl)
    yin=dble(yinsngl)
    nt=n
    xt=xin
    param=dble(widthsngl)

    write (*,'("Calling lowess from meanfit, n=",i6," nt=",i4)') n,nt
    write (*,'("Calling lowess from meanfit, n=",i6," nt=",i4)') n,nt
    call lowess(n,xin,yin,nt,xt,wintype,param,order,nrobust,yfit)

    yfitsngl=sngl(yfit)
    
    ! check for NaN of fitted values 
    do i=1,n
        yfitnan=.false.
        if (isnan(yfit(i))) then 
            yfitnan=.true.  
            yfitsngl(i)=0.0     
            write (*,'("yfit=NaN, ",i5,1x,g14.6,g14.6," substituted")') i,xt(i),yfitsngl(i)
            write (10,'("yfit=NaN, ",i5,1x,g14.6,g14.6," substituted")') i,xt(i),yfitsngl(i)
        end if
    end do

end subroutine meanfit


subroutine fitlwr(n,yinsngl,qmsngl,xinsngl,wintype,widthsngl,order,nrobust,yfitsngl)

    use lwr         ! lwr_module.f90

    implicit none

    integer             :: n,nt
    real(4)             :: xinsngl(n),qmsngl,yinsngl(n),widthsngl,yfitsngl(n)
    real(8)             :: xin(n),yin(n),xt(n),param,yfit(n)
    integer             :: order,nrobust,ntarg
    character(1)        :: wintype
    
    write (10,'("in fitlwr...")')

    ! note that lowess expects real(8) values, so convert types
    xin=dble(xinsngl)
    yin=dble(yinsngl)
    nt=n
    xt=xin
    param=dble(widthsngl)

    write (*,'("Calling lowess from fitlwr, n=",i6," nt=",i4)') n,nt
    write (10,'("Calling lowess from fitlwr, n=",i6," nt=",i4)') n,nt
    call lowess(n,xin,yin,nt,xt,wintype,param,order,nrobust,yfit)

    yfitsngl=sngl(yfit)

end subroutine fitlwr


subroutine fitlwr2(n,yinsngl,qmsngl,xinsngl,nt,xtsngl,wintype,widthsngl,order,nrobust,yfitsngl)

    use lwr         ! lwr_module.f90

    implicit none

    integer             :: n,nt
    real(4)             :: xinsngl(n),qmsngl,yinsngl(n),xtsngl(nt),widthsngl,yfitsngl(nt)
    real(8)             :: xin(n),yin(n),xt(nt),param,yfit(nt)
    integer             :: order,nrobust,ntarg
    character(1)        :: wintype
    integer             :: i
    
    write (10,'("in fitlwr2...")')

    ! note that lowess expects real(8) values, so convert types
    xin=dble(xinsngl)
    yin=dble(yinsngl)
    xt=dble(xtsngl)
    param=dble(widthsngl)

    write (*,'("Calling lowess from fitlwr2, n=",i6," nt=",i4)') n,nt
    write (10,'("Calling lowess from fitlwr2, n=",i6," nt=",i4)') n,nt     
    call lowess(n,xin,yin,nt,xt,wintype,param,order,nrobust,yfit)

    yfitsngl=sngl(yfit)
    
!    do i=1,nt
!        if (isnan(yfitsngl(i))) yfitsngl(i)=0.0
!    end do  
    
end subroutine fitlwr2


subroutine peakmag(n,age,quant,peak,pmag)

    implicit none
    
    integer(4)      :: n
    real(4)         :: age(n),quant(n),ptotal,pmag(n)
    integer(4)      :: peak(n)
    integer(4)      :: i
    
    write (10,'("in peakmag...")')
    
    ptotal=0.0
    if (peak(n).eq.1) ptotal=ptotal+quant(n)*(age(n)-age(n-1))
    do i=n-1,1,-1
        pmag(i)=0.0
        if (peak(i).eq.1) then
            ptotal=ptotal+quant(i)*(age(i+1)-age(i))
        else
            pmag(i+1)=ptotal
            ptotal=0.0
        end if
    end do
    pmag(1)=0.0
    if (peak(1).eq.1) pmag(1)=ptotal
    
    do i=1,n
        if (isnan(pmag(i))) pmag(i)=0.0d0
    end do

end subroutine peakmag


subroutine peakprob(n,age,peak,smooth,pprob)

    implicit none
    
    integer(4)      :: n
    real(4)         :: age(n),smooth,pprob(n),uage,lage
    integer(4)      :: peak(n),npts,ptotal
    integer(4)      :: i,ii
    
    write (10,'("in peakprob...")')
    
    pprob=0.0
    
    do i=1,n
        ptotal=0
        npts=0
        uage=age(i)+smooth
        lage=age(i)-smooth
        do ii=1,n
            if (age(ii).ge.lage .and. age(ii).le.uage) then
                npts=npts+1
                if (peak(ii).eq.1) ptotal=ptotal+1
            end if
        end do
        if (npts.gt.0) then
            pprob(i)=sngl(ptotal)/sngl(npts)
        end if
    end do
    
    do i=1,n
        if (isnan(pprob(i))) pprob(i)=0.0d0
    end do


end subroutine peakprob


subroutine smpeakprob(n,age,peak,wintype,smooth,order,nrobust,smpprobsngl)

    use lwr
    
    implicit none
    
    integer(4)      :: n
    real(4)         :: age(n),smooth,uage,lage,smpprobsngl(n)
    integer         :: order,nrobust
    character(1)    :: wintype
    real(8)         :: agein(n),agetarg(n),param,pprob(n),smpprob(n)
    integer(4)      :: peak(n),npts,ptotal
    integer(4)      :: i,ii
    
    write (10,'("in smpeakprob...")')

    pprob=0.0d0

    do i=1,n
        ptotal=0
        npts=0
        uage=age(i)+smooth
        lage=age(i)-smooth
        do ii=1,n
            if (age(ii).ge.lage .and. age(ii).le.uage) then
                npts=npts+1
                if (peak(ii).eq.1) ptotal=ptotal+1
            end if
        end do
        pprob(i)=dble(ptotal)/dble(npts)
    end do
    
    agein=dble(age)
    agetarg=agein
    param=dble(smooth)
    
    ! lowess
    write (*,'("Calling lowess from smpeakprob, n=",i4)') n    
    write (10,'("Calling lowess from smpeakprob, n=",i4)') n
    call lowess(n,agein,pprob,n,agetarg,wintype,param,order,nrobust,smpprob)
    
    do i=1,n
        if (isnan(smpprob(i))) smpprob(i)=0.0d0
    end do

    smpprobsngl=sngl(smpprob)

end subroutine smpeakprob       


subroutine peakcount(n,age,peak,smooth,interval,pcount)

    implicit none
    
    integer(4)      :: n
    real(4)         :: age(n),smooth,uage,lage,interval,winwidth,agemin,pcount(n)
    integer(4)      :: peak(n),npts,ptotal
    integer(4)      :: i,ii
    
    write (10,'("in peakcount...")')

    pcount=0
    agemin=minval(age(1:n))
    
    do i=1,n
        ptotal=0
        npts=0
        uage=age(i)+smooth
        lage=age(i)-smooth
        if (lage.lt.agemin) lage=agemin
        winwidth=uage-lage
        do ii=1,n
            if (age(ii).ge.lage .and. age(ii).le.uage) then
                npts=npts+1
                if (peak(ii).eq.1) ptotal=ptotal+1
            end if
        end do
        pcount(i)=sngl(ptotal)*(interval/(2.0*winwidth))
    end do
    
    do i=1,n
        if (isnan(pcount(i))) pcount(i)=0.0d0
    end do

end subroutine peakcount        


subroutine smpeakcount(n,age,rpeak,wintype,smooth,order,nrobust,interval,smpcountsngl)

    use lwr
    
    implicit none
    
    integer(4)      :: n
    real(4)         :: age(n),rpeak(n),smooth,uage,lage,interval,winwidth,agemin,smpcountsngl(n)
    integer         :: order,nrobust
    character(1)    :: wintype
    real(8)         :: agein(n),agetarg(n),param,pcount(n),smpcount(n)
    integer(4)      :: npts,ptotal
    integer(4)      :: i,ii

    write (10,'("in smpeakcount...")')

    pcount=0.0d0
    agemin=minval(age(1:n))

    do i=1,n
        ptotal=0
        npts=0
        uage=age(i)+smooth
        lage=age(i)-smooth
        if (lage.lt.agemin) lage=agemin
        winwidth=uage-lage
        do ii=1,n
            if (age(ii).ge.lage .and. age(ii).le.uage) then
                npts=npts+1
                if (rpeak(ii).eq.1.0) ptotal=ptotal+1
            end if
        end do
        pcount(i)=dble(ptotal)*dble(interval/(2.0*winwidth))
    end do
    
    agein=dble(age)
    agetarg=agein
    param=dble(smooth)
    
    ! lowess
    write (*,'("Calling lowess from smpcount, n=",i4)') n
    write (10,'("Calling lowess from smpcount, n=",i4)') n   
    call lowess(n,agein,pcount,n,agetarg,wintype,param,order,nrobust,smpcount)

    do i=1,n
        if (isnan(smpcount(i))) then
            smpcount(i)=0.0d0
    !        write (*,'("smpcount")') smpcount(i)
    !        pause
        end if
    end do
    
    smpcountsngl=sngl(smpcount)
    
end subroutine smpeakcount      
  

subroutine smoothmag(n,age,pmag,wintype,smooth,order,nrobust,magsngl)

    use lwr
    
    implicit none
    
    integer(4)      :: n,npts
    real(4)         :: age(n),pmag(n),smooth,magsngl(n),qmiss
    integer         :: order,nrobust
    character(1)    :: wintype
    real(8)         :: agein(n),pmagin(n),agetarg(n),param,mag(n)
    integer         :: i,ii
    
    write (10,'("in smoothmag...")')
    
    param=dble(smooth)
    qmiss=-9999.0
    
    ! collect points with nonzero pmag
    ii=0
    do i=1,n
        if (pmag(i).gt.0.0) then
            ii=ii+1
            agein(ii)=dble(age(i))
            pmagin(ii)=dble(pmag(i))
            !write (*,*) ii,agein(ii),pmagin(ii)
        end if
    end do
    npts=ii   
       
    ! lowess
    agetarg=age
    write (*,'("Calling lowess from smoothmag, npts=",i4)') npts
    write (10,'("Calling lowess from smoothmag, npts=",i4)') npts
    call lowess(npts,agein,pmagin,n,agetarg,wintype,param,order,nrobust,mag)
    
    do i=1,n
        if (isnan(mag(i))) mag(i)=0.0d0
    end do
    
    ! clamp
    do i=1,n
        if (mag(i).lt.0.0d0) mag(i)=0.0
    end do
    
    magsngl=sngl(mag)

end subroutine smoothmag


subroutine detrcum(n,x,dcx)

    implicit none
    
    integer(4)      :: n
    real(4)         :: x(n),dcx(n)
    real(8)         :: xtotal,cumx
    integer(4)      :: i
    
    write (10,'("in detrcum...")')
    
    xtotal=0.0d0
    do i=1,n
        xtotal=xtotal+dble(x(i))
    end do
    
    cumx=0.0d0
    do i=n,1,-1
        cumx=cumx+dble(x(i))
        dcx(i)=(cumx/xtotal)-(dble(n-i+1)/dble(n))
    end do
    
    do i=1,n
        if (isnan(dcx(i))) dcx(i)=0.0d0
    end do

end subroutine detrcum    
    
    
end module chaps_subs