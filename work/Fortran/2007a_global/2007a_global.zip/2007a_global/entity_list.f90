program entity_list
! makes a list of entities and their lats and lons

implicit none

integer,parameter   :: maxent=10000
real                :: latin,lonin,lat(maxent),lon(maxent)
integer             :: ent,entity(maxent),i
character(1)        :: header

open (1,file="e:\Projects\igbpfire\nachar\data\na_pollen\entity_full.dat")
open (2,file="e:\Projects\igbpfire\nachar\data\na_pollen\entity_latlon.dat")

entity=-9999
read (1,*) header
do
    if (eof(1)) exit
    read (1,*) ent,latin,lonin
        entity(ent)=ent
        lat(ent)=latin
        lon(ent)=lonin
end do

do i=1,maxent
    if (entity(i).ne.-9999) then
        write (2,'(i5,2f10.4)') entity(i),lat(i),lon(i)
    end if
end do

end