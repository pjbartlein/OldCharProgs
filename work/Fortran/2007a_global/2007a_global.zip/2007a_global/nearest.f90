program nearest
! assigns values from closest point to target point

implicit none

integer, parameter  :: maxpts=60000     ! maximum number of data points (control points)
integer, parameter  :: nv=9             ! number of variables

real(8)             :: lat(maxpts),lon(maxpts)  ! lats and lons of data points
real                :: var(maxpts,nv)           ! data

real(8)             :: tlat,tlon                ! lats and lons of target points
real(8)             :: dist,dmin                ! distances between data points and target points
real(8)             :: gdist

character(1)        :: dum                      ! dummy variable to read 1st line
integer             :: i,npts,j,nt,imin,ii                        

open (1,file="E:\Projects\igbpfire\spitfire\yan\ave_fire4varbs_modern_05x05.txt")
open (2,file="E:\Projects\igbpfire\spitfire\data\model_output02\05_target_pts.dat")   
open (3,file="E:\Projects\igbpfire\spitfire\data\model_output02\mod05.dat")

! read data
read (1,*) dum      ! read the first line
i=0
do while (.not. eof(1))
    i=i+1
    if (mod(i,100).eq.0) print *, i
    read (1,*) lon(i),lat(i),(var(i,j),j=1,nv)
end do
npts=i
print *,npts

! read a target point, loop over the control points and find the closest one
nt=0
do while(.not. eof(2))
    read (2,*) tlat,tlon
    nt=nt+1
    dmin=99999999.0d0
    if (mod(nt,100).eq.0) print *, nt
    do i=1,npts
      dist=gdist(tlat,tlon,lat(i),lon(i))
        if (dist.lt.dmin) then
            dmin=dist
            imin=i
        end if
    end do
    ii=imin
    
    write (3,'(2f8.2,3f12.1,6f10.3)') tlat,tlon,(var(ii,j),j=1,nv)

end do 
         
end program
  
