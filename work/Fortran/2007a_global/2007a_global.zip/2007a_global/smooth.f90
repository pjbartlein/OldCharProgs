program smooth
! fits a smooth lowess-type curve to transformed/standardized charcoal data

use lowess      ! use the lowess module

implicit none

integer, parameter  :: maxdata=100000
integer(4)      :: site_sample,id_sample
real(4)         :: depth,age,quant,qmnx,tquant_all,tquant_4k,tquant_2k
real(4)         :: zquant_all,zquant_4k,zquant_2k,ztquant_all,ztquant_4k,ztquant_2k
real(4)         :: varin,qmiss
character(8)    :: site_num_label

real(4)         :: begyr,endyr

real(8)         :: xin(maxdata),yin(maxdata),xtarg(maxdata),yfit(maxdata),param
real(8)         :: targbeg,targend,targstep
integer(4)      :: order,nrobust,ntarg
character(1)    :: wintype,header

integer         :: i,ii,ndata,npts
character(256)  :: datapath,plotpath,infile,ptsfile,lowfile,labelfile

infile="HS_2c_allsmooth.csv" !"HS_2c_allsamples.csv"

ptsfile="tquant_2k_sm.csv"  !"tquant_2k.csv"  !"ztquant_2k.csv" !"tquant_all.csv" !
lowfile="tquant_2k_40yr_sm.csv"  !"tquant_2k_40yr.csv"  !"ztquant_2k_20yr.csv" !"tquant_all_20yr.csv" !
labelfile="tquant_2k_40yr_sm.txt" !"tquant_2k_40yr.txt" !"ztquant_2k_20yr.txt" !"tquant_all_20yr.txt" !
!!!!!!!!!! change varin too

datapath="\Projects\igbpfire\charsum\data\current_hs2\files\"
plotpath="\Projects\igbpfire\charsum\data\plots01\"

! lowess parameters
param=40.0d0; wintype='w'; order=1; nrobust=1

! target point definitions
targend=2000.0d0; targbeg=-60.0d0; targstep=10.0d0

! overall age range of data
begyr=2020.0; endyr=-60.0

qmiss=-9999.0

! read data, and save age and variable to be smoothed
open (10,file="\Projects\igbpfire\charsum\data\current_hs2\files\HS_2c_debug3sm.dat")
open (1,file=trim(adjustl(datapath))//trim(adjustl(infile)))
read (1,*) header
i=0
do while (.not. eof(1))
    !read (1,*) site_num_label,site_sample,id_sample,age,depth,quant,qmnx,tquant_all,tquant_4k,tquant_2k, &
    !            zquant_all,zquant_4k,zquant_2k,ztquant_all,ztquant_4k,ztquant_2k
    !varin=tquant_2k !ztquant_2k  !tquant_all !
    read (1,*) site_num_label,age,varin
    if (age.le.begyr .and. age.ge.endyr .and. varin.ne.qmiss) then
        i=i+1
        xin(i)=dble(age)              ! x-variable for lowess
        yin(i)=dble(varin)            ! y-variable for lowess
        write (10,*) i,site_num_label,sngl(xin(i)),sngl(yin(i))
    end if
end do
npts=i
write (*,*) npts
close(1)
               
! generate target points
ntarg=int((targend-targbeg)/targstep)+1
do i=1,ntarg
    xtarg(i)=targend-dble(i-1)*targstep
    write (10,*) i,sngl(xtarg(i))
end do

! get the lowess curve
call lowess_curve(npts,xin,yin,ntarg,xtarg,wintype,param,order,nrobust,yfit)

! write data and curve for plotting, plus some labels

open (1,file=trim(adjustl(plotpath))//trim(adjustl(ptsfile)))
open (2,file=trim(adjustl(plotpath))//trim(adjustl(lowfile)))
open (3,file=trim(adjustl(plotpath))//trim(adjustl(labelfile)))
write (2,'("  targ_age,  tquant_2k_40yr_sm")')
do i=1,npts
    write (1,'(f10.2,f12.4)') xin(i),yin(i)
end do
do i=1,ntarg
    write (2,'(f10.2,",",f12.4)') xtarg(i),yfit(i)
end do
write (3,'("""",a20,"; param=",f4.1,"; wintype=",a1,"; order=",i1,"; nrobust=",i1,"""")') &
    trim(adjustl(lowfile)),param,wintype,order,nrobust
close(1)
close(2)
close(3)

end program smooth