program get_anom

implicit none

integer, parameter  :: maxpts=65000
real(8)     :: slat(maxpts),slon(maxpts)
real        :: area_anom (maxpts),bmass_anom(maxpts)
real        :: ignite_anom
real(8)     :: clat,clon
real        :: char00,char06,char21,char_anom06,char_anom21
real(8)     :: dist,dmin,gdist

integer     :: sitenum,i,npts,ii,imin

open (1,file="E:\Projects\igbpfire\spitfire\data\model_output02\fa21k00k.dat")
open (3,file="E:\Projects\igbpfire\spitfire\data\model_output02\b13_site.dat")
open (4,file="E:\Projects\igbpfire\spitfire\data\model_output02\ens21a_sim.dat")

i=0
do while (.not. eof(1))
    i=i+1
    read (1,*) slat(i),slon(i),area_anom(i),ignite_anom,bmass_anom(i)
end do
npts=i
print *,npts

write (4,'("lat,lon,sitenum,char_anom,area_anom,bmass_anom")')
do while (.not.eof(3))
    read (3,*) clat,clon,sitenum,char00,char06,char21,char_anom06,char_anom21
    dmin=99999999.0d0
    do i=1,npts
        dist=gdist(clat,clon,slat(i),slon(i))
        if (dist.lt.dmin) then
            dmin=dist
            imin=i
        end if
    end do
    ii=imin
    
    write (4,'(2f10.4,i5,2(f14.3,2f12.1),1x,i6)') &
!        clat,clon,sitenum,char_anom06,area_anom(ii),bmass_anom(ii)
        clat,clon,sitenum,char_anom21,area_anom(ii),bmass_anom(ii)
end do

end