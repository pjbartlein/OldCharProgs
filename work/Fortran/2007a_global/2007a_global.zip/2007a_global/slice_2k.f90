program slice_2k
! summarize charcoal data -- narrow windows, last 2kyr

use summarize_subs

implicit none

! declarations -- other declarations are in module summarize_subs

integer, parameter  ::  ns=41, maxreg=30                ! number of slices, regions
integer(4)      :: id_site(maxdata),id_site2(maxdata)   ! site id's
real(4)         :: id_site2_real
integer(4)      :: id_sample(maxdata)                   ! sample id's
real(4)         :: age_in(maxdata),age(maxrec)          ! ages
character(4)    :: units_in(maxdata),units(maxsites)     ! units of measurement
character(4)    :: context_in(maxdata),context(maxsites)    ! depositional context
character(4)    :: status_in(maxdata),status(maxsites)      ! database status
character(4)    :: source_in(maxdata),source(maxsites)      ! charcoal data source                 
real(4)         :: quant_in(maxdata),quant(maxrec)      ! quantity
real(4)         :: lat(maxdata),lon(maxdata)            ! decimal lat and lon
real(4)         :: lat_in,lon_in
integer         :: id_site_in(maxdata),id_sample_in(maxdata)
character(4)    :: id_site_char
character(80)   :: site_name(maxdata),site_name_in


real(4)         :: lambda, shift, lhmax                 ! Box-Cox transformation parameters

real(4)         :: site_lat(maxsites)
real(4)         :: site_lon(maxsites)                   ! decimal lat and lon
real(4)         :: qmiss                                ! quantity missing data code

integer(4)      :: site(maxsites), npts(maxsites)       ! site id's and number of points in block
integer(4)      :: bstart(maxsites),bend(maxsites)      ! block start and end obs numbers
integer         :: firstyr(maxsites),lastyr(maxsites)                       

real(4)         :: trans,tquant(maxrec)                 ! transformation parameter and series
real(4)         :: z(maxrec),zt(maxrec)                 ! zscores
real(4)         :: qmnx(maxrec),qmnxt(maxrec)           ! minimax transformed

real(4)         :: begbase,endbase                      ! beginning and end of base period for stats
integer(4)      :: ndata
real(4)         :: begint(ns),midint(ns),endint(ns)
real(4)         :: bmean,bstdev,bmin,bmax,brng        ! basic stats for an interval (no trans)
real(4)         :: bmeant,bstdevt,bmint,bmaxt,brngt        ! basic stats for an interval (no trans)
real(4)         :: qmean(maxsites,ns),qstdev(maxsites,ns),qmin(maxsites,ns),qmax(maxsites,ns),qrng(maxsites,ns)        ! basic stats for an interval (no trans)
real(4)         :: qmeant(maxsites,ns),qstdevt(maxsites,ns),qmint(maxsites,ns),qmaxt(maxsites,ns),qrngt(maxsites,ns)   ! basic stats for an interval (transformed)
real(4)         :: anm(maxsites,ns),anmt(maxsites,ns),dzt(maxsites,ns)
integer(4)      :: nbase,nin(maxsites,ns),tlabel(ns)

real(4)         :: rlatmax(maxreg),rlatmin(maxreg),rlonmax(maxreg),rlonmin(maxreg)
real(4)         :: regavez(ns,maxreg),regaveanm(ns,maxreg),countcut
integer(4)      :: ncounts(ns,maxreg),nposanm(ns,maxreg),nneganm(ns,maxreg)
integer(4)      :: nneut(ns,maxreg),ngt(ns,maxreg),nlt(ns,maxreg),nreg,n
character(8)    :: region(maxreg)
character(1)    :: dum,header


real(4)         :: begyr,yrinc,hw

integer(4)      :: i,ii,j,k,nsites,nsites2

open (1,file="e:\Projects\igbpfire\charsum\data\current_hs1\files\HS_1b.txt")
open (2,file="e:\Projects\igbpfire\charsum\data\work08\1kmeans.dat")
open (3,file="e:\Projects\igbpfire\charsum\data\work08\1kanms.dat")
open (4,file="e:\Projects\igbpfire\charsum\data\work08\1kstdev.dat")
open (5,file="e:\Projects\igbpfire\charsum\data\current_hs1\files_2k\100ymean.csv")
open (6,file="e:\Projects\igbpfire\charsum\data\current_hs1\files_2k\100yanom.csv")
open (7,file="e:\Projects\igbpfire\charsum\data\current_hs1\files_2k\100ystdv.csv")
open (8,file="e:\Projects\igbpfire\charsum\data\current_hs1\files_2k\regions.csv")
open (10,file="e:\Projects\igbpfire\charsum\data\current_hs1\files\HS_1b_site_list.csv")
open (11,file="e:\Projects\igbpfire\charsum\data\current_hs1\files_2k\2k_reg_nrecs.csv")
open (12,file="e:\Projects\igbpfire\charsum\data\current_hs1\files_2k\2k_reg_npos.csv")
open (13,file="e:\Projects\igbpfire\charsum\data\current_hs1\files_2k\2k_reg_nneg.csv")
open (14,file="e:\Projects\igbpfire\charsum\data\current_hs1\files_2k\2k_reg_avez.csv")
open (15,file="e:\Projects\igbpfire\charsum\data\current_hs1\files_2k\2k_reg_aveanm.csv")
open (16,file="e:\Projects\igbpfire\charsum\data\current_hs1\files_2k\2k_reg_nneut.csv")
open (17,file="e:\Projects\igbpfire\charsum\data\current_hs1\files_2k\2k_reg_ngt.csv")
open (18,file="e:\Projects\igbpfire\charsum\data\current_hs1\files_2k\2k_reg_nlt.csv")
open (19,file="e:\Projects\igbpfire\charsum\data\work08\100ydelt.dat")
open (20,file="e:\Projects\igbpfire\charsum\data\current_hs1\files_2k\100ydelt.csv")

! set summarization parameter values
qmiss=-9999.0       ! missing data code
begbase=-100.0       ! begining of base period
endbase=2000.0      ! end of base period
begyr=2000.0       ! beginning of intervals

shift=0.01          ! Box-Cox transformation shift parameter (input)

! get slice widths

begyr=2000.0
hw=50.0

! threshold for determining regional counts
countcut=0.375

! generate individual windows
do j=1,ns
    midint(j)=begyr-(j-1)*hw
    begint(j)=begyr-(j-1)*hw-hw
    endint(j)=begyr-(j-1)*hw+hw
    tlabel(j)=int(midint(j))
    write (*,*) j,begint(j),midint(j),endint(j),tlabel(j)
end do
pause
!j=42
!begint(j)=100.0
!endint(j)=1000.0
!midint(j)=500.0
!tlabel(j)=int(midint(j))
!write (*,*) j,begint(j),midint(j),endint(j),tlabel(j)
!j=43
!begint(j)=100.0
!endint(j)=500.0
!midint(j)=500.0
!tlabel(j)=0
!write (*,*) j,begint(j),midint(j),endint(j),tlabel(j)

! get regional boundaries region,n_lat,s_lat,w_lon,e_lon
i=0
read (8,*) dum
do
    if (eof(8)) exit
    i=i+1
    read (8,*) region(i),rlatmax(i),rlatmin(i),rlonmin(i),rlonmax(i)
    write (*,'(i4,1x,a8,4f10.4)') i,region(i),rlatmax(i),rlatmin(i),rlonmin(i),rlonmax(i)

end do
nreg=i

! write headers
write (5,'("id_site,site_lat,site_lon",43(",",i5))') (tlabel(j),j=1,ns)
write (6,'("id_site,site_lat,site_lon",43(",",i5))') (tlabel(j),j=1,ns-1)
write (7,'("id_site,site_lat,site_lon",43(",",i5))') (tlabel(j),j=1,ns)
write (11,'("slice   ",30(",",a8))') (region(n),n=1,nreg)
write (12,'("slice   ",30(",",a8))') (region(n),n=1,nreg)
write (13,'("slice   ",30(",",a8))') (region(n),n=1,nreg)
write (14,'("slice   ",30(",",a8))') (region(n),n=1,nreg)
write (15,'("slice   ",30(",",a8))') (region(n),n=1,nreg)
write (16,'("slice   ",30(",",a8))') (region(n),n=1,nreg)
write (17,'("slice   ",30(",",a8))') (region(n),n=1,nreg)
write (18,'("slice   ",30(",",a8))') (region(n),n=1,nreg)


! read data

! read all data and determine number of blocks
call read_data(ndata, id_site_in, id_sample_in, units_in, age_in, quant_in, &
                context_in, source_in, nsites, &
                site, units, context, source, bstart, bend, npts)
write (*,'("nsites from read_data: ",i5)') nsites

! read site_list query file
i=0
read (10,*) header
do
    if (eof(10)) exit
    i=i+1
    read (10,*) id_site2_real,site_name_in,lat_in,lon_in
    id_site2(i)=int(id_site2_real)
    lat(id_site2(i))=lat_in
    lon(id_site2(i))=lon_in
    site_name(id_site2(i))=site_name_in
    write (*,*) i,id_site2_real,id_site2(i)
end do
nsites2=i

! loop over site id/units blocks

do j=1,nsites
    site_lat(j)=lat(site(j))
    site_lon(j)=lon(site(j))
    write (*,*) j,site_lat(j),site_lon(j),site(j)
            
    ! load arrays
    ii=0
    do i=bstart(j),bend(j)
        ii=ii+1
        age(ii)=age_in(i)
        quant(ii)=quant_in(i)
    end do  

    ! call Box-Cox transformation of charcoal quantities
    call boxcox(npts(j),quant,qmiss,shift,lambda,lhmax,tquant)
    
    ! basic statistics for an interval from transformed values
    call stats(npts(j),age,tquant,qmiss,begbase,endbase,nbase,bmeant,bstdevt,bmint,bmaxt,brngt)
    
    ! z-scores of transformed values
    call zscores(npts(j),tquant,qmiss,bmeant,bstdevt,zt)

    ! call summarization subroutines for this block:  individual time slices
    
    do k=1,ns
    
    ! basic statistics for an interval from transformed values
    call stats(npts(j),age,zt,qmiss,begint(k),endint(k),nin(j,k),qmeant(j,k),qstdevt(j,k),qmint(j,k),qmaxt(j,k),qrngt(j,k))       
    !write (*,*) j,k,ndata,nin(j,k),meant(j,k)
    !pause
    end do
    
    do k=1,ns
        anm(j,k)=qmiss
        if (qmeant(j,k).ne.qmiss .and.qmeant(j,ns-1).ne.qmiss) then
            anm(j,k)=qmeant(j,k)-qmeant(j,ns-1)
        end if
    end do
    
    dzt=qmiss
    do k=2,ns
        if (qmeant(j,k).ne.qmiss .and.qmeant(j,k-1).ne.qmiss) then
            dzt(j,k)=qmeant(j,k)-qmeant(j,k-1)
        end if
    end do
    
    write (2,'(2f10.4,50f10.3)') lat(site(j)),lon(site(j)),(qmeant(j,k),k=1,ns)
    write (3,'(2f10.4,50f10.3)') lat(site(j)),lon(site(j)),(anm(j,k),k=1,ns-1)
    write (4,'(2f10.4,50f10.3)') lat(site(j)),lon(site(j)),(qstdevt(j,k),k=1,ns)
    write (5,'(i5,",",f10.4,",",f10.4,43(",",f10.3))') site(j),site_lat(j),site_lon(j),(qmeant(j,k),k=1,ns)
    write (6,'(i5,",",f10.4,",",f10.4,43(",",f10.3))') site(j),site_lat(j),site_lon(j),(anm(j,k),k=1,ns-1)
    write (7,'(i5,",",f10.4,",",f10.4,43(",",f10.3))') site(j),site_lat(j),site_lon(j),(qstdevt(j,k),k=1,ns)
    write (19,'(2f10.4,50f10.3)') lat(site(j)),lon(site(j)),(dzt(j,k),k=1,ns)
    write (20,'(i5,",",f10.4,",",f10.4,43(",",f10.3))') site(j),site_lat(j),site_lon(j),(dzt(j,k),k=1,ns)

end do

ncounts=0; nposanm=0; nneganm=0; regavez=0.0; regaveanm=0.0; nneut=0; ngt=0; nlt=0
do k=1,ns
    do n=1,nreg
        do j=1,nsites
        !if (n.eq.7) write (*,'(2i4,f11.4)') j,k,qmeant(j,k)
            if (site_lat(j).le.rlatmax(n) .and. site_lat(j).ge.rlatmin(n)) then
                if (site_lon(j).ge.rlonmin(n) .and. site_lon(j).le.rlonmax(n)) then
                    if (qmeant(j,k).ne.qmiss) then
                        ncounts(k,n)=ncounts(k,n)+1
                        regavez(k,n)=regavez(k,n)+qmeant(j,k)
                    end if
                    if (n.eq.7) write (*,'(3i4,2f11.4)') j,k,n,regavez(k,n),qmeant(j,k)
                    if (anm(j,k).ne.qmiss) then
                        if (anm(j,k).gt.0.0) then
                            nposanm(k,n)=nposanm(k,n)+1
                        else
                            nneganm(k,n)=nneganm(k,n)+1
                        end if    
                        if (anm(j,k).ge.countcut) ngt(k,n)=ngt(k,n)+1
                        if (anm(j,k).lt.countcut .and. anm(j,k).gt.-1.0*countcut) nneut(k,n)=nneut(k,n)+1                    
                        if (anm(j,k).le.-1.0*countcut) nlt(k,n)=nlt(k,n)+1
                        regaveanm(k,n)=regaveanm(k,n)+anm(j,k)
                    end if
                end if
            end if
            !write (*,'(3i4,6f11.4,i6)') k,j,n,site_lat(j),rlatmax(n),rlatmin(n),site_lon(j),rlonmin(n),rlonmax(n),ncounts(k,n)
        end do
        if (ncounts(k,n).ne.0.0) then
            regavez(k,n)=regavez(k,n)/sngl(ncounts(k,n))
        end if
        if ( (nneganm(k,n)+nposanm(k,n)) .ne.0) then
            regaveanm(k,n)=regaveanm(k,n)/sngl(nneganm(k,n)+nposanm(k,n))
        end if
    !pause
    end do
    write (11,'(i8,30(",",i8))') tlabel(k),(ncounts(k,n),n=1,nreg)
    write (12,'(i8,30(",",i8))') tlabel(k),(nposanm(k,n),n=1,nreg)
    write (13,'(i8,30(",",i8))') tlabel(k),(nneganm(k,n),n=1,nreg)
    write (14,'(i8,30(",",f8.3))') tlabel(k),(regavez(k,n),n=1,nreg)
    write (15,'(i8,30(",",f8.3))') tlabel(k),(regaveanm(k,n),n=1,nreg)
    write (16,'(i8,30(",",i8))') tlabel(k),(nneut(k,n),n=1,nreg)
    write (17,'(i8,30(",",i8))') tlabel(k),(ngt(k,n),n=1,nreg)
    write (18,'(i8,30(",",i8))') tlabel(k),(nlt(k,n),n=1,nreg)

end do            
            
end


