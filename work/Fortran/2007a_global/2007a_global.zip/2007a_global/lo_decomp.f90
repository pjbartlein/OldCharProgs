program lo_decomp
! lowess-based decomposition and peak summarization

use chaps_subs

implicit none

integer, parameter  :: maxdata=5000
integer(4)      :: site_num,nsamples
real(8)         :: lat,lon                              ! lat and lon
character(4)    :: pref_units, xst_level                ! pref_units, xst_level
character(72)   :: site_name                            ! site name

real(4)         :: thresh,trans,shift,interval          ! decomp parameters

character(1)    :: bwintype                             ! lowess params background
real(4)         :: bwidth                                 
integer(4)      :: border,bnrobust

character(1)    :: cwintype                             ! lowess params counts
real(4)         :: cwidth                                 
integer(4)      :: corder,cnrobust

character(1)    :: fwintype                             ! lowess params freq
real(4)         :: fwidth                                 
integer(4)      :: forder,fnrobust

character(1)    :: mwintype                             ! lowess params mag
real(4)         :: mwidth                                 
integer(4)      :: morder,mnrobust

integer         :: sample(maxdata)                      ! sample number                           
real(4)         :: depth(maxdata),est_age(maxdata)      ! depth, ages
real(4)         :: agemax                               ! global maximum age
real(4)         :: quant(maxdata),qmiss                 ! charcoal quantity, missing value code
real(4)         :: qconst                               ! additive constant for log transform
real(4)         :: tquant(maxdata)                      ! transformed charcoal quantity
real(4)         :: tmean(maxdata)                       ! local fitted value of charcoal quantity

real(4)         :: qmean(maxdata)                       ! untransformed value of local mean
real(4)         :: tdev(maxdata)                        ! tquant-tmean
real(4)         :: dev(maxdata)                         ! quant-mean
real(4)         :: posdev(maxdata)                      ! positive values of dev
real(4)         :: ratio(maxdata),tratio                ! tquant/tmean if posdev ne 0

integer(4)      :: peak(maxdata)                        ! peak 0/1 (tquant > thresh)
integer(4)      :: pstart(maxdata)                      ! 0/1 beginning of peak
integer(4)      :: pend(maxdata)                        ! 0/1 end of peak
real(4)         :: rpeak(maxdata)                       ! real-value peak series
real(4)         :: rpstart(maxdata)                     ! real-value peak-start series
integer(4)      :: pcount(maxdata)                      ! count of peaks in window
real(4)         :: rpcount(maxdata)                     ! real-value count of peaks
real(4)         :: smpcount(maxdata)                    ! smoothed value of rpcount

!real(4)         :: freq(maxdata)                        ! peak frequency (probability of peak)
!real(4)         :: smfreq(maxdata)                      ! smoothed peak frequency
real(4)         :: pprob(maxdata)                       ! probability sample is peak 
real(4)         :: smpprob(maxdata)                     ! smoothed probability sample is peak
real(4)         :: pmag(maxdata)                        ! total (quant) under peak
real(4)         :: mag(maxdata)                         ! smoothed peak magnitude
real(4)         :: dcquant(maxdata)                     ! detrended cumulative quant
real(4)         :: dcpeaks(maxdata)                     ! detrended cumulative peaks

integer         :: i,j
character(256)  :: inpath,outpath,decomplist,debugfile
character(4)    :: site_num_char
character(1)    :: dum

!decomplist="e:\Projects\igbpfire\nachar\data\decomp_sum\na_all\decomplist2.csv"
!inpath="e:\Projects\igbpfire\nachar\data\site_csv\"
!outpath="e:\Projects\igbpfire\nachar\data\decomp_sum\na_all\decomp_csv\"
!debugfile="e:\Projects\igbpfire\nachar\data\decomp_sum\na_all\decomp_csv\debug.dat"

!decomplist="e:\Projects\igbpfire\nachar\data\decomp_sum\yd_high\decomplist_ydhigh.csv"
!inpath="e:\Projects\igbpfire\nachar\data\site_csv\"
!outpath="e:\Projects\igbpfire\nachar\data\decomp_sum\yd_high\decomp_csv\"
!debugfile="e:\Projects\igbpfire\nachar\data\decomp_sum\yd_high\decomp_csv\debug.dat"

decomplist="e:\Projects\igbpfire\nachar\data\decomp_sum\quebec\decomp_list_quebec1.csv"
inpath="e:\Projects\igbpfire\nachar\data\site_csv\"
outpath="e:\Projects\igbpfire\nachar\data\decomp_sum\quebec\decomp_csv\"
debugfile="e:\Projects\igbpfire\nachar\data\decomp_sum\quebec\decomp_csv\debug.dat"

open (10,file=debugfile)

qmiss=-9999.0       ! missing data code -- not really implemented here yet
agemax=-999999.0

! open the decomplist 
open(1,file=decomplist)

! loop over sites
read (1,*) dum      ! read header
j=0
do
    j=j+1
    if (eof(1)) exit    ! exit loop if at end of file
    
    ! read info for j-th site
    read (1,*) site_num,lat,lon,pref_units,xst_level,nsamples,thresh,trans,shift,interval, & !   
        bwintype,bwidth,border,bnrobust,cwintype,cwidth,corder,cnrobust, &
        fwintype,fwidth,forder,fnrobust,mwintype,mwidth,morder,mnrobust, &
        site_name   
    write (*,'(2i5,1x,a72)') j,site_num,site_name
    write (*,'(a)') "nsamples,thresh,trans,shift,interval: "
    write (*,'(i5,1x,4f9.3)') nsamples,thresh,trans,shift,interval
    write (10,'(2i5,1x,a72)') j,site_num,site_name
    write (10,'(a)') "nsamples,thresh,trans,shift,interval: "
    write (10,'(i5,1x,4f9.3)') nsamples,thresh,trans,shift,interval
    
    ! open an input file, and read data
    site_num_char=int_to_string2(site_num,4)
    open (2,file=trim(inpath)//site_num_char//".csv")  
    read (2,*) dum
    do i=1,nsamples
        read (2,*) sample(i),depth(i),est_age(i),quant(i)
        if (agemax.le.est_age(i)) agemax=est_age(i)
    end do
    
    ! begin decomposition
    
    ! initialize variables
    tquant=0.0; tmean=0.0; qmean=0.0; tdev=0.0; dev=0.0; posdev=0.0; tratio=0.0
    peak=0; pstart=0; pend=0; rpcount=0.0; smpcount=0.0; pprob=0.0; smpprob=0.0
    pmag=0.0; mag=0.0; dcquant=0.0; dcpeaks=0.0
    
    ! transform data (if trans=1.0, nothing happens): tquant
    call transform(nsamples,trans,shift,quant,qmiss,tquant)
    
    ! lowess curve fit to tquant: tmean
    call fitlwr(nsamples,tquant,qmiss,est_age,bwintype,bwidth,border,bnrobust,tmean)
    
    ! untransform fitted values: qmean
    call untransform(nsamples,trans,shift,tmean,qmiss,qmean)
    
    ! deviation of transformed value about tmean:  tdev
    tdev=tquant-tmean
    
    ! deviation of untransformed value about untransformed mean (qmean):  dev
    dev=quant-qmean
    
    ! positive deviations: posdev
    where (dev.gt.0.0) posdev=dev
     
    ! peak
    where (tquant.gt.(thresh*tmean)) peak=1
    rpeak=peak

    ! pstart and pend
    do i=nsamples,1,-1
        if (peak(i+1).eq.0 .and. peak(i).eq.1) pstart(i)=1
        if (peak(i+1).eq.1 .and. peak(i).eq.0) pend(i+1)=1
    end do
    rpstart=pstart
        
    ! count of peaks within window:  rpcount
    call peakcount(nsamples,est_age,pstart,cwidth,interval,rpcount)
    !rpcount=rpcount*(interval/(2.0*cwidth))
    
    ! smoothed count of peaks within window:  smpcount
    call smpeakcount(nsamples,est_age,rpstart,cwintype,cwidth,corder,cnrobust,interval,smpcount)
    !smpcount=smpcount*(interval/(2.0*cwidth))
    
    ! peak frequency via lowess-curve fit to peaks: freq
    !call fitlwr(nsamples,rpstart,qmiss,est_age,wintype,smooth,1,0,freq)
    !freq=(interval/(2.0*smooth))*freq
    
    ! probability sample is a peak:  pprob
    call peakprob(nsamples,est_age,pstart,fwidth,pprob)    
    
    ! smoothed probabiliy samples is a peak:  smpprob
    call smpeakprob(nsamples,est_age,pstart,fwintype,fwidth,forder,fnrobust,smpprob)
    
    ! total quantity under peak:  pmag
    call peakmag(nsamples,est_age,quant,peak,pmag)
         
    ! smoothed peak magnitudes:  mag
    call smoothmag(nsamples,est_age,pmag,mwintype,mwidth,morder,mnrobust,mag)
    
    ! detrended cumulative quantity:  dcquant
    call detrcum(nsamples,quant,dcquant)
    
    ! detrended cumulative peaks:  dcpeaks
    call detrcum(nsamples,rpstart,dcpeaks)
        
    
    ! create the output .csv file, and write data 
    open (3,file=trim(outpath)//site_num_char//"_decomp.csv")
    ! first column label is site number
    write (3,'(a)') "site"//site_num_char//","// &
        "depth,est_age,quant,qmean,dev,posdev,tquant,tmean,tdev,"// &
        "peak,pstart,pend,pcount,smpcount,pprob,smpprob,pmag,mag,dcquant,dcpeaks"     
    do i=1,nsamples
        write (3,'(i4,",",f10.4,",",f9.1, 7(", ",f12.4), 3(", ",i6), 2(",",f12.4),&
             4(", ",f12.4), 2(", ",f12.8) )') & 
            sample(i),depth(i),est_age(i), &
            quant(i),qmean(i),dev(i),posdev(i),tquant(i),tmean(i),tdev(i), &
            peak(i),pstart(i),pend(i),rpcount(i),smpcount(i), &
            pprob(i),smpprob(i),pmag(i),mag(i), &
            dcquant(i),dcpeaks(i)
    end do
    
    close(2)
    close(3)
    
    write (*,'(/)') 
    write (10,'(/)') 
        
end do

write (*,'("maximum age: ",f12.4)') agemax

end program lo_decomp
