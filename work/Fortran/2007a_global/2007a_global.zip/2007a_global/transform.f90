program transform
! transforms and z-scores of individual charcoal records

use summarize_subs

implicit none

integer(4)      :: site_sample(maxdata),id_sample(maxdata)
real(4)         :: depth(maxdata),age(maxdata),quant(maxdata),qmnx(maxdata)
real(4)         :: tquant_all(maxdata),tquant_4k(maxdata),tquant_2k(maxdata)
real(4)         :: zquant_all(maxdata),zquant_4k(maxdata),zquant_2k(maxdata)
real(4)         :: ztquant_all(maxdata),ztquant_4k(maxdata),ztquant_2k(maxdata)
real(4)         :: temp(maxdata),sage(maxdata),squant(maxdata),qmiss

real(4)         :: begbase_all,endbase_all,begbase_4k,endbase_4k,begbase_2k,endbase_2k
real(4)         :: firstyr,lastyr

real(4)         :: lambda_all,shift_all,lhmax_all,lambda_4k,shift_4k,lhmax_4k,lambda_2k,shift_2k,lhmax_2k
real(4)         :: qmean_all,qstdev_all,qmin_all,qmax_all,qrng_all 
real(4)         :: qmean_4k,qstdev_4k,qmin_4k,qmax_4k,qrng_4k 
real(4)         :: qmean_2k,qstdev_2k,qmin_2k,qmax_2k,qrng_2k 
real(4)         :: tqmean_all,tqstdev_all,tqmin_all,tqmax_all,tqrng_all 
real(4)         :: tqmean_4k,tqstdev_4k,tqmin_4k,tqmax_4k,tqrng_4k 
real(4)         :: tqmean_2k,tqstdev_2k,tqmin_2k,tqmax_2k,tqrng_2k 

integer(4)      :: i,j,npts,nsel,npts_all,npts_4k,npts_2k

character(10)   :: csv_in,csv_out
character(4)    :: site_num_char
character(8)    :: site_num_label
character(256)  :: datapath,transpath,infile,outfile,lambdafile,allsamplesfile,debugfile 

datapath="e:\Projects\igbpfire\charsum\data\current_hs2\sites\site_csv\"
transpath="e:\Projects\igbpfire\charsum\data\current_hs2\sites\trans_csv\"
lambdafile="e:\Projects\igbpfire\charsum\data\current_hs2\files\HS_2c_lambda.dat"
allsamplesfile="e:\Projects\igbpfire\charsum\data\current_hs2\files\HS_2c_allsamples.csv"
debugfile="e:\Projects\igbpfire\charsum\data\current_hs2\files\HS_2c_debug2.dat"

begbase_4k=100.0; endbase_4k=4000.0; endbase_2k=2000.0
qmiss=-9999.0 
shift_all=0.01; shift_4k=0.01; shift_2k=0.01

open (3,file=lambdafile)
write (3,'(a)') "site, npts, npts_all, lambda_all, shift_all, lhmax_all, " &
                    //"npts_4k, lambda_4k, shift_4k, lhmax_4k, npts_2k, lambda_2k, shift_2k, lhmax_2k"
open (4,file=allsamplesfile)
write (4,'(a)') "site, site_sample, id_sample, est_age, depth, quant, qmnx, " &
                    // "tquant_all, tquant_4k, tquant_2k, zquant_all, zquant_4k, zquant_2k, " &
                    // "ztquant_all, ztquant_4k, ztquant_2k"
open (10,file=debugfile)

do j=1,maxsites
    ! try to open a file
    site_num_char=int_to_string2(j,4)
    open (1,file=trim(datapath)//trim(adjustl(site_num_char))//"_data.csv", status='old', err=100)
    open (2,file=trim(transpath)//trim(adjustl(site_num_char))//"_trans.csv")
    write (2,'(a)') "site, site_sample, id_sample, est_age, depth, quant, qmnx, " &
                    // "tquant_all, tquant_4k, tquant_2k, zquant_all, zquant_4k, zquant_2k, " &
                    // "ztquant_all, ztquant_4k, ztquant_2k"
    
    read (1,*) site_num_label
    
    ! initialize 
    depth=0.0; age=0.0; quant=qmiss; qmnx=qmiss
    npts_all=0; qmean_all=qmiss; qstdev_all=qmiss; qmin_all=qmiss; qmax_all=qmiss; qrng_all=qmiss
    tquant_all=qmiss; lambda_all=-9.0; lhmax_all=-99999.0
    npts_4k=0; qmean_4k=qmiss; qstdev_4k=qmiss; qmin_4k=qmiss; qmax_4k=qmiss; qrng_4k=qmiss
    tquant_4k=qmiss; lambda_4k=-9.0; lhmax_4k=-99999.0
    npts_2k=0; qmean_2k=qmiss; qstdev_2k=qmiss; qmin_2k=qmiss; qmax_2k=qmiss; qrng_2k=qmiss
    tquant_2k=qmiss; lambda_2k=-9.0; lhmax_2k=-99999.0

    
    i=0
    lastyr=-99999.0; firstyr=99999.0
    do while (.not. eof(1))
        i=i+1
        read (1,*) site_sample(i),id_sample(i),depth(i),age(i),quant(i)
        if (age(i).gt.lastyr) lastyr=age(i)
        if (age(i).lt.firstyr) firstyr=age(i)
    end do
    npts=i
    
    write (*,*) lastyr,firstyr
    begbase_all=firstyr; endbase_all=lastyr; begbase_2k=firstyr
    
    write (10,'(i5,1x,a4,1x,a8,1x,i4,2f10.2)') j,site_num_char,site_num_label,npts,firstyr,lastyr
    write (*,'(i5,1x,a4,1x,a8,1x,i4,2f10.2)') j,site_num_char,site_num_label,npts,firstyr,lastyr
    
    ! transformations and standardizations
    
    ! stats for whole record
    call stats(npts,age,quant,qmiss,begbase_all,endbase_all,npts_all,qmean_all,qstdev_all,qmin_all,qmax_all,qrng_all)
    
    ! qmnx -- minimax transformation of quant for whole record
    call minimax(npts_all,quant,qmiss,qmin_all,qmax_all,qmnx)
    
    ! Box-Cox transformation -- whole record
    call boxcox_lambda(npts_all,quant,qmiss,shift_all,lambda_all,lhmax_all)    
    call boxcox_trans(npts_all,lambda_all,shift_all,quant,qmiss,tquant_all)
    
    ! select points in the range 4000 to 100 (e.g. DP 1)
    write (*,*) npts_all,begbase_4k,endbase_4k
    call selectage(npts_all,begbase_4k,endbase_4k,age,quant,npts_4k,sage,squant)
    
    ! get Box-Cox parameters for selection of points
    if (npts_4k.gt.0) then
        call boxcox_lambda(npts_4k,squant,qmiss,shift_4k,lambda_4k,lhmax_4k)    
        ! transform whole record with 4k parameters  
        call boxcox_trans(npts_all,lambda_4k,shift_4k,quant,qmiss,tquant_4k)
    end if
    
    ! select points in the range 2000 to firstyr
    write (*,*) npts_all,begbase_2k,endbase_2k
    call selectage(npts_all,begbase_2k,endbase_2k,age,quant,npts_2k,sage,squant)
    
    ! get Box-Cox parameters for selection of points
    if (npts_2k.gt.0) then
        call boxcox_lambda(npts_2k,squant,qmiss,shift_2k,lambda_2k,lhmax_2k)    
        ! transform whole record with 2k parameters
        call boxcox_trans(npts_all,lambda_2k,shift_2k,quant,qmiss,tquant_2k)
    end if
    
    
    ! z-scores of untransformed values -- whole record
    call stats(npts,age,quant,qmiss,begbase_all,endbase_all,npts_all,qmean_all,qstdev_all,qmin_all,qmax_all,qrng_all)
    call zscores(npts,quant,qmiss,qmean_all,qstdev_all,zquant_all)

    ! z-scores of untransformed values -- 4000 to 100 (e.g. DP 1)
    call stats(npts,age,quant,qmiss,begbase_4k,endbase_4k,npts_4k,qmean_4k,qstdev_4k,qmin_4k,qmax_4k,qrng_4k)
    !write (*,*) npts_4k,qmean_4k,qstdev_4k
    call zscores(npts,quant,qmiss,qmean_4k,qstdev_4k,zquant_4k)
    !pause
    
    ! z-scores of untransformed values -- 2000 to firstyr
    call stats(npts,age,quant,qmiss,begbase_2k,endbase_2k,npts_2k,qmean_2k,qstdev_2k,qmin_2k,qmax_2k,qrng_2k)
    call zscores(npts,quant,qmiss,qmean_2k,qstdev_2k,zquant_2k)
    
    ! z-scores of transformed values -- whole record
    call stats(npts,age,tquant_all,qmiss,begbase_all,endbase_all,npts_all,tqmean_all,tqstdev_all,tqmin_all,tqmax_all,tqrng_all)
    call zscores(npts,tquant_all,qmiss,tqmean_all,tqstdev_all,ztquant_all)

    ! z-scores of transformed values -- 4000 to 100 (e.g. DP 1)
    call stats(npts,age,tquant_4k,qmiss,begbase_4k,endbase_4k,npts_4k,tqmean_4k,tqstdev_4k,tqmin_4k,tqmax_4k,tqrng_4k)
    call zscores(npts,tquant_4k,qmiss,tqmean_4k,tqstdev_4k,ztquant_4k)
    
    ! z-scores of transformed values -- 2000 to firstyr
    call stats(npts,age,tquant_2k,qmiss,begbase_2k,endbase_2k,npts_2k,tqmean_2k,tqstdev_2k,tqmin_2k,tqmax_2k,tqrng_2k)
    call zscores(npts,tquant_2k,qmiss,tqmean_2k,tqstdev_2k,ztquant_2k)
    
    ! minimax of transformed values -- 4000 to 100 (e.g. DP 1)
    temp=tquant_4k
    call minimax(npts_all,temp,qmiss,tqmin_4k,tqmax_4k,tquant_4k)
    
    ! minimax of transformed values -- 2000 to firstyr
    temp=tquant_2k
    call minimax(npts_all,temp,qmiss,tqmin_2k,tqmax_2k,tquant_2k)
    
    
    do i=1,npts
        write (2,'(a8,",",i8,",",i8,",",f10.2,",",f10.2,11(",",f12.4) )') &
            site_num_label,site_sample(i),id_sample(i),age(i),depth(i),quant(i),qmnx(i), &
            tquant_all(i),tquant_4k(i),tquant_2k(i),zquant_all(i), zquant_4k(i), zquant_2k(i), &
            ztquant_all(i), ztquant_4k(i), ztquant_2k(i)
        write (4,'(a8,",",i8,",",i8,",",f10.2,",",f10.2,11(",",f12.4) )') &
            site_num_label,site_sample(i),id_sample(i),age(i),depth(i),quant(i),qmnx(i), &
            tquant_all(i),tquant_4k(i),tquant_2k(i),zquant_all(i), zquant_4k(i), zquant_2k(i), &
            ztquant_all(i), ztquant_4k(i), ztquant_2k(i)
    end do
    
    write (3,'(a8,1x,i5,1x,3(i5,2f8.2,f10.2))') &
        site_num_label,npts,npts_all,lambda_all,shift_all,lhmax_all,  &
            npts_4k,lambda_4k,shift_4k,lhmax_4k,npts_2k,lambda_2k,shift_2k,lhmax_2k
    
   
100 continue
    
end do

end


