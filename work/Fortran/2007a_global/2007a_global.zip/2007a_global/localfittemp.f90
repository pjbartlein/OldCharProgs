subroutine lowess2(nctrl,xin,yin,ntarg,xt,wintype,param,order,nrobust,yfit)
! manages computation of a lowess "curve"

use lwr

implicit none

integer             :: nctrl,ntarg
real(8)             :: xin(nctrl),yin(nctrl),xt(ntarg),param,yfit(ntarg),y0
real(8)             :: xs(nctrl),ys(nctrl),targ,fitval,lwmean1,lwmean2,newparam
integer             :: order,nrobust
integer             :: np 
character(1)        :: wintype
logical             :: monotonic,yfitnan

integer             :: i,ii,iii,j,k

y0=0.0

do i=1,nctrl
    write (10,'(i5,2f12.4)') i,xin(i),yin(i)
end do
do i=1,ntarg
    write (10,'(i5,f12.4)') i,xt(i)
end do
write (10,*) nctrl,ntarg,wintype,param,order,nrobust

xs=xin; ys=yin
! sort the input data by x-values if necessary
monotonic=.true.
do i=2,nctrl
    if (xs(i).lt.xs(i-1)) then
        monotonic=.false.
        write (*,'("xs(i),xs(i-1) non-monotonic: ",i6,2f14.6)') i,xs(i),xs(i-1)
    end if
end do
if (.not. monotonic) then
    write (*,'(a)') "Note:  input x's were not monotonic"
    write (10,'(a)') "Note:  input x's were not monotonic"
    call sortxy(nctrl,xin,yin,xs,ys)
end if

! loop over target points
do ii=1,ntarg

    if (mod(ii,100).eq.0) write (*,'(i5,\)') ii
    
    targ=xt(ii)    
    call localfit2(nctrl,xs,ys,targ,wintype,param,order,nrobust,fitval,lwmean1)
    yfit(ii)=fitval
    
    write (10,'("nctrl,ii,targ,fitval,lwmean1 ",2i6,3f12.4)') nctrl,ii,targ,fitval,lwmean1
    
    !do k=1,nctrl
    !    write (*,*) k,xs(k),ys(k)
    !end do
    !pause

end do  
   
    
write (*,'(a)') " "
   
end subroutine lowess2


subroutine localfit2(nctrl,xs,ys,targval,wintype,param,order,nrobust,fitval,lwmean)
! gets a lowess-type fitted value at a particular target point

use lwr

implicit none

integer             :: nctrl
real(8)             :: targval,param,fitval,lwmean
real(8)             :: xs(nctrl),ys(nctrl),x(nctrl),y(nctrl)
real(8)             :: w(nctrl),wsum,ywm,ym,ystd
real(8)             :: b0,b1,b2,yhat(nctrl),resid(nctrl),mse,stderr,rsq
real(8)             :: dmax,diff,u,ul,ll
real(8)             :: r(nctrl),median,rmedx6,ru,rw(nctrl)
integer             :: order,nrobust
integer             :: np,np2,npts,low,high,nonzero
character(1)        :: wintype
integer             :: i,ii,iii,j

! write (*,*) param

! select data to use for a specific fitted value
if (wintype.eq.'s') then 
 
    ! find observations in param proportion of data
    npts=int(param*nctrl)
    np2=npts/2
    low=ii-np2
    high=ii+np2
    if (low.lt.1) then
        low=1
        high=low+npts
    end if
    if (high.gt.nctrl) then
        high=nctrl
        low=nctrl-npts
    end if
    np=high-low+1
    !write (*,*) low,high,np
    i=0
    do iii=low,high
        i=i+1
        x(i)=xs(iii)
        y(i)=ys(iii)
    end do
    
    ! get distance weights
    dmax=0.0d0
    do i=1,np
        diff=x(i)-targval
        if (dabs(diff).gt.dmax) dmax=dabs(diff)
    end do
    do i=1,np
        u=dabs(x(i)-targval)/dmax
        if (u.gt.1.0d0) u=1.0d0
        w(i)=(1.0d0-u**3.0d0)**3.0d0
    end do
    
else if (wintype.eq.'w') then

    ! find observations within plus or minus window half-width (param)
    ul=targval+param
    ll=targval-param
    i=0
    do iii=1,nctrl
        if (xs(iii).ge.ll .and. xs(iii).le.ul) then
            i=i+1
            x(i)=xs(iii)
            y(i)=ys(iii)
        end if
    end do
    np=i   
    
    ! get distance weights
    dmax=param
    do i=1,np
        u=dabs(x(i)-targval)/dmax
        if (u.gt.1.0d0) u=1.0d0
        w(i)=(1.0d0-u**3.0d0)**3.0d0
    end do         
end if

! data for this target value    
write (10,'("np ",i6)') np
do i=1,np
    write (10,'(i6,3f15.8)') i,x(i),y(i),w(i)
end do

! get a locally weighted mean
call wm2(np,y,w,lwmean,resid)
!write (*,*) lwmean
!pause

fitval=0.0d0/0.0d0 ! set to NaN initially

! set initial robustness weights equal to distance weights
nonzero=0
do i=1,np
    rw(i)=w(i)
    if (rw(i).ne.0.0d0) nonzero=nonzero+1
    write (10,'("i,rw: ",i6,f12.4)') i,rw(i)
end do

! robustness iterations
do j=0,nrobust

    ! case (0) (distance) weighted mean
        call wm(np,y,rw,ywm,resid)
        fitval=ywm

    ! lowess regressions
    select case (order)
        
        !case (0)
        !    ! (distance) weighted mean
        !    call wm(np,y,rw,ywm,resid)
        !    fitval=ywm

        case (1)       
            ! distance-weighted linear regression
            if (nonzero.gt.3) then
                call fitline2(np,x,y,rw,b0,b1,yhat,resid,mse,stderr,rsq)
                fitval=b0+b1*targval
            end if
            
        case (2)
            ! distance-weighted quadratic regression
            if (nonzero.gt.8) then
                call fitquad(np,x,y,rw,b0,b1,b2,yhat,resid,mse,stderr,rsq)
                fitval=b0+b1*targval+b2*targval*targval
            end if
   
        case default
            write (*,*) "Polynomial order not supported...."
            stop 
            
    end select
    
    ! robustness weights
    if (nrobust.ne.0 .and. j.lt.nrobust) then
    
        ! median of absolute values of current residuals
        call medianx(np,dabs(resid),median)
        rmedx6=median*6.0d0
        write (10,'("median,rmedx6: ",2f12.4)') median,rmedx6
    
        ! bisquare weights (r) and new robustness weights (rw)
        nonzero=0
        do i=1,np
            ru=dabs(resid(i)/rmedx6)    
            if (ru.gt.1.0d0) ru=1.0d0
            r(i)=(1.0d0-ru**2.0d0)**2.0d0
            rw(i)=w(i)*r(i)
            if (rw(i).ne.0.0d0) nonzero=nonzero+1
            write (10,'("i,ru,r,rw: ",i6,3f12.4)') i,ru,r(i),rw(i)
        end do
      
    end if      
    
    end do

end subroutine localfit2


subroutine wm2(npts,y,w,ywm,dev)
! weighted mean

implicit none

integer     :: npts
real(8)     :: y(npts),w(npts),dev(npts)
real(8)     :: wsum,ywm,ym
integer     :: i

ym=0.0d0
ywm=0.0d0
wsum=0.0d0
do i=1,npts
    ym=ym+y(i)
    ywm=ywm+y(i)*w(i)
    wsum=wsum+w(i)
    !write (10,*) i,y(i),ym
end do
!write (*,*) ym,ywm,wsum
if (wsum.gt.0.0) then
    ywm=ywm/wsum
else
    ywm=ym/dble(npts)
end if
write (10,'("in wm2: npts,ym,ywm,wsum ",i6,3f12.4)') npts,ym,ywm,wsum
!pause

do i=1,npts
    dev(i)=y(i)-ywm
end do

end subroutine wm2


subroutine fitline2(npts,x,y,w,b0,b1,yhat,resid,mse,stderr,rsq)
! simple weighted linear regression

implicit none

integer         :: npts
real(8)         :: x(npts),y(npts),w(npts),b0,b1,yhat(npts),resid(npts)
real(8)         :: xm,ym,wsum,sxx,sxy,sse,sst,mse,stderr,sratio,rsq,realNaN
integer         :: i

xm=0.0d0; ym=0.0d0; wsum=0.0d0; sxx=0.0d0; sxy=0.0d0 !; b0=0.0d0; b1=0.0d0

do i=1,npts
    wsum=wsum+w(i)
    xm=xm+x(i)*w(i)
    ym=ym+y(i)*w(i)
end do

if (wsum.ne.0.0d0) then
    xm=xm/wsum
    ym=ym/wsum

    do i=1,npts
        sxx=sxx+((x(i)-xm)**2.0d0)*w(i)
        sxy=sxy+(x(i)-xm)*(y(i)-ym)*w(i)
    end do

    b1=sxy/sxx
    b0=ym-(b1*xm)

    sse=0.0d0; sst=0.0d0
    do i=1,npts
        yhat(i)=b0+b1*x(i)
        resid(i)=y(i)-yhat(i)
        sse=sse+(resid(i)*dsqrt(w(i)))**2.0d0
        sst=sst+((y(i)-ym)*dsqrt(w(i)))**2.0d0
    end do

    mse=sse/dble(npts-2)
    stderr=dsqrt(mse)
    rsq=-1.0d0
    sratio=sse/sst
    if (sratio.le.1.0d0 .and. sratio.ge.0.0d0) rsq=1.0d0-sratio
else
    realNaN=0.0d0/0.0d0
    xm=realNaN
    ym=realNaN
    b1=realNaN
    b0=realNaN
    mse=realNaN
    stderr=realNaN
    rsq=realNaN
    sratio=realNaN
end if    

write (10,'("in fitline2,npts,wsum,xm,ym,sxx,sxy,b0,b1:"/,i6,7f13.4)') npts,wsum,xm,ym,sxx,sxy,b0,b1

end subroutine fitline2