program plot_summary
! plots series from sum_decomp 

use psc_inf
use uo_utils
use ifport

implicit none

integer, parameter  :: maxdata=5000, maxsites=1000
integer(4)      :: site_num(maxsites)                   ! site id's
real(4)         :: lat,lon
integer(4)      :: nsamples(maxsites)

real(4)			:: xr,xg,xb,xamin,xamax,xlwidth         ! x-axis parameters
real(4)         :: xmajorinterval,xminorinterval,xlabelinterval,xaoffset,xaloffset
character*1     :: xatype,xorient
integer         :: xdecimalplaces
real(4)			:: yr,yg,yb,yamin,yamax ,ylwidth        ! y-axis parameters
real(4)         :: ymajorinterval,yminorinterval,ylabelinterval,yaoffset,yaloffset
character*1     :: yatype,yorient
integer         :: ydecimalplaces

integer         :: ncols,ycol,xcol

integer         :: i,ns,ids,ntarg,npstart,nnzpmag,site

character(4)    :: site_num_char(maxsites)
character(32)    :: datfile
character(256)  :: infile,sitelist,sumcurvesfile,pstartfile,pmagfile,xaxisfile,yaxisfile,insite
character(80)   :: header
logical         :: status

workpath="e:\Projects\igbpfire\nachar\data\plots01\"

datapath="e:\Projects\igbpfire\nachar\data\decomp_sum\quebec\summary_csv\"
sitelist="e:\Projects\igbpfire\nachar\data\decomp_sum\quebec\sum_list_quebec1.csv"
sumcurvesfile="e:\Projects\igbpfire\nachar\data\decomp_sum\quebec\summary_csv\sumcurves_quebec1.csv"
pstartfile="e:\Projects\igbpfire\nachar\data\decomp_sum\quebec\summary_csv\allpstart_quebec1.csv"
pmagfile="e:\Projects\igbpfire\nachar\data\decomp_sum\quebec\summary_csv\allnzpmag_quebec1.csv"
infofile="sumplots_quebec1.inf" 



! general parameters

xmin=-16000; xmax=100; xlen=6.0
ymin=-0.5; ymax=1.5; ylen=2.0

xatype="E"; xorient="H"; xr=0.0; xg=0.0; xb=0.0; xamin=-16000; xamax=100; 
xmajorinterval=1000.0; xminorinterval=500; xlabelinterval=-1
xdecimalplaces=-1; xlwidth=0.5; xaoffset=0.0
xaloffset=0.005; xaxisfile="age.axs"

yatype="E"; yorient="V"; yr=0.0; yg=0.0; yb=0.0; yamin=0.0; yamax=1.01; 
ymajorinterval=0.2; yminorinterval=0.1; ylabelinterval=0.2
ydecimalplaces=1; ylwidth=0.5; yaoffset=0.0
yaloffset=0.0; yaxisfile="data.axs"

write (*,'(a)') infofile

! count allpstart, allnzpmag, and sumcurve records
open (10,file=pstartfile)
i=0
read (10,*) header
do 
    if (eof(10)) exit
    i=i+1
    read (10,*) site
end do
npstart=i
close(10)
open (10,file=pmagfile)
i=0
read (10,*) header
do 
    if (eof(10)) exit
    i=i+1
    read (10,*) site
end do
nnzpmag=i
close(10)
open (10,file=sumcurvesfile)
i=0
read (10,*) header
do 
    if (eof(10)) exit
    i=i+1
    read (10,*) site
end do
ntarg=i
close(10)

! read sitelist
open (1,file=sitelist)
read (1,*) header
i=0
do
    if (eof(1)) exit
    i=i+1
    read (1,*) site_num(i),lat,lon,nsamples(i)
    site_num_char(i)=int_to_string2(site_num(i),4)
    write (*,'(i4,i5,1x,a4,1x,i5)') i,site_num(i),site_num_char(i),nsamples(i)
end do
ns=i
close(1)

! start plotting

orient="P"
call psc_init(infofile,orient,1,0.0,0.0,1.0,workpath)

ids=0
ncols=18


! charcoal quantity (mquant) ==================================================

xpanel=1.5; ypanel=8.5
call psc_panel (xpanel,ypanel,xlen,ylen,xmin,xmax,ymin,ymax)
!call psc_box(1.0,0.0,0.0,1.0)

xcol=3; ycol=14
gtype="L"; gr=0.4; gg=0.4; gb=0.4; glwidth=0.8; 
do i=1,ns
    infile=trim(adjustl(datapath))//site_num_char(i)//"_summary.csv"
    ids=ids+1
    datfile="d_"//trim(adjustl(int_to_string2(ids,4)))//".dat"
    call writecols(infile,workpath,datfile,ncols,nsamples(i),xcol,ycol)
    call psc_graph (gtype,gr,gg,gb,glwidth,nsamples(i),datfile)
end do

! smquant
xcol=1; ycol=2
ids=ids+1
datfile="d_"//trim(adjustl(int_to_string2(ids,4)))//".dat"
gtype="L"; gr=1.0; gg=0.0; gb=0.0; glwidth=1.2; 
call writecols(sumcurvesfile,workpath,datfile,7,ntarg,xcol,ycol)
call psc_graph (gtype,gr,gg,gb,glwidth,ntarg,datfile)

! text	
fmt=0.0; fsize=10.0; font="H"
xtext=xpanel-0.4; ytext=ypanel+ylen/2.0; torient="V"; just="C"
text="Charcoal Quantity"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,text)	

! x and y axes
fmt=0.0; fsize=10.0; font="H"
call psc_font(fmt,fsize,font)
call psc_panel (xpanel,ypanel+0.45,xlen,1.0,xmin,xmax,0.0,1.0)
!call psc_box(0.0,1.0,0.0,1.0)
call psc_axis(xatype,xorient,xr,xg,xb,xamin,xamax,xmajorinterval,xminorinterval,xlabelinterval,xdecimalplaces,xlwidth,xaoffset)
call psc_panel (xpanel,ypanel+0.4,xlen,1.0,xmin,xmax,0.0,1.0)
call psc_axislabel (xaloffset,xaxisfile)
call psc_panel (xpanel,ypanel+0.5,xlen,1.0,xmin,xmax,0.0,1.0)
!call psc_box(0.0,0.0,1.0,1.0)
call psc_axis(yatype,yorient,yr,yg,yb,yamin,yamax,ymajorinterval,yminorinterval,ylabelinterval,ydecimalplaces,ylwidth,yaoffset)


! background (mqmean) =========================================================

xpanel=1.5; ypanel=7.0
call psc_panel (xpanel,ypanel,xlen,ylen,xmin,xmax,ymin,ymax)
!call psc_box(1.0,0.0,0.0,1.0)

xcol=3; ycol=15
gtype="L"; gr=0.4; gg=0.4; gb=0.4; glwidth=0.8; 
do i=1,ns
    infile=trim(adjustl(datapath))//site_num_char(i)//"_summary.csv"
    ids=ids+1
    datfile="d_"//trim(adjustl(int_to_string2(ids,4)))//".dat"
    call writecols(infile,workpath,datfile,ncols,nsamples(i),xcol,ycol)
    call psc_graph (gtype,gr,gg,gb,glwidth,nsamples(i),datfile)
end do

! smqmean
xcol=1; ycol=3
ids=ids+1
datfile="d_"//trim(adjustl(int_to_string2(ids,4)))//".dat"
gtype="L"; gr=1.0; gg=0.0; gb=0.0; glwidth=1.2; 
call writecols(sumcurvesfile,workpath,datfile,7,ntarg,xcol,ycol)
call psc_graph (gtype,gr,gg,gb,glwidth,ntarg,datfile)

! text	
fmt=0.0; fsize=10.0; font="H"
xtext=xpanel-0.4; ytext=ypanel+ylen/2.0; torient="V"; just="C"
text="Background"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,text)	

! x and y axes
fmt=0.0; fsize=10.0; font="H"
call psc_font(fmt,fsize,font)
call psc_panel (xpanel,ypanel+0.45,xlen,1.0,xmin,xmax,0.0,1.0)
!call psc_box(0.0,1.0,0.0,1.0)
call psc_axis(xatype,xorient,xr,xg,xb,xamin,xamax,xmajorinterval,xminorinterval,xlabelinterval,xdecimalplaces,xlwidth,xaoffset)
call psc_panel (xpanel,ypanel+0.4,xlen,1.0,xmin,xmax,0.0,1.0)
call psc_axislabel (xaloffset,xaxisfile)
call psc_panel (xpanel,ypanel+0.5,xlen,1.0,xmin,xmax,0.0,1.0)
!call psc_box(0.0,0.0,1.0,1.0)
call psc_axis(yatype,yorient,yr,yg,yb,yamin,yamax,ymajorinterval,yminorinterval,ylabelinterval,ydecimalplaces,ylwidth,yaoffset)


! peak starts (pstart) =======================================================

xpanel=1.5; ypanel=5.5
call psc_panel (xpanel,ypanel,xlen,1.5,xmin,xmax,0.5,sngl(ns)+0.5)
!call psc_box(1.0,0.0,0.0,1.0)

xcol=3; ycol=2
gtype="P"; gr=0.4; gg=0.4; gb=0.4; glwidth=2.0; 

infile=pstartfile
ids=ids+1
datfile="d_"//trim(adjustl(int_to_string2(ids,4)))//".dat"
call writecols(infile,workpath,datfile,3,npstart,xcol,ycol)
call psc_graph (gtype,gr,gg,gb,glwidth,npstart,datfile)

! text	
fmt=0.0; fsize=10.0; font="H"
xtext=xpanel-0.2; ytext=ypanel+ylen/2.0; torient="V"; just="C"
text="Peaks"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,text)	

! x and y axes
fmt=0.0; fsize=10.0; font="H"
call psc_font(fmt,fsize,font)
call psc_panel (xpanel,ypanel-.05,xlen,1.5,xmin,xmax,0.0,1.0)
!call psc_box(0.0,1.0,0.0,1.0)
call psc_axis(xatype,xorient,xr,xg,xb,xamin,xamax,xmajorinterval,xminorinterval,xlabelinterval,xdecimalplaces,xlwidth,xaoffset)
call psc_panel (xpanel,ypanel-.1,xlen,1.5,xmin,xmax,0.0,1.0)
call psc_axislabel (xaloffset,xaxisfile)
call psc_panel (xpanel,ypanel,xlen,1.5,xmin,xmax,0.0,1.0)
!call psc_box(0.0,0.0,1.0,1.0)
!call psc_axis(yatype,yorient,yr,yg,yb,yamin,yamax,ymajorinterval,yminorinterval,ylabelinterval,ydecimalplaces,ylwidth,yaoffset)


! peak counts (msmpcount) =====================================================

xpanel=1.5; ypanel=3.5
call psc_panel (xpanel,ypanel,xlen,ylen,xmin,xmax,ymin,ymax)
!call psc_box(1.0,0.0,0.0,1.0)

xcol=3; ycol=16
gtype="L"; gr=0.4; gg=0.4; gb=0.4; glwidth=0.8; 
do i=1,ns
    infile=trim(adjustl(datapath))//site_num_char(i)//"_summary.csv"
    ids=ids+1
    datfile="d_"//trim(adjustl(int_to_string2(ids,4)))//".dat"
    call writecols(infile,workpath,datfile,ncols,nsamples(i),xcol,ycol)
    call psc_graph (gtype,gr,gg,gb,glwidth,nsamples(i),datfile)
end do

! smsmpcount
xcol=1; ycol=4
ids=ids+1
datfile="d_"//trim(adjustl(int_to_string2(ids,4)))//".dat"
gtype="L"; gr=1.0; gg=0.0; gb=0.0; glwidth=1.2; 
call writecols(sumcurvesfile,workpath,datfile,7,ntarg,xcol,ycol)
call psc_graph (gtype,gr,gg,gb,glwidth,ntarg,datfile)

! text	
fmt=0.0; fsize=10.0; font="H"
xtext=xpanel-0.4; ytext=ypanel+ylen/2.0; torient="V"; just="C"
text="Peak Frequency"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,text)	

! x and y axes
fmt=0.0; fsize=10.0; font="H"
call psc_font(fmt,fsize,font)
call psc_panel (xpanel,ypanel+0.45,xlen,1.0,xmin,xmax,0.0,1.0)
!call psc_box(0.0,1.0,0.0,1.0)
call psc_axis(xatype,xorient,xr,xg,xb,xamin,xamax,xmajorinterval,xminorinterval,xlabelinterval,xdecimalplaces,xlwidth,xaoffset)
call psc_panel (xpanel,ypanel+0.4,xlen,1.0,xmin,xmax,0.0,1.0)
call psc_axislabel (xaloffset,xaxisfile)
call psc_panel (xpanel,ypanel+0.5,xlen,1.0,xmin,xmax,0.0,1.0)
!call psc_box(0.0,0.0,1.0,1.0)
call psc_axis(yatype,yorient,yr,yg,yb,yamin,yamax,ymajorinterval,yminorinterval,ylabelinterval,ydecimalplaces,ylwidth,yaoffset)


! peak magnitude (mnzpmag) ====================================================

xpanel=1.5; ypanel=2.0
call psc_panel (xpanel,ypanel,xlen,ylen,xmin,xmax,ymin,ymax)
!call psc_box(1.0,0.0,0.0,1.0)

xcol=2; ycol=4
gtype="P"; gr=0.4; gg=0.4; gb=0.4; glwidth=2.0; 

infile=pmagfile
ids=ids+1
datfile="d_"//trim(adjustl(int_to_string2(ids,4)))//".dat"
call writecols(infile,workpath,datfile,4,nnzpmag,xcol,ycol)
call psc_graph (gtype,gr,gg,gb,glwidth,nnzpmag,datfile)

! smmnzpmag
xcol=1; ycol=7
ids=ids+1
datfile="d_"//trim(adjustl(int_to_string2(ids,4)))//".dat"
gtype="L"; gr=1.0; gg=0.0; gb=0.0; glwidth=1.2; 
call writecols(sumcurvesfile,workpath,datfile,7,ntarg,xcol,ycol)
call psc_graph (gtype,gr,gg,gb,glwidth,ntarg,datfile)

! text	
fmt=0.0; fsize=10.0; font="H"
xtext=xpanel-0.4; ytext=ypanel+ylen/2.0; torient="V"; just="C"
text="Peak Magnitude"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,text)	

! x and y axes
fmt=0.0; fsize=10.0; font="H"
call psc_font(fmt,fsize,font)
call psc_panel (xpanel,ypanel+0.45,xlen,1.0,xmin,xmax,0.0,1.0)
!call psc_box(0.0,1.0,0.0,1.0)
call psc_axis(xatype,xorient,xr,xg,xb,xamin,xamax,xmajorinterval,xminorinterval,xlabelinterval,xdecimalplaces,xlwidth,xaoffset)
call psc_panel (xpanel,ypanel+0.4,xlen,1.0,xmin,xmax,0.0,1.0)
call psc_axislabel (xaloffset,xaxisfile)
call psc_panel (xpanel,ypanel+0.5,xlen,1.0,xmin,xmax,0.0,1.0)
!call psc_box(0.0,0.0,1.0,1.0)
call psc_axis(yatype,yorient,yr,yg,yb,yamin,yamax,ymajorinterval,yminorinterval,ylabelinterval,ydecimalplaces,ylwidth,yaoffset)


! peak magnitude (mmag) =======================================================

xpanel=1.5; ypanel=0.5
call psc_panel (xpanel,ypanel,xlen,ylen,xmin,xmax,ymin,ymax)
!call psc_box(1.0,0.0,0.0,1.0)

xcol=3; ycol=18
gtype="L"; gr=0.4; gg=0.4; gb=0.4; glwidth=0.8; 
do i=1,ns
    infile=trim(adjustl(datapath))//site_num_char(i)//"_summary.csv"
    ids=ids+1
    datfile="d_"//trim(adjustl(int_to_string2(ids,4)))//".dat"
    call writecols(infile,workpath,datfile,ncols,nsamples(i),xcol,ycol)
    call psc_graph (gtype,gr,gg,gb,glwidth,nsamples(i),datfile)
end do

! smmag
xcol=1; ycol=6
ids=ids+1
datfile="d_"//trim(adjustl(int_to_string2(ids,4)))//".dat"
gtype="L"; gr=1.0; gg=0.0; gb=0.0; glwidth=1.2; 
call writecols(sumcurvesfile,workpath,datfile,7,ntarg,xcol,ycol)
call psc_graph (gtype,gr,gg,gb,glwidth,ntarg,datfile)

! text	
fmt=0.0; fsize=10.0; font="H"
xtext=xpanel-0.4; ytext=ypanel+ylen/2.0; torient="V"; just="C"
text="Smoothed Peak Mag."
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,text)	

! x and y axes
fmt=0.0; fsize=10.0; font="H"
call psc_font(fmt,fsize,font)
call psc_panel (xpanel,ypanel+0.45,xlen,1.0,xmin,xmax,0.0,1.0)
!call psc_box(0.0,1.0,0.0,1.0)
call psc_axis(xatype,xorient,xr,xg,xb,xamin,xamax,xmajorinterval,xminorinterval,xlabelinterval,xdecimalplaces,xlwidth,xaoffset)
call psc_panel (xpanel,ypanel+0.4,xlen,1.0,xmin,xmax,0.0,1.0)
call psc_axislabel (xaloffset,xaxisfile)
call psc_panel (xpanel,ypanel+0.5,xlen,1.0,xmin,xmax,0.0,1.0)
!call psc_box(0.0,0.0,1.0,1.0)
call psc_axis(yatype,yorient,yr,yg,yb,yamin,yamax,ymajorinterval,yminorinterval,ylabelinterval,ydecimalplaces,ylwidth,yaoffset)

! text	
fmt=0.0; fsize=10.0; font="H"
xtext=xpanel; ytext=0.3; torient="H"; just="L"
text=infofile
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,text)	

! done

call psc_close

status = changedirqq(workpath)
status = systemqq("psc_f90_74.exe "//infofile)

end program plot_summary


subroutine writecols(infile,workpath,datfile,ncols,npts,xcol,ycol)

implicit none

integer(4)      :: ncols,npts
character(256)  :: infile,workpath,outfile
character(32)   :: datfile
real(4)         :: vals(npts,ncols)
integer(4)      :: xcol,ycol

integer(4)      :: i,j
character(80)   :: header

outfile=trim(adjustl(workpath))//trim(adjustl(datfile))

open (11,file=infile)
open (12,file=outfile)

read (11,*) header
do i=1,npts
    read (11,*) (vals(i,j),j=1,ncols)
end do

do i=1,npts
    write (12,'(f12.2,f12.4)') -1.0*vals(i,xcol),vals(i,ycol)
end do

close(11)
close(12)

end subroutine writecols


