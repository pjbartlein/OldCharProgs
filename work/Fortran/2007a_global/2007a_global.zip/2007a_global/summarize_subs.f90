module summarize_subs

    integer, parameter  :: maxdata=100000, maxrec=10000, maxsites=2000, maxvars=50

contains

subroutine transform(n,trans,quant,qmiss,tquant)

    implicit none

    integer, intent(in)     :: n
    real(4), intent(in)     :: trans
    real(4), intent(in)     :: quant(n),qmiss
    real(4), intent(out)    :: tquant(n)
    real(4)                 :: qmin,qadd

    integer(4)              :: i

    ! transformation
    
    tquant=qmiss
    if (trans .eq. 1.0) then        ! no transformation
        do i=1,n
            if (quant(i).ne.qmiss) tquant(i)=quant(i)
        end do
        
    elseif (trans .eq. 0.5) then    ! square-root transformation
        do i=1,n
            if (quant(i).ne.qmiss) tquant(i)=sqrt(quant(i))
        end do 
        
    elseif (trans .eq. 0.0) then    ! log10 transformation
        
        qadd=0.1
        do i=1,n
            if (quant(i) .ne. qmiss) tquant(i)=log10(quant(i)+qadd)
        end do
    
    else                            ! other transformation
        stop "don't know transformation"
    end if
    
end subroutine transform

subroutine boxcox(n,quant,qmiss,shift,lambda2,lhmax2,tquant)

    implicit none

    integer, parameter      :: nlam=101
    integer, intent(in)     :: n
    real(4), intent(in)     :: shift
    real(4), intent(in)     :: quant(n),qmiss
    real(4), intent(out)    :: lambda2,lhmax2
    real(4), intent(out)    :: tquant(n)
    
    real(8)                 :: qmin,qmax
    real(8)                 :: y(n),logy(n),logymean,ydot,yt(n),zt(n),ztmean,rss
    real(8)                 :: lambda,lhmax,lam(nlam),lh(nlam)
    integer(4)              :: i,j,jmax,nonmiss

    ! maximum likelihood estimation of transformation parameter (lambda)
    ! adapted from the boxcox() function in the MASS R package
    
    ! do evaluations in double precision (real(8))
    
    ! rescale to [0,1] add shift and calculate geometric mean
    nonmiss=0; y=dble(qmiss); logy=dble(qmiss)
    qmax=maxval(dble(quant)); qmin=minval(dble(quant))
    do i=1,n
        if (quant(i).ne.qmiss) then
            nonmiss=nonmiss+1
            y(i)=(dble(quant(i))-qmin)/(qmax-qmin)+shift
            if (y(i).le.0.0) stop "variable being transformed must be positive after shift"
            logy(i)=dlog(y(i))
        end if
    end do
    call dmean(n,logy,dble(qmiss),logymean)
    ydot=dexp(logymean)
    
    ! loop over lambdas in the range [-2,+2] and find maximum likelihood value
    lhmax=-999999.0d0; lambda=-9.0d0; jmax=1
    do j=1,nlam
        lam(j)=-2.0d0+dble((j-1))*(4.0/(dble(nlam-1)))
        yt=dble(qmiss); zt=dble(qmiss)
        ! Box-Cox transformation with current lambda
        do i=1,n
            if (y(i).ne.dble(qmiss)) then
                if (lam(j).ne.0.0) then
                    yt(i)=(y(i)**lam(j) -1.0d0)/lam(j)
                else
                    yt(i)=logy(i)*(1.0d0+(lam(j)*logy(i))/2.0d0*(1.0d0+(lam(j)*logy(i))/3.0d0*(1.0d0+(lam(j)*logy(i))/4.0d0)))
                end if
                zt(i)=yt(i)/(ydot**(lam(j)-1.0d0))
            end if
        end do 
        ! "residual" sum of squares
        call dmean(n,zt,dble(qmiss),ztmean)  
        rss=0.0d0
        do i=1,n
            if (zt(i).ne.qmiss) rss=rss+(zt(i)-ztmean)**2
        end do
        ! likelihood
        lh(j)=(-1.0*nonmiss/2.0d0)*dlog(rss)
        if (lh(j).ge.lhmax) then
            lhmax=lh(j)     ! maximum likelihood value
            lambda=lam(j)   ! lambda at maximum likelihood
            jmax=j
        end if      
        
    end do
    write (*,'(f8.2,f12.1,i4)') lambda,lhmax,jmax
    
    ! transformation with optimal lambda
    
    do i=1,n
        if (y(i).ne.dble(qmiss)) then
            if (lambda.ne.0.0d0) then
                tquant(i)=(y(i)**lambda-1.0d0)/lambda
            else
                tquant(i)=dlog(y(i))
            end if
        end if
    end do  
    
    lambda2=sngl(lambda)
    lhmax2=sngl(lhmax)
               			        
end subroutine boxcox  

subroutine mean(n,x,xmiss,xmean)

    implicit none
    
    integer, intent(in)     :: n
    real(4), intent(in)     :: x(n),xmiss
    real(4), intent(out)    :: xmean
    integer(4)              :: npts
    integer(4)              :: i
    
    npts=0; xmean=0.0
    do i=1,n
        if (x(i).ne.xmiss) then
            xmean=xmean+x(i)
            npts=npts+1
        end if
    end do
    if (npts.ne.0) then
        xmean=xmean/real(npts)
    else
        xmean=xmiss
    end if
    
end subroutine mean

subroutine dmean(n,x,xmiss,xmean)

    implicit none
    
    integer, intent(in)     :: n
    real(8), intent(in)     :: x(n),xmiss
    real(8), intent(out)    :: xmean
    integer(4)              :: npts
    integer(4)              :: i
    
    npts=0; xmean=0.0
    do i=1,n
        if (x(i).ne.xmiss) then
            xmean=xmean+x(i)
            npts=npts+1
        end if
    end do
    if (npts.ne.0) then
        xmean=xmean/dble(npts)
    else
        xmean=xmiss
    end if
    
end subroutine dmean

subroutine stats(n,age,q,qmiss,begbase,endbase,nbase,mean,stdev,qmin,qmax,qrng)

    implicit none

    integer, intent(in)     :: n
    real(4), intent(in)     :: age(n),q(n),qmiss
    real(4), intent(in)     :: begbase,endbase
    real(4), intent(out)    :: mean,stdev,qmax,qmin,qrng
    integer(4), intent(out) :: nbase

    integer(4)              :: i    
   
    ! mean
    nbase=0; mean=0.0
    do i=1,n
        if (q(i).ne.qmiss .and. age(i).ge.begbase .and. age(i).le.endbase) then
            mean=mean+q(i)
            nbase=nbase+1
        end if
    end do
    if (nbase.ne.0) then
        mean=mean/real(nbase)
    else
        mean=qmiss
    end if
    
    
    ! standard deviation
    stdev=0.0
    do i=1,n
        if (q(i).ne.qmiss .and. age(i).ge.begbase .and. age(i).le.endbase) then
            stdev=stdev+(q(i)-mean)*(q(i)-mean)
        end if
    end do
    if (nbase.gt.1) then
        stdev=sqrt((stdev)/real(nbase-1))
    else
        stdev=qmiss
    end if
    
    ! min, max, range
    qmin=9999999.0; qmax=-9999999.0
    do i=1,n
        if (q(i).ne.qmiss .and. age(i).ge.begbase .and. age(i).le.endbase) then
            if (q(i) .le. qmin) qmin=q(i)
            if (q(i) .ge. qmax) qmax=q(i)
        end if
    end do
    qrng=qmax-qmin

end subroutine stats

subroutine zscores(n,quant,qmiss,mean,stdev,z)

    implicit none

    integer, intent(in)     :: n
    real(4), intent(in)     :: quant(n),qmiss
    real(4), intent(in)     :: mean,stdev
    real(4), intent(out)    :: z(n)

    integer(4)              :: i
    
    ! zscores
    z=qmiss
    if (mean.ne.qmiss .and. stdev.ne.qmiss .and. stdev.ne.0.0) then
        do i=1,n
            if (quant(i).ne.qmiss) z(i)=(quant(i)-mean)/stdev
        end do
    end if
    
end subroutine zscores


subroutine anomaly(n,quant,qmiss,mean,anm)

    implicit none

    integer, intent(in)     :: n
    real(4), intent(in)     :: quant(n),qmiss
    real(4), intent(in)     :: mean
    real(4), intent(out)    :: anm(n)

    integer(4)              :: i
    
    ! zscores
    anm=qmiss
    if (mean.ne.qmiss) then
        do i=1,n
            if (quant(i).ne.qmiss) anm(i)=quant(i)-mean
        end do
    end if
    
end subroutine anomaly



subroutine minimax(n,age,q,qmiss,qmin,qmax,qmnx)

implicit none

    integer, intent(in)     :: n
    real(4), intent(in)     :: age(n),q(n),qmiss
    real(4), intent(in)     :: qmin,qmax
    real(4), intent(out)    :: qmnx(n)

    integer(4)              :: i
       
    qmnx=0.0 !qmnx=qmiss
    do i=1,n
        if (q(i).ne.qmiss) then
            qmnx(i)=(q(i)-qmin)/(qmax-qmin)
        end if
    end do
    
end subroutine minimax       

subroutine closest(n,age,q,qmiss,agetarg,qclose,ageclose)

    implicit none

    integer, intent(in)     :: n
    real(4), intent(in)     :: age(n),q(n),qmiss
    real(4), intent(in)     :: agetarg
    real(4), intent(out)    :: qclose,ageclose
    
    real(4)                 :: agediff,mindiff
    integer(4)              :: i,imin
    
    mindiff=9999999.0
    do i=1,n
        if (q(i).ne.qmiss) then
            agediff=abs(agetarg-age(i))
            if (agediff.lt.mindiff) then
                mindiff=agediff
                imin=i
            end if
        end if
    end do
    qclose=q(imin)
    ageclose=age(imin)
    
end subroutine closest

subroutine diff(mean1,mean2,qmiss,intdiff)

    implicit none
    
    real(4), intent(in)     :: qmiss,mean1,mean2
    real(4), intent(out)    :: intdiff
    
    intdiff=qmiss
    if (mean1.ne.qmiss .and. mean2.ne.qmiss) then
        intdiff=mean2-mean1
    end if

end subroutine diff

subroutine binarydiff(mean1,mean2,qmiss,intdiff)

    implicit none
    
    real(4), intent(in)     :: qmiss,mean1,mean2
    real(4), intent(out)    :: intdiff
    
    intdiff=qmiss
    if (mean1.ne.qmiss .and. mean2.ne.qmiss) then
        if (mean2.ge.mean1) then
            intdiff=1
        else
            intdiff=-1
        end if
    end if

end subroutine binarydiff

subroutine stddiff(mean1,mean2,qmiss,mean,stdev,zintdiff)

    implicit none
    
    real(4), intent(in)     :: qmiss,mean1,mean2
    real(4), intent(in)     :: mean,stdev
    real(4), intent(out)    :: zintdiff
    
    zintdiff=qmiss
    if (mean1.ne.qmiss .and. mean2.ne.qmiss) then
        zintdiff=(mean2-mean1)/stdev
    end if

end subroutine stddiff

!function int_to_string(inum)

!	implicit none
!	character(32)	:: int_to_string
!	character(32)	:: buffer, str
!	integer			:: inum

!	write (buffer,*) inum
!	read (buffer,*) str

!	int_to_string=trim(adjustl(str))

!end function int_to_string

!function int_to_string2(inum,numlen)

!	implicit none
!	character(32)	:: int_to_string2
!	character(32)	:: buffer, str
!	character(8)	:: ifmt,iedit
!	integer			:: inum,numlen

!	iedit=int_to_string(numlen)
!	ifmt="(i"//trim(adjustl(iedit))//"."//trim(adjustl(iedit))//")"

!	write (buffer,ifmt) inum
!	read (buffer,*) str

!	int_to_string2=trim(adjustl(str))

!end function int_to_string2


end module summarize_subs