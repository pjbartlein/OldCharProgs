module uo_utils

implicit none

contains

real function convertDMStoDD(intDegrees, intMinutes, intSeconds)
	integer, intent(in)		:: intDegrees, intMinutes, intSeconds
	real					:: rMin
		
	rMin = intMinutes + (intSeconds/60)
		
	if (intDegrees.lt.0) then
		rMin = rMin*(-1)
	end if		
	
	convertDMStoDD = intDegrees + (rMin/60)
end function	

real function convertKtoC(realKelvin)
	! convert Kelvin to Celsius
	implicit none
	real, intent(in)	:: realKelvin
	
	convertKtoC = realKelvin - 273.15
end function

character*3 function getMonthAbbr(intMonth)
	
	implicit none
	integer, intent(in)		:: intMonth
	integer, parameter		:: nMonths = 12
	character*3				:: monthName(nMonths)
	data monthName/'Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'/
	
	getMonthAbbr = monthName(intMonth)

end function

character*16 function getMonthName(intMonth)
	
	implicit none
	integer, intent(in)		:: intMonth
	integer, parameter		:: nMonths = 12
	character*16				:: monthLongName(nMonths)
	data monthLongName/'January','February','March','April','May','June','July', &
		'August','September','October','November','December'/
	
	getMonthName = monthLongName(intMonth)

end function

integer function getMonthDayCount(intMonth)
	integer, intent(in)		:: intMonth
	integer					:: intDays
	
	Select Case (intMonth)
		CASE (1,3,5,7,8,10,12)
			intDays=31
		CASE (4,6,9,11)
			intDays=30
		CASE (2)
			intDays=28
		CASE DEFAULT
			intDays=-1
	end select
	getMonthDayCount=intDays

end function

!function quote(string)
!
!	character(len=*)	:: string
!	character*256		:: quote
!	character*1			:: quotemark='"'
!
!write(*,*) string
!	quote=quotemark//trim(adjustl(string))//quotemark
!write(*,*) quote
!end function quote

function int_to_string(inum)

	implicit none
	character(32)	:: int_to_string
	character(32)	:: buffer, str
	integer			:: inum

	write (buffer,*) inum
	read (buffer,*) str

	int_to_string=trim(adjustl(str))

end function int_to_string

function real4_to_string(num)

	implicit none
	character(32)	:: real4_to_string
	character(32)	:: buffer, str
	real			:: num

	write (buffer,*) num
	read (buffer,*) str

	real4_to_string=trim(adjustl(str))

end function real4_to_string

function real8_to_string(num,fmtout,fmtin)

	implicit none
	character(32)	:: real8_to_string
	character(32)	:: buffer, str,fmtout,fmtin,fmt2,fmtin2
	real*8			:: num

	fmt2=trim(adjustl(fmtout))
	fmtin2=trim(adjustl(fmtin))

	write (buffer,fmt2) num
	read (buffer,fmtin2) str

	real8_to_string=trim(adjustl(str))

end function real8_to_string

function int_to_string2(inum,numlen)

	implicit none
	character(32)	:: int_to_string2
	character(32)	:: buffer, str
	character(8)	:: ifmt,iedit
	integer			:: inum,numlen

	iedit=int_to_string(numlen)
	ifmt="(i"//trim(adjustl(iedit))//"."//trim(adjustl(iedit))//")"

	write (buffer,ifmt) inum
	read (buffer,*) str

	int_to_string2=trim(adjustl(str))

end function int_to_string2

function int_to_string3(inum,numlen)

	implicit none
	character(32)	:: int_to_string3
	character(32)	:: buffer, str
	character(8)	:: ifmt,iedit
	integer			:: inum,numlen

	iedit=int_to_string(numlen)
	ifmt="(i"//trim(adjustl(iedit))//"."//trim(adjustl(iedit))//")"

	write (buffer,ifmt) inum
	read (buffer,*) str

	int_to_string3=trim(adjustl(str))

end function int_to_string3

end module uo_utils