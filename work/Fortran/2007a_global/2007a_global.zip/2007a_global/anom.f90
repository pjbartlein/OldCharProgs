program anom
! anomalies

implicit none

integer, parameter  :: nv=9             ! number of variables
integer, parameter  :: npts=14257

real(8)             :: lat,lon                  ! lats and lons of data points
real                :: exper(nv),ctrl(nv),anm(nv)
integer             :: i,j                       

!open (1,file="E:\Projects\igbpfire\spitfire\data\model_output02\fmod.dat")
!open (2,file="E:\Projects\igbpfire\spitfire\data\model_output02\f00k.dat")   
!open (3,file="E:\Projects\igbpfire\spitfire\data\model_output02\mod0kaan.dat")

open (1,file="E:\Projects\igbpfire\spitfire\data\model_output02\MIR21.dat")
open (2,file="E:\Projects\igbpfire\spitfire\data\model_output02\MIR06.dat")   
open (3,file="E:\Projects\igbpfire\spitfire\data\model_output02\MIR2106a.dat")

do i=1,npts
    read (1,*) lat,lon,(exper(j),j=1,nv)
    read (2,*) lat,lon,(ctrl(j),j=1,nv)
    anm=exper-ctrl
    write (3,'(2f8.2,3f12.1,6f10.2)') lat,lon,(anm(j),j=1,nv)
end do

end
    

