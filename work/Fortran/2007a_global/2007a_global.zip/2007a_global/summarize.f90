program summarize
! summarize charcoal data

use summarize_subs

implicit none

! declarations -- other declarations are in module summarize_subs

integer(4)      :: id_site(maxdata),id_site2(maxdata)   ! site id's
real(4)         :: id_site2_real
integer(4)      :: id_sample(maxdata)                   ! sample id's
real(4)         :: age_in(maxdata),age(maxrec)          ! ages
character(4)    :: units_in(maxdata),units(maxsites)     ! units of measurement
character(4)    :: context_in(maxdata),context(maxsites)    ! depositional context
character(4)    :: status_in(maxdata),status(maxsites)      ! database status
character(4)    :: source_in(maxdata),source(maxsites)      ! charcoal data source                 
real(4)         :: quant_in(maxdata),quant(maxrec)      ! quantity
real(4)         :: lat(maxdata),lon(maxdata)           ! decimal lat and lon
real(4)         :: lat_in,lon_in
integer         :: id_site_in(maxdata),id_sample_in(maxdata)
character(4)    :: id_site_char
character(80)   :: site_name(maxdata),site_name_in

real(4)         :: site_lat(maxsites)
real(4)         :: site_lon(maxsites)                   ! decimal lat and lon
real(4)         :: qmiss                                ! quantity missing data code

integer(4)      :: site(maxsites), npts(maxsites)       ! site id's and number of points in block
integer(4)      :: bstart(maxsites),bend(maxsites)      ! block start and end obs numbers

integer         :: firstyr(maxsites),lastyr(maxsites)                       

real(4)         :: trans,tquant(maxrec)                 ! transformation parameter and series
real(4)         :: lambda, shift, lhmax                 ! Box-Cox transformation parameters

real(4)         :: begbase,endbase                      ! beginning and end of base period for stats
real(4)         :: qmean,qstdev,qmin,qmax,qrng          ! basic stats for an interval (no trans)
real(4)         :: qmeant,qstdevt,qmint,qmaxt,qrngt     ! basic stats for an interval (transformed)

real(4)         :: z(maxrec),zt(maxrec)                 ! zscores
real(4)         :: anm(maxrec)                          ! anomalies
real(4)         :: qmnx(maxrec),qmnxt(maxrec)           ! minimax transformed

real(4)         :: agetarg1,agetarg2,agetarg3           ! target ages
real(4)         :: qclose1,qclose2,zqclose1,zqclose2    ! values at points closest to target ages
real(4)         :: qclose3,qclose4,zqclose3,zqclose4    ! values at points closest to target ages
real(4)         :: qage1,qage2,qage3,qage4              ! ages at points closest to target ages

real(4)         :: begrng1,endrng1,begrng2,endrng2      ! beginnings and ends of two age ranges
real(4)         :: begrng3,endrng3,begrng4,endrng4      ! beginnings and ends of two age ranges
real(4)         :: mean1,stdev1,qmin1,qmax1,qrng1       ! interval stats, untransformed
real(4)         :: mean2,stdev2,qmin2,qmax2,qrng2       ! interval stats, untransformed
real(4)         :: mean3,stdev3,qmin3,qmax3,qrng3       ! interval stats, untransformed
real(4)         :: mean4,stdev4,qmin4,qmax4,qrng4       ! interval stats, untransformed
real(4)         :: diff12,diff12t,pdiff12,pdiff12t      ! plain and standardized interval differences
real(4)         :: diff13,diff13t,pdiff13,pdiff13t      ! plain and standardized interval differences

real(4)         :: mean1t,stdev1t,qmin1t,qmax1t,qrng1t  ! interval stats, transformed
real(4)         :: mean2t,stdev2t,qmin2t,qmax2t,qrng2t  ! interval stats, transformed
real(4)         :: mean3t,stdev3t,qmin3t,qmax3t,qrng3t  ! interval stats, transformed
real(4)         :: mean4t,stdev4t,qmin4t,qmax4t,qrng4t  ! interval stats, transformed

real(4)         :: modernz1,modernz2                    ! modern approximations
integer(4)      :: modnbase1,modnbase2
real(4)         :: modmeanz1,modmeanz2
real(4)         :: modstdevz1,modstdevz2
real(4)         :: modqmintz1,modqmintz2
real(4)         :: modqmaxtz1,modqmaxtz2
real(4)         :: modqrngz1,modqrngz2

integer(4)      :: nvars                                ! number of variables
character(8)    :: varname(maxvars)                     ! varname
character(128)  :: vartitle(maxvars)                    ! variable title
character(80)   :: header
!character(32)   :: int_to_string2
character(128)  :: siteoutpath

 
integer(4)      :: i,ii,j,k,ndata,nsites,nsites2,nbase,irec

open (1,file="e:\Projects\igbpfire\charsum\data\current_hs1\files\HS_1a.txt")
open (2,file="E:\Projects\igbpfire\charsum\data\current_hs1\files\HS_1a_samples.csv")
open (3,file="E:\Projects\igbpfire\charsum\data\current_hs1\files\HS_1a_site.csv")
open (4,file="E:\Projects\igbpfire\charsum\data\work03\HS_1a_site.dat")
open (5,file="E:\Projects\igbpfire\charsum\data\work03\varlist.dat")
open (10,file="E:\Projects\igbpfire\charsum\data\current_hs1\files\HS_1a_site_list.csv")
open (7,file="E:\Projects\igbpfire\charsum\data\current_hs1\files\HS_1a_units.csv")
open (9,file="E:\Projects\igbpfire\charsum\data\current_hs1\files\HS_1a_lambda.csv")
siteoutpath="E:\Projects\igbpfire\charsum\data\current_hs1\sites\sitecsv\"


! set summarization parameter values
qmiss=-9999.0       ! missing data code
begbase=100.0       ! begining of base period
endbase=4000.0      ! end of base period
agetarg1=-60.0      ! target age
agetarg2=6000.0     ! target age
begrng1=100.0       ! beginning of interval averaging period 1
endrng1=1000.0       ! end of interval averaging period 1
begrng2=5500.0      ! beginning of interval averaging period 2
endrng2=6500.0      ! end of interval averaging period 2
begrng3=20500.0     ! beginning of interval averaging period 3
endrng3=21500.0     ! end of interval averaging period 3
shift=0.01          ! Box-Cox transformation shift parameter (input)

! read all data from .txt query file and determine number of blocks
call read_data(ndata, id_site_in, id_sample_in, units_in, age_in, quant_in, &
                context_in, source_in, nsites, &
                site, units, context, source, bstart, bend, npts)
write (*,'("nsites from read_data: ",i5)') nsites
                
! read site_list query file
i=0
read (10,*) header
do
    if (eof(10)) exit
    i=i+1
    read (10,*) id_site2_real,site_name_in,lat_in,lon_in
    id_site2(i)=int(id_site2_real)
    lat(id_site2(i))=lat_in
    lon(id_site2(i))=lon_in
    site_name(id_site2(i))=site_name_in
    write (*,*) i,id_site2_real,id_site2(i)
end do
nsites2=i
      
i=0
do while(.not.eof(5))
    i=i+1
    read (5,'(a8,5x,a72)') varname(i)
end do
nvars=i

! write headers
write (2,'(a)') 'row,lat,lon,id_site, id_sample, age, id_units, quant, tquant, zt, anm' 
write (3,'(40(a8,", "))') (varname(i),i=1,nvars)
write (7,'("recnum,lat,lon,id_site,units")') 
write (9,'("lat,lon,id_site,lambda,lhmax,npts")') 


! loop over site id/units blocks

irec=0
do j=1,nsites
    write (*,*) j,lat(site(j)),lon(site(j)),site(j),npts(j)
    write (7,'(i5,",",2(f12.6,","),i6,",",a4)') j,lat(site(j)),lon(site(j)),site(j),units(j)
    firstyr(j)=age_in(bstart(j))
    lastyr(j)=age_in(bend(j))
    
    id_site_char=int_to_string2(site(j),4)
    open (8,file=trim(siteoutpath)//id_site_char//".csv")
    write (8,'("age,char,transchar,zt,anm")')
    
    ! load arrays
    ii=0
    do i=bstart(j),bend(j)
        ii=ii+1
        age(ii)=age_in(i)
        quant(ii)=quant_in(i)     
    end do  
    
    ! call summarization subroutines for this block
    
    ! log10 transform charcoal quantities
    !trans=0.0
    !call transform(npts(j),trans,quant,qmiss,tquant)   
    
    ! call Box-Cox transformation of charcoal quantities
    call boxcox(npts(j),quant,qmiss,shift,lambda,lhmax,tquant)
    write (*,*) lambda,lhmax

    
!    ! basic statistics for an interval, no transformation
!    call stats(npts(j),age,quant,qmiss,begbase,endbase,nbase,qmean,qstdev,qmin,qmax,qrng)
    
    ! basic statistics for an interval from transformed values
    call stats(npts(j),age,tquant,qmiss,begbase,endbase,nbase,qmeant,qstdevt,qmint,qmaxt,qrngt)
    
!    ! z-scores of untransformed values
!    call zscores(npts(j),quant,qmiss,qmean,qstdev,z)
    
    ! z-scores of transformed values
    call zscores(npts(j),tquant,qmiss,qmeant,qstdevt,zt)
    
!    ! minimax transformation -- raw values
!    call minimax(npts(j),age,quant,qmiss,qmin,qmax,qmnx)
    
!    ! minimax transformation -- log transformed values
!    call minimax(npts(j),age,tquant,qmiss,qmint,qmaxt,qmnxt)
    
!    ! values at points closest to target ages
!    call closest(npts(j),age,z,qmiss,agetarg1,qclose1,qage1)
!    call closest(npts(j),age,z,qmiss,agetarg2,qclose2,qage2)
    
!    ! difference between points closest to two target ages
!    call binarydiff(qclose1,qclose2,qmiss,pdiff12)
    
!    ! difference between two intervals, z-scores of untransformed values
!    call stats(npts(j),age,z,qmiss,begrng1,endrng1,nbase,mean1,stdev1,qmin1,qmax1,qrng1)
!    call stats(npts(j),age,z,qmiss,begrng2,endrng2,nbase,mean2,stdev2,qmin2,qmax2,qrng2)
!    call stats(npts(j),age,z,qmiss,begrng3,endrng3,nbase,mean3,stdev3,qmin3,qmax3,qrng3)
!    call diff(mean1,mean2,qmiss,diff12)    
!    call diff(mean1,mean3,qmiss,diff13)
    
    ! difference between two intervals, z-scores of transformed values
    call stats(npts(j),age,zt,qmiss,begrng1,endrng1,nbase,mean1t,stdev1t,qmin1t,qmax1t,qrng1t)
    call stats(npts(j),age,zt,qmiss,begrng2,endrng2,nbase,mean2t,stdev2t,qmin2t,qmax2t,qrng2t)
    call stats(npts(j),age,zt,qmiss,begrng3,endrng3,nbase,mean3t,stdev3t,qmin3t,qmax3t,qrng3t)
    call diff(mean1t,mean2t,qmiss,diff12t)
    call diff(mean1t,mean3t,qmiss,diff13t)
    
    ! anomalies--values minus a particular mean
    call anomaly(npts(j),zt,qmiss,mean1t,anm)
    
!    ! difference between minimax values for two intervals, untransformed values
!    call stats(npts(j),age,qmnx,qmiss,begrng1,endrng1,nbase,mean1,stdev1,qmin1,qmax1,qrng1)
!    call stats(npts(j),age,qmnx,qmiss,begrng2,endrng2,nbase,mean2,stdev2,qmin2,qmax2,qrng2)
!    call stats(npts(j),age,qmnx,qmiss,begrng3,endrng3,nbase,mean3,stdev3,qmin3,qmax3,qrng3)
!    call diff(mean1,mean2,qmiss,diff12)    
!    call diff(mean1,mean3,qmiss,diff13)
    
!    ! difference between minimax values for two intervals, transformed values
!    call stats(npts(j),age,qmnxt,qmiss,begrng1,endrng1,nbase,mean1t,stdev1t,qmin1t,qmax1t,qrng1t)
!    call stats(npts(j),age,qmnxt,qmiss,begrng2,endrng2,nbase,mean2t,stdev2t,qmin2t,qmax2t,qrng2t)
!    call stats(npts(j),age,qmnxt,qmiss,begrng3,endrng3,nbase,mean3t,stdev3t,qmin3t,qmax3t,qrng3t)
!    call diff(mean1t,mean2t,qmiss,diff12t)
!    call diff(mean1t,mean3t,qmiss,diff13t)

    
    !! basic statistics for an interval from transformed values
    !call stats(npts(j),age,zt,qmiss,100.,500.,modnbase1,modmeanz1,modstdevz1,modqmintz1,modqmaxtz1,modqrngz1)
    !call stats(npts(j),age,zt,qmiss,250.,750.,modnbase2,modmeanz2,modstdevz2,modqmintz2,modqmaxtz2,modqrngz2)

    ii=0
    do i=bstart(j),bend(j)
        irec=irec+1
        ii=ii+1
        write (2,'(i6,",",f10.4,",",f10.4,",",i5,",",i7,",",f7.0," ," "",a6,"" ,4(",",f14.4))') &
            i,lat(site(j)),lon(site(j)),site(j),id_sample_in(i),age_in(i),units_in(i),quant_in(i), &  
            tquant(ii),zt(ii),anm(ii)
        write (8,'(f14.6,",",f14.4,",",f14.4,",",f14.4,",",f14.4)') &
            age(ii),quant(ii),tquant(ii),zt(ii),anm(ii)
    end do
    close(8)
    
    !write (3,'(f10.4,",",f10.4,",",i5,2i7,2(",",a4),",",2(i6,","),30(f14.3,","))') &
    !    site_lat(j),site_lon(j),site(j),firstyr(j),lastyr(j),units(j),context(j), &
    !    npts(j),nbase,mean,stdev,meant,stdevt,qmin,qmax, &
    !    qclose1,qage1,qclose2,qage2,pdiff12,mean1,mean2,mean3,diff12,diff13, &
    !    mean1t,mean2t,mean3t,tdiff12,tdiff13 
    !    
    !write (4,'(f10.4,f10.4,i5,2i7,2(1x,"""",a4""""),2i6,30f14.3)') &
    !    site_lat(j),site_lon(j),site(j),firstyr(j),lastyr(j),units(j),context(j), &
    !    npts(j),nbase,mean,stdev,meant,stdevt,qmin,qmax, &
    !    qclose1,qage1,qclose2,qage2,pdiff12,mean1,mean2,mean3,diff12,diff13, &
    !    mean1t,mean2t,mean3t,tdiff12,tdiff13 
    !write (4,'(f10.4,f10.4,f14.3)') site_lat(j),site_lon(j),mean2
    
!    write (3,'(f10.4,",",f10.4,",",i5,",",30(f14.3,","))') &
!        site_lat(j),site_lon(j),site(j),mean1,mean2,mean3,diff12,diff13        
!    write (4,'(f10.4,f10.4,i5,30f14.3)') &
!        site_lat(j),site_lon(j),site(j),mean1,mean2,mean3,diff12,diff13
        
    write (3,'(f10.4,",",f10.4,",",i5,",",30(f14.3,","))') &
        lat(site(j)),lon(site(j)),site(j),mean1t,mean2t,mean3t,diff12t,diff13t     
    write (4,'(f10.4,f10.4,i5,30f14.3)') &
        lat(site(j)),lon(site(j)),site(j),mean1t,mean2t,mean3t,diff12t,diff13t 
    write (9,'(f10.4,",",f10.4,",",i5,",",f8.2,",",f12.1,",",i5)') &
        lat(site(j)),lon(site(j)),site(j),lambda,lhmax,npts(j)      
    
end do
close(2)
close(3)
           
end
    
