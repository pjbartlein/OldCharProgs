program summary_char
! summarizes decomp files for a set of sites

use summarize_subs  ! summarize_subs.f90
use chaps_subs      ! chaps_module.f90
use lwr             ! lwr_module.f90
use uo_utils        ! uo_utils.f90

implicit none

integer, parameter :: maxtarg=2200
integer(4)      :: site_num,nsamples
real(8)         :: lat,lon                              ! lat and lon
character(72)   :: site_name                            ! site name
real(4)         :: begbase,endbase                      ! base period

integer         :: sample(maxdata)                      ! sample number                           
real(4)         :: depth(maxdata),est_age(maxdata)      ! depth, ages
real(4)         :: quant(maxdata),qmiss                 ! charcoal quantity, missing value code
real(4)         :: qconst                               ! additive constant for log transform
real(4)         :: tquant(maxdata)                      ! transformed charcoal quantity
real(4)         :: tmean(maxdata)                       ! local fitted value of charcoal quantity

real(4)         :: qmean(maxdata)                       ! untransformed value of local mean
real(4)         :: tdev(maxdata)                        ! tquant-tmean
real(4)         :: dev(maxdata)                         ! quant-mean
real(4)         :: posdev(maxdata)                      ! positive values of dev
real(4)         :: ratio(maxdata),tratio                ! tquant/tmean if posdev ne 0

integer(4)      :: peak(maxdata)                        ! peak 0/1 (tquant > thresh)
integer(4)      :: pstart(maxdata)                      ! 0/1 beginning of peak
integer(4)      :: pend(maxdata)                        ! 0/1 end of peak
real(4)         :: rpeak(maxdata)                       ! real-value peak series
real(4)         :: rpstart(maxdata)                     ! real-value peak-start series
integer(4)      :: pcount(maxdata)                      ! count of peaks in window
real(4)         :: rpcount(maxdata)                     ! real-value count of peaks
real(4)         :: smpcount(maxdata)                    ! smoothed value of rpcount

!real(4)         :: freq(maxdata)                        ! peak frequency (probability of peak)
!real(4)         :: smfreq(maxdata)                      ! smoothed peak frequency
real(4)         :: pprob(maxdata)                       ! probability sample is peak 
real(4)         :: smpprob(maxdata)                     ! smoothed probability sample is peak
real(4)         :: pmag(maxdata)                        ! total (quant) under peak
real(4)         :: mag(maxdata)                         ! smoothed peak magnitude
real(4)         :: dcquant(maxdata)                     ! detrended cumulative quant
real(4)         :: dcpeaks(maxdata)                     ! detrended cumulative peaks

real(4)         :: qmn,qstdev,qmin,qmax,qrng            ! parameters for minimax transformation
integer(4)      :: nbase                                ! parameters for minimax transformations

real(4)         :: mquant(maxdata)                      ! mm-trans quant values
real(4)         :: mqmean(maxdata)                      ! mm-trans mean values
real(4)         :: msmpcount(maxdata)                   ! mm-trans smoothed values of peak counts
real(4)         :: mpmag(maxdata)                       ! mm-trans pmag values
real(4)         :: mmag(maxdata)                        ! mm-trans mag values

real(4)         :: aage(maxdata)                        ! all age values
real(4)         :: amquant(maxdata)                     ! all mm-trans tquant values
real(4)         :: amqmean(maxdata)                     ! all mm-trans tmean values
integer(4)      :: apstart(maxdata)                     ! all pstart values (including zeros)
real(4)         :: arpstart(maxdata)                    ! real values all pstart values
real(4)         :: amsmpcount(maxdata)                  ! all mm-trans smoothed values of peak counts
real(4)         :: aagenzpmag(maxdata)                  ! all ages of nonzero pmag values
real(4)         :: amnzpmag(maxdata)                    ! all mm-trans nonzero pmag values
real(4)         :: ramnzpmag(maxdata)                   ! sqrt all mm-trans nonzero pmag values
real(4)         :: ammag(maxdata)                       ! all mm-trans mag values

character(1)    :: wintype                              ! lowess params 
real(4)         :: width                                 
integer(4)      :: order,nrobust

real(4)         :: begtarg,endtarg,targstep             ! target age parameters
real(4)         :: tage(maxtarg)                        ! target ages for lowess curves
integer(4)      :: ntarg                                ! number of target ages

real(4)         :: smquant(maxtarg)                     ! smoothed all quant values
real(4)         :: smqmean(maxtarg)                     ! smoothed all tmean values
real(4)         :: smpstart(maxdata)                    ! smoothed all pstart values (including zeros)
real(4)         :: smsmpcount(maxtarg)                  ! smoothed all smoothed values of peak counts
real(4)         :: smmnzpmag(maxtarg)                   ! smoothed all nonzero pmag values
real(4)         :: rsmmnzpmag(maxtarg)                  ! sqrt smoothed all nonzero pmag values

real(4)         :: smmagage(maxdata)                    ! ages of non-NaN smmag values
real(4)         :: smmag(maxdata)                       ! smoothed all mag (smmag)
                

integer         :: i,j,k,n,npts,ii,nnzpmag,iii,nnan
character(256)  :: inpath,outpath,sitelist,debugfile,pstartfile,pmagfile,sumdatafile,sumcurvesfile
character(4)    :: site_num_char
character(1)    :: dum

inpath="\Projects\igbpfire\nachar\data\char_decomp_sum\NRM2k\decomp_csv\"
outpath="\Projects\igbpfire\nachar\data\char_decomp_sum\NRM2k\summary_csv\"
debugfile="\Projects\igbpfire\nachar\data\char_decomp_sum\NRM2k\summary_csv\debug2.dat"

sitelist="\Projects\igbpfire\nachar\data\char_decomp_sum\NRM2k\sum_list_NRM2k.csv"
pstartfile="\Projects\igbpfire\nachar\data\char_decomp_sum\NRM2k\summary_csv\allpstart_NRM2k.csv"
pmagfile="\Projects\igbpfire\nachar\data\char_decomp_sum\NRM2k\summary_csv\allnzpmag_NRM2k.csv"
sumdatafile="\Projects\igbpfire\nachar\data\char_decomp_sum\NRM2k\summary_csv\sumdata_NRM2k.csv"
sumcurvesfile="\Projects\igbpfire\nachar\data\char_decomp_sum\NRM2k\summary_csv\sumcurves_NRM2k.csv"

! lowess summary curve parameters
wintype="w"
width=2000.0
order=2
nrobust=1

open (10,file=debugfile)

qmiss=-9999.0       ! missing data code -- not really implemented here yet

! target ages for summary lowess curves
begtarg=-50.0
endtarg=15000.0
targstep=50.0
ntarg=int((endtarg-begtarg)/targstep)+1
do i=1,ntarg
    tage(i)=-50+(i-1)*50.0
!    write (*,*) i,tage(i)
end do

! open the sitelist 
open(1,file=sitelist)

! open output files for all pstart and all pmag
open (6,file=pstartfile)
open (7,file=pmagfile)
write (6,'(a)') "site_num,speak_num,est_age"
write (7,'(a)') "site_num,est_age,mnzpmag,rmnzpmag"
! open output files for lowess curves
open (8,file=sumdatafile)
write (8,'(a)') "site_num,est_age,mquant,mqmean,pstart,msmpcount,mpmag,mmag"
open (9,file=sumcurvesfile)
write (9,'(a)') "tage,smquant,smqmean,smsmpcount,smmnzpmag,smmag,rsmmnzpmag"

! loop over sites
read (1,*) dum      ! read header
j=0
ii=0
iii=0
nnzpmag=0
do
    j=j+1
    if (eof(1)) exit    ! exit loop if at end of file
    
    ! read info for j-th site
    read (1,*) site_num,lat,lon,nsamples,begbase,endbase,site_name   
    write (*,'(2i5,1x,a72)') j,site_num,site_name
    write (*,'(a)') "begbase, endbase: "
    write (*,'(2f8.1)') begbase,endbase
    write (10,'(2i5,1x,a72)') j,site_num,site_name
    write (10,'(a)') "begbase, endbase: "
    write (10,'(2f8.1)') begbase,endbase
    
    ! open an input file, and read data
    site_num_char=int_to_string2(site_num,4)
    open (2,file=trim(inpath)//site_num_char//"_decomp.csv")  
    read (2,*) dum
       
    do i=1,nsamples
        read (2,*) sample(i),depth(i),est_age(i), &
            quant(i),qmean(i),dev(i),posdev(i),tquant(i),tmean(i),tdev(i), &
            peak(i),pstart(i),pend(i),rpcount(i),smpcount(i), &
            pprob(i),smpprob(i),pmag(i),mag(i), &
            dcquant(i),dcpeaks(i)
    end do
    
    ! begin summary
    
    ! minimax transformations
    call stats(nsamples,est_age,quant,qmiss,begbase,endbase,nbase,qmn,qstdev,qmin,qmax,qrng)
    write (*,*) qmn,qstdev,qmin,qmax,qrng
    call minimax(nsamples,est_age,quant,qmiss,qmin,qmax,mquant)
    call stats(nsamples,est_age,qmean,qmiss,begbase,endbase,nbase,qmn,qstdev,qmin,qmax,qrng)
    call minimax(nsamples,est_age,qmean,qmiss,qmin,qmax,mqmean)
    call stats(nsamples,est_age,smpcount,qmiss,begbase,endbase,nbase,qmn,qstdev,qmin,qmax,qrng)
    call minimax(nsamples,est_age,smpcount,qmiss,qmin,qmax,msmpcount)
    do k=1,nsamples
        write (10,*) i,k,smpcount(k),msmpcount(k)
    end do
    call stats(nsamples,est_age,pmag,qmiss,begbase,endbase,nbase,qmn,qstdev,qmin,qmax,qrng)
    call minimax(nsamples,est_age,pmag,qmiss,qmin,qmax,mpmag)
    !call stats(nsamples,est_age,mag,qmiss,begbase,endbase,nbase,qmn,qstdev,qmin,qmax,qrng)
    call minimax(nsamples,est_age,mag,qmiss,qmin,qmax,mmag)
    
    ! accumulate values for lowess curves
    do i=1,nsamples
        ii=ii+1
        aage(ii)=est_age(i)
        amquant(ii)=mquant(i)
        amqmean(ii)=mqmean(i)
        apstart(ii)=pstart(i)
        arpstart(ii)=sngl(apstart(ii))
        amsmpcount(ii)=msmpcount(i)
        if (isnan(amsmpcount(ii))) amsmpcount(ii)=0.0
        write (10,*) i,ii,aage(ii),amsmpcount(ii)
        if (pmag(i).gt.0.0) then
            nnzpmag=nnzpmag+1
            aagenzpmag(nnzpmag)=est_age(i)
            if (isnan(aagenzpmag(ii))) aagenzpmag(ii)=0.0
            amnzpmag(nnzpmag)=mpmag(i)
            if (isnan(amnzpmag(ii))) amnzpmag(ii)=0.0
            ramnzpmag(nnzpmag)=sqrt(amnzpmag(nnzpmag))
            write (7,'(i4,",",f12.4,2(",",f10.4))') site_num,aagenzpmag(nnzpmag),amnzpmag(nnzpmag),ramnzpmag(nnzpmag)
        end if
        if (.not. isnan(mmag(i))) then
            iii=iii+1
            ammag(iii)=mmag(i)
            smmagage(iii)=est_age(i)
 !           write (*,*) iii,smmagage(iii),ammag(iii)
        end if     
        
        if (pstart(i).gt.0) then
            write (6,'(i4,",",i4,",",f12.4)') site_num,j,est_age(i)
        end if
        
        ! trap some Nan's
        if (isnan(msmpcount(i))) msmpcount(i)=0.0
        if (isnan(mpmag(i))) mpmag(i)=0.0
        if (isnan(mmag(i))) mmag(i)=0.0
            
        write (8,'(i4,3(",",f12.4),",",i4,4(",",f12.4))') & 
            site_num,est_age(i),mquant(i),mqmean(i),pstart(i),msmpcount(i),mpmag(i),mmag(i)
    end do
   
    ! create the output .csv file, and write data 
    open (3,file=trim(outpath)//site_num_char//"_summary.csv")
    ! first column label is site number
    write (3,'(a)') "site"//site_num_char//","// &
        "depth,est_age,quant,qmean,dev,posdev,tquant,tmean,tdev,"// &
        "pstart,smpcount,pmag,mquant,mqmean,msmpcount,mpmag,mmag "     
    do i=1,nsamples
        write (3,'(i4,",",f10.4,",",f9.1, 7(", ",f12.4), &
            ",",i4,7(",",f12.4) )') & 
            sample(i),depth(i),est_age(i), &
            quant(i),qmean(i),dev(i),posdev(i),tquant(i),tmean(i),tdev(i), &
            pstart(i),smpcount(i),pmag(i),mquant(i),mqmean(i),msmpcount(i),mpmag(i),mmag(i)
    end do
    
    close(2)
    close(3)
    
    write (*,'(/)') 
    write (10,'(/)') 
    
!    pause
        
end do
npts=ii
nnan=iii

close(6)
close(7)
close(8)

! all data in -- do lowess curves

write (*,'(a)') "smquant"
call fitlwr2(npts,amquant,qmiss,aage,ntarg,tage,wintype,width,order,nrobust,smquant)
write (*,'(a)') "smqmean"
call fitlwr2(npts,amqmean,qmiss,aage,ntarg,tage,wintype,width,order,nrobust,smqmean)
write (*,'(a)') "smsmpcount"
call fitlwr2(npts,amsmpcount,qmiss,aage,ntarg,tage,wintype,width,order,nrobust,smsmpcount)
write (*,'(a)') "smmnzpmag"
call fitlwr2(nnzpmag,amnzpmag,qmiss,aagenzpmag,ntarg,tage,wintype,width,order,nrobust,smmnzpmag)
write (*,'(a)') "smmag"
call fitlwr2(nnan,ammag,qmiss,smmagage,ntarg,tage,wintype,width,order,nrobust,smmag)

do i=1,ntarg
    rsmmnzpmag(i)=sqrt(smmnzpmag(i))
    write (9,'(f12.4,8(",",f10.4))') &
        tage(i),smquant(i),smqmean(i),smsmpcount(i),smmnzpmag(i),smmag(i),rsmmnzpmag(i)
end do

close(9)

end program summary_char
