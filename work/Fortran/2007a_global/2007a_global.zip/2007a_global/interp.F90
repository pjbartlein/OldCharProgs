program interp

use nc_subs

implicit none

!integer, parameter  :: nlat=360, nlon=720
integer, parameter  :: nlat=180, nlon=360

real(8)             :: lat(nlat),lon(nlon),latmin,lonmin,dlat,dlon
real                :: a1(nlat,nlon),a2(nlat,nlon),a1fill,a2fill
real(8)             :: latin,lonin,a1in,a2in,tlat,tlon
real                :: a1int,a2int,gdist
real                :: dist,dmin
character(1)        :: dum

integer             :: j,k,jmin,kmin,jj,kk,jjj,kkk

a1fill=-9999.0; a2fill=-9999.0
a1=a1fill; a2=a2fill

!open (1,file="E:\Projects\igbpfire\spitfire\data\model_output\ctrl_0k_ave_fire.csv")
!open (1,file="E:\Projects\igbpfire\spitfire\data\model_output\6k_oa_mean_fire.csv")
open (1,file="E:\Projects\igbpfire\spitfire\data\model_output\6k_oa_mean_areaburnt.txt")
open (4,file="E:\Projects\igbpfire\spitfire\data\model_output\6k_oa_mean_firec.txt")

open (2,file="E:\Projects\igbpfire\spitfire\data\cru_grid\cru10min30_pts.dat")

!open (3,file="E:\Projects\igbpfire\spitfire\data\model_output\ctrl_0k_ave_fire_grd.csv")
open (3,file="E:\Projects\igbpfire\spitfire\data\model_output\6k_oa_mean_fire_grd.dat")


! generate grid
!latmin=-89.75d0; lonmin=-179.75d0; dlat=0.50d0; dlon=0.50d0
latmin=-89.5d0; lonmin=-179.5d0; dlat=1.0d0; dlon=1.0d0

do j=1,nlon
    lon(j)=lonmin+(j-1)*dlon
    write (*,*) j,lon(j)
end do
do k=1,nlat
    lat(k)=latmin+(k-1)*dlat
    write (*,*) k,lat(k)
end do

! read control data
read (1,*) dum
do while(.not.eof(1))
    read (1,*) lonin,latin,a1in !,a2in
    j=cell(lonin,nlon,lon)
    k=cell(latin,nlat,lat)
    k=nlat-k+1
    a1(k,j)=a1in
!    write (*,'(2f8.2,2f12.4,2i5,2f8.2)') lonin,latin,a1in,j,k,lon(j),lat(k)
end do
read (4,*) dum
do while(.not.eof(4))
    read (4,*) lonin,latin,a2in
    j=cell(lonin,nlon,lon)
    k=cell(latin,nlat,lat)
    k=nlat-k+1
    a2(k,j)=a2in    
!    write (*,'(2f8.2,2f12.4,2i5,2f8.2)') lonin,latin,a2in,j,k,lon(j),lat(k)
end do
!do k=1,nlat
!    write (3,'(720f12.4)') (a2(k,j),j=1,nlon)
!end do


! read target data and interpolate
do while (.not.eof(2))
    read (2,*) tlat,tlon  
    j=cell(tlon,nlon,lon)
    k=cell(tlat,nlat,lat)
    k=nlat-k+1
    if (a1(k,j).ne.a1fill) then
        write (3,'(2f8.2,2f12.4)') tlat,tlon,a1(k,j),a2(k,j)       
        write (*,'(2f8.2,2f12.4,2i5)') tlat,tlon,a1(k,j),a2(k,j),j,k       
    else    
        dmin=9999999.0
        do jj=1,nlon
	        do kk=1,nlat
		        !call wrap(jj,kk,nlon,nlat,jjj,kkk)
		        dist=gdist(tlat,tlon,lat(kk),lon(jj))
		        if (dist.lt.dmin .and. a1(kk,jj).ne.a1fill) then
			        dmin=dist
			        jmin=jj
			        kmin=kk
		        end if
	        end do
        end do
        write (3,'(2f8.2,2f12.4)') tlat,tlon,a1(kmin,jmin),a2(kmin,jmin)
    end if
end do

end