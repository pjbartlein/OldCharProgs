program site_smooth_v2_lr
! gets lowess-smoothed values for an individual site

use lowess

implicit none

integer, parameter  :: maxdata=300000, maxsites=5000 

integer(4)      :: site_sample
integer(8)      :: id_sample
real(4)         :: depth,age,var,varmnx,tall,ztall,zt21k,zt15132k,zt132k,zt40k,zt1583k
real(4)         :: varin,varmiss
real(8)         :: begbase,endbase
character(8)    :: site_num_label

real(8)         :: xin(maxdata),yin(maxdata),xtarg(maxdata),yfit(maxdata)
real(8)         :: yfitse(maxdata),fitcu_95(maxdata),fitcl_95(maxdata),ypredse(maxdata)
real(8)         :: xtemp(maxdata),vartemp(maxdata),vartemp2(maxdata),vmean,vstdev,vmin,vmax,vrng

integer         :: npfit(maxdata),minpts
real(8)         :: param,stage1,xspan(maxdata)
real(8)         :: targbeg,targend,targstep
integer(4)      :: order,nrobust,ntarg
character(1)    :: wintype

integer         :: i,j,npts,nctrl,npts2

character(32)   :: int_to_string2
character(256)  :: transpath,smoothpath,allfile,transfile,smoothfile
character(80)   :: header
character(1)    :: dum
character(4)    :: site_num_char,char_s1
character(16)   :: base, query, sww
character(32)   :: vname

base="zt15132k" 
query="v2l-lr"

stage1=10.0
sww=int_to_string2(int(stage1),2)
char_s1="sm"//trim(adjustl(sww))

vname="conc2"

! lowess parameters
param=dble(stage1); minpts=0; wintype='w'; order=0; nrobust=0

! target point definitions
targend=300000.0d0; targbeg=-60.0d0; targstep=2.0*sngl(param)

! restandardization
begbase=15000.0d0; endbase=132000.0d0 

! generate target points
ntarg=int((targend-targbeg)/targstep)+1
write (*,*) stage1,param,targstep,ntarg
do i=1,ntarg
    xtarg(i)=targbeg+dble(i-1)*targstep
    !xtarg(i)=targend-dble(i-1)*targstep
    !write (*,*) i,sngl(xtarg(i))
end do


allfile="\PROJECTS\GPWG\data\files\v2l\"//trim(adjustl(query))//"_all_"//trim(adjustl(vname))// &
    "_"//trim(adjustl(base))//"_"//char_s1//".csv"
smoothpath="\PROJECTS\GPWG\data\csv_files\"//trim(adjustl(query))//"_smooth_"//trim(adjustl(vname))// &
    "_"//trim(adjustl(base))//"_sm"//trim(adjustl(sww))
transpath="\PROJECTS\GPWG\data\csv_files\"//trim(adjustl(query))//"_trans_"//trim(adjustl(vname))
write (*,*) trim(adjustl(allfile))
write (*,*) trim(adjustl(smoothpath))
write (*,*) trim(adjustl(transpath))

open (3,file=allfile)
write (3,'("site, xtarg, yfit, sefit, cu95, cl95, np")')

varmiss=-9999.0

! loop over sites
do j=1,2000

    site_num_char=int_to_string2(j,4)
    
    ! try to open a file
    site_num_char=int_to_string2(j,4)
    transfile=trim(adjustl(transpath))//"\"//trim(adjustl(site_num_char))//"_trans_"//trim(adjustl(vname))//".csv"
    smoothfile=trim(adjustl(smoothpath))//"\"//trim(adjustl(site_num_char))//"_smooth_"//trim(adjustl(vname))// &
        "_"//trim(adjustl(base))//"_sm"//trim(adjustl(sww))//".csv"
    open (1,file=transfile, status='old', err=100)
    open (2,file=smoothfile) 
    write (*,*) trim(transfile)
    write (*,*) trim(smoothfile)
    
    write (2,'("site",a4,", xtarg, yfit, sefit, fitcu95, fitcl95, np")') site_num_char
    write (*,*) site_num_char
    
    ! read data, and save age and variable to be smoothed
    read (1,*) header
    i=0
    do while (.not. eof(1))
        read (1,*) site_num_label,site_sample,id_sample,age,depth,var,varmnx,tall,ztall,zt21k,zt15132k,zt132k,zt40k,zt1583k

        select case (base)
            case ("zt15132k")
                varin=zt15132k 
            case ("zt132k") 
                varin=zt132k
            case ("zt40k") 
                varin=zt40k
        end select
        !write (*,*) i,varin
        if (varin.ne.varmiss) then
            i=i+1
            xin(i)=age
            yin(i)=varin
            ! write (2,'(i5," ,",a8," ,",i4,2(",",f14.6))') i,site_num_label,site_sample,xin(i),yin(i)         
        end if
    end do
    nctrl=i
    
    yfit=0.0d0; yfitse=0.0d0; fitcu_95=0.0d0; fitcl_95=0.0d0
    
    call lowess_curve(nctrl,xin,yin,ntarg,xtarg,wintype,param,minpts,order,nrobust,yfit,yfitse,ypredse,npfit,xspan)
    

    do i=1,ntarg
        if (.not. isnan(yfit(i))) then
            fitcu_95(i)=yfit(i)+2.0d0*yfitse(i)
            fitcl_95(i)=yfit(i)-2.0d0*yfitse(i)
            !write (2,'(i4,5(",",f14.6),", ",i6)') i,xtarg(i),yfit(i),yfitse(i),fitcu_95(i),fitcl_95(i),npfit(i)
            !write (3,'("site",a4,5(",",f14.6),", ",i6)') site_num_char,xtarg(i),yfit(i),yfitse(i),fitcu_95(i),fitcl_95(i),npfit(i)
        else    
            yfit(i)=varmiss
        end if
    end do
    
    ! go to 20
    
    ! restandardize
    vartemp=yfit; xtemp=xtarg
    call stats(ntarg,xtemp,vartemp,dble(varmiss),begbase,endbase,npts2,vmean,vstdev,vmin,vmax,vrng)
    write (*,'(i5,2f14.6)') j,vmean,vstdev
    !pause
    
    ! z-scores
    call zscores(ntarg,vartemp,dble(varmiss),vmean,vstdev,vartemp2)
    yfit=vartemp2
    
    vartemp=fitcu_95
    call zscores(ntarg,vartemp,dble(varmiss),vmean,vstdev,vartemp2)
    fitcu_95=vartemp2
    vartemp=fitcl_95
    call zscores(ntarg,vartemp,dble(varmiss),vmean,vstdev,vartemp2)
    fitcl_95=vartemp2
    
    20 continue
    
    !vartemp=yfit; xtemp=xtarg
    !call stats(ntarg,xtemp,vartemp,dble(varmiss),begbase,endbase,npts2,vmean,vstdev,vmin,vmax,vrng)
    !write (*,'(i5,2f14.6)') j,vmean,vstdev
    
    do i=1,ntarg
        if (yfit(i).ne.varmiss) then
            write (2,'(i7,5(",",f14.6),", ",i6,",",f10.2)') i,xtarg(i),yfit(i),yfitse(i),fitcu_95(i),fitcl_95(i),npfit(i),xspan(i)
            write (3,'("site",a4,5(",",f14.6),", ",i6,",",f10.2)') site_num_char,xtarg(i),yfit(i),yfitse(i),fitcu_95(i),fitcl_95(i),npfit(i),xspan(i)
        end if
    end do 
     
    
    write (*,*) nctrl
    close(1)
    close(2)
    
100 continue

end do

end

function int_to_string(inum)

	implicit none
	character(32)	:: int_to_string
	character(32)	:: buffer, str
	integer			:: inum

	write (buffer,*) inum
	read (buffer,*) str

	int_to_string=trim(adjustl(str))

end function int_to_string


function int_to_string2(inum,numlen)

	implicit none
	character(32)	:: int_to_string,int_to_string2
	character(32)	:: buffer, str
	character(8)	:: ifmt,iedit
	integer			:: inum,numlen

	iedit=int_to_string(numlen)
	ifmt="(i"//trim(adjustl(iedit))//"."//trim(adjustl(iedit))//")"

	write (buffer,ifmt) inum
	read (buffer,*) str

	int_to_string2=trim(adjustl(str))

end function int_to_string2

subroutine stats(n,age,q,qmiss,begbase,endbase,nbase,mean,stdev,qmin,qmax,qrng)

    implicit none

    integer, intent(in)     :: n
    real(8), intent(in)     :: age(n),q(n),qmiss
    real(8), intent(in)     :: begbase,endbase
    real(8), intent(out)    :: mean,stdev,qmax,qmin,qrng
    integer(4), intent(out) :: nbase

    integer(4)              :: i    
        
    ! mean
    nbase=0; mean=0.0d0
    do i=1,n
        if (q(i).ne.qmiss .and. age(i).ge.begbase .and. age(i).le.endbase) then
            mean=mean+q(i)
            nbase=nbase+1
        end if
    end do
    if (nbase.ne.0) then
        mean=mean/dble(nbase)
    else
        mean=qmiss
    end if
    
    ! standard deviation
    stdev=0.0
    do i=1,n
        if (q(i).ne.qmiss .and. age(i).ge.begbase .and. age(i).le.endbase) then
            stdev=stdev+(q(i)-mean)*(q(i)-mean)
        end if
    end do
    if (nbase.gt.1) then
        stdev=dsqrt((stdev)/dble(nbase-1))
    else
        stdev=qmiss
    end if
    
    ! min, max, range
    qmin=9999999.0d0; qmax=-9999999.0d0
    do i=1,n
        if (q(i).ne.qmiss .and. age(i).ge.begbase .and. age(i).le.endbase) then
            if (q(i) .le. qmin) qmin=q(i)
            if (q(i) .ge. qmax) qmax=q(i)
        end if
    end do
    qrng=qmax-qmin

end subroutine stats


subroutine zscores(n,quant,qmiss,mean,stdev,z)

    implicit none

    integer, intent(in)     :: n
    real(8), intent(in)     :: quant(n),qmiss
    real(8), intent(in)     :: mean,stdev
    real(8), intent(out)    :: z(n)

    integer(4)              :: i
    
    ! zscores
    z=qmiss
    if (mean.ne.qmiss .and. stdev.ne.qmiss .and. stdev.ne.0.0d0) then
        do i=1,n
            if (quant(i).ne.qmiss) then 
                z(i)=(quant(i)-mean)/stdev 
            else
                z(i)=qmiss
            end if
        end do
    end if
    
end subroutine zscores


subroutine minimax(n,q,qmiss,qmin,qmax,qmnx)

implicit none

    integer, intent(in)     :: n
    real(8), intent(in)     :: q(n),qmiss
    real(8), intent(in)     :: qmin,qmax
    real(8), intent(out)    :: qmnx(n)
    real(8)                 :: qrange

    integer(4)              :: i
       
    qmnx=qmiss
    !write (*,*) qmiss
    !pause
    qrange=qmax-qmin
    do i=1,n
        if (q(i).ne.qmiss .and. qrange.gt.0.0d0) then
            qmnx(i)=(q(i)-qmin)/qrange
        end if
    !    write (*,*) i,qmnx(i)
    end do
    
end subroutine minimax       

