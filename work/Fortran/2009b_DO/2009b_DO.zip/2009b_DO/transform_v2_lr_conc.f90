program transform_v2_lr_conc
! transforms and z-scores of individual charcoal records
! long record / concentration version

use summarize_subs

implicit none

integer(4)      :: site_sample(maxdata)
integer(8)      :: id_sample(maxdata)
real(4)         :: depth(maxdata),age(maxdata),var(maxdata),varmnx(maxdata)
real(4)         :: tall(maxdata)
real(4)         :: ztall(maxdata),zt21k(maxdata),zt15132k(maxdata),zt132k(maxdata),zt40k(maxdata),zt1573k(maxdata)
real(4)         :: sedrate_in,quant_in,conc_in,influx_in,conc2_in,influx2_in
real(4)         :: vartemp(maxdata),varmiss

real(4)         :: begbase_all,endbase_all,begbase_21k,endbase_21k,begbase_15132k,endbase_15132k,begbase_132k,endbase_132k
real(4)         :: begbase_40k,endbase_40k,begbase_1573k,endbase_1573k
real(4)         :: firstyr,lastyr

real(4)         :: lambda_all,shift_all,lhmax_all
real(4)         :: vmean_all,vstdev_all,vmin_all,vmax_all,vrng_all 
real(4)         :: vmean_21k,vstdev_21k,vmin_21k,vmax_21k,vrng_21k 
real(4)         :: vmean_15132k,vstdev_15132k,vmin_15132k,vmax_15132k,vrng_15132k 
real(4)         :: vmean_132k,vstdev_132k,vmin_132k,vmax_132k,vrng_132k 
real(4)         :: vmean_40k,vstdev_40k,vmin_40k,vmax_40k,vrng_40k 
real(4)         :: vmean_1573k,vstdev_1573k,vmin_1573k,vmax_1573k,vrng_1573k 

integer(4)      :: i,j,npts,npts_all,npts_21k,npts_15132k,npts_132k,npts_40k,npts_1573k

character(4)    :: source(maxdata)
character(4)    :: quant_source_in,conc_source_in,influx_source_in,conc2_source_in,influx2_source_in

character(4)    :: site_num_char
character(8)    :: site_num_label
character(256)  :: datapath,transpath,lambdafile,allsamplesfile,debugfile,statsfile 

datapath="\Projects\GPWG\data\csv_files\v2m\v2m-lr_site\"
transpath="\Projects\GPWG\data\csv_files\v2m\v2m-lr_trans_conc2\"  ! ######
lambdafile="\Projects\GPWG\data\files\v2m\v2m-lr_conc2_lambda.dat" ! ###### 
allsamplesfile="\Projects\GPWG\data\files\v2m\v2m-lr_all_conc2.csv" ! ######
statsfile="\Projects\GPWG\data\files\v2m\v2m-lr_conc2_stats.dat" ! ######
debugfile="\Projects\GPWG\data\files\v2m\v2m-lr_transform_debug.dat"

begbase_21k=200.0; endbase_21k=21000.0; begbase_15132k=14700.0; endbase_15132k=132000.0; begbase_132k=200.0; endbase_132k=132000.0
begbase_40k=200.0; endbase_40k=40000.0; begbase_1573k=14700.0; endbase_1573k=73500.0

varmiss=-9999.0 
shift_all=0.01

open (3,file=lambdafile)
write (3,'(a)') "site, npts, npts_all, lambda_all, shift_all, lhmax_all"
open (4,file=allsamplesfile)               
write (4,'(a)') "site, site_sample, id_sample,   est_age,         depth," &
                    // "       conc2,    conc2mnx,        tall,       ztall," & ! ######
                    // "       zt21k,    zt15132k,      zt132k,       zt40k,     zt1573k, source"
open (9,file=statsfile)
open (10,file=debugfile)

do j=1,maxsites
    ! try to open a file
    site_num_char=int_to_string2(j,4)
    open (1,file=trim(datapath)//trim(adjustl(site_num_char))//"_data.csv", status='old', err=100)
    open (2,file=trim(transpath)//trim(adjustl(site_num_char))//"_trans_conc2.csv") ! ######
    write (2,'(a)') "site, site_sample, id_sample,   est_age,     depth," &
                    // "       conc2,    conc2mnx,        tall,       ztall," & ! ######
                    // "       zt21k,    zt15132k,      zt132k,       zt40k,     zt1573k, source"
    
    read (1,*) site_num_label
    
    ! initialize 
    depth=0.0; age=0.0; var=varmiss; varmnx=varmiss
    vmean_all=varmiss; vstdev_all=varmiss; vmin_all=varmiss; vmax_all=varmiss; vrng_all=varmiss
    npts_all=0; tall=varmiss; lambda_all=-9.0; lhmax_all=-99999.0
    npts_21k=0; npts_15132k=0; npts_132k=0; npts_40k=0; npts_40k=0  
    tall=varmiss; ztall=varmiss; zt21k=varmiss; zt15132k=varmiss; zt132k=varmiss; zt40k=varmiss; zt1573k=varmiss
 
    i=0
    lastyr=-99999.0; firstyr=99999.0
    do while (.not. eof(1))
        i=i+1
        read (1,*) site_sample(i),id_sample(i),depth(i),age(i),sedrate_in,quant_in,conc_in,influx_in,conc2_in,influx2_in, &
            quant_source_in,conc_source_in,influx_source_in,conc2_source_in,influx2_source_in   
        var(i)=conc2_in  ! ######
        source(i)=conc2_source_in ! ######
        if (age(i).gt.lastyr) lastyr=age(i)
        if (age(i).lt.firstyr) firstyr=age(i)
        if (var(i).eq.varmiss) write (*,*) j,i,age(i),var(i)
    end do
    npts=i
    
    write (*,*) firstyr,lastyr
    begbase_all=firstyr; endbase_all=lastyr
    
    write (10,'(i5,1x,a4,1x,a8,1x,i4,2f10.2)') j,site_num_char,site_num_label,npts,firstyr,lastyr
    write (*,'(i5,1x,a4,1x,a8,1x,i4,2f10.2)') j,site_num_char,site_num_label,npts,firstyr,lastyr
    
    ! transformations -- NOTE:  one transformation, all data (z-scores are still separate)
    
    ! stats for whole record
    call stats(npts,age,var,varmiss,begbase_all,endbase_all,npts_all,vmean_all,vstdev_all,vmin_all,vmax_all,vrng_all)

    ! qmnx -- minimax transformation of var for whole record
    call minimax(npts,var,varmiss,vmin_all,vmax_all,varmnx)
    
    ! Box-Cox transformation -- whole record
    call boxcox_lambda(npts,var,varmiss,shift_all,lambda_all,lhmax_all)    
    ! transform record with whole-record parameters
    call boxcox_trans(npts,lambda_all,shift_all,var,varmiss,vartemp)
    ! minimax of transformed data using whole record parameters
    call stats(npts,age,vartemp,varmiss,begbase_all,endbase_all,npts_all,vmean_all,vstdev_all,vmin_all,vmax_all,vrng_all)
    write (9,'(i6,2f9.2,i6,2f14.4)') npts,firstyr,lastyr,npts_all,vmean_all,vstdev_all
    
    ! minimax rescaling, whole record
    call minimax(npts,vartemp,varmiss,vmin_all,vmax_all,tall)
    ! z-scores -- whole record
    call zscores(npts,vartemp,varmiss,vmean_all,vstdev_all,ztall)
    
    ! z-scores 21k
    call stats(npts,age,vartemp,varmiss,begbase_21k,endbase_21k,npts_21k,vmean_21k,vstdev_21k,vmin_21k,vmax_21k,vrng_21k)
    call zscores(npts,vartemp,varmiss,vmean_21k,vstdev_21k,zt21k)
    write (9,'(i6,2f9.2,i6,2f14.4)') npts_all,begbase_21k,endbase_21k,npts_21k,vmean_21k,vstdev_21k
    
    ! z-scores 15k-132k 
    call stats(npts,age,vartemp,varmiss,begbase_15132k,endbase_15132k,npts_15132k,vmean_15132k,vstdev_15132k,vmin_15132k,vmax_15132k,vrng_15132k)
    call zscores(npts,vartemp,varmiss,vmean_15132k,vstdev_15132k,zt15132k)
    write (9,'(i6,2f9.2,i6,2f14.4)') npts_all,begbase_15132k,endbase_15132k,npts_15132k,vmean_15132k,vstdev_15132k
    
    ! z-scores 132k
    call stats(npts,age,vartemp,varmiss,begbase_132k,endbase_132k,npts_132k,vmean_132k,vstdev_132k,vmin_132k,vmax_132k,vrng_132k)
    call zscores(npts,vartemp,varmiss,vmean_132k,vstdev_132k,zt132k)
    write (9,'(i6,2f9.2,i6,2f14.4)') npts_all,begbase_132k,endbase_132k,npts_132k,vmean_132k,vstdev_132k
    
    ! z-scores 40k
    call stats(npts,age,vartemp,varmiss,begbase_40k,endbase_40k,npts_40k,vmean_40k,vstdev_40k,vmin_40k,vmax_40k,vrng_40k)
    call zscores(npts,vartemp,varmiss,vmean_40k,vstdev_40k,zt40k)
    write (9,'(i6,2f9.2,i6,2f14.4)') npts_all,begbase_40k,endbase_40k,npts_40k,vmean_40k,vstdev_40k
    
    ! z-scores 15k to 83k
    call stats(npts,age,vartemp,varmiss,begbase_1573k,endbase_1573k,npts_1573k,vmean_1573k,vstdev_1573k,vmin_1573k,vmax_1573k,vrng_1573k)
    call zscores(npts,vartemp,varmiss,vmean_1573k,vstdev_1573k,zt1573k)
    write (9,'(i6,2f9.2,i6,2f14.4)') npts_all,begbase_1573k,endbase_1573k,npts_1573k,vmean_1573k,vstdev_1573k
    
    ! pause
    
    do i=1,npts
        write (2,'(a8,",",i8,",",i10,",",f10.2,",",f10.2,9(",",g12.6),", ","""",a4,"""" )') &
            site_num_label,site_sample(i),id_sample(i),age(i),depth(i),var(i),varmnx(i), &
            tall(i),ztall(i),zt21k(i),zt15132k(i),zt132k(i),zt40k(i),zt1573k(i),source(i)
        write (4,'(a8,",",i8,",",i10,",",f10.2,",",f10.2,9(",",g12.6),", ","""",a4,"""" )') &
            site_num_label,site_sample(i),id_sample(i),age(i),depth(i),var(i),varmnx(i), &
            tall(i),ztall(i),zt21k(i),zt15132k(i),zt132k(i),zt40k(i),zt1573k(i),source(i)
    end do
    
    write (3,'(a8,1x,i5,1x,3(i5,2f8.2,f10.2))') &
        site_num_label,npts,npts_all,lambda_all,shift_all,lhmax_all
            
    close(1)
    close(2)
   
100 continue
    
end do

end


