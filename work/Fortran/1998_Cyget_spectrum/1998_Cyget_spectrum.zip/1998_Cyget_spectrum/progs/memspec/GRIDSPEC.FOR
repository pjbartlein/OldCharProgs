      program gridspec
      parameter (nf=100,nyrs=51)
      real grid (nf,nyrs)
c     
      open(1,file='armove.dat')
      open(2,file='armove.grd')
c
      nx=nf
      xlo=.0005
      xhi=.0500
      ny=nyrs
      ylo=1000.
      yhi=11000.     
c     
      zlo=9E10
      zhi=-9e10
      do 10 k=1,nyrs
          do 10 j=1,nf
              read (1,*) year,freq,period,spec,grid(j,k)
              zlo=min(zlo,grid(j,k))
              zhi=max(zhi,grid(j,k))      
   10 continue        
c            
      write (2,901)
  901 format ('DSAA')
      write (2,902) nx,ny
  902 format (2i6)
      write (2,903) xlo,xhi
  903 format (2f11.4)  
      write (2,904) ylo,yhi
  904 format (2f11.4)
      write (2,905) zlo,zhi
  905 format (2f11.4)
c
      do 11 j=1,nx
          write (2,906) (grid(j,k),k=1,ny)
  906     format (8f10.4)
   11 continue
      stop
      end