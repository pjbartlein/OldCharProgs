      program memspec 
      implicit none
      integer nmax,mmax,fmax   
      parameter (nmax=3000,mmax=300,fmax=2000)
      integer n,nfdt,m,i,j,nobs
      real evlmem,mse,cof(mmax)
      real delta,fdt(fmax),period(fmax),freq(fmax),spec(fmax)
      real obs(nmax),dt(nmax),da(nmax),x(nmax)
c      
      open(1,file='d:\fire\mem\cygage10.dat')
      open(2,file='d:\fire\mem\memout.dat') 
c     
      m=50
      nfdt=1500
      delta=10.
c      
      nobs=1681  
	n=nobs   
      do 10 i=1,n
          read(1,*) dt(i),da(i) 
c	write (*,*) i,dt(i),da(i)
		da(i)=log(da(i)+.001)
   10 continue
c   
      n=nobs
      do 11 i=1,n
          x(i)=da(i)
   11 continue
c
      do 12 j=1,nfdt
          fdt(j)=0.5*j/nfdt
          freq(j)=fdt(j)/delta
          period(j)=1.0/freq(j) 
   12 continue
c      
      call memcof(x,n,m,mse,cof)
c
      do 16 j=1,nfdt
          spec(j)=evlmem(fdt(j),cof,m,mse)
   16 continue
c
      do 17 j=1,nfdt                       
          write(*,901) freq(j),period(j),spec(j)
          write(2,901) freq(j),period(j),spec(j)          
  901     format (1x,f8.5,f10.2,f8.3)      
17    continue 
      stop
      end
