      program summary
c
      implicit none
      integer nd,ns
      parameter (nd=1471,ns=2)
      real inflx(nd,ns),back(nd,ns),detr(nd,ns)
      real minflx(ns),mback(ns),peak(nd,ns),start(nd,ns),mdetr(ns)
      real ppeak(ns),pstart(ns) 
      integer age(nd,ns)    
      integer i,step,wlen,count,j,l,nstep,ibeg,iend
c
      open (1,file='cyandsc.dat')
      open (2,file='cysc400.dat')
c
      step=20
      wlen=40
c
      do 10 i=1,nd
          read (1,*) (age(i,j),inflx(i,j),back(i,j),peak(i,j),
     +        start(i,j),detr(i,j),j=1,ns)
   10 continue
      nstep=(nd-(mod(nd,step)))/step
      write (*,*) mod(nd,step),nstep 
c
      do 20 l=1,nstep-1
          ibeg=(l-1)*step+1
          iend=ibeg+wlen-1
c          write (2,*) l,ibeg,iend,age(ibeg,1),age(iend,1)
          do 21 j=1,ns
              count=0
              minflx(j)=0.0
              mback(j)=0.0
              ppeak(j)=0
              pstart(j)=0
              mdetr(j)=0
              do 22 i=ibeg,iend
                  if (peak(i,j).ne.9) then
                      count=count+1
                      minflx(j)=minflx(j)+inflx(i,j)
                      mback(j)=mback(j)+back(i,j)
                      ppeak(j)=ppeak(j)+peak(i,j)
                      pstart(j)=pstart(j)+start(i,j)
                      mdetr(j)=mdetr(j)+detr(i,j)
                  endif    
   22         continue
                  if (count.gt.0) then
                      minflx(j)=minflx(j)/count
                      mback(j)=mback(j)/count
                      ppeak(j)=ppeak(j)/count
                      pstart(j)=pstart(j)/count
                      mdetr(j)=mdetr(j)/count
                  else
                      minflx(j)=999.
                      mback(j)=999.
                      ppeak(j)=999
                      pstart(j)=999
                      mdetr(j)=999.    
                  endif    
   21     continue    
          write (2,900) age(ibeg,1),age(iend,1),(minflx(j),
     +        mback(j),ppeak(j),pstart(j),mdetr(j),j=1,ns)
  900     format (2i6,10f8.3)
   20 continue
               
      
      stop
      end                     