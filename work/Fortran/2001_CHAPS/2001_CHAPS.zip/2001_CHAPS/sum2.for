	program sum2
c
      implicit none
      integer nd,nyrs
      parameter (nd=1800,nyrs=1681)
      real age(nd),influx(nd),mean(nd),stddev(nd),ar1(nd),diff(nd)
	real ratio(nd),pflux(nd),freq(nd),mag(nd),dev(nd),ageka(nd)
	real freq2,freq3,mtslp
      integer peak(nd),pstart(nd),tslp(nd),tstart(nd),tinc,temp
	integer nstart  
      integer t,t2,step,wlen,count,j,k,nstep,ibeg,iend
c      
	influx=0.0
	mean=0.0
	stddev=0.0
	ar1=0.0
	diff=0.0
	ratio=0.0
	pflux=0.0
	freq=0.0
	mag=0.0
	dev=0.0
	age(1)=0.0
	ageka(1)=0.0
	do t=1,nd
		age(t)=(t-1)*10.
		ageka(t)=(t-1)/100.
	end do
	
c
	open (1,file='\Fire\Summary\cygstat3.dat')
      do t=1,nyrs
		read (1,*) age(t),influx(t),mean(t),stddev(t),ar1(t),
     +		diff(t),ratio(t),peak(t),pstart(t),pflux(t),freq(t),
     +		mag(t),dev(t),ageka(t)
	end do
c
	open (10,file='\Fire\Summary\debug.dat')
c	do t=1,nd
c		write (10,'(f8.1,3f8.3,3f8.3,2i3,f10.3,f7.1,f10.3,f8.3,f7.3)') 
c     +		age(t),influx(t),mean(t),stddev(t),ar1(t),
c     +		diff(t),ratio(t),peak(t),pstart(t),pflux(t),freq(t),
c     +		mag(t),dev(t),ageka(t)
c	end do
c      
	open (2,file='\Fire\Summary\tslp.dat')
	tinc=0
	do t=1675,1,-1
		if (pstart(t).ne.1) then
			tinc=tinc+10
			tslp(t)=tinc
		else
			tinc=tinc+10
			tslp(t)=tinc
			tinc=0
		end if
	end do
c
	temp=tslp(1)
	do t=1,nyrs
c		if (pstart(t).eq.1) then
c			tstart(t)=tslp(t)
c		else
c			tstart(t)=0
c		end if
		if (pstart(t).eq.0) then
			tstart(t)=temp
		else
			temp=tslp(t)
			tstart(t)=temp
		end if
	end do
c
	do t=1,nyrs
		write (2,'(f7.3,2i6)') ageka(t),tslp(t),tstart(t)
	end do
	close (2)
c
	open (2,file='\Fire\Summary\tslp2.dat')
	write (2,'("  0.00 0")')
	do t=1,nyrs
		if (tstart(t).ne.0) then
			write (2,'(f7.3,i6)') ageka(t),tstart(t)
		end if
	end do
	write (2,'(f7.3," 0")') ageka(nyrs)
c
	open (2,file='\Fire\Summary\mtslp.dat')
      step=100
      wlen=100
      nstep=(nd-(mod(nd,step)))/step
      write (*,*) step,wlen,nstep
      t=0
      mtslp=0.0
      write (2,'(f7.3,f7.2)') ageka(1),mtslp
      do j=1,nstep
		do k=1,wlen
			t=t+1
			mtslp=mtslp+tstart(t) !tslp(t)
		end do
		mtslp=mtslp/float(wlen)
		write (2,'(f7.3,f7.2)') ageka(t),mtslp
		nstart=0
      end do
      nstart=0
      freq2=0.0
      write (2,'(f7.3,f7.2)') ageka(nd),mtslp
      close(2)         
c
	open (2,file='\Fire\Summary\mtslp2.dat')
      step=1
      wlen=100
      nstep=(nd-(mod(nd,step)))/step
      write (*,*) step,wlen,nstep
      t=0
      mtslp=0.0
      write (2,'(f7.3,f7.2)') ageka(1),mtslp
      do j=1,nstep-(wlen/step)
		t=(j-1)*step
		do k=1,wlen
			t=t+1
			mtslp=mtslp+tstart(t) !tslp(t)
		end do
		mtslp=mtslp/float(wlen)
		write (2,'(f7.3,f7.2)') ageka(t)+.5,mtslp
		nstart=0
      end do
      nstart=0
      freq2=0.0
      write (2,'(f7.3,f7.2)') ageka(nd),mtslp
      close(2)         
	stop
	end