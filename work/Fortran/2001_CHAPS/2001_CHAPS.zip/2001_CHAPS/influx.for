      program influx 
c
c        reads level, age, and charcoal concentration, and interpolates
c        to annual values, and then averages concentrations over a
c        particular interval to produce concentration values at even
c        age intervals
c
c        P.J. Bartlein, Dept. Geography, Univ. Oregon (bartlein@uoregon.edu)
c        August 1999, April 2003
c
c        input data:
c           depth in meters (m) (depth)
c           age in years (yrs) (age) 
c           Tilia concentration (char/cm^3) (conc)
c           Tilia influx (char/cm^2/yr) (tflux)
c           Tilia deposition time (yr/cm) (span)
c
c         info file contents:
c             line 1:  input file name (infile)
c             line 2:  output file name (outfile)
c             line 3:  first year (yrs) (firstyr)
c             line 4:  last year (yrs) (lastyr)
c             line 5:  output averaging interval (yrs) (step)
c             line 4:  missing concentration data code (cmiss)
c                   (i.e. ignore input if conc = missing)
c
      implicit none
      integer maxlvls,maxyrs
      parameter (maxlvls=5000,maxyrs=45000)
      real dp,ag,cn,tf,sp
      real depth(maxlvls),age(maxlvls),conc(maxlvls)
      real tflux(maxlvls),span(maxlvls),cmiss
      real target,intconc(-100:maxyrs),intspan(-100:maxyrs)
	real intflux(-100:maxyrs)
      real intsrate(-100:maxyrs)
      real aveconc,avespan,avesrate,intage(-100:maxyrs)
	real aveflux(-100:maxyrs)
      integer i,j,l,firstyr,lastyr,nv
      integer nlvls,nmiss,step
      character*128 infofile,infile,outfile
      character*8 label(4)
c
      data label/'  IntAge',' AveFlux',' AveSpan','AveSedRt' /
      nv=4
c
c        open info file 
c
      print *, "Enter info file name (including path):"
      read (*,*) infofile
      open (1,file=infofile,status='old')
c
c      read (1,'(a128)') infile
	read (1,*) infile
      write (*,901) infile
  901 format (' Input file: ',a128)
c      read (1,'(a128)') outfile
      read (1,*) outfile
      write (*,902) outfile
  902 format (' Output file: ',a128)
c
c        read first year, last year and
c        averaging interval for influx calculations
c
      read (1,*) firstyr,lastyr,step
      write (*,903) firstyr,lastyr,step
  903 format (' First year, last year, averaging interval: ',3i6)
c
c        read missing data code
c
      read (1,*) cmiss
      write (*,904) cmiss
  904 format (' Observations with conc = ',f6.1,'  will be ignored')
c
c        open input and output files
c
      open (2,file=infile)
      open (3,file=outfile)
c
      nmiss=0
      i=0
      do while (.not.eof(2))
      read (2,*) dp,ag,cn,tf,sp
c
c        check for missing concentration value
c
      if (cn.ne.cmiss) then
         i=i+1
         depth(i)=dp
         age(i)=ag
         conc(i)=cn
         tflux(i)=tf
         span(i)=sp
      else
         nmiss=nmiss+1
      endif
c
      end do
      nlvls=i
      write (*,905) nmiss
  905 format (' Number of levels with missing data: ',i5)
      write (*,906) nlvls
  906 format (' Number of usable levels in data set: ',i5)
c
c        interpolation to produce pseudo-annual values
c        (uses hunt.for from Numerical Recipes)
c
      j=1
      do i=firstyr,lastyr+step
          target=i
          call hunt(age,nlvls,target,j)
c
          if (j.le.1) then
              intconc(i)=conc(1)
              intspan(i)=span(1)
              intflux(i)=tflux(1) 
              intsrate(i)=1.0/span(1)
          else if (j.eq.nlvls) then
              intconc(i)=conc(nlvls)
              intspan(i)=span(nlvls)
              intflux(i)=tflux(nlvls)
              intsrate(i)=1.0/span(nlvls)
          else
              intconc(i)=conc(j)
     +        + ((target-age(j))/(age(j+1)-age(j)))*(conc(j+1)-conc(j))
              intspan(i)=span(j)
     +        + ((target-age(j))/(age(j+1)-age(j)))*(span(j+1)-span(j))
              intflux(i)=tflux(j)
     +        +((target-age(j))/(age(j+1)-age(j)))*(tflux(j+1)-tflux(j))
              intsrate(i)=1.0/intspan(i)
          endif
c
      end do
c
c         calcuate average concentrations and influxes
c             over averaging intervals
c
      write (3,'(4(2x,a8))') (label(l),l=1,nv)
      do l=firstyr,lastyr,step
          aveconc=0.0
          avespan=0.0
          do i=l,l+step-1
              aveconc=aveconc+intconc(i)
              avespan=avespan+intspan(i)
              avesrate=avesrate+intsrate(i)
          end do
          aveconc=aveconc/step
          avespan=avespan/step
          avesrate=avesrate/step
c
          aveflux(l)=aveconc/avespan
          intage(l)=l
c
          write (3,911) intage(l),aveflux(l),avespan,avesrate
  911     format (f10.2,4f10.3)
      end do
c
      stop
      end
c
      SUBROUTINE hunt(xx,n,x,jlo)
      INTEGER jlo,n
      REAL x,xx(n)
      INTEGER inc,jhi,jm
      LOGICAL ascnd
      ascnd=xx(n).gt.xx(1)
      if(jlo.le.0.or.jlo.gt.n)then
        jlo=0
        jhi=n+1
        goto 3
      endif
      inc=1
      if(x.ge.xx(jlo).eqv.ascnd)then
1       jhi=jlo+inc
        if(jhi.gt.n)then
          jhi=n+1
        else if(x.ge.xx(jhi).eqv.ascnd)then
          jlo=jhi
          inc=inc+inc
          goto 1
        endif
      else
        jhi=jlo
2       jlo=jhi-inc
        if(jlo.lt.1)then
          jlo=0
        else if(x.lt.xx(jlo).eqv.ascnd)then
          jhi=jlo
          inc=inc+inc
          goto 2
        endif
      endif
3     if(jhi-jlo.eq.1)return
      jm=(jhi+jlo)/2
      if(x.gt.xx(jm).eqv.ascnd)then
        jlo=jm
      else
        jhi=jm
      endif
      goto 3
      END
C  (C) Copr. 1986-92 Numerical Recipes Software D04'%1'i0(95.)61j'1..