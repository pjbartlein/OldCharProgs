      program sum1
c
      implicit none
      integer nd,nyrs
      parameter (nd=1800,nyrs=1681)
      real age(nd),influx(nd),mean(nd),stddev(nd),ar1(nd),diff(nd)
	real ratio(nd),pflux(nd),freq(nd),mag(nd),dev(nd),ageka(nd)
	real freq2,freq3
      integer peak(nd),pstart(nd)
	integer nstart  
      integer t,t2,step,wlen,count,j,k,nstep,ibeg,iend
c      
	influx=0.0
	mean=0.0
	stddev=0.0
	ar1=0.0
	diff=0.0
	ratio=0.0
	pflux=0.0
	freq=0.0
	mag=0.0
	dev=0.0
	age(1)=0.0
	ageka(1)=0.0
	do t=1,nd
		age(t)=(t-1)*10.
		ageka(t)=(t-1)/100.
	end do
c
	open (1,file='\Fire\Summary\cygstat3.dat')
      do t=1,nyrs
		read (1,*) age(t),influx(t),mean(t),stddev(t),ar1(t),
     +		diff(t),ratio(t),peak(t),pstart(t),pflux(t),freq(t),
     +		mag(t),dev(t),ageka(t)
	end do
c
	open (10,file='\Fire\Summary\debug.dat')
c	do t=1,nd
c		write (10,'(f8.1,3f8.3,3f8.3,2i3,f10.3,f7.1,f10.3,f8.3,f7.3)') 
c     +		age(t),influx(t),mean(t),stddev(t),ar1(t),
c     +		diff(t),ratio(t),peak(t),pstart(t),pflux(t),freq(t),
c     +		mag(t),dev(t),ageka(t)
c	end do
c      
	open (2,file='\Fire\Summary\freq3000.dat')
	step=300
	wlen=300
	nstep=(nd-(mod(nd,step)))/step
	write (*,*) step,wlen,nstep
	t=0
	nstart=0
	freq2=0.0
	write (2,'(f7.3,i6,2f6.2)') ageka(1),nstart,freq2
	do j=1,nstep
		do k=1,wlen
			t=t+1
			nstart=nstart+pstart(t)			
		end do
		freq2=float(nstart)/(wlen/100.0)
		write (2,'(f7.3,i6,2f6.2)') ageka(t),nstart,freq2
		nstart=0
	end do
	nstart=0
	freq2=0.0
	write (2,'(f7.3,i6,2f6.2)') ageka(nd),nstart,freq2
	close(2)
c
	open (2,file='\Fire\Summary\freq1000.dat')
	step=100
	wlen=100
	nstep=(nd-(mod(nd,step)))/step
	write (*,*) step,wlen,nstep
	t=0
	nstart=0
	freq2=0.0
	write (2,'(f7.3,i6,2f6.2)') ageka(1),nstart,freq2
	do j=1,nstep
		do k=1,wlen
			t=t+1
			nstart=nstart+pstart(t)			
		end do
		freq2=float(nstart)/(wlen/100.0)
		write (2,'(f7.3,i6,2f6.2)') ageka(t),nstart,freq2
		nstart=0
	end do
	nstart=0
	freq2=0.0
	write (2,'(f7.3,i6,2f6.2)') ageka(nd),nstart,freq2
	close(2)
c
	open (2,file='\Fire\Summary\freq0500.dat')
	step=50
	wlen=50
	nstep=(nd-(mod(nd,step)))/step
	write (*,*) step,wlen,nstep
	t=0
	nstart=0
	freq2=0.0
	write (2,'(f7.3,i6,2f6.2)') ageka(1),nstart,freq2
	do j=1,nstep
		do k=1,wlen
			t=t+1
			nstart=nstart+pstart(t)			
		end do
		freq2=float(nstart)/(wlen/100.0)
		write (2,'(f7.3,i6,2f6.2)') ageka(t),nstart,freq2
		nstart=0
	end do
	nstart=0
	freq2=0.0
	write (2,'(f7.3,i6,2f6.2)') ageka(nd),nstart,freq2
	close(2)
c
	open (2,file='\Fire\Summary\freq0750w.dat')
	step=25
	wlen=75
	nstep=(nd-(mod(nd,step)))/step
	write (*,*) step,wlen,nstep
	t=0
	nstart=0
	freq2=0.0
	write (2,'(f7.3,i6,2f6.2)') ageka(1),nstart,freq2
	do j=1,nstep-(wlen/step)
		t=(j-1)*step
		do k=1,wlen
			t=t+1
			nstart=nstart+pstart(t)			
		end do
		freq2=float(nstart)/(wlen/100.0)
		t2=(j-1)*step+(step/2)		
		write (2,'(f7.3,i6,2f6.2)') ageka(t2),nstart,freq2
		nstart=0
	end do
	nstart=0
	freq2=0.0
	write (2,'(f7.3,i6,2f6.2)') ageka(nd),nstart,freq2
	close(2)
c	
	open (2,file='\Fire\Summary\freq1000w.dat')
	step=25
	wlen=100
	nstep=(nd-(mod(nd,step)))/step
	write (*,*) step,wlen,nstep
	t=0
	nstart=0
	freq2=0.0
	write (2,'(f7.3,i6,2f6.2)') ageka(1),nstart,freq2
	do j=1,nstep-(wlen/step)
		t=(j-1)*step
		do k=1,wlen
			t=t+1
			nstart=nstart+pstart(t)			
		end do
		freq2=float(nstart)/(wlen/100.0)
		t2=(j-1)*step+(step/2)
		write (2,'(f7.3,i6,2f6.2)') ageka(t2)+.5,nstart,freq2
		nstart=0
	end do
	nstart=0
	freq2=0.0
	write (2,'(f7.3,i6,2f6.2)') ageka(nd),nstart,freq2
	close(2)
c
	open (2,file='\Fire\Summary\freq1000w2.dat')
	step=10
	wlen=100
	nstep=(nd-(mod(nd,step)))/step
	write (*,*) step,wlen,nstep
	t=0
	nstart=0
	freq2=0.0
	write (2,'(f7.3,i6,2f6.2)') ageka(1),nstart,freq2
	do j=1,nstep-(wlen/step)
		t=(j-1)*step
		do k=1,wlen
			t=t+1
			nstart=nstart+pstart(t)			
		end do
		freq2=float(nstart)/(wlen/100.0)
		t2=(j-1)*step+(step/2)
		write (2,'(f7.3,i6,2f6.2)') ageka(t2)+.5,nstart,freq2
		nstart=0
	end do
	nstart=0
	freq2=0.0
	write (2,'(f7.3,i6,2f6.2)') ageka(nd),nstart,freq2
	close(2)
c
	open (2,file='\Fire\Summary\freq1000w3.dat')
	step=1
	wlen=100
	nstep=(nd-(mod(nd,step)))/step
	write (*,*) step,wlen,nstep
	t=0
	nstart=0
	freq2=0.0
	write (2,'(f7.3,i6,2f6.2)') ageka(1),nstart,freq2
	do j=1,nstep-(wlen/step)
		t=(j-1)*step
		do k=1,wlen
			t=t+1
			nstart=nstart+pstart(t)			
		end do
		freq2=float(nstart)/(wlen/100.0)
		t2=(j-1)*step+(step/2)
		write (2,'(f7.3,i6,2f6.2)') ageka(j)+.5,nstart,freq2
		nstart=0
	end do
	nstart=0
	freq2=0.0
	write (2,'(f7.3,i6,2f6.2)') ageka(nd)+((wlen*10)/2/1000.),nstart,freq2
	close(2)
c
      stop
      end                     