      program decompos  
c          
c         DECOMPOS program ver. 1.00 compiled for MS-DOS 5.0 and higher
c
c         calculates a weighted mean, standard deviation and
c             autocorrelation of charcoal influx data, and 
c             filters and passes peaks in the influx data 
c         this version assumes equally spaced observations
c          
c         
c         input (output from char.for):
c             age (years)
c             average influx (char/cm2/yr)
c
c         info file contents:
c             line 1:  input filename
c             line 2:  output filename
c             line 3:  window width (number of samples, not years)
c             line 4:  peak-to-mean ratio threshold value
c             line 5:  transformation parameter
c             line 6:  window width for smoothing peak mag and freq
c             line 7:  interval for calculating frequency
c             line 8:  missing data code 
c
c         output  
c             col 1:  age(yrs)
c             col 2:  influx (char/cm2/yr)
c             col 3:  mean (background) influx (char/cm2/yr)
c             col 4:  standard deviation of influx (char/cm2/yr)
c             col 5:  ar1 (lag-1 autocorrelation)
c             col 6:  difference (in transformed units if a transformation
c                         was requested (between influx and mean (char/cm2/yr)
c             col 7:  ratio (in transformed units if a transformation was
c                         requested) between influx and mean
c             col 8:  peak (1 if under peak, 0 otherwise)
c             col 9:  start of peak (1 if at beginning of peak, 0 otherwise)
c             col 10: total influx under peak (char/cm2)
c             col 11: smoothed value of frequency of peaks (scaled to no. of
c                         peaks per interval)
c             col 12: smoothed value of total influxes under peaks
c             col 13: influx, deviations about mean 
c
      implicit none
      integer maxobs,wmax
	real const
      parameter (maxobs=4400,wmax=3000,const=1.0)
      real age(maxobs),influx(maxobs),tflux(maxobs),miss
      real thresh,trans,dist,weight(wmax)
      real w(wmax),x(wmax),y(wmax),incl(wmax)
      real wsum,sum,tmean(maxobs),ssq,denom,tvar,tstdv,scp,tratio
      real mean(maxobs),var(maxobs),stddev(maxobs),ar1(maxobs)
      real diff(maxobs),ratio(maxobs),ptotal,pflux(maxobs),dev(maxobs)
      real interval,freq(maxobs),mag(maxobs),duration,logten
      integer peak(maxobs),pstart(maxobs),use(maxobs),nuse
      integer nh,nobs,i,t,in,ii,id,width,smooth,begt,endt
      character*64 infile,outfile
c      
c       Initialize all array variables to 0 before running program
c
	age=0.0
	influx=0.0
	tflux=0.0
	tmean=0.0
	mean=0.0
      stddev=0.0
      ar1=0.0
      var=0.0 
      diff=0.0
      ratio=0.0
      pflux=0.0
      dev=0.0
      freq=0.0
      mag=0.0
      peak=0
      pstart=0
      use=0
      weight=0.0
      w=0.0
      x=0.0
	y=0.0
	incl=0.0                      
c
c                     
c
      call getinfo (infile,outfile,width,thresh,trans,smooth,interval,
     +     miss)
c
c         open input file
c      
      open (2,file=infile,status='old')    
c     
      i=0
      do while (.not.eof(2))
          i=i+1
          read (2,*) age(i),influx(i)
      end do
      nobs=i
      write (*,101) nobs
  101 format (' Number of observations in data set: ',i5)
      age(nobs+1)=age(nobs)+(age(nobs)-age(nobs-1))
      influx(nobs+1)=influx(nobs)
c     
c
c         check for missing data, and transform data if requested
c
      do 10 t=1,nobs
          use(t)=0
          if (influx(t).ne.miss) use(t)=1
          if (use(t).ne.0) then
              if (trans.eq.0.0) then
                  tflux(t)=log(influx(t)+const)
              elseif (trans.eq.1.0) then
                  tflux(t)=influx(t)
              else    
                  tflux(t)=influx(t)**trans
              endif
          endif    
   10 continue 
      logten=log(10.)                     
c
c         calculate window half-width, and weights
c
      nh=int(width/2)+1
      do 11 i=1,width+1 
          dist=float((abs(nh-i)))/float(nh)
          weight(i)=(1.0-dist**3.0)**3.0  
   11 continue  
c 
c         loop over data
c
      do 20 t=1,nobs
         if (use(t).ne.0) then          
             in=0
             do 21 ii=1,width+1
                id=(t-nh)+ii  
                if (id.ge.1.and.id.le.nobs) then
                  in=in+1           
                  x(in)=tflux(id)
                  w(in)=weight(ii)
                  incl(in)=use(id)
                endif
   21        continue
c
c         calculate statistics
c
c         weighted mean
c
         wsum=0.0
         sum=0.0
         tmean(t)=0.0
         do 30 i=1,in
             if (incl(i).eq.1) then
                 sum=sum+x(i)*w(i)
                 wsum=wsum+w(i)
             endif    
   30    continue
         if (wsum.ne.0) tmean(t)=sum/wsum
c
c         variance and standard deviation
c      
         ssq=0.0
         tvar=0.0
         nuse=0
         do 32 i=1,in
            if (incl(i).eq.1) then
                nuse=nuse+1
                ssq=ssq+w(i)*(x(i)-tmean(t))*(x(i)-tmean(t))
            endif    
   32    continue
         denom=0.0
           if (nuse.ne.0) denom=(float(nuse-1)*wsum/float(nuse))
           if (denom.ne.0.0) tvar=ssq/denom
         tstdv=sqrt(tvar)
c
c         first-order autocorrelation coefficient
c     
         scp=0.0
         ar1(t)=0.0
         nuse=0
         do 33 i=1,in-1
            if (incl(i).eq.1) then
                nuse=nuse+1
                scp=scp+w(i)*(x(i+1)-tmean(t))*(x(i)-tmean(t))
            endif    
   33    continue
         denom=0.0
         if (nuse.ne.0) denom=tvar*(nuse-1) 
         if (denom.ne.0.0) ar1(t)=scp/denom 
c
c         untransform data if necessary
c      
         if (trans.eq.0.0) then
            mean(t)=exp(tmean(t)+(tvar/2.0))-const
            var(t)=(mean(t)**2.0)*(exp(tvar)-1.0)
            stddev(t)=sqrt(var(t))
         elseif (trans.eq.1.0) then
            mean(t)=tmean(t)
            var(t)=tvar
            stddev(t)=tstdv
         else
            mean(t)=tmean(t)**(1.0/trans)
            var(t)=tvar
            stddev(t)=tstdv**(1.0/trans)
         endif
c
c         deviations about the mean
c     
         dev(t)=0.0
         if (trans.eq.0.0) then
             dev(t)=log10(influx(t) + const)-log10(mean(t))
         else    
             dev(t)=influx(t)-mean(t)
         endif    
c     
      endif 
   20 continue
c
c         calculate peak statistics
c     
      diff(nobs+1)=0.0
      ratio(nobs+1)=thresh
      do 41 t=nobs,1,-1
      if (use(t).ne.0) then
         diff(t)=0.0         
         if (tflux(t).gt.tmean(t)) diff(t)=tflux(t)-tmean(t)
c         
c         define peak using ratio between transformed (if requested)
c         value of influx and the mean
c
         ratio(t)=thresh
         tratio=0.0
         peak(t)=0
         if (tflux(t).gt.tmean(t)) then 
             tratio=tflux(t)/tmean(t) 
            if (tratio.gt.thresh) then 
                ratio(t)=tratio
                peak(t)=1
            endif    
         endif
c
c         note starting observation of a peak
c  
         pstart(t)=0
       if ((ratio(t+1).le.thresh).and.(ratio(t).gt.thresh)) pstart(t)=1  
      endif
   41 continue 
c
c         calculate total influx under peak (magnitude)
c
      ptotal=0.0
      do 42 t=nobs,1,-1
      if (use(t).ne.0) then    
          pflux(t)=0.0
          if (peak(t).eq.1) then
              ptotal=ptotal+influx(t)*(age(t+1)-age(t))
          else
              pflux(t+1)=ptotal
              ptotal=0.0
          endif
      endif    
   42 continue 
      pflux(1)=0.0
      if (peak(1).eq.1) pflux(1)=ptotal   
c
c         smooth frequency and magnitudes of peaks
c
c         calculate window half-width, and weights 
c
      nh=int(smooth/2)+1
      do 51 i=1,smooth+1 
          dist=float((abs(nh-i)))/float(nh)
          weight(i)=(1.0-dist**3.0)**3.0  
   51 continue  
c 
c         loop over data
c
      do 52 t=1,nobs
      if (use(t).ne.0) then
c          
          in=0
          do 53 ii=1,smooth+1
              id=(t-nh)+ii  
              if (id.ge.1.and.id.le.nobs) then
                  in=in+1           
                  x(in)=pstart(id)
                  y(in)=pflux(id)
                  w(in)=weight(ii)
                  incl(in)=use(id)
              endif
   53     continue
          begt=(t-nh)+1
          if (begt.lt.1) begt=1
          endt=(t-nh)+smooth+1
          if (endt.gt.nobs) endt=nobs
c
c         calculate statistics
c
c         weighted proportion of obs with peaks (frequency)
c
         wsum=0.0
         sum=0.0
         freq(t)=0.0
         do 54 i=1,in
             if (incl(i).ne.0) then
                 sum=sum+x(i)*w(i)
                 wsum=wsum+w(i)
             endif    
   54    continue
         duration=age(endt)-age(begt)
         if (wsum.ne.0) freq(t)=in*(sum/wsum)*(interval/duration)
c
c         calculate weighted total influx (magnitude)
c
         wsum=0.0
         sum=0.0
         mag(t)=0.0
         do 55 i=1,in
            if (incl(i).ne.0) then
                if (y(i).gt.0.0) then
                    sum=sum+y(i)*w(i)
                    wsum=wsum+w(i)
                endif
            endif        
   55    continue
         if (wsum.ne.0) mag(t)=sum/wsum  
c     
      endif
   52 continue      
c 
c         write out the results     
c      
    	call wrtfile (outfile,age,influx,mean,stddev,ar1,diff,ratio,peak,
     +              pstart,pflux,freq,mag,dev,nobs,use)
c     
      end   
c
c	 --------------------------------------------------------------
c	 --------------------------------------------------------------     
      subroutine getinfo (ifile,ofile,xwidth,th,tr,s,inter,xmiss)

c		This subroutine asks user for input file, output file, info file to save parameters.
c		User supplies parameters to run program, parameters are appended to info
c		file
c
	implicit none
	real xmiss,th,tr,inter
	integer xwidth,s
	character*64 ifile, ofile, infofile	
	logical found,done,there
c
c	   Ask user for input file to use, output file to create and info 
c	   file to append.
c
c
      PRINT*,'---------------------------------------------------------'
      PRINT*,'---------------------------------------------------------'
      PRINT*
      PRINT*, '                            CHAPS'
      PRINT*, '                 (Charcoal Analysis Programs)      ' 
      PRINT*, '                          Ver. 1                     '
      PRINT*, '                    For MS-DOS 5.0 or higher' 
      PRINT*
      PRINT*, '                    Department of Geography'
      PRINT*, '                      University of Oregon'
      PRINT*, '                       Eugene, OR 97403'
      PRINT*
      PRINT*
      PRINT*, 'Please enter parameters at each prompt, hit enter to'
      PRINT*, 'accept and go to next prompt.'
      PRINT*
      PRINT*, 'As soon as last parameter is entered and accepted'
      PRINT*, 'the program will run.'
      PRINT*
      PRINT*, 'To start DECOMPOS hit enter, '
      PRINT*, 'To terminate program hit Ctrl+Break'
      read*
cc
c
	done =.false.
	found = .false.
      Print*, 'Enter the name of the information file'
	Print*, 'to append:'
      READ (*,'(A)') infofile
c
      do while (.not.done)
      inquire (file=infofile,exist=there)
	   if (.not.there) then
	      print*, 'File not found'
	      print*, 'Enter name of information file to create'
	      print*, 'or type QUIT to terminate program:'
	      read (*,'(A)') infofile
	     if ((infofile.eq.'QUIT').or.(infofile.eq.'quit')) stop
	   else  
	     done = .true.
	     found = .true.
	   end if
	end do
c
	if (found) then      
	   write (*,901) infofile
  901    format (1x,'Info file:',/,1x,a64,/)
c
         open (4,file=infofile, access ='append', status = 'old')
	end if
c
	done = .false.
	found = .false.
	Print*, 'Enter the name of the input file to use:'
      read (*,'(a)') ifile
c
      do while (.not.done)                              
	   inquire (file=ifile,exist=there)
	   if (.not.there) then
	      print*, 'Input file not found'
	      print*, 'Re-enter name of input file'
	      print*, 'or type QUIT to terminate program:'
	      read (*,'(a)') ifile
	      if ((ifile.eq.'QUIT').or.(ifile.eq.'quit')) stop   
	   else
	     done = .true.
	     found = .true.
	   end if
	end do
c
	if (found) then      
          write (*,902) ifile
  902     format (1x,'Input file:',/,1x,a64,/)
      end if
c     
	Print*, 'Enter the name of the output file to create:'
      read (*,'(a)') ofile
      write (*,903) ofile
  903 format (1x,'Output file:',/,1x,a64,/)
c
c          Ask user for window width, peak-to-mean ratio threshold 
c          transformation exponent, mag and freq smoother
c	     width,interval for freq calculations, and
c          missing data code (skip if missing)
c
      Print*, 'Enter window width for smoothing: '
	read*, xwidth
      write (*,904) xwidth
  904 format (' Window width for smoothing: ',i5,/)
c
      Print*, 'Enter peak-to-mean ratio threshold value: '
	read*, th
      write (*,905) th
  905 format (' Peak-to-mean ratio threshold: ',f6.2,/)
c
	print*, 'Enter power transformation exponent:'
	print*, '  (0.0=log10 transformation,'
	print*, '   1.0=no transformation, or'
	print*, '   x.x for other power transformation)'
      read*, tr
      write (*,906) tr
  906 format (' Transformation exponent: ',f6.2,/)
c
	print*, 'Enter window width for smoothing peak magnitude'
	print*, 'and frequency:'
      read*, s
      write (*,907) s
  907 format (' Window width for smoothing peak mag and freq: ',i5,/)
c    
      print*, 'Enter interval for calculating frequency:'
      read*, inter
      write (*,908) inter
  908 format (' Interval for frequency calculations: ',f7.1,/)
c
     	print*, 'Enter missing data code:'
      read*, xmiss
      write (*,909) xmiss
  909 format (' Missing data code:  ',f10.4) 

c
c		Write information supplied, append to existing infofile
c
	write (4,910) ifile,ofile,xwidth,th,tr,s,inter,xmiss
  910 format (/,1x,'Input file: ',a64,/,1x,'Output file: ',a64,/,
     +        1x,'Window width:',i5,/,1x,'Threshold ratio:',f6.2,/,
     +        1x,'Transformation parameter:',f6.2,/,
     +        1x,'Peak/Freq window width:',i5,/,
     +        1x,'Frequency interval:',f7.1,/,
     +        1x,'Missing data code:',f10.4,/)
c
	return
	end
c
c		---------------------------------------------------------
c		---------------------------------------------------------
	subroutine wrtfile (ofile,xage,infl,xmean,sd,xar1,xdiff,xratio,
     +        xpeak,ps,pf,xfreq,xmag,xdev,xnobs,xuse)
c
      implicit none 
	integer xnobs,t
      real xage(xnobs),infl(xnobs),xmean(xnobs),sd(xnobs),xar1(xnobs)
	real xdiff(xnobs),xratio(xnobs),pf(xnobs),xfreq(xnobs),xmag(xnobs)
	real xdev(xnobs)
	integer xpeak(xnobs),ps(xnobs),xuse(xnobs)
	character*64 ofile
c
c
	open (3,file=ofile,status='new')
c
	write (3,505) 
c  505 format (1x,'  Age',3x,'Influx',3x,'Mean',4x,'S.D.',6x,'AR1',4x,
c     +        'Diff',3x,'Ratio',3x,'Peak',1x,'P-start',1x,'T-influx',1x,
c     +        'Freq',1x,'T-freq',5x,'Dev.')
c
  505 format (1x,' Age,',3x,'Influx,',3x,'Mean,',4x,'S.D.,',6x,'AR1,',4x,
     +        'Diff,',3x,'Ratio,',3x,'Peak,',1x,'P-start,',1x,
     +        'T-influx,',1x,
     +        'Freq,',1x,'T-freq,',5x,'Dev.,')
c
	do 60 t=1,xnobs
      if (xuse(t).eq.1) then
          write (3,510) xage(t),infl(t),xmean(t),sd(t),xar1(t),
     +    xdiff(t),xratio(t),xpeak(t),ps(t),pf(t),xfreq(t),
     +    xmag(t),xdev(t)
  510     format (f8.1,',',f8.3,',',f8.3,',',f8.3,',',f8.3,',',f8.3,',',
     +            f8.3,',',2x,i3,',',2x,i3,',',f10.3,',',f7.1,',',
     +            f10.3,',',f8.3',')
      else
          write (3,511) xage(t)
  511     format (f8.1,3(7x,'*'),3(7x,'*'),2(2x,'*'),9x,'*',
     +    6x,'*',9x,'*',7x,'*')
      endif
   60 continue
c
      return
      end