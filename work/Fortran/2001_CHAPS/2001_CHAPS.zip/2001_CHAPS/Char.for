      program char 
c 
c         CHAR program Ver. 1, compiled for MS-DOS 5.0 and higher
c            
c         reads level, age, and charcoal concentration, and interpolates
c         to annual values, and then averages concentrations over a 
c         particular interval to produce concentration values at even
c         age intervals 
c         
c         input data:
c             depth in meters
c             age in years
c             Tilia concentration (char/cm3)
c             Tilia influx (char/cm2/yr)--ignored
c             Tilia deposition time (yr/cm)--ignored    
c
c         info file contents:  
c             line 1:  input file name
c             line 2:  output file name
c             line 3:  first year, last year, output averaging interval
c             line 4:  missing concentration data code 
c                         (i.e. ignore input if conc = missing)
c
      implicit none
      integer maxlvls,maxyrs
      parameter (maxlvls=5000,maxyrs=45000)
      real depth(maxlvls),age(maxlvls),conc(maxlvls)
      real tflux(maxlvls),span(maxlvls),cmiss
      real target,intconc(0:maxyrs),intspan(0:maxyrs)
      real aveconc,avespan,intage(0:maxyrs),aveflux(0:maxyrs)
      integer i,j,l,firstyr,lastyr
      integer nlvls,step
      character*64 infile,outfile
c
      call getfile (infile, outfile, firstyr, lastyr, step, cmiss) 
c     
      call readfile (infile, depth, age, conc, tflux, span,
     +     cmiss, nlvls, maxlvls)
c
c
c         interpolation to produce pseudo-annual values
c         (uses hunt.for from Numerical Recipes)
c
      j=1
      do 20 i=firstyr,lastyr+step
          target=i
          call hunt(age,nlvls,target,j) 
          if (j.le.1) then
              intconc(i)=conc(1)
              intspan(i)=span(1)
          else if (j.eq.nlvls) then
              intconc(i)=conc(nlvls)  
              intspan(i)=span(nlvls)
          else
              intconc(i)=conc(j)
     +         + ((target-age(j))/(age(j+1)-age(j)))*(conc(j+1)-conc(j))  
              intspan(i)=span(j)
     +         + ((target-age(j))/(age(j+1)-age(j)))*(span(j+1)-span(j))
          endif
   20 continue 
c
c         calcuate average concentrations and influxes
c             over averaging intervals
c

      do 30 l=firstyr,lastyr,step
          aveconc=0.0
          avespan=0.0
          do 31 i=l,l+step-1          
              aveconc=aveconc+intconc(i)
              avespan=avespan+intspan(i)
   31     continue
          aveconc=aveconc/step  
          avespan=avespan/step
c
          aveflux(l)=aveconc/avespan
          intage(l)=l
c         
      open (3,file=outfile,status='new')
c
      write (3,911) intage(l),aveflux(l)
  911     format (f10.2,f10.3)                     
   30 continue
c               
      stop
      end
c
c
c       ------------------------------------------------------
c       ------------------------------------------------------
      subroutine getfile (ifile, ofile, fyr, lyr, interval, xmiss)
c
c         This subroutine asks the user for input and output files,
c		first and last years of data and missing data code.
c 
c   
      implicit none
      real xmiss
      integer fyr,lyr, interval
      character*64 ifile,ofile,infofile
      logical done,found,there  
c     
      PRINT*,'---------------------------------------------------------'
      PRINT*,'---------------------------------------------------------'
      PRINT*
      PRINT*, '                            CHAPS'
      PRINT*, '                 (Charcoal Analysis Programs)      ' 
      PRINT*, '                          Ver. 1                     '
      PRINT*, '                    For MS-DOS 5.0 or higher' 
      PRINT*
      PRINT*, '                    Department of Geography'
      PRINT*, '                      University of Oregon'
      PRINT*, '                       Eugene, OR 97403'
      PRINT*
      PRINT*
      PRINT*, 'Please enter parameters at each prompt, hit enter to'
      PRINT*, 'accept and go to next prompt.'
      PRINT*
      PRINT*, 'As soon as last parameter is entered and accepted'
      PRINT*, 'the program will run.'
      PRINT*
      PRINT*, 'To start CHAR hit enter, '
      PRINT*, 'To terminate program hit Ctrl+Break'
      read*
c
c         ask user for input and output files, 
c
      done =.false.
      found = .false.
       
      PRINT*, 'Enter the name of the information file'
      PRINT*, 'to create:'
      READ (*,'(A)') infofile
c      
      do while (.not.done)
      inquire (file=infofile,exist=there)
         if (there) then
           print*, 'File already exists'
           print*, 'Enter name of new information file to create'
           print*, 'or type QUIT to terminate program:'
           read (*,'(A)') infofile
           if ((infofile.eq.'QUIT').or.(infofile.eq.'quit')) stop
         else  
           done = .true.
           found = .true.
         end if 
      end do  
c
      if (found) then      
         write (*,500) infofile
  500    format (1x,'Info file:',/,1x,a64,/)
         open (4,file=infofile,status='new')
      end if
c
	done = .false.
	found = .false.
	Print*, 'Enter the name of the input file to use:'
      read (*, '(a)') ifile
c
      do while (.not.done)
	   inquire (file=ifile,exist=there)
	   if (.not.there) then
	      print*, 'Input file not found'
	  print*, 'Re-enter name of input file'
	  print*, 'or type QUIT to terminate program:'
	  read (*,'(a)') ifile
	    if ((ifile.eq.'QUIT').or.(ifile.eq.'quit')) stop
	  else
	    done = .true.
	    found = .true.
	end if 
	end do
c
	if (found) then	
      write (*,501) ifile
  501 format (' Input file: ',a64,/)
      end if
c		
	Print*,'Enter name of the output file to create:'
      read (*, '(a)') ofile
      write (*,502) ofile
  502 format (' Output file: ',a64,/)
c
c          Ask for first year
c
      print*, 'Enter first year of data'
      print*, 'rounded to the closest, whole, positive number:'
      print*, 'i.e. 201 not 200.6'
	read*,  fyr
      write (*,503) fyr
  503 format (' First year: ',i6,/)
c
c          Ask for last year
c
      print*, 'Enter last year of data'
      print*, 'rounded to the closest, whole, postive number:'
	read*, lyr
      write (*,504) lyr
  504 format (' Last year: ',i6,/)   
c
c           Ask for output averaging interval
c
      print*, 'Enter output averaging interval:'
	read*, interval
	write (*,505) interval
  505 format (' Output averaging interval: ',i6,/)   
c
c         Ask for missing data code
c     
      print*, 'Enter missing data code'
      print*, 'i.e. 999 or -1:'
	read*, xmiss
      write (*,506) xmiss
  506 format (' Observations with conc = ',f6.1,'  will be ignored')
c
c
	write (4,510) ifile, ofile, fyr, lyr,interval, xmiss
  510 format (1x,'Input file: ',A64,/,1x,'Output file: ',A64,/,
     +        1x,'First year: ',i6,/,1x,'Last year: ',i6,/,
     +        1x,'Averaging interval: 'i6,/,
     +        1x,'Missing data code: ',f6.1)   
c
	return
	end
c     -------------------------------------------------------
c     -------------------------------------------------------
	subroutine readfile (ifile, xdepth, xage, xconc, xtflux, 
     +                     xspan, xmiss, xlvls, xmaxl)


c         open input and output files, read data and check for 
c         missing data
c      
	integer nmiss, i, xlvls, xmaxl
	real dp, ag, cn, tf, sp, xmiss
	real xdepth(xmaxl), xage(xmaxl),xconc(xmaxl), xtflux(xmaxl),
     +     xspan(xmaxl)
	character*64 ifile 
c
      open (2,file=ifile, status='old')    
c     
      nmiss=0
      i=0
      do while (.not.eof(2))
          read (2,*) dp,ag,cn,tf,sp
c
c         check for missing concentration value
c
          if (cn.ne.xmiss) then
              i=i+1
              xdepth(i)=dp
              xage(i)=ag
              xconc(i)=cn
              xtflux(i)=tf
              xspan(i)=sp
          else
              nmiss=nmiss+1
          endif
c          
      end do
      xlvls=i
      write (*,905) nmiss
  905 format (' Number of levels with missing data: ',i5)
      write (*,906) xlvls
  906 format (' Number of usable levels in data set: ',i5)
c
	return
	end
c
c	--------------------------------------------------------
c	--------------------------------------------------------	
      SUBROUTINE hunt(xx,n,x,jlo)
c
      INTEGER jlo,n
      REAL x,xx(n)
      INTEGER inc,jhi,jm
      LOGICAL ascnd
      ascnd=xx(n).ge.xx(1)
      if(jlo.le.0.or.jlo.gt.n)then
        jlo=0
        jhi=n+1
        goto 3
      endif
      inc=1
      if(x.ge.xx(jlo).eqv.ascnd)then
1       jhi=jlo+inc
        if(jhi.gt.n)then
          jhi=n+1
        else if(x.ge.xx(jhi).eqv.ascnd)then
          jlo=jhi
          inc=inc+inc
          goto 1
        endif
      else
        jhi=jlo
2       jlo=jhi-inc
        if(jlo.lt.1)then
          jlo=0
        else if(x.lt.xx(jlo).eqv.ascnd)then
          jhi=jlo
          inc=inc+inc
          goto 2
        endif
      endif
3     if(jhi-jlo.eq.1)then
        if(x.eq.xx(n))jlo=n-1
        if(x.eq.xx(1))jlo=1
        return
      endif
      jm=(jhi+jlo)/2
      if(x.ge.xx(jm).eqv.ascnd)then
        jlo=jm
      else
        jhi=jm
      endif
      goto 3
      END
