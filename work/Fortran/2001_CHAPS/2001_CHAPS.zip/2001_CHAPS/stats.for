      program stats 
c
c         calculates a weighted mean, standard deviation and
c             autocorrelation of charcoal influx data, and 
c             filters and passes peaks in the influx data 
c
c       P.J. Bartlein, Dept. Geography, Univ. Oregon (bartlein@uoregon.edu)
c       August 1999, April 2003
c
c         this version assumes equally spaced observations 
c         
c         input (output from influx.for):
c             age (years) (first column of influx.for output)
c             average influx (char/cm2/yr) (second column of influx.for output)
c
c         info file contents:
c             line 1:  input filename (infile)
c             line 2:  output filename (outfile)
c             line 3:  window width (number of samples, not years) (width)
c             line 4:  peak-to-mean ratio threshold value (thresh)
c             line 5:  transformation parameter (trans)
c             line 6:  window width for smoothing peak mag and freq (smooth)
c             line 7:  interval for calculating smoothed frequency, magnitude, etc. (interval)
c             line 8:  missing data code (miss)
c
c         output  
c             col 1:  age (yrs) (Age)
c             col 2:    age/1000 (age ka) (ageka)
c             col 3:  influx (char/cm2/yr) (influx)
c             col 4:  mean (background) influx (char/cm2/yr) (mean)
c             col 5:  standard deviation of influx (char/cm2/yr) (stddev)
c             col 6:  ar1 (lag-1 autocorrelation) (ar1)
c             col 7:  ratio (in transformed units if a transformation was
c                         requested) between influx and mean (ratio)
c             col 8:  peak (1 if under peak, 0 otherwise) (peak)
c             col 9:  start of peak (1 if at beginning of peak, 0 otherwise) (pstart)
c             col 10: end of peak (1 ifa at end of peak, 0 otherwise) (pend)
c             col 11: total influx under peak (char/cm2) (pflux)
c             col 12: smoothed value of frequency of peaks (scaled to no. of
c                         peaks per interval) (freq)
c             col 13: smoothed value of total influxes under peaks (mag)
c             col 14: influx, deviations about mean (dev)
c             col 15: influx, positive deviations from mean (posdev)
c             col 16: time since last peak (years) (tslp)
c             col 17: time between peaks (years) (tbtwp)
c             col 18: mean time between peaks (years) (mntbtwp)
c
      implicit none
      integer maxobs,wmax,nv
      parameter (maxobs=45000,wmax=5000,nv=18)
      real age(maxobs),influx(maxobs),tflux(maxobs),miss,ageka
      real thresh,trans,const,dist,weight(wmax)
      real w(wmax),x(wmax),y(wmax),z(wmax),incl(wmax)
      real wsum,sum,tmean(maxobs),ssq,denom,tvar,tstdv,scp,tratio
      real mean(maxobs),var(maxobs),stddev(maxobs),ar1(maxobs)
      real ratio(maxobs),ptotal,pflux(maxobs),dev(maxobs),posdev(maxobs)
      real tslp(maxobs),tbtwp(maxobs),temp,tinc,mntbtwp(maxobs)
      real interval,freq(maxobs),mag(maxobs),duration,logten
      integer peak(maxobs),pstart(maxobs),pend(maxobs),use(maxobs),nuse
      integer nh,nobs,i,t,in,ii,id,width,smooth,begt,endt,l
      character*128 infile,outfile,infofile
      character*8 label(nv),dum
c
      data label/'    Age ','Age/1000','  Influx','    Mean',
     +           '  StdDev','     AR1','   Ratio','    Peak',
     +         '  Pstart','    Pend','   Pflux','    Freq',
     +         '     Mag','     Dev','  PosDev','    TSLP',
     +           '   TbtwP',' MnTbtwP' /
c 
c         open info file and read file names
c
      print *, "Enter info file name (including path):"
      read (*,*) infofile
      open (1,file=infofile)
c
c      read (1,'(a128)') infile
      read (1,*) infile
      write (*,901) infile
  901 format (' Input file: ',a128)
c      read (1,'(a128)') outfile
      read (1,*) outfile
      write (*,902) outfile
  902 format (' Output file: ',a128)
c     
c         open input and output files
c      
      open (2,file=infile)    
      open (3,file=outfile)
c     
      read (2,*) dum ! skip the labels
c
      i=0
      do while (.not.eof(2))
          i=i+1
          read (2,*) age(i),influx(i)
      end do
      nobs=i
      write (*,903) nobs
  903 format (' Number of observations in data set: ',i5)
      age(nobs+1)=age(nobs)+(age(nobs)-age(nobs-1))
      influx(nobs+1)=influx(nobs)
c
c          read window width, peak-to-mean ratio threshold 
c             transformation exponent, mag and freq smoother
c             width,  interval for freq calculations, and
c             missing data code (skip if missing)
c
      read (1,*) width
      write (*,904) width
  904 format (' Window width for smoothing: ',i5)
      read (1,*) thresh
      write (*,905) thresh
  905 format (' Peak-to-mean ratio threshold ',f6.2)
      read (1,*) trans
      write (*,906) trans
  906 format (' Transformation exponent: ',f6.2)
      read (1,*) smooth
      write (*,907) smooth
  907 format (' Window width for smoothing peak mag and freq: ',i5)
      read (1,*) interval
      write (*,908) interval
  908 format (' Interval for frequency calculations: ',f7.1)
      read (1,*) miss
      write (*,909) miss
  909 format (' Missing data code:  ',f10.4)      
c
c         check for missing data, and transform data if necessary
c
      const=1.0
      do t=1,nobs
          use(t)=0
          if (influx(t).ne.miss) use(t)=1
          if (use(t).ne.0) then
              if (trans.eq.0.0) then
                  tflux(t)=log(influx(t)+const)
              elseif (trans.eq.1.0) then
                  tflux(t)=influx(t)
              else    
                  tflux(t)=influx(t)**trans
              endif
          endif    
      end do
      logten=log(10.)                     
c
c         calculate window half-width, and weights
c
      nh=int(width/2)+1
      do i=1,width+1 
          dist=float((abs(nh-i)))/float(nh)
          weight(i)=(1.0-dist**3.0)**3.0  
      end do
c 
c         loop over data
c         note:  time (t) runs from top to bottom of file (i.e. core)
c
      do t=1,nobs
      if (use(t).ne.0) then
c          
      in=0
      do ii=1,width+1
          id=(t-nh)+ii  
          if (id.ge.1.and.id.le.nobs) then
              in=in+1           
              x(in)=tflux(id)
              w(in)=weight(ii)
              incl(in)=use(id)
          endif
      end do
c
c         calculate statistics
c
c         weighted mean
c
      wsum=0.0
      sum=0.0
      tmean(t)=0.0
      do i=1,in
          if (incl(i).eq.1) then
              sum=sum+x(i)*w(i)
              wsum=wsum+w(i)
          endif    
      end do
      if (wsum.ne.0) tmean(t)=sum/wsum
c
c         variance and standard deviation
c      
      ssq=0.0
      tvar=0.0
      nuse=0
      do i=1,in
          if (incl(i).eq.1) then
              nuse=nuse+1
              ssq=ssq+w(i)*(x(i)-tmean(t))*(x(i)-tmean(t))
          endif    
      end do
      denom=0.0
      if (nuse.ne.0) denom=(float(nuse-1)*wsum/float(nuse))
      if (denom.ne.0.0) tvar=ssq/denom
      tstdv=sqrt(tvar)
c
c         first-order autocorrelation coefficient
c     
      scp=0.0
      ar1(t)=0.0
      nuse=0
      do i=1,in-1
          if (incl(i).eq.1) then
              nuse=nuse+1
              scp=scp+w(i)*(x(i+1)-tmean(t))*(x(i)-tmean(t))
          endif    
      end do
      denom=0.0
      if (nuse.ne.0) denom=tvar*(nuse-1) 
      if (denom.ne.0.0) ar1(t)=scp/denom 
c
c         untransform data if necessary
c
      
      if (trans.eq.0.0) then
          mean(t)=exp(tmean(t)+(tvar/2.0))-const
          var(t)=(mean(t)**2.0)*(exp(tvar)-1.0)
          stddev(t)=sqrt(var(t))
      elseif (trans.eq.1.0) then
          mean(t)=tmean(t)
          var(t)=tvar
          stddev(t)=tstdv
      else
          mean(t)=tmean(t)**(1.0/trans)
          var(t)=tvar
          stddev(t)=tstdv**(1.0/trans)
      endif
c
c         deviations about the mean
c     
      dev(t)=0.0
      posdev(t)=0.0
      if (trans.eq.0.0) then
          dev(t)=tflux(t)-tmean(t)
      else    
          dev(t)=influx(t)-mean(t)
      endif    
      if (dev(t).gt.0.0) posdev(t)=dev(t)
c     
      endif 
c
      end do
c
c         peak statistics
c     
      ratio(nobs+1)=thresh
      do t=nobs,1,-1
      if (use(t).ne.0) then
c         
c         define peak using ratio between transformed (if requested)
c         value of influx and the mean
c
      ratio(t)=thresh
      tratio=0.0
      peak(t)=0
      if (tflux(t).gt.tmean(t)) then 
          tratio=tflux(t)/tmean(t) 
          if (tratio.gt.thresh) then 
              ratio(t)=tratio
              peak(t)=1
          endif    
      endif
c
c         note starting and ending observations of a peak
c  
      pstart(t)=0
      pend(t)=0
      if ((ratio(t+1).le.thresh).and.(ratio(t).gt.thresh)) pstart(t)=1
      if ((ratio(t+1).gt.thresh).and.(ratio(t).le.thresh)) pend(t+1)=1
c     
      endif
      end do
c
c         calculate total influx under peak (magnitude)
c
      ptotal=0.0
      do t=nobs,1,-1
      if (use(t).ne.0) then    
          pflux(t)=0.0
          if (peak(t).eq.1) then
              ptotal=ptotal+influx(t)*(age(t+1)-age(t))
          else
              pflux(t+1)=ptotal
              ptotal=0.0
          endif
      endif    
      end do
      pflux(1)=0.0
      if (peak(1).eq.1) pflux(1)=ptotal   
c
c       calculate time since last peak and time between peaks
c
      tinc=0
      do t=nobs,1,-1
        if (pstart(t).ne.1) then
            tinc=tinc+age(t+1)-age(t)
            tslp(t)=tinc
        else
            tinc=tinc+age(t+1)-age(t)
            tslp(t)=tinc
            tinc=0
        end if
      end do
c
      temp=tslp(1)
      do t=1,nobs
        if (pstart(t).eq.0) then
            tbtwp(t)=temp
        else
            temp=tslp(t)
            tbtwp(t)=temp
        end if
      end do
c
c         smooth frequency and magnitudes of peaks, and 
c           time between peaks
c
c         calculate window half-width, and weights 
c
      nh=int(smooth/2)+1
      do i=1,smooth+1 
          dist=float((abs(nh-i)))/float(nh)
          weight(i)=(1.0-dist**3.0)**3.0  
      end do 
c 
c         loop over data
c
      do t=1,nobs
      if (use(t).ne.0) then
c          
          in=0
          do ii=1,smooth+1
              id=(t-nh)+ii  
              if (id.ge.1.and.id.le.nobs) then
                  in=in+1           
                  x(in)=pstart(id)
                  y(in)=pflux(id)
                z(in)=tbtwp(id)
                  w(in)=weight(ii)
                  incl(in)=use(id)
              endif
        end do
          begt=(t-nh)+1
          if (begt.lt.1) begt=1
          endt=(t-nh)+smooth+1
          if (endt.gt.nobs) endt=nobs
c
c         calculate statistics
c
c         weighted proportion of obs with peaks (frequency)
c
      wsum=0.0
      sum=0.0
      freq(t)=0.0
      do i=1,in
          if (incl(i).ne.0) then
              sum=sum+x(i)*w(i)
              wsum=wsum+w(i)
          endif    
      end do
      duration=age(endt)-age(begt)
      if (wsum.ne.0) freq(t)=in*(sum/wsum)*(interval/duration)
c
c         weighted total influx (magnitude)
c
      wsum=0.0
      sum=0.0
      mag(t)=0.0
      do i=1,in
          if (incl(i).ne.0) then
              if (y(i).gt.0.0) then
                  sum=sum+y(i)*w(i)
                  wsum=wsum+w(i)
              endif
          endif        
      end do
      if (wsum.ne.0) mag(t)=sum/wsum       
c
c         weighted time between peaks
c
      wsum=0.0
      sum=0.0
      mntbtwp(t)=0.0
      do i=1,in
          if (incl(i).ne.0) then
              if (y(i).gt.0.0) then
                  sum=sum+z(i)*w(i)
                  wsum=wsum+w(i)
              endif
          endif        
      end do
      if (wsum.ne.0) mntbtwp(t)=sum/wsum  
      endif
c
      end do    
c 
c         write out the results     
c      
      write (3,'(32a8)') (label(l),l=1,nv)
      do t=1,nobs
      ageka=age(t)/1000.0
      if (use(t).eq.1) then
          write (3,910) age(t),ageka,influx(t),mean(t),stddev(t),ar1(t),
     +    ratio(t),peak(t),pstart(t),pend(t),pflux(t),freq(t),
     +    mag(t),dev(t),posdev(t),tslp(t),tbtwp(t),mntbtwp(t)
  910     format (f8.1,f8.3,2f8.3,f8.1,2f8.3,
     +			3i8,f8.1,f8.3,f8.1,2f8.3,3f8.1)
      else
          write (3,911) age(t),ageka
  911     format (f8.1,f8.3,16(7x,'*'))
      endif
      end do
c                    
      end       