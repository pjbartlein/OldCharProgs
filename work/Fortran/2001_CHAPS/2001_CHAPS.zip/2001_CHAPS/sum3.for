	program sum3
c
      implicit none
      integer nd,nyrs
      parameter (nd=1800,nyrs=1681)
      real age(nd),influx(nd),mean(nd),stddev(nd),ar1(nd),diff(nd)
	real ratio(nd),pflux(nd),freq(nd),mag(nd),dev(nd),ageka(nd)
	real cuflux(nd),cumag(nd),posdev(nd),cusum(nd)
	real detcuflux(nd),detcumag(nd),detcusum(nd),div
      integer peak(nd),pstart(nd),cupeaks(nd),detcupeaks(nd)
	integer nstart  
      integer t,t2,step,wlen,count,j,k,nstep,ibeg,iend
c      
	influx=0.0
	mean=0.0
	stddev=0.0
	ar1=0.0
	diff=0.0
	ratio=0.0
	pflux=0.0
	freq=0.0
	mag=0.0
	dev=0.0
	age(1)=0.0
	ageka(1)=0.0
	do t=1,nd
		age(t)=(t-1)*10.
		ageka(t)=(t-1)/100.
	end do
	
c
	open (1,file='\Fire\Summary\cygstat3.dat')
      do t=1,nyrs
		read (1,*) age(t),influx(t),mean(t),stddev(t),ar1(t),
     +		diff(t),ratio(t),peak(t),pstart(t),pflux(t),freq(t),
     +		mag(t),dev(t),ageka(t)
	end do
c
	open (10,file='\Fire\Summary\debug.dat')
c	do t=1,nd
c		write (10,'(f8.1,3f8.3,3f8.3,2i3,f10.3,f7.1,f10.3,f8.3,f7.3)') 
c     +		age(t),influx(t),mean(t),stddev(t),ar1(t),
c     +		diff(t),ratio(t),peak(t),pstart(t),pflux(t),freq(t),
c     +		mag(t),dev(t),ageka(t)
c	end do
c      
	open (2,file='\Fire\Summary\cu.dat')
	cuflux=0.0
	cumag=0.0
	posdev=0.0
	cupeaks=0
	detcuflux=0.0
	detcumag=0.0
	detcusum=0.0
	detcupeaks=0
	do t=1675,1,-1
		cuflux(t)=cuflux(t+1)+influx(t)*10.0
		cumag(t)=cumag(t+1)+pflux(t)
		if (dev(t).gt.0.0) then
			posdev(t)=dev(t)
		end if
		cusum(t)=cusum(t+1)+dev(t)*dev(t)
		cupeaks(t)=cupeaks(t+1)+pstart(t)
	end do
c
	do t=1,1675
		div=(float(1675-t+1)/float(1675))
		detcuflux(t)=cuflux(t)-div*cuflux(1)
		detcumag(t)=cumag(t)-div*cumag(1)
		detcusum(t)=cusum(t)-div*cusum(1)
		detcupeaks(t)=cupeaks(t)-int(div*cupeaks(1))
	end do
c
	do t=1,1675
		write (2,'(f7.3,i5,6f10.2,i5,f10.2)') 
     +		ageka(t),cupeaks(t),cuflux(t),
     +		cumag(t),cusum(t),detcuflux(t),detcumag(t),detcusum(t),
     +		detcupeaks(t),posdev(t)
	end do
c
	stop
	end