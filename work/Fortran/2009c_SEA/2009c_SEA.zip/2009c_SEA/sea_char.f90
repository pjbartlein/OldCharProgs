program sea_char
! superposed epoch analysis of Greeland interstadials

implicit none

integer, parameter  :: npts=7002, nevents=7, ntarg=401
real(8)             :: age(npts),y(npts),agebp,depth,yin1,yin2
real(8)             :: targage(ntarg),delta,targspan
real(8)             :: q25s(ntarg),q50s(ntarg),q75s(ntarg),mean(ntarg),stddev(ntarg)
real(8)             :: events(nevents),x(ntarg,nevents),a1,a2
integer             :: np(ntarg),eventnum(nevents)

real(8)             :: q0,q01,q05,q10,q25,q50,q75,q90,q95,q99,q100
integer             :: i,ii,j,k

character(80)       :: header

open (7,file="e:\Projects\GPWG\data\files\v2m\curves\v2m_lr_all_ok_boot_conc2_ztall_250-1000_dev.csv")
open (2,file="e:\Projects\GPWG\data\files\v2m\curves\v2m_lr_250-1000_HS_sea.csv")
open (3,file="e:\Projects\GPWG\data\files\v2m\curves\v2m_lr_250-1000_HS_sea_series.csv")
open (4,file="e:\Projects\GPWG\work\long\figs\HS_onset.csv")
open (10,file="e:\Projects\GPWG\data\files\v2m\curves\sea_debug.csv")

read (4,'(a)') header
do k=1,nevents
    read (4,*) eventnum(k),a1,events(k)
end do

read (7,'(a)') header
write (2,'(a)') "year,q50,q25,q75,mean,stddev"
write (3,'("year",21(", ","""",f12.0,""""))') (events(k),k=1,nevents)

targspan=8000.0d0
delta=targspan/dble(ntarg-1)

! target offsets
do j=1,ntarg
    targage(j)=(targspan/2.0d0)-dble(j-1)*delta !dble(2000-(j-1)*20)
    !write (10,*) j,targage(j)
end do

! read data and calculate deviations
do i=1,npts
    read (7,*) age(i),y(i)
    age(i)=(age(i))
end do

x=0.0d0; np=0
! loop over events
do k=1,nevents
    do i=1,npts
        if (age(i).eq.events(k)) exit
    end do
    do j=1,ntarg
        ii=i+((ntarg-1)/2)-(j-1)
        if (ii.ge.1 .and. ii.le.npts) then
            x(j,k)=y(ii) !age(ii) !  
            np(j)=np(j)+1
        end if
        ! write (10,'(3i5,2f10.2)') k,i,j,x(j,k),targage(j)
    end do
end do

do j=1,ntarg
    write (3,'(f8.0,21(", ",f12.5))') targage(j),(x(j,k),k=1,np(j))
    call quantiles(np(j),x(j,:),q0,q01,q05,q10,q25s(j),q50s(j),q75s(j),q90,q95,q99,q100)
    call desc(np(j),x(j,:),mean(j),stddev(j))
    write (2,'(f8.0,6(",",f12.5))') targage(j),q50s(j),q25s(j),q75s(j),mean(j),stddev(j)
end do            

end


subroutine quantiles(n,y,q0,q01,q05,q10,q25,q50,q75,q90,q95,q99,q100)
! usual quantile values

    implicit none
    
    integer, parameter  :: nq=9
    integer     :: n
    real(8)     :: y(n),ys(n),p(n)
    real(8)     :: q0,q01,q05,q10,q25,q50,q75,q90,q95,q99,q100
    real(8)     :: pval(nq),q(nq)
    integer     :: i,k
    
    data pval/0.01d0,0.05d0,0.10d0,0.25d0,0.50d0,0.75d0,0.90d0,0.95d0,0.99d0/
    
    call sortx(n,y,ys)
    do k=1,n
        p(k)=float(k-1)/float(n-1)
        !write (*,'(i4,3f10.3)') k,y(k),ys(k),p(k)
    end do
    
    do i=1,nq
        q(i)=-9999.0
        do k=1,n-1
            if (pval(i).gt.p(k) .and. pval(i).le.p(k+1)) exit
        end do
        q(i)=ys(k)+(ys(k+1)-ys(k))*(pval(i)-p(k))/(p(k+1)-p(k))
        !write (*,'(i2,2f10.3)') i,pval(i),q(i)
    end do
    q0=ys(1); q01=q(1); q05=q(2); q10=q(3); q25=q(4); q50=q(5); q75=q(6); q90=q(7); q95=q(8); q99=q(9); q100=ys(n)
    
end subroutine quantiles


subroutine sortx(npts,x,xs)
! sorts x

    implicit none

    integer         :: npts
    real(8)         :: x(npts),xs(npts+1),tx
    integer         :: i,j,k,kp1
    logical         :: flag
    
    do i=1,npts
        xs(i)=x(i)
    end do

    i=0
    flag=.true.
    do 
        i=i+1
        j=npts-i
        flag=.false.
        do k=1,j
            kp1=k+1
            if (xs(k).gt.xs(kp1)) then
                tx=xs(kp1)
                xs(kp1)=xs(k)
                xs(k)=tx
                flag=.true.
            end if
        end do
        if (.not.flag) exit
    end do

end subroutine sortx


subroutine medianx(npts,x,median)
! finds median of x

    implicit none

    integer         :: npts
    real(8)         :: x(npts),xs(npts+1),tx,median
    integer         :: i,j,k,kp1
    logical         :: flag

    do i=1,npts
        xs(i)=x(i)
    end do

    i=0
    flag=.true.
    do 
        i=i+1
        j=npts-i
        flag=.false.
        do k=1,j
            kp1=k+1
            if (xs(k).gt.xs(kp1)) then
                tx=xs(kp1)
                xs(kp1)=xs(k)
                xs(k)=tx
                flag=.true.
            end if
        end do
        if (.not.flag) exit
    end do

    ! xs contains sorted values of x

    select case (npts)
        case (0)
            median=0.0d0
        case (1)
            median=xs(1)
        case (2)
            ! crude definition
            median=xs(int(npts/2))
        case default
            ! statistical definition
            median=(xs(int(npts/2)+1) + xs(npts - int(npts/2) +2))/2.0d0
    end select

end subroutine medianx


subroutine desc(npts,y,mean,stdev)
! mean and standard deviation of a variable

    implicit none

    integer     :: npts
    real(8)     :: y(npts),mean,stdev
    integer     :: i

    mean=0.0d0
    do i=1,npts
        mean=mean+y(i)
    end do
    if (npts.gt.0) mean=mean/dble(npts)
    stdev=0.0d0
    do i=1,npts
        stdev=stdev+(y(i)-mean)*(y(i)-mean)
    end do
    if (stdev.gt.0.0d0) stdev=(sqrt(stdev/dble(npts-1)))

end subroutine desc



