module sea_subs

contains

subroutine sea(nctrl,x,y,ntarg,xt,hw,nevents,events,nreps,begage,endage,q50s,q25s,q75s,qs50,qs95l,qs95u,np)

! superposed epoch analysis

    use ifport

    implicit none
    
    integer, parameter  :: maxpts=40000, maxreps=5000
    integer             :: nctrl,ntarg,nevents,nreps
    real(8)             :: x(nctrl),y(nctrl),xt(ntarg),hw
    real(8)             :: events(nevents),begage,endage,randseed,randval,randage(nevents)
    real(8)             :: xrel,xin(maxpts),yin(maxpts)
    real(8)             :: q25s(ntarg),q50s(ntarg),q75s(ntarg)
    real(8)             :: qsim(ntarg,maxreps),qs50(ntarg),qs95l(ntarg),qs95u(ntarg)
    real(8)             :: q0,q01,q025,q05,q10,q25,q50,q75,q90,q95,q975,q99,q100
    integer             :: i,n,ii,j,k,npts,np(ntarg)
    
    ! randomization CIs
    ! random number seed
    call srand(100)
    do k=1,nreps
        if (mod(k,10) .eq.0) write (*,'(i5,\)') k 
        ii=0
        do i=1,nctrl
            do n=1,nevents
                randval=rand(0)
                randage(n)=dble(int((randval*(endage-begage))+begage))
                xrel=x(i)-randage(n)
                if (xrel.ge.xt(1)-2.0d0*hw .and. xrel.le.xt(ntarg)+2.0d0*hw) then
                    ii=ii+1
                    xin(ii)=xrel
                    yin(ii)=y(i)
                end if
            end do
        end do
        npts=ii
        
        call sea_quant(npts,xin,yin,ntarg,xt,hw,q50s,q25s,q75s,np)
        qsim(:,k)=q50s
                
    end do
    
    do j=1,ntarg
        write (10,'(f10.2,101(",",f9.4))') xt(j),(qsim(j,k),k=1,101)
    end do
    
    do j=1,ntarg
        !write (10,'("j=",i5)') j
        !write (10,*) qsim(j,:)
        call quantiles(nreps,qsim(j,:),q0,q025,q01,q05,q10,q25,q50,q75,q90,q95,q975,q99,q100)
        qs50(j)=q50
        qs95l(j)=q025
        qs95u(j)=q975
    end do
    
    ! the actual sea curve
    ! stack around events
    ii=0
    do i=1,nctrl
        do n=1,nevents
            xrel=x(i)-events(n)
            if (xrel.ge.xt(1)-2.0*hw .and. xrel.le.xt(ntarg)+2.0*hw) then
                ii=ii+1
                xin(ii)=xrel
                yin(ii)=y(i)
            end if
        end do
    end do
    npts=ii
    
    call sea_quant(npts,xin,yin,ntarg,xt,hw,q50s,q25s,q75s,np)
    
end subroutine sea

            
subroutine sea_quant(npts,xin,yin,ntarg,xt,hw,q50s,q25s,q75s,np)

! manages computation of a quantile "curve"

    implicit none

    integer             :: npts,ntarg
    real(8)             :: xin(npts),yin(npts),ys(npts),xt(ntarg),hw
    real(8)             :: q25s(ntarg),q50s(ntarg),q75s(ntarg)
    real(8)             :: q0,q01,q025,q05,q10,q25,q50,q75,q90,q95,q975,q99,q100
    integer             :: n,np(npts),nevents
    
    integer             :: i,ii
    
    !write (10,*) npts,ntarg
    ! loop over target points, calling localfit for each target point
    do ii=1,ntarg   
        n=0   
        do i=1,npts
        !write (10,'(3i5,2f12.2)') ii,n,i,xin(i),xt(ii)
            if (xin(i).ge.xt(ii)-2.0d0*hw .and. xin(i).lt.xt(ii)+0.0d0*hw) then
                n=n+1
                ys(n)=yin(i)
            end if
        end do
        if (n.gt.0) then
            call quantiles(n,ys,q0,q025,q01,q05,q10,q25,q50,q75,q90,q95,q975,q99,q100)
        end if
        !write (10,'(i4,11f8.3)') n,q0,q01,q05,q10,q25,q50,q75,q90,q95,q99,q100
        np(ii)=n
        q50s(ii)=q50; q25s(ii)=q25; q75s(ii)=q75
    end do  
   
end subroutine sea_quant


subroutine quantiles(n,y,q0,q01,q025,q05,q10,q25,q50,q75,q90,q95,q975,q99,q100)
! usual quantile values

    implicit none
    
    integer, parameter  :: nq=11
    integer     :: n
    real(8)     :: y(n),ys(n),p(n)
    real(8)     :: q0,q01,q025,q05,q10,q25,q50,q75,q90,q95,q975,q99,q100
    real(8)     :: pval(nq),q(nq)
    integer     :: i,k
    
    data pval/0.01d0,0.025d0,0.05d0,0.10d0,0.25d0,0.50d0,0.75d0,0.90d0,0.95d0,0.975d0,0.99d0/
    
    call sortq(n,y,ys)
    do k=1,n
        if (n-1.gt.0) then
            p(k)=float(k-1)/float(n-1)
        else
            p(k)=1.0d0
        end if
        !write (10,'(i4,3f10.3)') k,y(k),ys(k),p(k)
    end do
    
    do i=1,nq
        q(i)=-9999.0
        if (n.ge.2) then
            do k=1,n-1
                if (pval(i).gt.p(k) .and. pval(i).le.p(k+1)) exit
            end do
            q(i)=ys(k)+(ys(k+1)-ys(k))*(pval(i)-p(k))/(p(k+1)-p(k))
        else
            q(i)=ys(1)
        end if
        !write (*,'(i2,2f10.3)') i,pval(i),q(i)
    end do
    
    q0=ys(1); q01=q(1); q025=q(2); q05=q(3); q10=q(4); q25=q(5); q50=q(6)
    q75=q(7); q90=q(8); q95=q(9); q975=q(10); q99=q(11); q100=ys(n)
    
    ! q50 <- median
    
    select case (n)
        case (0)
            q50=0.0d0
        case (1)
            q50=ys(1)
        case (2)
            ! crude definition
            q50=ys(int(n/2))
        case default
            ! statistical definition
            if (mod(n,2).eq.0) then
                q50=(ys(int(n/2))+ys(int(n/2)+1))/2.0d0
            else
                q50=ys(int((n+1)/2))
            end if
            !q50=(ys(int(n/2)+1) + ys(n - int(n/2) +2))/2.0d0
    end select
    
end subroutine quantiles

subroutine sortq(npts,x,xs)
! sorts x

    implicit none

    integer         :: npts
    real(8)         :: x(npts),xs(npts+1),tx
    integer         :: i,j,k,kp1
    logical         :: flag
    
    do i=1,npts
        xs(i)=x(i)
    end do

    i=0
    flag=.true.
    do 
        i=i+1
        j=npts-i
        flag=.false.
        do k=1,j
            kp1=k+1
            if (xs(k).gt.xs(kp1)) then
                tx=xs(kp1)
                xs(kp1)=xs(k)
                xs(k)=tx
                flag=.true.
            end if
        end do
        if (.not.flag) exit
    end do

end subroutine sortq



end module sea_subs