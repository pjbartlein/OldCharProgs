program sea_boot_ngrip_demo
! superposed epoch analysis of Greeland interstadials

use sea_subs

implicit none

integer, parameter  :: maxdata=100000, maxtarg=10000, maxreps=5000, maxevents=25
real(8)             :: age(maxdata),y(maxdata)
real(8)             :: agebp,depth,yin1,yin2,d1,d2,d3,d4
real(8)             :: seatarg(maxtarg),seatargbeg,seatargend,seatargstep,hw
real(8)             :: q05(maxtarg),q50(maxtarg),q95(maxtarg)
real(8)             :: qs50(maxtarg),qs95l(maxtarg),qs95u(maxtarg)
real(8)             :: events(maxevents),a1,a2,sea_begage,sea_endage
integer             :: np(maxtarg),nevents,eventnum(maxevents),nseatarg,nctrl,nreps,dummy

integer             :: i,k

character(80)       :: header

open (1,file="e:\Projects\paleovar\data\NGRIP\NGRIP_WC.csv")
open (2,file="e:\Projects\paleovar\data\NGRIP\NGRIP_WC_GISevents_sea_boot_20_demo.csv")
open (4,file="e:\Projects\paleovar\data\NGRIP\GISevents.csv")

open (5,file="e:\Projects\paleovar\data\NGRIP\random_stack.csv")
open (6,file="e:\Projects\paleovar\data\NGRIP\events_stack.csv")

open (10,file="e:\Projects\paleovar\data\NGRIP\sea_debug.csv")
write (2,'(a)') "targ,q50,q25,q75,qs50,qs95l,qs95u,np" 

seatargbeg=-4000.0d0
seatargend=4000.0d0
seatargstep=20.0d0 ! 
hw=10.0d0 ! 
nreps=1
sea_begage=11000.0d0
sea_endage=80000.0d0

read (4,'(a)') header
k=0
do while (.not. eof(4))
    k=k+1
    read (4,*) eventnum(k),d1,d2,events(k) ! d3,
    write (10,*) k,eventnum(k),events(k)
end do
nevents=k

! generate sea target points
nseatarg=int((seatargend-seatargbeg)/seatargstep)+1
write (*,'(3f12.2,i8)') seatargbeg,seatargend,seatargstep,nseatarg
!write (10,*) seatargstep,nseatarg
do i=1,nseatarg
    seatarg(i)=seatargbeg+dble(i-1)*seatargstep
    !write (10,*) i,seatarg(i)
end do

! read data 
read (1,'(a)') header
i=0
do while(.not. eof(1))
    i=i+1
    read (1,*) d1,d2,d3,y(i),d4,age(i)
    write (10,*) i,age(i),y(i)
end do
nctrl=i

call sea(nctrl,age,y,nseatarg,seatarg,hw,nevents,events,nreps,sea_begage,sea_endage,q50,q05,q95,qs50,qs95l,qs95u,np)

do i=1,nseatarg
    write (2,'(f10.2,6(","f10.4),",",i6)') seatarg(i),q50(i),q05(i),q95(i),qs50(i),qs95l(i),qs95u(i),np(i) 
end do

end


