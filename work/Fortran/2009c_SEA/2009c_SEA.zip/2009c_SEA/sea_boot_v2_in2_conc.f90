program sea_boot_v2_in2_conc
! superposed epoch analysis
! fits a smooth lowess-type curve to transformed/standardized charcoal data
! gets Monte Carlo estimates of SEA
use lowess
use sea_subs
use ifport

implicit none

integer, parameter  :: maxdata=100000, maxsitedata=9000, maxsites=2000, maxtarg=10000, maxreps=5000, maxevents=25

integer(4)      :: site_sample
integer(8)      :: id_sample
real(4)         :: age,depth,influx2,influx2mnx,tall,ztall,zt21k,zt4k,zt2k,ztpi2,ztpi4
real(4)         :: conc2,conc2mnx,zt15132k,zt132k,zt40k,zt1573k

real(4)         :: varin,varmiss
integer         :: site_num,usesitenum,usesite(maxsites)
character(16)   :: site_num_label,timeprefix,ww
character(4)    :: site_num_char

character(32)   :: vname

real(8)         :: xsite(maxsitedata,maxsites),ysite(maxsitedata,maxsites)
integer         :: nrecs(maxsites),idsite(maxsites),nsel(maxsites),ndec(maxtarg,maxsites),ndec_tot(maxtarg)

real(8)         :: xin(maxdata),yin(maxdata)

real(4)         :: begyr,endyr
real(8)         :: xtarg(maxtarg),yfit1(maxtarg),yfitse(maxtarg),fit_cu95(maxtarg),fit_cl95(maxtarg),ypredse(maxtarg),yfit2(maxtarg)
real(8)         :: param1,param2,xspan(maxtarg)
real(8)         :: targbeg,targend,targstep
integer(4)      :: npfit(maxtarg),minpts,order,nrobust,ntarg
character(1)    :: wintype

real(8)         :: events(maxevents),xsearel,d1,d2,d3
real(8)         :: seatargbeg,seatargend,seatargstep,sea_hw,sea_begage,sea_endage
real(8)         :: seatarg(maxtarg),sea50(maxtarg),sea25(maxtarg),sea75(maxtarg),searep_50(maxtarg),searep_cl95(maxtarg),searep_cu95(maxtarg)
real(8)         :: xinsea(maxdata),yinsea(maxdata)
integer         :: nseareps,elbl(maxevents),nevents,nseatarg,nseapts,np(maxdata)

real(8)         :: ranseed,randval
real(8)         :: yfit_reps(maxtarg,maxreps),temp(maxreps),sorttemp(maxreps)
real(8)         :: yfit_boot(maxtarg),yfit_boot_median(maxtarg),yfit_boot_stdev(maxtarg),yfit_boot_se(maxtarg)
real(8)         :: yfit_boot_cu95(maxtarg),yfit_boot_cl95(maxtarg)
integer         :: jsel(maxsites,maxreps),jmax,jmin,ncl95,ncu95,n50

integer         :: i,j,k,n,npts,nctrl,jsite,nsites,ii,nreps,intype

character(32)   :: int_to_string2,int_to_string
character(256)  :: infofile
character(256)  :: infilepath,infile,outpath,plotpath,ptsfile,lowfile,lowcsvfile,eventsfile
character(256)  :: region,regionpath,regionfile
character(16)   :: base, query, sww, seaww

character(80)   :: header
character(1)    :: dum

logical         :: yfitnan,nan 

! read the info file
call get_command_argument(1,infofile)
open (99,file=trim(adjustl(infofile)))

do while (.not. eof(99))
    read (99,*) infilepath
    read (99,*) outpath
    read (99,*) regionpath
    read (99,*) eventsfile
    read (99,*) region
    read (99,*) vname
    read (99,*) timeprefix
    read (99,*) param1,param2
    read (99,*) targend, targbeg, targstep
    read (99,*) begyr, endyr
    read (99,*) nreps
    read (99,*) seatargend, seatargbeg, seatargstep
    read (99,*) sea_begage,sea_endage
    read (99,*) sea_hw
    read (99,*) nseareps
    
    write (*,'(a)') eventsfile

regionfile=trim(adjustl(regionpath))//trim(adjustl(region))//".csv"
open (10,file=trim(adjustl(outpath))//"debug_boot.dat")  

!vname="conc2" ! "influx2" !
!timeprefix="mnxall" ! "ztall" ! "zt21k" ! "ztpi4" ! "ztpi2" ! "ztall" ! 

sww="10"
intype=2 ! 1 ! 

! lowess parameters
wintype='w'; minpts=30; order=1; nrobust=1     ! ############
!ww="rnd"//int_to_string(int(param))
ww=int_to_string(int(param1))
seaww=int_to_string(int(2.0d0*sea_hw))

! number of bootstrap samples
!nreps=100

write (*,'("outpath:"/a80)') outpath 
write (*,'("regionfile:"/a80)') regionfile
write (*,'("infilepath:"/a80)') infilepath

select case (intype)
    case (1)
        lowcsvfile=trim(adjustl(region))//"_"//trim(adjustl(eventsfile))//"_"//trim(adjustl(seaww))//"_sea_"//trim(adjustl(vname))//"_"//trim(adjustl(timeprefix))// &
            "_"//trim(adjustl(ww))//".csv" 
    case (2)
        lowcsvfile=trim(adjustl(region))//"_"//trim(adjustl(eventsfile))//"_"//trim(adjustl(seaww))//"_sea_"//trim(adjustl(vname))//"_"//trim(adjustl(timeprefix))// &
            "_"//trim(adjustl(sww))//"_"//trim(adjustl(ww))//".csv"
end select
write (*,'("lowcsvfile:"/a80)') lowcsvfile

open (7,file=trim(adjustl(outpath))//trim(adjustl(lowcsvfile)))
write (7,'(a)') "targ, q50, q25, q75, qs50, qs95l, qs95u, np" 
open (8,file=regionfile) 
open (9,file=trim(adjustl(regionpath))//"\"//trim(adjustl(eventsfile))//".csv")
!open (10,file=trim(adjustl(outpath))//"debug_boot.dat")  
!open (11,file=trim(adjustl(outpath))//"yfit_"//trim(adjustl(ww))//"_boot.dat") ! ############

!select case (intype)
!    case (1)
!        write (7,'(a)') "targ_age,  "//trim(adjustl(timeprefix))//"_"//trim(adjustl(vname))//"_"//trim(adjustl(ww))//", sefit, fitcu95, fitcl95, np, "// &
!            trim(adjustl(timeprefix))//"_"//trim(adjustl(vname))//"_"//trim(adjustl(ww))//"_boot, yfit_boot_median,yfit_boot_se, yfit_boot_cu95, yfit_boot_cl95, nsites, xspan"  ! ############
!        write (*,'(a)') "targ_age,  "//trim(adjustl(timeprefix))//"_"//trim(adjustl(vname))//"_"//trim(adjustl(ww))//", sefit, fitcu95, fitcl95, np, "// &
!            trim(adjustl(timeprefix))//"_"//trim(adjustl(vname))//"_"//trim(adjustl(ww))//"_boot, yfit_boot_median,yfit_boot_se, yfit_boot_cu95, yfit_boot_cl95, nsites, xspan"  ! ############
!    case (2)
!        write (7,'(a)') "targ_age,  "//trim(adjustl(timeprefix))//"_"//trim(adjustl(vname))//"_"//trim(adjustl(sww))//"_"//trim(adjustl(ww))//", sefit, fitcu95, fitcl95, np, "// &
!            trim(adjustl(timeprefix))//"_"//trim(adjustl(vname))//"_"//trim(adjustl(sww))//"_"//trim(adjustl(ww))//"_boot, yfit_boot_median, yfit_boot_se, yfit_boot_cu95, yfit_boot_cl95, nsites, xspan"  ! ############
!        write (*,'(a)') "targ_age,  "//trim(adjustl(timeprefix))//"_"//trim(adjustl(vname))//"_"//trim(adjustl(sww))//"_"//trim(adjustl(ww))//", sefit, fitcu95, fitcl95, np, "// &
!            trim(adjustl(timeprefix))//"_"//trim(adjustl(vname))//"_"//trim(adjustl(sww))//"_"//trim(adjustl(ww))//"_boot, yfit_boot_median, yfit_boot_se, yfit_boot_cu95, yfit_boot_cl95, nsites, xspan"  ! ############
!end select

! random number seed
call srand(100)

! generate target points
ntarg=int((targend-targbeg)/targstep)+1
write (*,*) param1,param2,targstep,ntarg,order,nrobust,wintype
!write (10,*) param1,param2,targstep,ntarg,order,nrobust,wintype
do i=1,ntarg
    !xtarg(i)=targend-dble(i-1)*targstep
    xtarg(i)=targbeg+dble(i-1)*targstep
    !write (10,*) i,sngl(xtarg(i))
end do

! generate sea target points
nseatarg=int((seatargend-seatargbeg)/seatargstep)+1
write (*,*) seatargstep,nseatarg
!write (10,*) seatargstep,nseatarg
do i=1,nseatarg
    !seatarg(i)=seatargend-dble(i-1)*seatargstep
    seatarg(i)=seatargbeg+dble(i-1)*seatargstep
    !write (10,*) i,sngl(xseatarg(i))
end do

varmiss=-9999.0

! read the region site file
usesite=0
read (8,*) header
do while (.not. eof(8))
    read (8,*) usesitenum
    !write (*,*) usesitenum
    usesite(usesitenum)=1
end do 
close (8)
!write (*,'(20i5)') usesite
!pause

! read events file (use b2k)
i=0
read (9,*) header
do while(.not. eof(9))
    i=i+1
    read (9,*) elbl(i),d1,d2,d3,events(i)
end do
nevents=i

! read data, store individual sites in array

nsel=0
jsite=0
xsite=0.0; ysite=0.0
ndec=0; ndec_tot=0
do j=1,maxsites

    site_num_char=int_to_string2(j,4)
    
    ! try to open a file
    site_num_char=int_to_string2(j,4)   ! ############
    select case (intype)
        case (1)
            infile=trim(adjustl(infilepath))//trim(adjustl(site_num_char))//"_trans_"//trim(adjustl(vname))//".csv"
        case (2)
            infile=trim(adjustl(infilepath))//trim(adjustl(site_num_char))//"_smooth_"//trim(adjustl(vname))//"_"// &
                trim(adjustl(timeprefix))//"_sm"//trim(adjustl(sww))//".csv"
    end select
    
    !if (usesite(j).eq.1) then
    !    write (*,*) site_num_char, usesite(j)
    !    write (*,'(a256)') infile
    !    !pause
    !end if
    
    open (1,file=infile, status='old', err=100)
    ! if site file exists:
     
    if (usesite(j).eq.1) then    
        jsite=jsite+1
        idsite(jsite)=j    
        
        write (*,*) site_num_char, usesite(j)
        write (*,'(a96)') infile
        
        ! read data, and save age and variable to be smoothed
        read (1,*) header
        i=0
        do while (.not. eof(1))   ! ############
            select case (intype)
                case (1) ! trans input
                    !read (1,*) site_num_label,site_sample, id_sample, age, depth, influx2, influx2mnx, tall, ztall, zt21k, zt4k, zt2k, ztpi2, ztpi4
                    read (1,*) site_num_label,site_sample, id_sample, age,depth,conc2,conc2mnx,tall,ztall,zt21k,zt15132k,zt132k,zt40k,zt1573k
                        select case (timeprefix)    
                            case ("ztall")
                                varin=ztall
                            case ("tall")
                                varin=tall
                            case ("zt1573k")
                                varin=zt1573k
                        end select
                case (2) ! 1st stage smoothing file
                    read (1,*) site_sample,age,varin
            end select
            if (age.le.begyr .and. age.ge.endyr .and. varin.ne.varmiss) then
                i=i+1
                xsite(i,jsite)=age !+50.0d0 !###################  b2k
                ysite(i,jsite)=varin        
                !write (*,*) i,age,varin
                ii=(age-xtarg(1))/targstep + 1
                if (ii.gt.0 .and. ii.le.ntarg) ndec(ii,jsite)=1
                ! write (10,*) age,varin,ii,jsite,ndec(ii,jsite)
            end if
        end do
        nrecs(jsite)=i
        close(1)
        
        !write (10,'("j,jsite,idsite,nrecs,site_num_char:",4i5,1x,a4)') j,jsite,idsite(jsite),nrecs(jsite),site_num_char
        !write (*,'("j,jsite,idsite,nrecs,site_num_char:",4i5,1x,a4)') j,jsite,idsite(jsite),nrecs(jsite),site_num_char
        !write (10,'(i4,1x,3000i1)') jsite,(ndec(i,jsite),i=1,ntarg)
        !write (*,'(i4,1x,3000i1)') jsite,(ndec(i,jsite),i=1,ntarg)

    end if
    go to 101
    
100 continue
!write (*,'(a)') "file not found"

101 continue

end do
nsites=jsite

! bootstrap sampling and fitting

yfit_reps=0.0d0; nsel=0
!nreps=20

!write (10,'(a)') "i,age,yfit"
do k=1,nreps

    jmax=-99999; jmin=99999
    ii=0
    do j=1,nsites

        ! select a site at random
        randval=rand(0)
        jsel(j,k)=int(randval*sngl(nsites))+1
        nsel(jsel(j,k))=nsel(jsel(j,k))+1
        if (jmax.lt.jsel(j,k)) jmax=jsel(j,k)
        if (jmin.gt.jsel(j,k)) jmin=jsel(j,k)
        
        jsel(j,k)=j !############## non-random selection
       
        ! concatenate records
        if (nrecs(jsel(j,k)).gt.1) then
            do i=1,nrecs(jsel(j,k))
                ii=ii+1
                xin(ii)=xsite(i,jsel(j,k))
                yin(ii)=ysite(i,jsel(j,k))
                !write (2,'(4i6,2f14.6)') ii,j,idsite(jsel(j,k)),i,xin(ii),yin(ii)
            end do
        end if
    end do
    npts=ii
    
    write (*,'(i5,\)') k,npts,ntarg
    yfit2=0.0d0; yfitse=0.0d0; fit_cu95=0.0d0; fit_cl95=0.0d0; npfit=0
    call lowess_curve(npts,xin,yin,ntarg,xtarg,wintype,param2,minpts,order,nrobust,yfit2,yfitse,ypredse,npfit,xspan)
    yfit1=0.0d0; yfitse=0.0d0; fit_cu95=0.0d0; fit_cl95=0.0d0; npfit=0
    call lowess_curve(npts,xin,yin,ntarg,xtarg,wintype,param1,minpts,order,nrobust,yfit1,yfitse,ypredse,npfit,xspan)
    do i=1,ntarg
        write (10,'(i5,",",f12.2,",",4f10.4)') i,xtarg(i),yfit1(i),yfit2(i),yfit1(i)-yfit2(i)
        yinsea(i)=yfit1(i)-yfit2(i)
        xinsea(i)=xtarg(i)
    end do
    
    
    ! save fitted values
    do i=1,ntarg
        yfit_reps(i,k)=yfit1(i)
    end do
       
    !write (10,*) k,jmin,jmax
    !write (10,'(20i4)') (jsel(j,k),j=1,nsites)  
    
end do
write (*,*) " "

! SEA
call sea(ntarg,xinsea,yinsea,nseatarg,seatarg,sea_hw,nevents,events,nseareps,sea_begage,sea_endage, &
    sea50,sea25,sea75,searep_50,searep_cl95,searep_cu95,np)

    
go to 500     

200 continue

! one more fit to get standard (unresampled) values
ii=0
do j=1,nsites
    ! concatenate records
    if (nrecs(j).gt.1) then
        do i=1,nrecs(j)
            ii=ii+1
            xin(ii)=xsite(i,j)
            yin(ii)=ysite(i,j)
            !write (2,'(4i6,2f14.6)') ii,j,idsite(j),i,xin(ii),yin(ii)
        end do
    end if
end do
npts=ii
    
write (*,*) npts,ntarg
yfit1=0.0d0; yfitse=0.0d0; fit_cu95=0.0d0; fit_cl95=0.0d0; npfit=0
call lowess_curve(npts,xin,yin,ntarg,xtarg,wintype,param1,minpts,order,nrobust,yfit1,yfitse,ypredse,npfit,xspan)

! get bootstrap estimates

ncl95=int(sngl(nreps)*0.025)
if (ncl95.le.0) ncl95=1
ncu95=int(sngl(nreps)*0.975)
if (ncu95.ge.nreps .or. ncu95.le.0) ncu95=nreps
n50=int(sngl(nreps)/2.0)
if (n50.ge.nreps .or. n50.le.0) n50=nreps
write (*,*) ncl95,ncu95,n50

yfit_boot=0.0d0; yfit_boot_stdev=0.0d0; yfit_boot_se=0.0d0; yfit_boot_cu95=0.0d0; yfit_boot_cl95=0.0d0
do i=1,ntarg
    do k=1,nreps
        yfit_boot(i)=yfit_boot(i)+yfit_reps(i,k)
    end do
    yfit_boot(i)=yfit_boot(i)/dble(nreps)
    !write (*,*) i,yfit_boot(i)
    do k=1,nreps
        yfit_boot_stdev(i)=yfit_boot_stdev(i)+(yfit_reps(i,k)-yfit_boot(i))*(yfit_reps(i,k)-yfit_boot(i))
        !write (*,*) i,k,yfit_reps(i,k),yfit_boot_stdev(i)
    end do
    !write (*,*) i,yfit_boot_stdev(i)
    yfit_boot_stdev(i)=dsqrt(yfit_boot_stdev(i)/dble(nreps-1))
    !write (*,*) i,yfit_boot_stdev(i)
    yfit_boot_se(i)=yfit_boot_stdev(i)/dsqrt(dble(nreps))
    temp(:)=yfit_reps(i,:)
    call sortx(nreps,temp,sorttemp)
    yfit_boot_cu95(i)=sorttemp(ncu95)
    yfit_boot_cl95(i)=sorttemp(ncl95)
    yfit_boot_median(i)=sorttemp(n50)
    
    !write (10,'(i4,1x,100i1)') i,(ndec(i,j),j=1,nsites)
    do j=1,nsites
        ndec_tot(i)=ndec_tot(i)+ndec(i,j)
        ! write (10,*) i,j,ndec_tot(i),ndec(i,j),idsite(j)
    end do
    
    ! replace Nan's 
    if (isnan(yfit1(i))) then 
        yfit1(i)=varmiss
        yfitse(i)=varmiss
        fit_cu95(i)=varmiss
        fit_cl95(i)=varmiss
    end if
    if (isnan(yfit_boot(i)))        yfit_boot(i)=varmiss
    if (isnan(yfit_boot_median(i))) yfit_boot_median(i)=varmiss
    if (isnan(yfit_boot_se(i)))     yfit_boot_se(i)=varmiss
    if (isnan(yfit_boot_cu95(i)))   yfit_boot_cu95(i)=varmiss
    if (isnan(yfit_boot_cl95(i)))   yfit_boot_cl95(i)=varmiss

!    write (5,'(f10.2,4f14.6,i6,5f14.6,i6)') & 
!        xtarg(i),yfit1(i),yfitse(i),fit_cu95(i),fit_cl95(i),npfit(i), &
!        yfit_boot(i),yfit_boot_median(i),yfit_boot_se(i),yfit_boot_cu95(i),yfit_boot_cl95(i),ndec_tot(i)
    write (7,'(f10.2,4(",",f14.6),", ",i8,5(",",f14.6),","i6,",",f10.2)') & 
        xtarg(i),yfit1(i),yfitse(i),fit_cu95(i),fit_cl95(i),npfit(i), &
        yfit_boot(i),yfit_boot_median(i),yfit_boot_se(i),yfit_boot_cu95(i),yfit_boot_cl95(i),ndec_tot(i),xspan(i)
    !write (10,*) i,xtarg(i),npfit(i)
    
end do

500 continue

do i=1,nseatarg
    write (7,'(f10.2,6(",",f10.4),",",i6)') seatarg(i),sea50(i),sea25(i),sea75(i),searep_50(i),searep_cl95(i),searep_cu95(i),np(i)
end do

write (*,*) " "

!write (6,'("""",a24,"; bootstrap estimates param=",f5.1,"; wintype=",a1,"; order=",i1,"; nrobust=",i1,"""")') &
!    trim(adjustl(lowfile)),param,wintype,order,nrobust

!do j=1,nsites
!    write (10,*) j,nsel(j)
!end do

!do i=1,ntarg
!    write (11,'(i5,f10.1,200f8.4)') i,xtarg(i),(yfit_reps(i,k),k=1,50)
!end do

close(7); close(8) !; close(10); close(11)

end do
    
end


function int_to_string(inum)

	implicit none
	character(32)	:: int_to_string
	character(32)	:: buffer, str
	integer			:: inum

	write (buffer,*) inum
	read (buffer,*) str

	int_to_string=trim(adjustl(str))

end function int_to_string


function int_to_string2(inum,numlen)

	implicit none
	character(32)	:: int_to_string,int_to_string2
	character(32)	:: buffer, str
	character(8)	:: ifmt,iedit
	integer			:: inum,numlen

	iedit=int_to_string(numlen)
	ifmt="(i"//trim(adjustl(iedit))//"."//trim(adjustl(iedit))//")"

	write (buffer,ifmt) inum
	read (buffer,*) str

	int_to_string2=trim(adjustl(str))

end function int_to_string2

