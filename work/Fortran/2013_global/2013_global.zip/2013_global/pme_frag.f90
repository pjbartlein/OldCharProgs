! Lv based on eqn 8 of Henderson-Sellers (1984, QJRMS)
! tmp2m in K
! precip rates in m s-1 
! lhtflx in W m-2
! pme and evap in mm d-1

evap = lhtflx*(1.0/(1.91846e6*tmp2m/(tmp2m-33.91))**2))*86400.0 

pme = (convective_precip_rate + large_scale_precip_rate)*1000.0*86400.0 &
    	- lhtflx*(1.0/(1.91846e6*tmp2m/(tmp2m-33.91))**2))*86400.0 

