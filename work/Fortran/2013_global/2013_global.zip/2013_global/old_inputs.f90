
!infilepath="e:\Projects\igbpfire\hstick\tseries\ipcc_ch6\source\"
!outfilepath="e:\Projects\igbpfire\hstick\tseries\ipcc_ch6\source\"
!infile= "fig6.10b_ave_b.csv"
!outfile="fig6.10b_ave_b_low50_boot.csv"

!infilepath="e:\Projects\paleovar\data\Cariaco\"
!outfilepath="e:\Projects\paleovar\data\Cariaco\"
!infile= "cariaco_ti.csv"
!outfile="cariaco_ti_500_boot.csv"

!infilepath="e:\Projects\igbpfire\hstick\tseries\ipcc_ch6\"
!outfilepath="e:\Projects\igbpfire\hstick\tseries\ipcc_ch6\"
!infile= "fig610_maxover.csv"
!outfile="fig610_maxover_low50_boot.csv"

!infilepath="e:\Projects\igbpfire\hstick\figs\fig01\"
!outfilepath="e:\Projects\igbpfire\hstick\figs\fig01\"
!infile= "mj2003sh.csv"
!outfile="mj2003sh_low50_boot.csv"

!infilepath="e:\Projects\igbpfire\hstick\figs\fig_suppl\"
!outfilepath="e:\Projects\igbpfire\hstick\figs\fig_suppl\"
!outfilepath="e:\Projects\GPWG\projects\wus\figs\"
!infile= "jm4a_wus.csv"
!outfile="jm4a_wus_low_boot_100.csv"

!infilepath="e:\Projects\igbpfire\charsum\data\current_hs6\files\"
!outfilepath="e:\Projects\igbpfire\charsum\data\current_hs6\files\"
!infile= "ferretti.csv"
!outfile="ferretti_low_boot.csv"

!infilepath="e:\Projects\igbpfire\hstick\tseries\jonesmann\"
!outfilepath="e:\Projects\igbpfire\hstick\tseries\jonesmann\"
!infile= "jm_sh.csv"
!outfile="jm_sh_low_boot.csv"

!variable="tmp"; region="WNA"; atype="mxn"
!infilepath="e:\Projects\igbpfire\hstick\data\ccsm\"
!outfilepath="e:\Projects\igbpfire\hstick\data\ccsm\"
!infile= "land_"//trim(adjustl(variable))//"_"//trim(adjustl(region))//"_"//trim(adjustl(atype))//"_anm.dat"
!outfile="land_"//trim(adjustl(variable))//"_"//trim(adjustl(region))//"_"//trim(adjustl(atype))//"_anm_low100_boot.csv"
!write (*,*) infile

!infilepath="e:\Projects\igbpfire\hstick\data\ccsm\"
!outfilepath="e:\Projects\igbpfire\hstick\data\ccsm\"
!infile= "VolcanicForcing_Global.dat"
!outfile="VF_low_boot.csv"

!infilepath="e:\Projects\igbpfire\hstick\tseries\jonesmann\source\"
!outfilepath="e:\Projects\igbpfire\hstick\tseries\jonesmann\source\"
!infile= "mj2003gl.csv"
!outfile="mj2003gl_low_boot.csv"

!infilepath="e:\Projects\igbpfire\hstick\tseries\samer_ice\"
!outfilepath="e:\Projects\igbpfire\hstick\tseries\samer_ice\"
!infile= "q83o18.csv"
!outfile="q83o18_100.csv"

!infilepath="e:\Projects\igbpfire\hstick\tseries\misc\"
!outfilepath="e:\Projects\igbpfire\hstick\tseries\misc\"
!infile= "gisp2_d18O_20.csv"
!outfile="gisp2_d18O_100_boot.csv"

!infilepath="e:\Projects\paleovar\data\EDC\"
!outfilepath=infilepath
!infile= "edc3temp2007.csv"
!outfile="edc3temp2007_400_boot.csv"

!infilepath="e:\Projects\paleovar\data\NGRIP\"
!outfilepath=infilepath
!infile= "NGRIP_WC.csv"
!outfile="NGRIP_WC_200.csv"

!infilepath="e:\Projects\paleovar\data\EDC\"
!outfilepath=infilepath
!infile= "edc3temp2007.csv"
!outfile="edc3temp2007_1000_boot.csv"

!infilepath="e:\Projects\GPWG\work\global\figs\controls\"
!outfilepath=infilepath
!infile="ngrip-gicc05-60ka-20yr.csv"
!outfile="ngrip-gicc05-60ka-20yr_boot_500.csv"

!infilepath="e:\Projects\paleovar\data\EDC\"
!outfilepath=infilepath
!infile="edc-ch4-2008.csv"
!outfile="edc-ch4-2008_1000_boot.csv"

!infilepath="e:\Projects\paleovar\data\EDC\"
!outfilepath=infilepath
!infile="edc-ch4-2008.csv"
!outfile="edc-ch4-2008_500_boot.csv"

!infilepath="e:\Projects\paleovar\data\EDC\"
!outfilepath=infilepath
!infile="edc_dust2008.csv"
!outfile="edc_dust2008_1000_boot.csv"

!infilepath="e:\Projects\paleovar\data\GISP2\"
!outfilepath=infilepath
!infile="gisp2-ch4.csv"
!outfile="gisp2-ch4_250_boot.csv"

!infilepath="e:\Projects\paleovar\data\Quelccaya\"
!outfilepath=infilepath
!infile="qeulccaya_d18O.csv"
!outfile="qeulccaya_d18O_500_boot.csv"

infilepath="e:\Projects\GPWG\work\1492\aaves\"
outfilepath=infilepath
infile="aaves_tmp2.csv"
outfile="aaves_americas_tmp_150_boot.csv"
!outfile="aaves_nonamericas_tmp_150_boot.csv"

!infilepath="e:\Projects\GPWG\work\1492\data\"
!outfilepath=infilepath
!infile="allCO2_3k.csv"
!outfile="allCO2_3k_200_boot.csv"

!infilepath="e:\Projects\GPWG\work\1492\data\"
!outfilepath=infilepath
!infile="mm_ch4.csv"
!outfile="mm_ch4_150_boot.csv"

!infilepath="e:\Projects\GPWG\work\1492\data\"
!outfilepath=infilepath
!infile="all_c13C_CH4.csv"
!outfile="all_c13C_CH4_150_boot.csv"

!infilepath="e:\Projects\GPWG\work\global\tseries\Timm\"
!outfilepath=infilepath
!infile="SIM2b1_bands.csv"
!outfile="SIM2b1_tmp_globe_200_lwr.csv"