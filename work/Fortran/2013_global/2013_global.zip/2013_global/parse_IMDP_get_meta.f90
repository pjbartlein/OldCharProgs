program parse_IMPD_get_meta

implicit none

integer(4), parameter  :: maxlines = 3000, maxchars = 640, max_vars = 32
character(len=*), parameter :: skipchars = "123456789"//achar(9)//achar(32)
character(256)      :: txt_file_name, txt_file, meta_file_name, site_csv_name, site_data_name, out_name, varnames_file, meta_file2
character(1024)     :: txt_file_path, work_file_path, out_file_path, data_file_header
character(1)        :: dum1
character(2)        :: dum2
character(32)       :: cvar(max_vars)
character(512)      :: continent, file_name, site_name, place, lat_str, lon_str, elev_str
character(640)      :: string_buffer, txt_lines(maxlines), txt_line_pad, out_txt_line
character(128)      :: var_name(max_vars)
character(640)      :: quote

real(8)             :: longitude, latitude, elevation
integer(4)          :: file_num, nfiles, istat, nlines, var_num(max_vars)
integer(4)          :: i, j, k, idx, str_len, line_number, nvars, i1, i2, i3, ll, nobs
logical             :: found_variables, vartype1, vartype2, vartype3


!allocate(txt_lines(maxlines, maxchars))

txt_file_path = "e:\Projects\GCD\GCD_Data\IMPD\charcoal\"
txt_file_name = "IMPD_txtfiles.txt"

work_file_path = "e:\Projects\GCD\GCD_Data\IMPD\work01\"
meta_file_name = "meta_data_02.txt"
site_csv_name = "IMPD_sites_02.csv"
varnames_file = "IMPD_varnames_02.txt"
meta_file2 = "IMPD_meta_data_02.txt"

out_file_path = "e:\Projects\GCD\GCD_Data\IMPD\work01\IMPD_data\"

open (1, file = trim(work_file_path)//trim(txt_file_name))
open (3, file = trim(work_file_path)//trim(meta_file_name))
open (4, file = trim(work_file_path)//trim(site_csv_name))
write (4, '(a)') "IMPD_file, site_name, longitude_dd, latitude_dd, elevation_m, nsamp, continent, location"
open (6, file = trim(work_file_path)//trim(varnames_file))
open (7, file = trim(work_file_path)//trim(meta_file2))

! loop over files
nfiles = 0
file_loop: do
    ! read a filename
    read (1,'(a)', iostat = istat) txt_file
    if (istat .ne. 0) exit file_loop
    nfiles = nfiles + 1
    write (3, '(a)') trim(txt_file)
    write (7, '(a)') trim(quote(txt_file))
    write (*, '(a)') trim(txt_file)
    idx = index(txt_file, "\")
    write (string_buffer, '(a)') txt_file(1:(idx-1))
    read (string_buffer, '(a)') continent
    write (string_buffer, '(a)') txt_file((idx + 1):len_trim(txt_file))
    read (string_buffer, '(a)') file_name
    write (3, '(a)') trim(file_name)
    write (3, '("continent: ", a)') trim(continent)
    write (7, '(a)') trim(quote(file_name))
    write (7, '(a)') trim(quote(continent))
    
    
    ! open and read the IMPD file
    open (2, file = trim(txt_file_path)//trim(txt_file))
    i = 0
    do 
        i = i + 1
        read (2, '(a, a)', iostat = istat) txt_lines(i)
        !write (*, '(a)') txt_lines(i)(1:120)
        if (istat .ne. 0) exit 
    end do 
    nlines = i - 1
    write (3,'("nlines: ", i4)') nlines
    write (7,'(i4)') nlines
    close(2)
    
    ! out file name
    out_name = file_name(1:(len_trim(file_name)-4))
    site_csv_name = trim(out_file_path)//trim(out_name)//"_data.csv"
    open (5, file = trim(site_csv_name))
    
    ! check for blank lines at bottom of file
    if (len_trim(txt_lines(nlines)) .eq. 0) nlines = nlines - 1
    
    ! loop over the file, looking for different things  
    
    ! metadata
    
    ! find "Site_Name" or "Site name"    
    do i = 1, nlines
        if (index(txt_lines(i), "Site_Name") .ne. 0) exit 
        if (index(txt_lines(i), "Site name") .ne. 0) exit 
    end do 
    idx = index(txt_lines(i), ":")
    site_name = adjustl(txt_lines(i)((idx+1):256))
    str_len = len_trim(adjustl(site_name)) 
    ! remove commas
    do i = 1, str_len 
        if (site_name(i:i) .eq. ",") site_name(i:i) = " "
    end do
    write (3, '("site_name: ",a)') trim(site_name)
    write (7, '(a)') trim(quote(site_name))
    
    ! place
    place = ""
    do i = 1, nlines
        if (index(txt_lines(i), "Country") .ne. 0) exit 
        if (index(txt_lines(i), "Place") .ne. 0) exit 
    end do
    idx = index(txt_lines(i), ":")
    if (idx .ne. 0) place = adjustl(txt_lines(i)((idx+1):256))
    write (3, '("place/place: ",a)') trim(place)
    write (7, '(a)') trim(quote(place))
    ! latitude string
    lat_str = ""
    do i = 1, nlines
        if (index(txt_lines(i), "Latitude:") .ne. 0) exit 
    end do
    idx = index(txt_lines(i), ":")
    if (idx .ne. 0) lat_str = adjustl(txt_lines(i)((idx+1):(idx+20)))
    write (3, '("lat_str: ",a)') trim(lat_str)
    call ll_str_to_real(lat_str, latitude)
    write (3, '("latitude:  ", f13.8)') latitude
    write (7, '(f13.8)') latitude
    ! longitude string
    lon_str = ""
    do i = 1, nlines
        if (index(txt_lines(i), "Longitude:") .ne. 0) exit 
    end do
    idx = index(txt_lines(i), ":")
    if (idx .ne. 0) lon_str = adjustl(txt_lines(i)((idx+1):(idx+20)))
    write (3, '("lon_str: ",a)') trim(lon_str)
    call ll_str_to_real(lon_str, longitude)
    write (3, '("longitude: ", f13.8)') longitude
    write (7, '(f13.8)') longitude
    
    ! find "Elevation:" or "Elevation (m)"    
    do i = 1, nlines
        if (index(txt_lines(i), "Elevation") .ne. 0) exit 
        if (index(txt_lines(i), "Elevation (m)") .ne. 0) exit 
    end do 
    idx = index(txt_lines(i), ":")
    elev_str = adjustl(txt_lines(i)((idx+1):256))
    if (len_trim(elev_str) .eq. 0) elev_str = "-9999.0"
    write (3, '("elevation: ",a)') trim(elev_str)
    write (string_buffer, '(a)') trim(elev_str)
    read (string_buffer, *) elevation
    write (7, '(f5.0)') elevation
    
    ! data 
    
    found_variables = .false.; vartype1 = .false.; vartype2 = .false.; vartype3 = .false.
    
    ! look for data 
    
    ! type 1 indicator: blank first column
    do i = 1, nlines
        if (txt_lines(i)(1:1) .eq. achar(32)) exit
        if (txt_lines(i)(1:1) .eq. achar(9)) exit
    end do
    if (i .lt. nlines) then
        found_variables = .true.; vartype1 = .true.
        write (3, '(" type 1 variables found at line ", i4)') i
        i1 = i
    end if
    
    ! type 2 indicator: "##"
    do i = 1, nlines
        if (txt_lines(i)(1:2) .eq. "##") exit 
    end do
    if (i .lt. nlines) then
        found_variables = .true.; vartype2 = .true.
        write (3, '(" type 2 variables found at line ", i4)') i
        i2 = i
    end if
    
    if (found_variables .eq. .false.) then ! look for a third type
        ! type 3 indicator: not "#"
        do i = 1, nlines
            if (txt_lines(i)(1:1) .ne. "#") exit 
        end do
        if (i .lt. nlines) then
            found_variables = .true.; vartype3 = .true.
            write (3, '(" type 3 variables found at line ", i4)') i
            i3 = i
        end if
    end if
    
    if (.not. found_variables) then
        write (3, '(" no variables were found")') 
    end if
    
    if (vartype1 .and. vartype2) vartype1 = .false. ! probably Chron
    if (vartype2 .and. vartype3) vartype3 = .false. ! probably data
    
    ! type 1
    if (vartype1) then   
        do j = 1, len_trim(txt_lines(i1))
            if (txt_lines(i1)(j:j) .eq. achar(9)) txt_lines(i1)(j:j) = " "
        end do
        ! write (3, '(a)') trim(txt_lines(i1)(1:128))
        nvars = 0
        do j = 1, max_vars
            !write (3, *) j, nvars, trim(txt_lines(i1 + j - 1))
            !write (3, '(a1)') txt_lines(i1 + j - 1)(1:1)
            if ((txt_lines(i1 + j - 1)(1:1) .eq. " ") .or. (txt_lines(i1 + j - 1)(1:1) .eq. achar(9))) then
                call underscore(txt_lines(i1 + j - 1), txt_line_pad)
                nvars = nvars + 1 
                write (string_buffer, *) trim(txt_line_pad)
                read (string_buffer, *) var_num(j), var_name(j)
            else
                exit
            end if
        end do
        write (3, '("number of variables: ", i3)') nvars
        write (7, '(i3)') nvars
        do j = 1, nvars
            write (3, '(i4, 1x, a)') var_num(j), trim(var_name(j))
            write (7, '(i4, 1x, a)') var_num(j), trim(quote(var_name(j)))
        end do
            
        ! data file header
        data_file_header = ""
        do j = 1, nvars - 1
            data_file_header = trim(data_file_header)//trim(var_name(j))//","
            write (6, '(a38, 1x, i3, 1x, a80)') adjustl(txt_file), var_num(j),adjustl(var_name(j))
        end do
        data_file_header = trim(data_file_header)//var_name(nvars)
        write (5, '(a)') trim(data_file_header)
        
        ! read and write data
        nobs = 0
        do i = (i1 + nvars), nlines
            !write (3, '(i3, 1x, a)') i, trim(txt_lines(i))
            write (5, '(a)') trim(txt_lines(i))
            nobs = nobs + 1
        end do
        close(5)
        write (3, '("number of observations: ", i5)') nobs
        write (7, '(i5)') nobs
    end if     
    
    if (vartype2) then
        do j = 1, len_trim(txt_lines(i2))
            if (txt_lines(i2)(j:j) .eq. achar(9)) txt_lines(i2)(j:j) = " "
        end do
        ! write (3, '(a)') trim(txt_lines(i2)(1:128))
        nvars = 0
        do j = 1, max_vars
            ! write (3, *) j, nvars, trim(txt_lines(i2 + j - 1))
            if ((txt_lines(i2 + j - 1)(4:4) .ne. "-") .and. (txt_lines(i2+ j - 1)(4:4) .ne. achar(32))) then
                nvars = nvars + 1
                write (string_buffer, '(a)') trim(txt_lines(i2 + j - 1)(3:maxchars))
                read (string_buffer, *) var_name(j)
                var_num(j) = nvars
            else
                exit
            end if
        end do
        write (3, '("number of variables: ", i3)') nvars
        write (7, '(i3)') nvars
        do j = 1, nvars
            write (3, '(i4, 1x, a)') var_num(j), trim(var_name(j))
            write (7, '(i4, 1x, a)') var_num(j), trim(quote(var_name(j)))
        end do
        
        ! data file header
        data_file_header = ""
        do j = 1, nvars - 1
            data_file_header = trim(data_file_header)//trim(var_name(j))//","
            write (6, '(a38, 1x, i3, 1x, a80)') adjustl(txt_file), var_num(j),adjustl(var_name(j))
        end do
        data_file_header = trim(data_file_header)//var_name(nvars)
        write (5, '(a)') trim(data_file_header)
        
        ! read and write data
        nobs = 0
        do i = (i2 + nvars + 6), nlines
            !write (3, '(i3, 1x, a)') i, trim(txt_lines(i))
            write (string_buffer, '(a)') trim(txt_lines(i))
            read (string_buffer, *) (cvar(j), j = 1, nvars)
            write (5, '(32(a, :, ", "))') (trim(cvar(j)), j = 1, nvars)
            nobs = nobs + 1
        end do
        close(5)
        write (3, '("number of observations: ", i5)') nobs
        write (7, '(i5)') nobs      
    end if
    
    if (vartype3) then
        do j = 1, len_trim(txt_lines(i3))
            if (txt_lines(i3)(j:j) .eq. achar(9)) txt_lines(i3)(j:j) = " "
        end do
        !write (3, '(a)') trim(txt_lines(i3)(1:128))
        nvars = 0
        do j = 1, max_vars
            !write (3, *) j, nvars, trim(txt_lines(i3 + j - 1))
            if (index(skipchars, txt_lines(i3 + j - 1)(1:1)) .eq. 0) then
                exit
            else
                nvars = nvars + 1
                write (string_buffer, '(a)') trim(txt_lines(i3 + j - 1))
                read (string_buffer, *) var_num(j), var_name(j)
                var_num(j) = nvars
            end if
        end do
        write (3, '("number of variables: ", i3)') nvars
        write (7, '(i3)') nvars
        do j = 1, nvars
            write (3, '(i4, 1x, a)') var_num(j), trim(var_name(j))
            write (7, '(i4, 1x, a)') var_num(j), trim(quote(var_name(j)))
        end do
        
        ! data file header
        data_file_header = ""
        do j = 1, nvars - 1
            data_file_header = trim(data_file_header)//trim(var_name(j))//","
            write (6, '(a38, 1x, i3, 1x, a80)') adjustl(txt_file), var_num(j),adjustl(var_name(j))
        end do
        data_file_header = trim(data_file_header)//var_name(nvars)
        write (5, '(a)') trim(data_file_header)
        
        ! read and write data
        nobs = 0
        do i = (i2 + nvars + 1), nlines
            !write (3, '(i3, 1x, a)') i, trim(txt_lines(i))
            write (string_buffer, '(a)') trim(txt_lines(i))
            read (string_buffer, *) (cvar(j), j = 1, nvars)
            write (5, '(32(a, :, ", "))') (trim(cvar(j)), j = 1, nvars)
            nobs = nobs + 1
        end do
        close(5)
        write (3, '("number of observations: ", i5)') nobs
        write (7, '(i5)') nobs
    end if

    
    write (3,'(a)') " "
    write (7,'(a)') " "
    
    !site_name = '"'//trim(site_name)//'"'
    !place = '"'//trim(place)//'"'
    write (4, '(2(a, ", "), 2(f13.8, ", "), f6.0, ", ", i5, 2(", ", a))') &
         trim(file_name), trim(site_name), longitude, latitude, elevation, nobs, trim(continent), trim(place)
    
end do file_loop

write (*, '("nfiles = ", i4)') nfiles
close(1); close(3); close(4)

end

subroutine ll_str_to_real(ll_str, ll_real)
    
    implicit none
    
    character(15)   :: ll_str, string_buffer
    
    real(8)         :: ll_real, deg, min, sec     
    
    integer(4)      :: i, idx, istat, str_len 
    logical         :: isN, isS, isE, isW
    
    ll_str = trim(adjustl(ll_str))
    !write (3, '(a)') ll_str
    
    ! check for N, S, E, or W attached
    isN = .false.; isS = .false.; isE = .false.; isW = .false.
    idx = index(ll_str, "N")
    if (idx .ne. 0) then
        isN = .true.
        ll_str(idx:idx) = " "
    end if
    idx = index(ll_str, "S")
    if (idx .ne. 0) then
        isS = .true.
        ll_str(idx:idx) = " "
    end if 
    idx = index(ll_str, "E")
    if (idx .ne. 0) then
        isE = .true.
        ll_str(idx:idx) = " "
    end if
    idx = index(ll_str, "W")
    if (idx .ne. 0) then
        isW = .true.
        ll_str(idx:idx) = " "
    end if

    !write (3,*) isN, isS, isE, isW
    
    ! check whether it's already a real number
    write (string_buffer, *) ll_str
    read (string_buffer, *, iostat = istat) ll_real
    
    if (istat .eq. 0) then
        ! it's a real number, but may have N, S, E, or W attached
        ! make sure S and W are negative
        if (isS) ll_real = -1.0d0 * dabs(ll_real)
        if (isW) ll_real = -1.0d0 * dabs(ll_real)
        return
    else
        ! it's not a real number
        str_len = len_trim(adjustl(ll_str))
        !write (3, '("      str_len: ", i2)') str_len
        
        ! remove "."'s
        do i = 1, str_len 
            if (ll_str(i:i) .eq. ".") ll_str(i:i) = " "
        end do
        !write (3, '(a)') ll_str   
        
        write (string_buffer, *) ll_str
        read(string_buffer, *) deg, min, sec
        ll_real = deg + (min / 60.0d0) + (sec / 3600.0d0)
        if (isS) ll_real = -1.0d0 * dabs(ll_real)
        if (isW) ll_real = -1.0d0 * dabs(ll_real)
    end if
    
end subroutine ll_str_to_real
    
subroutine underscore(txt_line, txt_line_pad)
    ! replaces blanks with underscores in text part of string
    ! also pads with quotes

    implicit none
    
    character(len=*), parameter :: skipchars = "0123456789"//achar(9)//achar(32)
    character(640)              :: txt_line, txt_line_pad
    
    integer(4)      :: length_txt_line, first_char   
    integer(4)      :: j, start_char
    
    txt_line_pad(1:640) = " "
    
    !write (3, '(a)') trim(txt_line)
    length_txt_line = len_trim(txt_line)
    !write (3, *) len_trim(txt_line), len(trim(txt_line))
    do j = 1, length_txt_line
        if (index(skipchars, txt_line(j:j)) .eq. 0) exit
    end do
    start_char = j
    !write (3, *) length_txt_line, start_char
    do j = start_char, length_txt_line
        if (txt_line(j:j) .eq. " ") txt_line(j:j) = "_"
        if (txt_line(j:j) .eq. ",") txt_line(j:j) = "_"
    end do
    
    ! pad with quotes
    txt_line_pad(1:(start_char - 1)) = txt_line(1:(start_char - 1))
    txt_line_pad(start_char:start_char) = '"'
    txt_line_pad((start_char + 1):length_txt_line + 1) = txt_line((start_char):(length_txt_line))
    txt_line_pad((length_txt_line + 2):length_txt_line + 2) = '"'
    
    !write (3, '(a)') txt_line_pad
    
end subroutine underscore
    
function quote(string)

	implicit none
	character(640)		:: quote
	character(len=*)	:: string
	character(1)        :: quotemark='"'

	quote=trim(quotemark//trim(adjustl(string))//quotemark)

end function quote