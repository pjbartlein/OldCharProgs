program slice_sum_v3
! summarizes transformed charcoal data for mapping -- GCDv3

use summarize_subs
use ifport

implicit none

integer,parameter   :: maxslice=100
integer(4)      :: site_sample_in,id_sample_in
real(4)         :: depth_in,age_in,var_in,varmnx_in,t_in,zt_in
real(4)         :: age(maxrec),quant(maxrec)
character(8)    :: site_num_label
character(4)    :: source_in

real(4)         :: qmiss,begbaseanm,endbaseanm
real(4)         :: lastyr,firstyr
real(4)         :: begslice(maxslice),midslice(maxslice),endslice(maxslice)
integer         :: tlabel(maxslice)
real(4)         :: qmeant(maxslice),qstdevt(maxslice),qmint(maxslice),qmaxt(maxslice),qrngt(maxslice),anm(maxslice)
real(4)         :: qpianm

integer         :: nin(maxslice)

real(4)         :: lat,lon,elev
character(72)   :: site_name
character(80)   :: header
character(256)  :: fmt,fmtstr
character(4)    :: site_num_char
character(32)   :: slicelabel(maxslice)

integer         :: i,j,k,ns,npts

character(256)  :: infile
character(256)  :: infofile,analname,sitefile,transpath,transfile,meanfile,anomfile,outpath,mappath,slicedeffile
character(256)  :: pltmeanfile,pltanomfile,pltsumfile,mxyfile,debugfile,cutfile

integer             :: pathlen
character(3)        :: drive
character(256)      :: dir,name,ext,file
logical             :: fileexists, direxists, fileresult

! read the info file
call get_command_argument(1,infofile)
open (99,file=trim(adjustl(infofile)))

read (99,*) analname
read (99,*) sitefile
read (99,*) transpath
read (99,*) transfile
read (99,*) outpath
read (99,*) mappath
read (99,*) slicedeffile
read (99,*) begbaseanm
read (99,*) endbaseanm

!sitefile="e:\Projects\GPWG\analysis\regions\v2n\v2n_austl.csv"
!transpath="e:\Projects\GPWG\analysis\csv_files\v2n\v2n_trans\"
!meanfile="e:\Projects\GPWG\analysis\output\v2n\v2n_summary\v2n_austl_means.csv"
!anomfile="e:\Projects\GPWG\analysis\output\v2n\v2n_summary\v2n_austl_anoms.csv"
!pltmeanfile="e:\Projects\GPWG\analysis\maps\v2n_austl\mean.dat"
!pltanomfile="e:\Projects\GPWG\analysis\maps\v2n_austl\anom.dat"
!pltsumfile="e:\Projects\GPWG\data\maps\work02\v2.5b_austl_sum.dat"
!mxyfile="e:\Projects\GPWG\data\maps\v2n_austl\v2.5b_austl_sum.mxy"
!debugfile="e:\Projects\GPWG\analysis\maps\v2n_austl\v2n_austl_debug.csv"
!cutfile="e:\Projects\GPWG\analysis\maps\v2n_austl\v2n_austl_cutpts.csv"

! check for existence of sitefile
inquire (file=sitefile, exist=fileexists)
if (.not. fileexists) stop "Sitefile does not exist, stopping..." 

! check for existence of transpath (.csv files)
pathlen=splitpathqq(transpath, drive, dir, name, ext)
inquire (directory=dir, exist=direxists)
if (.not. direxists) stop "Transformed files folder does not exist, or is specified wrong, stopping..."

! check for existence of outpath (.csv files)
pathlen=splitpathqq(outpath, drive, dir, name, ext)
inquire (directory=dir, exist=direxists)
if (.not. direxists) stop "Output file folder does not exist, or is specified wrong, stopping..."

! check for existence of mappath (.csv files)
pathlen=splitpathqq(mappath, drive, dir, name, ext)
inquire (directory=dir, exist=direxists)
if (.not. direxists) stop "Map folder does not exist, or is specified wrong, stopping..."

! check for existence of slice definition files
inquire (file=slicedeffile, exist=fileexists)
if (.not. fileexists) stop "Slice definition file does not exist, stopping..."
 
meanfile=trim(outpath)//trim(analname)//"_means.csv"        ; open (3,file=meanfile)
anomfile=trim(outpath)//trim(analname)//"_anoms.csv"        ; open (4,file=anomfile)
pltmeanfile=trim(mappath)//trim(analname)//"_means.csv"      ; open (5,file=pltmeanfile)
pltanomfile=trim(mappath)//trim(analname)//"_anoms.csv"      ; open (6,file=pltanomfile)
mxyfile=trim(mappath)//"slice.mxy"                          ; open (7,file=mxyfile)
pltsumfile=trim(mappath)//trim(analname)//"_sum.dat"        ; open (8,file=pltsumfile)
debugfile=trim(outpath)//trim(analname)//"_sum_debug.dat"   ; open (10,file=debugfile)
cutfile=trim(outpath)//trim(analname)//"_cutpts.csv"        ; open (11,file=cutfile)

write (*,'("analname:"/a80)') analname;         write (10,'("analname:"/a80)') analname
write (*,'("sitefile:"/a80)') sitefile;         write (10,'("sitefile:"/a80)') sitefile
write (*,'("transpath:"/a256)') transpath;       write (10,'("transpath:"/a256)') transpath
write (*,'("transfile:"/a80)') transfile;       write (10,'("sitefile:"/a80)') transfile
write (*,'("outpath:"/a256)') outpath;           write (10,'("outpath:"/a256)') outpath
write (*,'("mappath:"/a256)') mappath;           write (10,'("mappath:"/a256)') mappath
write (*,'("meanfile:"/a80)') meanfile;         write (10,'("meanfile:"/a80)') meanfile
write (*,'("anmfile:"/a80)') anomfile;          write (10,'("anmfile:"/a80)') anomfile
write (*,'("slicedeffile:"/a80)') slicedeffile; write (10,'("slicedeffile:"/a80)') slicedeffile
write (*,'("begbaseanm:"/f8.1)') begbaseanm;    write (10,'("begbaseanm:"/f8.1)') begbaseanm
write (*,'("endbaseanm:"/f8.1)') endbaseanm;    write (10,'("endbaseanm:"/f8.1)') endbaseanm

! read slice information
open (1,file=slicedeffile)
read (1,*) header

ns=0
do while (.not. eof(1))
    ns=ns+1
    read (1,*) k,midslice(ns),begslice(ns),endslice(ns),slicelabel(ns)
    slicelabel(k)='"'//trim(slicelabel(k))//'"'
    write (*,'(i4,3f10.2,1x,a32)') k,midslice(ns),begslice(ns),endslice(k),slicelabel(ns)
    write (10,'(i4,3f10.2,1x,a32)') k,midslice(ns),begslice(ns),endslice(k),slicelabel(ns)
end do
close(1)


!write (fmt,'(" (i4,",i2,"a4) ")') ns
!write (*,*) trim(fmt)
!write (*,fmt) 4,"xxxx"," yyy","  zz"

! write headers
write (fmt,'(" (""id_site,site_lat,site_lon,"",","",i2.2,"(a32,"",""),""sitename"")") ")') ns
write (*,*) fmt

write (3,fmt) (slicelabel(k),k=1,ns)
write (4,fmt) (slicelabel(k),k=1,ns)
write (5,fmt) (slicelabel(k),k=1,ns)
write (6,fmt) (slicelabel(k),k=1,ns)
!write (3,'("id_site, site_lat, site_lon, sitename",100(", ",a32))') (slicelabel(k),k=1,ns)
!write (4,'("id_site, site_lat, site_lon, sitename",100(", ",a32))') (slicelabel(k),k=1,ns)
!write (5,'("id_site, site_lat, site_lon, sitename",100(", ",a32))') (slicelabel(k),k=1,ns)
!write (6,'("id_site, site_lat, site_lon, sitename",100(", ",a32))') (slicelabel(k),k=1,ns)
write (11,'("Mean")')

qmiss=-9999.0       ! missing data code

! loop over sites
open (1,file=sitefile)
read (1,*) header

do while (.not. eof(1))
    read (1,*) j,lat,lon,elev,site_name
    write (*,'(i5,2f10.4,1x,f7.0,2x,a32)') j,lat,lon,elev,site_name
    write (10,'(i5,2f10.4,1x,f7.0,2x,a32)') j,lat,lon,elev,site_name

    site_num_char=int_to_string2(j,4)
    infile=trim(transpath)//trim(adjustl(site_num_char))//"_trans_"//trim(transfile)//".csv"
    write (10,'(a)') trim(infile)

    open (2,file=infile)
    
    i=0
    lastyr=-99999.0; firstyr=99999.0
    read (2,*) header
    do while (.not. eof(2))
        i=i+1
        ! site, site_sample, id_sample, est_age, depth, influx, influxmnx, tall, zt21k
        read (2,*) site_num_label,site_sample_in,id_sample_in,age_in,depth_in,var_in,varmnx_in, &
            t_in,zt_in      
        age(i)=age_in  
        quant(i)=zt_in ! ######
        if (age(i).gt.lastyr) lastyr=age(i)
        if (age(i).lt.firstyr) firstyr=age(i)
    end do
    npts=i
    close(2)
    write (*,'(2i5,2f9.1,1x,a32)') j,npts,lastyr,firstyr,site_name
    write (10,'(2i5,2f9.1,1x,a32)') j,npts,lastyr,firstyr,site_name
    
    ! loop over times
    
    do k=1,ns 
        ! basic statistics for an interval from transformed values
        call stats(npts,age,quant,qmiss,begslice(k),endslice(k),nin(k),qmeant(k),qstdevt(k),qmint(k),qmaxt(k),qrngt(k))       
        !write (*,*) k,ndata,nin(k),meant(k)
        !pause
    end do
        ! basic statistics for the anomaly base
        k=ns+1
        call stats(npts,age,quant,qmiss,begbaseanm,endbaseanm,nin(k),qmeant(k),qstdevt(k),qmint(k),qmaxt(k),qrngt(k))  
        write (*,*) begbaseanm,endbaseanm
        write (*,*) k,qmeant(k)     

        
    do k=1,ns
        anm(k)=qmiss
        if (qmeant(k).ne.qmiss .and.qmeant(42).ne.qmiss) then
            anm(k)=qmeant(k)-qmeant(42)
        end if
    end do    
    qpianm=anm(ns)
                
    ! rotate longitudes
    !!if (lon.le.0.0d0) lon=lon+360.0d0       
    !write (fmt,'(" (i5,2("","",f10.4),"",","",i2.2,"("","",f10.3),"","",a72)") ")') ns

    write (fmt,'(" (i5,2("","",f10.4),","",i2.2,"("","",f10.3),"","",a72)") ")') ns
    write (*,*) fmt  
    
    write (3,fmt) j,lat,lon,(qmeant(k),k=1,ns),(adjustl(site_name))
    write (4,fmt) j,lat,lon,(anm(k),k=1,ns),(adjustl(site_name))
    write (5,fmt) j,lat,lon,(qmeant(k),k=1,ns),(adjustl(site_name))
    write (6,fmt) j,lat,lon,(anm(k),k=1,ns),(adjustl(site_name))
    !write (3,'(i5,2(", ",f10.4),",",a32,100(", ",f10.3))') j,lat,lon,adjustl(site_name),(qmeant(k),k=1,ns)
    !write (4,'(i5,2(", ",f10.4),",",a32,100(", ",f10.3))') j,lat,lon,adjustl(site_name),(anm(k),k=1,ns)
    !write (5,'(i5,2(", ",f10.4),",",a32,100(", ",f10.3))') j,lat,lon,adjustl(site_name),(qmeant(k),k=1,ns)
    !write (6,'(i5,2(", ",f10.4),",",a32,100(", ",f10.3))') j,lat,lon,adjustl(site_name),(anm(k),k=1,ns)
    write (7,'(4f10.4)') lat,lon,lon,lat
    
    write (8,'(2f10.4,i5,7f10.3)') lat,lon,j,qmeant(42),qmeant(31),qmeant(1),anm(31),anm(1),qpianm
    
    do k=1,ns
        if (qmeant(k).ne.qmiss) then
            write (11,'(2f10.3)') qmeant(k)
        end if
    end do

end do

end


