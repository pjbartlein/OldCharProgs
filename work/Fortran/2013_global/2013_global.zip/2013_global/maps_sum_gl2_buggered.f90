program maps_sum_gl2
! maps of paleofire indicators

use psc_inf

implicit none

integer, parameter	:: maxpts=2000, maxsites=1000, maxtarg=4000, nvars=6
real(8)		    :: lat,lon,varin(maxtarg),var(nvars),vmiss
real(8)		    :: y(maxsites),x(maxsites)
real(4)         :: lwd1=1.0, lwd2=1.5, lwd3=2.0
integer(4)      :: ndots(nvars),site_num,ntarg

character(1)    :: dum
character(256)  :: version,transform,mapdate,dataset

character(8)    :: baseout1,baseout2,baseout3,baseout4,baseout5,baseout6
character(256)  :: infilename
character(256)  :: gratfile,framefile,coastfile,countryfile,polefile
character(256)  :: landfile1,landfile2
character(256)  :: icefile1,icefile2,icefile3,icefile4,icefile5
character(256)  :: legboxfile
character(256)  :: polyfile1,polyloc1,polyfile2,polyloc2,polyfile3,polyloc3
character(256)  :: colorfile1,colorfile11,colorfile12,colorfile21,colorfile22
character(256)  :: polyclrfile
character(80)   :: header
integer         :: nclr1

integer		    :: i,j,npts,ntree,nice,nvrs,nmask1,nmask2,nmask3,npclr

datapath="e:\Projects\GPWG\analysis\maps\v3d_global\"
!         e:\Projects\GPWG\analysis\maps\v3d_global\
!         e:\Projects\GPWG\analysis\maps\v3d_global\v3d_sum.dat

infilename="v3d_sum.dat"
datafile="map.dat"
locfile="map.mxy";

version="Database query:  v3d_query.txt -- 6 July 2013"
dataset="Dataset:  "//trim(infilename)
transform="Data treatment:  Box-Cox transformed, Z-Scores (200 to 21,000 cal yr BP base period)"
mapdate="6 July 2013"

vmiss=-9999.0
ntarg=422

! global maps
cornerfile="rob_00k.cnr "
gratfile="gl_grtxy.dat"; framefile="gl_frmxy.dat"; polefile="gl_polexy.dat"
coastfile="robwcl.dat"; countryfile="rcntry3.dat" !"robcntry.dat"
icefile1="rice00p.dat"; icefile2="rant00p.dat"; icefile3="rice06p.dat"; icefile4="rice21a.dat"; icefile5="rice21b.dat"
landfile1="rland06.dat"; landfile2="rland21.dat"
baseout1="gl00k"; baseout2="gl06k"; baseout3="gl21k"; baseout4="gl06kanm"; baseout5="gl21kanm"; baseout6="glpianm"
polyfile1="pice00.dat"; polyloc1="pice00.ply"; polyfile2="pice06.dat"; polyloc2="pice06.ply" 
polyfile3="pice21.dat"; polyloc3="pice21.ply"
polyclrfile="flag.clr"; npclr=2

! general things
mr=-1.0; mg=-1.0; mb=-1.0; fr=0.80; fg=0.80; fb=0.80; lwidth=0.5
mr2=-1.0; mg2=-1.0; mb2=-1.0; fr2=0.00; fg2=0.00; fb2=0.00; lwidth2=0.25
mr3=-1.0; mg3=-1.0; mb3=-1.0; fr3=0.80; fg3=0.80; fb3=0.80; lwidth3=-0.25
mr4=1.0; mg4=1.0; mb4=1.0; fr4=0.80; fg4=0.80; fb4=0.80; lwidth4=0.25
res=300; frwide=10.5; frhigh=5.8
xbpanel=0.00; ybpanel=0.00 
xblen=frwide; yblen=frhigh; xbmin=0.0; xbmax=1.0; ybmin=0.0; ybmax=1.0
xorig=0.25; yorig=0.5
xlen=9.8; ylen=4.9; xmin=-2.6662; xmax=2.6662; ymin=-1.3523 ; ymax=1.3523
xpanel=xorig; ypanel=yorig 

!colorfile1="zs03c.clr"; colorfile2="zs03ct.clr"; nclr=3
!colorfile11="zs03c1.clr"; colorfile12="zs03ct1.clr"; nclr1=1
!colorfile21="zs03c2.clr"; colorfile22="zs03ct2.clr"; nclr2=2

colorfile1="zs05c.clr"; colorfile2="zs05ct.clr"; nclr=5
colorfile11="zs05c1.clr"; colorfile12="zs05ct1.clr"; nclr1=1
colorfile21="zs05c2.clr"; colorfile22="zs05ct2.clr"; nclr2=4

!colorfile1="zs12c.clr"; colorfile2="zs12ct.clr"; nclr=12
!colorfile11="zs12c.clr"; colorfile12="zs12ct.clr"; nclr1=12
!colorfile21="zs12c.clr"; colorfile22="zs12ct.clr"; nclr2=12
 
legboxfile="legbox.dat"
xleg=xpanel+0.2; yleg=ypanel+0.6 ! nclr 3 and 5
!xleg=xpanel+0.2; yleg=ypanel+1.4 ! nclr 12
ltype="S"; lorient="V"; xlbox=10.0; ylbox=10.0

nmask1=29186; nmask2=29524; nmask3=48588

! project data points and count nonzero data values (ndots)
open (3,file=trim(datapath)//trim(infilename))
!read (3,*) header
open (4,file=trim(datapath)//trim(datafile))
open (5,file=trim(datapath)//trim(locfile))

ndots=0
i=0
do while(.not.eof(3))
    i=i+1
    !read (3,*) site_num,lat,lon,(varin(j),j=1,ntarg)
    !write (*,*) i,site_num,lat,lon
    read (3,*) lat,lon,(varin(j),j=1,ntarg)
    write (*,*) i,lat,lon
    
    var=vmiss
    var(1)=varin(011); var(2)=varin(122); var(3)=varin(422)
    if (var(2).ne.vmiss .and. var(1).ne.vmiss) var(4)=var(2)-var(1)
    if (var(3).ne.vmiss .and. var(1).ne.vmiss) var(5)=var(3)-var(1)
    if (varin(001).ne.vmiss .and. var(1).ne.vmiss) var(6)=varin(001)-var(1)
    
    do j=1,nvars
        if (var(j).ne.vmiss) ndots(j)=ndots(j)+1
    end do
    
    write (4,'(2f12.6,20f10.3)') lat,lon,(var(j),j=1,nvars)
    call robinson(lat,lon,x(i),y(i),1.0d0,0.0d0)
    write (5,'(2f12.6,2f10.4)') lat,lon,x(i),y(i)
end do
nobs=i
write (*,*) i
close(3); close(4); close(5)
write (*,*) (ndots(j),j=1,nvars)

! go to 60

title="Z-Scores of Transformed Charcoal Influx 200 to 700 cal yr BP (PreIndustrial)"
baseout=baseout1; j=1; isym=1 

infofile=trim(adjustl(baseout))//".inf"
call psc_init(infofile,'P',1,0.0,0.0,1.00,datapath)
call psc_panel (xbpanel,ybpanel,xblen,yblen,xbmin,xbmax,ybmin,ybmax)
r=0.0; g=0.0; b=0.0; bwidth=0.5
! call psc_box(r,g,b,bwidth)

call psc_panel (xpanel,ypanel,xlen,ylen,xmin,xmax,ymin,ymax)    
call psc_map (-1.0,-1.0,-1.0,0.80,0.80,0.80,lwd2,gratfile,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.80,0.80,0.80,lwd2,countryfile,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd1,coastfile,cornerfile)
call psc_poly (1,1,nmask1,polyfile1,npclr,polyclrfile,4,polyloc1)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd1,icefile1,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd1,icefile2,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd1,framefile,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd3,polefile,cornerfile)
call psc_symbol (isym,nvars,nobs,datafile,nclr1,colorfile11,locfile)
call psc_symbol (isym,nvars,nobs,datafile,nclr2,colorfile21,locfile)

!call psc_map ( 1.0, 1.0, 1.0,0.00,0.00,0.00,lwd1,legboxfile,cornerfile)
fmt=0.0; fsize=8.0; font="N"
call psc_legend (fmt,fsize,font,ltype,lorient,xleg,yleg,xlbox,ylbox,nclr,colorfile1)
            
! text	
fmt=0.0; fsize=16.0; font="H"
xtext=xorig; ytext=yorig+ylen+0.05; torient="H"; just="L"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,title)	
xtext=10.0; ytext=yorig+ylen+0.05; torient="H"; just="R"
text="n="//int_to_string(ndots(j))
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,text)	

fmt=0.0; fsize=10.0; font="H"
xtext=10.0; ytext=0.5; torient="H"; just="R"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,mapdate)	

fmt=0.0; fsize=8.0; font="H"
xtext=2.5; ytext=0.3; torient="H"; just="L"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,version)
xtext=xorig+xlen/2.0; ytext=0.3; torient="H"; just="L"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,dataset)
xtext=2.5; ytext=0.15; torient="H"; just="L"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,transform)

call psc_close
call psc_ps (datapath,infofile,pmappath)
pngfile=trim(baseout)//".png"; psfile=trim(baseout)//".ps"
call psc_png (datapath,pngfile,psfile,frwide,frhigh,res)
 
20 continue
! go to 60

title="Mid-Holocene Z-Scores of Transformed Charcoal Influx" ! (5750 to 6250 cal yr BP)"
!title="6 ka Z-Scores of Transformed Charcoal Influx" ! (5750 to 6250 cal yr BP)"
baseout=baseout2; j=2; isym=2 

infofile=trim(adjustl(baseout))//".inf"
call psc_init(infofile,'P',1,0.0,0.0,1.00,datapath)
call psc_panel (xbpanel,ybpanel,xblen,yblen,xbmin,xbmax,ybmin,ybmax)
! call psc_box(r,g,b,bwidth)

call psc_panel (xpanel,ypanel,xlen,ylen,xmin,xmax,ymin,ymax)    
call psc_map (-1.0,-1.0,-1.0,0.80,0.80,0.80,lwd2,gratfile,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.80,0.80,0.80,lwd2,countryfile,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.80,0.80,0.80,lwd2,coastfile,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd1,landfile1,cornerfile)
call psc_poly (1,1,nmask2,polyfile2,npclr,polyclrfile,4,polyloc2)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd1,icefile2,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd1,icefile3,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd1,framefile,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd3,polefile,cornerfile)

call psc_symbol (isym,nvars,nobs,datafile,nclr1,colorfile11,locfile)
call psc_symbol (isym,nvars,nobs,datafile,nclr2,colorfile21,locfile)
    
!call psc_map ( 1.0, 1.0, 1.0,0.00,0.00,0.00,lwd1,legboxfile,cornerfile)
fmt=0.0; fsize=8.0; font="N"
call psc_legend (fmt,fsize,font,ltype,lorient,xleg,yleg,xlbox,ylbox,nclr,colorfile1)
            
! text	
fmt=0.0; fsize=16.0; font="H"
xtext=xorig; ytext=yorig+ylen+0.05; torient="H"; just="L"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,title)	
xtext=10.0; ytext=yorig+ylen+0.05; torient="H"; just="R"
text="n="//int_to_string(ndots(j))
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,text)	

fmt=0.0; fsize=10.0; font="H"
xtext=10.0; ytext=0.5; torient="H"; just="R"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,mapdate)	

fmt=0.0; fsize=8.0; font="H"
xtext=2.5; ytext=0.3; torient="H"; just="L"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,version)
xtext=xorig+xlen/2.0; ytext=0.3; torient="H"; just="L"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,dataset)
xtext=2.5; ytext=0.15; torient="H"; just="L"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,transform)

call psc_close
call psc_ps (datapath,infofile,pmappath)
pngfile=trim(baseout)//".png"; psfile=trim(baseout)//".ps"
call psc_png (datapath,pngfile,psfile,frwide,frhigh,res)

30 continue
!go to 40

title="LGM Z-Scores of Transformed Charcoal Influx" ! (20,750 to 21,250 cal yr BP)"
!title="21 ka Z-Scores of Transformed Charcoal Influx" ! (20,750 to 21,250 cal yr BP)"
baseout=baseout3; j=3; isym=3

infofile=trim(adjustl(baseout))//".inf"
call psc_init(infofile,'P',1,0.0,0.0,1.00,datapath)
call psc_panel (xbpanel,ybpanel,xblen,yblen,xbmin,xbmax,ybmin,ybmax)
! call psc_box(r,g,b,bwidth)

call psc_panel (xpanel,ypanel,xlen,ylen,xmin,xmax,ymin,ymax)    
call psc_map (-1.0,-1.0,-1.0,0.80,0.80,0.80,lwd2,gratfile,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.80,0.80,0.80,lwd2,countryfile,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.80,0.80,0.80,lwd2,coastfile,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd1,landfile2,cornerfile)
call psc_poly (1,1,nmask3,polyfile3,npclr,polyclrfile,4,polyloc3)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd1,icefile4,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd1,icefile5,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd1,framefile,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd3,polefile,cornerfile)

call psc_symbol (isym,nvars,nobs,datafile,nclr1,colorfile11,locfile)
call psc_symbol (isym,nvars,nobs,datafile,nclr2,colorfile21,locfile)

!call psc_map ( 1.0, 1.0, 1.0,0.00,0.00,0.00,lwd1,legboxfile,cornerfile)
fmt=0.0; fsize=8.0; font="N"
call psc_legend (fmt,fsize,font,ltype,lorient,xleg,yleg,xlbox,ylbox,nclr,colorfile1)
            
! text	
fmt=0.0; fsize=16.0; font="H"
xtext=xorig; ytext=yorig+ylen+0.05; torient="H"; just="L"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,title)	
xtext=10.0; ytext=yorig+ylen+0.05; torient="H"; just="R"
text="n="//int_to_string(ndots(j))
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,text)	

fmt=0.0; fsize=10.0; font="H"
xtext=10.0; ytext=0.5; torient="H"; just="R"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,mapdate)	

fmt=0.0; fsize=8.0; font="H"
xtext=2.5; ytext=0.3; torient="H"; just="L"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,version)
xtext=xorig+xlen/2.0; ytext=0.3; torient="H"; just="L"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,dataset)
xtext=2.5; ytext=0.15; torient="H"; just="L"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,transform)

call psc_close
call psc_ps (datapath,infofile,pmappath)
pngfile=trim(baseout)//".png"; psfile=trim(baseout)//".ps"
call psc_png (datapath,pngfile,psfile,frwide,frhigh,res)

40 continue
!go to 50

title="Mid-Holocene - PI difference in Z-Scores of Transformed Charcoal Influx" ! (5750 to 6250 minus 200 to 700 cal yr BP)"
!title="6ka - PI difference in Z-Scores of Transformed Charcoal Influx" ! (5750 to 6250 minus 200 to 700 cal yr BP)"
baseout=baseout4; j=4; isym=4 

infofile=trim(adjustl(baseout))//".inf"
call psc_init(infofile,'P',1,0.0,0.0,1.00,datapath)
call psc_panel (xbpanel,ybpanel,xblen,yblen,xbmin,xbmax,ybmin,ybmax)
! call psc_box(r,g,b,bwidth)

call psc_panel (xpanel,ypanel,xlen,ylen,xmin,xmax,ymin,ymax)    
call psc_map (-1.0,-1.0,-1.0,0.80,0.80,0.80,lwd2,gratfile,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.80,0.80,0.80,lwd2,countryfile,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.80,0.80,0.80,lwd2,coastfile,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd1,landfile1,cornerfile)
call psc_poly (1,1,nmask2,polyfile2,npclr,polyclrfile,4,polyloc2)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd1,icefile2,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd1,icefile3,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd1,framefile,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd3,polefile,cornerfile)

call psc_symbol (isym,nvars,nobs,datafile,nclr1,colorfile12,locfile)
call psc_symbol (isym,nvars,nobs,datafile,nclr2,colorfile22,locfile)
    
!call psc_map ( 1.0, 1.0, 1.0,0.00,0.00,0.00,lwd1,legboxfile,cornerfile)
fmt=0.0; fsize=8.0; font="N"
call psc_legend (fmt,fsize,font,ltype,lorient,xleg,yleg,xlbox,ylbox,nclr,colorfile2)
            
! text	
fmt=0.0; fsize=16.0; font="H"
xtext=xorig; ytext=yorig+ylen+0.05; torient="H"; just="L"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,title)	
xtext=10.0; ytext=yorig+ylen+0.05; torient="H"; just="R"
text="n="//int_to_string(ndots(j))
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,text)	

fmt=0.0; fsize=10.0; font="H"
xtext=10.0; ytext=0.5; torient="H"; just="R"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,mapdate)	

fmt=0.0; fsize=8.0; font="H"
xtext=2.5; ytext=0.3; torient="H"; just="L"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,version)
xtext=xorig+xlen/2.0; ytext=0.3; torient="H"; just="L"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,dataset)
xtext=2.5; ytext=0.15; torient="H"; just="L"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,transform)

call psc_close
call psc_ps (datapath,infofile,pmappath)
pngfile=trim(baseout)//".png"; psfile=trim(baseout)//".ps"
call psc_png (datapath,pngfile,psfile,frwide,frhigh,res)

50 continue
!go to 60

title="LGM - PI difference in Z-Scores of Transformed Charcoal Influx" ! (20,750 to 21,250 minus 200 to 700 cal yr BP)"
!title="21ka - PI difference in Z-Scores of Transformed Charcoal Influx" ! (20,750 to 21,250 minus 200 to 700 cal yr BP)"
baseout=baseout5; j=5; isym=5

infofile=trim(adjustl(baseout))//".inf"
call psc_init(infofile,'P',1,0.0,0.0,1.00,datapath)
call psc_panel (xbpanel,ybpanel,xblen,yblen,xbmin,xbmax,ybmin,ybmax)
! call psc_box(r,g,b,bwidth)

call psc_panel (xpanel,ypanel,xlen,ylen,xmin,xmax,ymin,ymax)    
call psc_map (-1.0,-1.0,-1.0,0.80,0.80,0.80,lwd2,gratfile,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.80,0.80,0.80,lwd2,countryfile,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.80,0.80,0.80,lwd2,coastfile,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd1,landfile2,cornerfile)
call psc_poly (1,1,nmask3,polyfile3,npclr,polyclrfile,4,polyloc3)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd1,icefile4,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd1,icefile5,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd1,framefile,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd3,polefile,cornerfile)

call psc_symbol (isym,nvars,nobs,datafile,nclr1,colorfile12,locfile)
call psc_symbol (isym,nvars,nobs,datafile,nclr2,colorfile22,locfile)
    
!call psc_map ( 1.0, 1.0, 1.0,0.00,0.00,0.00,lwd1,legboxfile,cornerfile)
fmt=0.0; fsize=8.0; font="N"
call psc_legend (fmt,fsize,font,ltype,lorient,xleg,yleg,xlbox,ylbox,nclr,colorfile2)
            
! text	
fmt=0.0; fsize=16.0; font="H"
xtext=xorig; ytext=yorig+ylen+0.05; torient="H"; just="L"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,title)	
xtext=10.0; ytext=yorig+ylen+0.05; torient="H"; just="R"
text="n="//int_to_string(ndots(j))
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,text)	

fmt=0.0; fsize=10.0; font="H"
xtext=10.0; ytext=0.5; torient="H"; just="R"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,mapdate)	

fmt=0.0; fsize=8.0; font="H"
xtext=2.5; ytext=0.3; torient="H"; just="L"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,version)
xtext=xorig+xlen/2.0; ytext=0.3; torient="H"; just="L"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,dataset)
xtext=2.5; ytext=0.15; torient="H"; just="L"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,transform)

call psc_close
call psc_ps (datapath,infofile,pmappath)
pngfile=trim(baseout)//".png"; psfile=trim(baseout)//".ps"
call psc_png (datapath,pngfile,psfile,frwide,frhigh,res)

title="Modern - PI difference in Z-Scores of Transformed Charcoal Influx" ! (1750 to 2008 AD minus 1250 to 1750 AD)"
baseout=baseout6; j=6; isym=6

infofile=trim(adjustl(baseout))//".inf"
call psc_init(infofile,'P',1,0.0,0.0,1.00,datapath)
call psc_panel (xbpanel,ybpanel,xblen,yblen,xbmin,xbmax,ybmin,ybmax)
! call psc_box(r,g,b,bwidth)

call psc_panel (xpanel,ypanel,xlen,ylen,xmin,xmax,ymin,ymax)    
call psc_map (-1.0,-1.0,-1.0,0.80,0.80,0.80,lwd2,gratfile,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.80,0.80,0.80,lwd2,countryfile,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd1,coastfile,cornerfile)
call psc_poly (1,1,nmask1,polyfile1,npclr,polyclrfile,4,polyloc1)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd1,icefile1,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd1,icefile2,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd1,framefile,cornerfile)
call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,lwd3,polefile,cornerfile)

call psc_symbol (isym,nvars,nobs,datafile,nclr1,colorfile12,locfile)
call psc_symbol (isym,nvars,nobs,datafile,nclr2,colorfile22,locfile)
    
!call psc_map ( 1.0, 1.0, 1.0,0.00,0.00,0.00,lwd1,legboxfile,cornerfile)
fmt=0.0; fsize=8.0; font="N"
call psc_legend (fmt,fsize,font,ltype,lorient,xleg,yleg,xlbox,ylbox,nclr,colorfile2)
            
! text	
fmt=0.0; fsize=16.0; font="H"
xtext=xorig; ytext=yorig+ylen+0.05; torient="H"; just="L"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,title)	
xtext=10.0; ytext=yorig+ylen+0.05; torient="H"; just="R"
text="n="//int_to_string(ndots(j))
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,text)	

fmt=0.0; fsize=10.0; font="H"
xtext=10.0; ytext=0.5; torient="H"; just="R"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,mapdate)	

fmt=0.0; fsize=8.0; font="H"
xtext=2.5; ytext=0.3; torient="H"; just="L"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,version)
xtext=xorig+xlen/2.0; ytext=0.3; torient="H"; just="L"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,dataset)
xtext=2.5; ytext=0.15; torient="H"; just="L"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,transform)

999 continue

call psc_close
call psc_ps (datapath,infofile,pmappath)
pngfile=trim(baseout)//".png"; psfile=trim(baseout)//".ps"
call psc_png (datapath,pngfile,psfile,frwide,frhigh,res)


60 continue

end
