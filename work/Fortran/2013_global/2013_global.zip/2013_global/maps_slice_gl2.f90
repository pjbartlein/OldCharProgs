program maps_slice_gl2
! global maps of time slices

use psc_inf

implicit none

integer, parameter	:: nsites=652, maxslice=200
real(8)		    :: lat,lon
real(8)		    :: y(nsites),x(nsites),var(maxslice,nsites),vmiss,age(maxslice)
real(4)         :: slicenum(maxslice),begslice(maxslice),midslice(maxslice),endslice(maxslice)
character(32)   :: slicelabel(maxslice),filelabel(maxslice)

character(256)  :: gratfile,framefile,coastfile,countryfile
character(256)  :: landfile1
character(256)  :: icefile1,icefile2
character(256)  :: legboxfile
character(256)  :: polyfile1,polyloc1,polyclrfile
character(256)  :: treatment
character(256)  :: slicedeffile

integer         :: iyr,ndots(maxslice)
character(5)    :: strbeg,strend 
character(2)    :: str
character(128)  :: plottitle,extratext1,extratext2
character(1)    :: header
character(256)  :: version,transform,mapdate
character(256)  :: id_site,site_lat,site_lon,site_name

character(256)  :: colorfile1,colorfile11,colorfile22
integer         :: nclr1

integer		    :: i,j,ns,npts,ntree,nice,nvars,nvrs,nmask1,npclr,npc

workpath="e:\Projects\GPWG\analysis\maps\v3d_global\"

!##### also change colorfiles

datafile1="v3d_lm_anoms.csv" ! "v3d_lm_means.csv" ! "v3d_means.csv" ! "v3d_anoms.csv" ! 
locfile1="slice.mxy"
!slicedeffile="e:\Projects\GPWG\analysis\main\slice_definitions_21ka.csv"
slicedeffile="e:\Projects\GPWG\analysis\main\slice_03_jm_b.csv"

version="Database query:  v3d_query.txt -- 1 July 2013"
!transform="Data treatment:  Box-Cox transformed, Z-Scores (200 to 21,000 cal yr BP base period)"
transform="Data treatment:  Box-Cox transformed, Z-Scores (200 to 2000 cal yr BP base period)"
mapdate="7 July 2013"
!title="Z-Scores of Transformed Charcoal Influx"
title="Anomalies of Z-Scores of Transformed Charcoal Influx"
treatment="Block means"

baseout="a_" ! "m" ! 

! read slice information
open (1,file=slicedeffile)
read (1,*) header

i=0
do while (.not. eof(1))
    read (1,*) i,midslice(i),begslice(i),endslice(i),slicelabel(i),filelabel(i)
    write (*,'(i4,3f10.2,1x,a32,1x,a32)') i,midslice(i),begslice(i),endslice(i),slicelabel(i),filelabel(i)
    write (10,'(i4,3f10.2,1x,a32,1x,a32)') i,midslice(i),begslice(i),endslice(i),slicelabel(i),filelabel(i)
end do
close(1)
ns=i
write (*,*) ns

vmiss=-9999.0

! global maps
cornerfile="rob_00k.cnr "
gratfile="gl_grtxy.dat"; framefile="gl_frmxy.dat"
coastfile="robwcl.dat"; countryfile="rcntry3.dat" !"robcntry.dat"
icefile1="rice00p.dat"; icefile2="rant00p.dat"

polyfile1="pice00.dat"; polyloc1="pice00.ply"
polyclrfile="flag.clr"; npclr=2

! general things
mr=-1.0; mg=-1.0; mb=-1.0; fr=0.80; fg=0.80; fb=0.80; lwidth=0.5
mr2=-1.0; mg2=-1.0; mb2=-1.0; fr2=0.00; fg2=0.00; fb2=0.00; lwidth2=0.25
mr3=-1.0; mg3=-1.0; mb3=-1.0; fr3=0.80; fg3=0.80; fb3=0.80; lwidth3=-0.25
mr4=1.0; mg4=1.0; mb4=1.0; fr4=0.80; fg4=0.80; fb4=0.80; lwidth4=0.25
res=300; frwide=10.5; frhigh=5.8
xbpanel=0.00; ybpanel=0.00 
xblen=frwide; yblen=frhigh; xbmin=0.0; xbmax=1.0; ybmin=0.0; ybmax=1.0
xorig=0.25; yorig=0.5
xlen=10.0; ylen=5.0; xmin=-2.6662; xmax=2.6662; ymin=-1.3523 ; ymax=1.3523
xpanel=xorig; ypanel=yorig 

!colorfile="zs05c.clr"; nclr=5
!colorfile11="zs05c1.clr"; nclr1=1; colorfile22="zs05c2.clr"; nclr2=4

colorfile="zs05ct.clr"; nclr=5
colorfile11="zs05ct1.clr"; nclr1=1; colorfile22="zs05ct2.clr"; nclr2=4


legboxfile="legbox.dat"
xleg=xpanel+0.1; yleg=ypanel+0.5 ! nclr 3 and 5
!xleg=xpanel+0.5; yleg=ypanel+1.75 ! nclr 12
ltype="S"; lorient="V"; xlbox=10.0; ylbox=10.0

nmask1=29186
nvars=ns

! read and reformat data, project locations
open (2,file=trim(workpath)//trim(datafile1),status="old")
open (3,file=trim(workpath)//trim(locfile1),status="old")

datafile="datafile.dat"; locfile="datafile.mxy"
open (4,file=trim(workpath)//trim(datafile))
open (5,file=trim(workpath)//trim(locfile))

read (2,*) header

do j=1,nsites
    read (2,*) id_site,site_lat,site_lon,(var(i,j),i=1,ns),site_name
    write (*,*) trim(id_site)," ",trim(site_name)
    read (3,*) lat,lon
    call robinson(lat,lon,x(i),y(i),1.0d0,0.0d0)
    write (4,'(2f12.4,250f10.3)') lat,lon,(var(i,j),i=1,ns)
    write (5,'(2f12.4,2f10.4)') lat,lon,x(i),y(i)
end do
nobs=nsites
close(2); close(3); close(4); close(5)

do i=1,ns
    
    isym=i

    infofile=trim(baseout)//trim(adjustl(filelabel(i)))//".inf"
    call psc_init(infofile,'P',1,0.0,0.0,1.00,workpath)
    call psc_panel (xbpanel,ybpanel,xblen,yblen,xbmin,xbmax,ybmin,ybmax)
    r=0.0; g=0.0; b=0.0; bwidth=0.5
    !call psc_box(r,g,b,bwidth)

    call psc_panel (xpanel,ypanel,xlen,ylen,xmin,xmax,ymin,ymax)    
    call psc_map (-1.0,-1.0,-1.0,0.80,0.80,0.80,0.50,gratfile,cornerfile)
    call psc_map (-1.0,-1.0,-1.0,0.80,0.80,0.80,0.50,countryfile,cornerfile)
    call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,0.25,coastfile,cornerfile)
    call psc_poly (1,1,nmask1,polyfile1,npclr,polyclrfile,4,polyloc1)
    call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,0.25,icefile1,cornerfile)
    call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,0.25,icefile2,cornerfile)
    call psc_map (-1.0,-1.0,-1.0,0.00,0.00,0.00,0.25,framefile,cornerfile)
    !call psc_symbol (isym,nvars,nobs,datafile,nclr,colorfile,locfile)
    call psc_symbol (isym,nvars,nobs,datafile,nclr1,colorfile11,locfile)
    call psc_symbol (isym,nvars,nobs,datafile,nclr2,colorfile22,locfile)

    !call psc_map ( 1.0, 1.0, 1.0,0.00,0.00,0.00,0.25,legboxfile,cornerfile)
    fmt=0.0; fsize=8.0; font="N"
    call psc_legend (fmt,fsize,font,ltype,lorient,xleg,yleg,xlbox,ylbox,nclr,colorfile)
                
    ! text	
    fmt=0.0; fsize=14.0; font="H"
    xtext=xorig; ytext=yorig+ylen+0.05; torient="H"; just="L"
    text=trim(title)
    call psc_text (fmt,fsize,font,xtext,ytext,torient,just,text)
    text=trim(slicelabel(i))
    xtext=10.0; ytext=yorig+ylen+0.05; torient="H"; just="R"
    call psc_text (fmt,fsize,font,xtext,ytext,torient,just,text)

    fmt=0.0; fsize=10.0; font="H"
    xtext=10.0; ytext=0.5; torient="H"; just="R"
    call psc_text (fmt,fsize,font,xtext,ytext,torient,just,mapdate)	

    fmt=0.0; fsize=8.0; font="H"
    xtext=2.5; ytext=0.3; torient="H"; just="L"
    call psc_text (fmt,fsize,font,xtext,ytext,torient,just,version)
    xtext=2.5; ytext=0.2; torient="H"; just="L"
    call psc_text (fmt,fsize,font,xtext,ytext,torient,just,transform)
    xtext=2.5; ytext=0.1; torient="H"; just="L"
    strbeg=int_to_string(int(begslice(i))); strend=int_to_string(int(endslice(i)))
    treatment="Block means: "//trim(strend)//" to "//trim(strbeg)//" yr BP (1950) -- "//trim(filelabel(i))
    call psc_text (fmt,fsize,font,xtext,ytext,torient,just,treatment)

    call psc_close
    call psc_ps (workpath,infofile,pmappath)
    pngfile=trim(baseout)//trim(filelabel(i))//".png"
    psfile=trim(baseout)//trim(filelabel(i))//".ps"
    call psc_png (workpath,pngfile,psfile,frwide,frhigh,res)

end do

60 continue
end
