program lwr_curve
! fits a locally weighted regression (lowess) curve

use lowess

implicit none

integer, parameter  :: maxdata=100000, maxtarg=100000, maxin=20
real(8)             :: age(maxdata),y(maxdata)
real(8)             :: cin(maxin)
real(8)             :: param,begyr,endyr
real(8)             :: targbeg,targend,targstep
real(8)             :: xtarg(maxtarg),resid(maxtarg)
real(8)             :: yfit(maxtarg),yfitse(maxtarg),ypredse(maxtarg),xspan(maxtarg)
integer             :: nctrl,ntarg,npfit(maxtarg),minpts,order,nrobust

integer             :: i,k,l,nvars,varin,agein

character(1)        :: wintype
character(1028)     :: workpath,infile,outfile,debugfile
character(256)      :: inname,outname,varname,region,paramstr
character(80)       :: header

! input description
workpath="e:\Projects\GPWG\analysis\output\v3d\v3d_zt21k_curves_zt21kabase\" 
inname="v3d_nsa_whemis_boot_influx_zt21k_sm10_0200.csv"
outname="v3d_nsa_whemis_boot_influx_zt21k_lwr2000.csv"

nvars=14
varin=2
agein=1
varname="ts200"

param=2000.0 !1000.0d0 ! 5000.0d0
wintype="w"; minpts=30; order=1; nrobust=1
paramstr=int_to_string2(int(param),4)
targbeg=-60.0d0; targend=22000.0d0; targstep=20.0d0

infile=trim(workpath)//trim(inname)
outfile=trim(workpath)//trim(outname)
debugfile=trim(workpath)//"detr_debug.dat"

write (*,'(a)') trim(infile)
write (*,'(a)') trim(outfile)
open (1,file=infile); open (2,file=outfile); open (10,file=debugfile)
write (2,'(a)') "age, "//trim(varname)//"_"//trim(paramstr)//", se, xspan"

begyr=0.0; endyr=21000.0

! generate target points
ntarg=int((targend-targbeg)/targstep)+1
write (*,*) param,targstep,ntarg,order,nrobust,wintype
do i=ntarg,1,-1
    xtarg(i)=targbeg+dble(i-1)*targstep !targend-dble(i-1)*targstep
    ! write (*,*) i,sngl(xtarg(i))
end do

! read the series

read (1,'(a)') header
i=0
do while(.not. eof(1))
    i=i+1
    read (1,*) (cin(l),l=1,varin)
    age(i)=cin(agein)
    y(i)=cin(varin)
    ! write (10,*) i,age(i),y(i)
end do
nctrl=i
write (*,'("Number of samples: ",i5)') nctrl

! fit the curve

write (*,'(a)') "Fitting curve..."
call lowess_curve(nctrl,age,y,ntarg,xtarg,wintype,param,minpts,order,nrobust,yfit,yfitse,ypredse,npfit,xspan)

do i=1,ntarg
    write (2,'(f10.2,3(",",f14.6),",",f10.2)') & 
        xtarg(i),yfit(i),yfitse(i),xspan(i)
end do

end




