program area_averages_pts
! area averages of Mann et al. (2009) data
! regions are specified as a list of target points

use netCDF_subs

implicit none

integer, parameter  :: nlon=33, nlat=19, nt=2007, maxpts=nlon*nlat
real(8)             :: lon(nlon),lat(nlat),tlon(maxpts),tlat(maxpts)
real(8)             :: t(nt)

real(8)             :: area(nlat),pdsiwgtsum
real(4)             :: pdsi(nlon,nlat,nt)
real(8)             :: area_region,area_nonmiss,area_drought
real(4)             :: prop_nonmiss,pdsi_aave,dai
integer(4)          :: total_pts,data_pts,drought_pts

integer             :: begyr,endyr,year
integer             :: i,j,k,n,kk,npts(nlon,nlat),ntarg

character(1024)     :: ncpath,ncfile,ncin,datapath,areafile,targname,targfile,tsfile,debugfile
character(80)       :: header

ncpath="e:\Projects\drought\data_2008\distrib\"
ncfile="NADAv2-2008.nc"
datapath="e:\Projects\drought\data_2008\derived_us_e\"
targname="us_e_ne_gridcells" ! "us_e_nm_gridcells" ! "us_e_sm_gridcells" ! "wus_test"
targfile=trim(targname)//".csv"
write (*,*) trim(targfile)
tsfile=trim(targname)//"_drought.csv"
write (*,*) trim(tsfile)
areafile="e:\Projects\drought\data_2008\derived_us_e\grid_lat_area.dat"
debugfile=trim(datapath)//"debug.dat"

begyr=500

open (1,file=trim(datapath)//trim(targfile))
open (2,file=trim(datapath)//trim(tsfile))
open (10,file=debugfile)

! get target points
read (1,'(a80)') header
write (*,'(a)') header
i=0
do
    if (eof(1)) exit
    i=i+1
    read (1,*) tlon(i),tlat(i)
    write (*,'(i4,2f12.4)') i,tlon(i),tlat(i)
end do
ntarg=i
write (*,'("number of points in region: ",i5)') ntarg

write (2,'("Year",", ",a)') "pdsi_"//trim(targname)//", dai_"//trim(targname)//", "// &
    "area_region, area_nonmiss, area_drought, prop_nonmiss, total_pts, data_pts, drought_pts"

! get tmp anomalies and grid-cell areas
ncin=trim(ncpath)//trim(ncfile)
call netcdf_open(ncin,0,ncid)
call netcdf_get_1d_double(ncid,nlat,'lat',lat) 
call netcdf_get_1d_double(ncid,nlon,'lon',lon) 
call netcdf_get_1d_double(ncid,nt,'time',t) 
call netcdf_get_3d_real(ncid,nlon,nlat,nt,'PDSI',pdsi)       
call netcdf_close(ncin,ncid)

open (1,file=trim(areafile))
read (1,*) header
do k=1,nlat
    read (1,*) lat(k),area(k)
end do
write (10,*) area

! area averages
do n=nt,1,-1
    pdsi_aave=0.0; dai=0.0
    area_region=0.0; area_nonmiss=0.0; area_drought=0.0; prop_nonmiss=0.0
    total_pts=0; data_pts=0; drought_pts=0
    
    pdsiwgtsum=0.0d0
    year=t(n)

    do i=1,ntarg
        j=cell(tlon(i),nlon,lon)
        k=cell(tlat(i),nlat,lat)
        total_pts=total_pts+1
        area_region=area_region+area(k)
        if (.not.isnan(pdsi(j,k,n))) then
            data_pts=data_pts+1
            pdsi_aave=pdsi_aave+pdsi(j,k,n)*area(k)
            area_nonmiss=area_nonmiss+area(k)
            if (pdsi(j,k,n).lt.-1) then
                drought_pts=drought_pts+1
                area_drought=area_drought+area(k)
            end if
        end if
        write (10,'(4i5,5f12.2)') n,i,j,k,pdsi(j,k,n),pdsi_aave,area(k),area_nonmiss,area_drought
    end do
    if (area_nonmiss.ne.0.0d0) then
        pdsi_aave=pdsi_aave/sngl(area_nonmiss)
        dai=area_drought/sngl(area_nonmiss)
    else 
        pdsi_aave=0.0d0/0.0d0
        dai=0.0d0/0.0d0
    end if
    prop_nonmiss=sngl(area_nonmiss/area_region)
    write (10,'(2i5,f12.2,f10.6)') n,year,pdsi_aave,dai
    
    write (2,'(i5,2(", ",f12.4),3(", ",f12.1),", ",f7.4,3(", ",i4))') year,pdsi_aave,dai, &
        area_region, area_nonmiss, area_drought, prop_nonmiss,total_pts, data_pts, drought_pts

end do

end