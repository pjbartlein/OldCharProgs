program parse_IMPD_get_fileinfo
    
use ifport

implicit none

!integer(4), parameter  :: maxlines = 3000, maxchars = 640, max_vars = 32
!character(len=*), parameter :: skipchars = "123456789"//achar(9)//achar(32)
character(256)      :: txt_file_name, txt_file_in, txt_file, fileinfo_name
character(1024)     :: txt_file_path, work_file_path, data_file_path
!character(1)        :: dum1
!character(2)        :: dum2
!character(32)       :: cvar(max_vars)
!character(512)      :: continent, file_name, site_name, place, lat_str, lon_str, elev_str
!character(640)      :: string_buffer, txt_lines(maxlines), txt_line_pad, out_txt_line
!character(128)      :: var_name(max_vars)
!character(640)      :: quote

integer(8)          ::  handle
integer(4)          :: nfiles, istat, length
integer(2)          :: iyr, imon, iday, ihr, imin, isec


type(file$infoi8)   :: fileinfo

!real(8)             :: longitude, latitude, elevation
!integer(4)          :: file_num, nfiles, istat, nlines, var_num(max_vars)
!integer(4)          :: i, j, k, idx, str_len, line_number, nvars, i1, i2, i3, ll, nobs
!logical             :: found_variables, vartype1, vartype2, vartype3


!allocate(txt_lines(maxlines, maxchars))

txt_file_path = "e:\Projects\GCD\GCD_Data\IMPD\charcoal\"
txt_file_name = "IMPD_txtfiles.txt"

data_file_path = "f:\Dropbox\WorkCurrent\GCD\GCD_Data\IMPD\distrib\"

work_file_path = "e:\Projects\GCD\GCD_Data\IMPD\work01\"
fileinfo_name = "IMPD_fileinfo.txt"


open (1, file = trim(work_file_path)//trim(txt_file_name))
open (3, file = trim(work_file_path)//trim(fileinfo_name))

! loop over files
nfiles = 0
do
    ! read a filename
    read (1,'(a)', iostat = istat) txt_file_in
    if (istat .ne. 0) exit 
    nfiles = nfiles + 1
    txt_file = trim(data_file_path)//trim(txt_file_in)
    write (*, '(a)') trim(txt_file)
    !write (3, '(a)') trim(txt_file)
    handle = file$first
    length = getfileinfoqq(trim(txt_file), fileinfo, handle)
    CALL unpacktimeqq(fileinfo%lastwrite, iyr, imon, iday, ihr, imin, isec)
    write (*, *) length
    write (*, *) fileinfo%lastwrite, iyr, imon, iday, ihr, imin, isec
    write (*, '(i4, "-", i2.2, "-", i2.2, " ", a)') iyr, imon, iday, txt_file_in
    write (3, '(i4, "-", i2.2, "-", i2.2, " ", a)') iyr, imon, iday, txt_file_in
end do   
write (*, '("number of files: ", i4)') nfiles

end 
    
