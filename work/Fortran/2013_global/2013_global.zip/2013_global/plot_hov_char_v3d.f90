program plot_hov_char_v3d
! plots zonal averages

use psc_inf
use dflib

implicit none

!integer, parameter	:: nc=55200, ni=75850
real(4)			:: xr,xg,xb,xamin,xamax,xlwidth         ! x-axis parameters
real(4)         :: xmajorinterval,xminorinterval,xlabelinterval,xaoffset,xaloffset
character*1     :: xatype,xorient
integer         :: xdecimalplaces
character(256)  :: xaxisfile,xaxistitle

real(4)			:: yr,yg,yb,yamin,yamax,ylwidth         ! y-axis parameters
real(4)         :: ymajorinterval,yminorinterval,ylabelinterval,yaoffset,yaloffset
character*1     :: yatype,yorient
integer         :: ydecimalplaces
character(256)  :: yaxisfile,yaxistitle

character(256)  :: plottitle,datatitle
character(80)   :: querytxt,basetxt

integer         :: plottype,timescale
logical				:: status
character(80)        :: dum

querytxt="v3d_query.txt"
basetxt= "2 kyr (PI)" ! "21 kyr (PI)" !"3 kyr (PI)" ! 
datapath="e:\Projects\GPWG\analysis\maps\v3d_hov\" ! "e:\PROJECTS\GPWG\data\maps\hov07\" ! "e:\PROJECTS\GPWG\data\maps\hov05\" ! 

plottype=24
yminorinterval=-1; ylabelinterval=-1
ydecimalplaces=0; ylwidth=0.5; yaoffset=0.05 

select case (plottype)
    case (1)
        baseout="austl_lat"
        datafile="influx_lat_austl.dat"; locfile="influx_lat_austl.mxy"
        plottitle="Z-Scores -- Australasia (50S-20N; 110E-170W)"
        timescale=4 ! 1
        yatype="E"; yorient="V"; yr=0.0; yg=0.0; yb=0.0; yamin=-50.0; yamax=20.0 
        yaloffset=0.15; yaxisfile="latval.axs"; ymajorinterval=10
        yaxistitle="Latitude"  
        ymin=-50.0; ymax=20.0
        
    case (2)    
        baseout="austl_latb"
        datafile="influx2_lat_austl.dat"; locfile="influx2_lat_austl.mxy"
        plottitle="Z-Scores -- Australasia (60S-20N; 110E-180E)"
        timescale=2
        yatype="E"; yorient="V"; yr=0.0; yg=0.0; yb=0.0; yamin=-50.0; yamax=20.0
        yaloffset=0.15; yaxisfile="latval.axs"; ymajorinterval=10
        yaxistitle="Latitude"
        ymin=-50.0; ymax=20.0

    case (3)
        baseout="austl_lon"
        datafile="influx2_lon_austl.dat"; locfile="influx2_lon_austl.mxy"
        plottitle="Z-Scores -- Australasia (60S-20N; 110E-180E)"
        timescale=1
        yatype="E"; yorient="V"; yr=0.0; yg=0.0; yb=0.0; yamin=110.0; yamax=180.0
        yaloffset=0.15; yaxisfile="lonval.axs"; ymajorinterval=10
        yaxistitle="Longitude"   
        ymin=110.0; ymax=180.0

    case (4)
        baseout="austl_lonb"
        datafile="influx2_lon_austl.dat"; locfile="influx2_lon_austl.mxy"
        plottitle="Z-Scores -- Australasia (60S-20N; 110E-180E)"
        timescale=2
        yatype="E"; yorient="V"; yr=0.0; yg=0.0; yb=0.0; yamin=110.0; yamax=180.0
        yaloffset=0.15; yaxisfile="lonval.axs"; ymajorinterval=10
        yaxistitle="Longitude"   
        ymin=110.0; ymax=180.0
        
    case (5)
        baseout="austl_sitelat"
        datafile="influx2_site_austl_bylat.dat"; locfile="influx2_site_austl_bylat.mxy"
        plottitle="Z-Scores -- Australasia (60S-20N; 110E-180E)"
        timescale=1
        yatype="E"; yorient="V"; yr=0.0; yg=0.0; yb=0.0; yamin=0.0; yamax=143.0
        yaloffset=0.15; yaxisfile="sitenum.axs"; ymajorinterval=10
        yaxistitle="(South)     Sites in Latitudinal Order     (North)"   
        ymin=0.0; ymax=145.0
    
    case (6)
        baseout="austl_sitelatb"
        datafile="influx2_site_austl_bylat.dat"; locfile="influx2_site_austl_bylat.mxy"
        plottitle="Z-Scores -- Australasia (60S-20N; 110E-180E)"
        timescale=2
        yatype="E"; yorient="V"; yr=0.0; yg=0.0; yb=0.0; yamin=0.0; yamax=143.0
        yaloffset=0.15; yaxisfile="sitenum.axs"; ymajorinterval=10
        yaxistitle="(South)     Sites in Latitudinal Order     (North)"   
        ymin=0.0; ymax=145.0
        
    case (7)
        baseout="austl_sitelon"
        datafile="influx2_site_austl_bylon.dat"; locfile="influx2_site_austl_bylon.mxy"
        plottitle="Z-Scores -- Australasia (60S-20N; 110E-180E)"
        timescale=1
        yatype="E"; yorient="V"; yr=0.0; yg=0.0; yb=0.0; yamin=0.0; yamax=143.0
        yaloffset=0.15; yaxisfile="sitenum.axs"; ymajorinterval=10
        yaxistitle="(West)     Sites in Longitudinal Order     (East)"   
        ymin=0.0; ymax=145.0
    
    case (8)
        baseout="austl_sitelonb"
        datafile="influx2_site_austl_bylon.dat"; locfile="influx2_site_austl_bylon.mxy"
        plottitle="Z-Scores -- Australasia (60S-20N; 110E-180E)"
        timescale=2
        yatype="E"; yorient="V"; yr=0.0; yg=0.0; yb=0.0; yamin=0.0; yamax=143.0
        yaloffset=0.15; yaxisfile="sitenum.axs"; ymajorinterval=10
        yaxistitle="(West)     Sites in Longitudinal Order     (East)"   
        ymin=0.0; ymax=145.0

    case (9)
        baseout="eq-30n_sitelon"
        datafile="site_v2h_eq-30n_bylon.dat"; locfile="site_v2h_eq-30n_bylon.mxy"
        plottitle="Z-Scores -- Northern Tropics (Eq-30N)"
        timescale=3
        yatype="E"; yorient="V"; yr=0.0; yg=0.0; yb=0.0; yamin=0.0; yamax=143.0
        yaloffset=0.15; yaxisfile="sitenum.axs"; ymajorinterval=10
        yaxistitle="(West)     Sites in Longitudinal Order     (East)"   
        ymin=0.0; ymax=145.0
        
    case (10)
        baseout="30s-eq_sitelon"
        datafile="site_v2h_30s-eq_bylon.dat"; locfile="site_v2h_30s-eq_bylon.mxy"
        plottitle="Z-Scores -- Southern Tropics (30s-Eq)"
        timescale=3
        yatype="E"; yorient="V"; yr=0.0; yg=0.0; yb=0.0; yamin=0.0; yamax=143.0
        yaloffset=0.15; yaxisfile="sitenum.axs"; ymajorinterval=10
        yaxistitle="(West)     Sites in Longitudinal Order     (East)"   
        ymin=0.0; ymax=145.0

    case (11)
        baseout="tropics_sitelat"
        datafile="site_v2h_tropics_bylat.dat"; locfile="site_v2h_tropics_bylat.mxy"
        plottitle="Z-Scores -- Tropics (30S - 30N) (Equator at Site 123)"
        timescale=3
        yatype="E"; yorient="V"; yr=0.0; yg=0.0; yb=0.0; yamin=0.0; yamax=162.0
        yaloffset=0.15; yaxisfile="sitenum2.axs"; ymajorinterval=10
        yaxistitle="(South)     Sites in Latitudinal Order     (North)"   
        ymin=0.0; ymax=165.0
        
    case (12)
        baseout="v2l_globe_lat"
        datafile="lat_v2l_globe.dat"; locfile="lat_v2l_globe.mxy"
        plottitle="Z-Scores -- Globe"
        timescale=3
        yatype="E"; yorient="V"; yr=0.0; yg=0.0; yb=0.0; yamin=-60.0; yamax=70.0
        yaloffset=0.15; yaxisfile="latvalgl.axs"; ymajorinterval=5
        yaxistitle="Latitude"  
        ymin=-60.0; ymax=70.0
        
    case (13)
        baseout="v2l_globe_sitelat"
        datafile="site_v2l_globe.dat"; locfile="site_v2l_globe.mxy"
        plottitle="Z-Scores -- Globe (Equator at Site 282)"
        timescale=3
        yatype="E"; yorient="V"; yr=0.0; yg=0.0; yb=0.0; yamin=0.0; yamax=700.0
        yaloffset=0.15; yaxisfile="sitenumg.axs"; ymajorinterval=50
        yaxistitle="(South)     Sites in Latitudinal Order     (North)"   
        ymin=0.0; ymax=700.0
        
    case (14)
        baseout="v3c_eur_lat"
        datafile="lat_v3c_eur.dat"; locfile="lat_v3c_eur.mxy"
        plottitle="Z-Scores -- Europe (30W to 60E, 30N to 70N)"
        timescale=3
        yatype="E"; yorient="V"; yr=0.0; yg=0.0; yb=0.0; yamin=30.0; yamax=70.0
        yaloffset=0.15; yaxisfile="latvleur.axs"; ymajorinterval=5
        yaxistitle="Latitude"  
        ymin=30.0; ymax=70.0
        
    case (15)
        baseout="v3c_eur_sitelat"
        datafile="site_v3c_eur.dat"; locfile="site_v3c_eur.mxy"
        plottitle="Z-Scores -- Europe (45N at Row 56)"
        timescale=3
        yatype="E"; yorient="V"; yr=0.0; yg=0.0; yb=0.0; yamin=0.0; yamax=140.0
        yaloffset=0.15; yaxisfile="siteneur.axs"; ymajorinterval=20
        yaxistitle="(South)     Sites in Latitudinal Order     (North)"   
        ymin=0.0; ymax=140.0
        
    case (16)
        baseout="v3c_med_lat"
        datafile="lat_all_Med.dat"; locfile="lat_all_Med.mxy"
        plottitle="Z-Scores -- Europe (30W to 60E, 30N to 50N)"
        timescale=3
        yatype="E"; yorient="V"; yr=0.0; yg=0.0; yb=0.0; yamin=30.0; yamax=50.0
        yaloffset=0.15; yaxisfile="latvlmed.axs"; ymajorinterval=5; yminorinterval=1
        yaxistitle="Latitude"  
        ymin=30.0; ymax=50.0
        
    case (17)
        baseout="v3c_med_sitelat"
        datafile="site_all_Med.dat"; locfile="site_all_Med.mxy"
        plottitle="Z-Scores -- Europe (~40N at Row 15)"
        timescale=3
        yatype="E"; yorient="V"; yr=0.0; yg=0.0; yb=0.0; yamin=0.0; yamax=37.0
        yaloffset=0.15; yaxisfile="sitenmed.axs"; ymajorinterval=5; yminorinterval=1
        yaxistitle="(South)     Sites in Latitudinal Order     (North)"   
        ymin=0.0; ymax=37.0
        
    case (18)
        baseout="v2n_wus_lat"
        datafile="influx_lat_wus.dat"; locfile="influx_lat_wus.mxy"
        plottitle="Z-Scores -- Western United States"
        timescale=5
        yatype="E"; yorient="V"; yr=0.0; yg=0.0; yb=0.0; yamin=30.0; yamax=50.0
        yaloffset=0.15; yaxisfile="latvlwus.axs"; ymajorinterval=5; yminorinterval=1
        yaxistitle="Latitude"  
        ymin=30.0; ymax=50.0
        
    case (19)
        baseout="v2n_wus_sitelat"
        datafile="influx_site_wus.dat"; locfile="influx_site_wus.mxy"
        plottitle="Z-Scores -- Western United States"
        timescale=5
        yatype="E"; yorient="V"; yr=0.0; yg=0.0; yb=0.0; yamin=0.0; yamax=55.0
        yaloffset=0.15; yaxisfile="sitenwus.axs"; ymajorinterval=5; yminorinterval=-1
        yaxistitle="(South)     Sites in Latitudinal Order     (North)"   
        ymin=0.0; ymax=55.0
        
    case (20)
        baseout="v2.5c_globe_lat"
        datafile="lat_v2.5c_globe.dat"; locfile="lat_v2.5c_globe.mxy"
        plottitle="Z-Scores -- Globe"
        timescale=6
        yatype="E"; yorient="V"; yr=0.0; yg=0.0; yb=0.0; yamin=-60.0; yamax=70.0
        yaloffset=0.15; yaxisfile="latvalgl.axs"; ymajorinterval=5
        yaxistitle="Latitude"  
        ymin=-60.0; ymax=70.0
        
    case (21)
        baseout="v2.5c_globe_sitelat"
        datafile="site_v2.5c_globe.dat"; locfile="site_v2.5c_globe.mxy"
        plottitle="Z-Scores -- Globe (Equator at Site 290)"
        timescale=6
        yatype="E"; yorient="V"; yr=0.0; yg=0.0; yb=0.0; yamin=0.0; yamax=700.0
        yaloffset=0.05; yaxisfile="sitenumg.axs"; ymajorinterval=50
        yaxistitle="(South)     Sites in Latitudinal Order     (North)"   
        ymin=0.0; ymax=700.0
        
    case (22)
        baseout="v3d_globe_21k_lat"
        datafile="lat_v3d_globe_21k.dat"; locfile="lat_v3d_globe_21k.mxy"
        plottitle="Z-Scores -- Globe"
        timescale=3
        yatype="E"; yorient="V"; yr=0.0; yg=0.0; yb=0.0; yamin=-60.0; yamax=70.0
        yaloffset=0.15; yaxisfile="latvalgl.axs"; ymajorinterval=5
        yaxistitle="Latitude"  
        ymin=-60.0; ymax=70.0
        
    case (23)
        baseout="v3d_globe_21k_sitelat"
        datafile="site_v3d_globe_21k.dat"; locfile="site_v3d_globe_21k.mxy"
        plottitle="Z-Scores -- Globe (Equator at Site 292)"
        timescale=3
        yatype="E"; yorient="V"; yr=0.0; yg=0.0; yb=0.0; yamin=0.0; yamax=800.0
        yaloffset=0.05; yaxisfile="sitenumg.axs"; ymajorinterval=50
        yaxistitle="(South)     Sites in Latitudinal Order     (North)"   
        ymin=0.0; ymax=800.0
        
    case (24)
        baseout="v3d_globe_2k_lat"
        datafile="lat_v3d_globe_2k.dat"; locfile="lat_v3d_globe_2k.mxy"
        plottitle="Z-Scores -- Globe"
        timescale=7
        yatype="E"; yorient="V"; yr=0.0; yg=0.0; yb=0.0; yamin=-60.0; yamax=70.0
        yaloffset=0.15; yaxisfile="latvalgl.axs"; ymajorinterval=5
        yaxistitle="Latitude"  
        ymin=-60.0; ymax=70.0
        
    case (25)
        baseout="v3d_globe_2k_sitelat"
        datafile="site_v3d_globe_2k.dat"; locfile="site_v3d_globe_2k.mxy"
        plottitle="Z-Scores -- Globe (Equator at Site 292)"
        timescale=7
        yatype="E"; yorient="V"; yr=0.0; yg=0.0; yb=0.0; yamin=0.0; yamax=800.0
        yaloffset=0.05; yaxisfile="sitenumg.axs"; ymajorinterval=50
        yaxistitle="(South)     Sites in Latitudinal Order     (North)"   
        ymin=0.0; ymax=800.0
    case default
        write (*,*) "don't know"
end select

! count number of observations
open (2,file=trim(adjustl(datapath))//trim(adjustl(datafile)))
write (*,*) trim(adjustl(datapath))//trim(adjustl(datafile))
nobs=0
do while (.not. eof(2))
    read (2,*) dum
    nobs=nobs+1
end do
close(2)
    
datatitle="Charcoal Influx"

infofile=trim(adjustl(baseout))//".inf"
write (*,*) infofile

! common parameter values
xorig=0.75; yorig=1.0; dyp=2.25 ! origin and offsets of panels
xlen=7.0; ylen=6.0 ! xlen=5.2; ylen=3.0; ! 
r=0.0; g=0.0; b=0.0; bwidth=0.50

select case (timescale)
    case (1)
        xatype="E"; xorient="H"; xr=0.0; xg=0.0; xb=0.0; xamin=-225000.5; xamax=60.5 
        xmajorinterval=5000.0; xminorinterval=-1; xlabelinterval=-1
        xaloffset=0.005; xaxisfile="age225k.axs"
        xmin=-225000.0 ; xmax=60.0; wgx=1.0    
    case (2)
        xatype="E"; xorient="H"; xr=0.0; xg=0.0; xb=0.0; xamin=-50000.5; xamax=60.5 
        xmajorinterval=1000.0; xminorinterval=-1; xlabelinterval=-1
        xaloffset=0.005; xaxisfile="age50k.axs"
        xmin=-50000.0 ; xmax=60.0; wgx=1.0
    case (3)
        xatype="E"; xorient="H"; xr=0.0; xg=0.0; xb=0.0; xamin=-21000.5; xamax=60.5 
        xmajorinterval=1000.0; xminorinterval=-1; xlabelinterval=-1
        xaloffset=0.005; xaxisfile="age21k.axs"
        xmin=-21000.0 ; xmax=60.0; wgx=1.0
    case (4)
        xatype="E"; xorient="H"; xr=0.0; xg=0.0; xb=0.0; xamin=-150000.5; xamax=60.5 
        xmajorinterval=5000.0; xminorinterval=-1; xlabelinterval=-1
        xaloffset=0.005; xaxisfile="age225k.axs"
        xmin=-150000.0 ; xmax=60.0; wgx=1.0    
    case (5)
        xatype="E"; xorient="H"; xr=0.0; xg=0.0; xb=0.0; xamin=-3000.5; xamax=60.5 
        xmajorinterval=100.0; xminorinterval=-1; xlabelinterval=-1
        xaloffset=0.005; xaxisfile="age03k.axs"
        xmin=-3000.0 ; xmax=60.0; wgx=1.0    
    case (6)
        xatype="E"; xorient="H"; xr=0.0; xg=0.0; xb=0.0; xamin=-1100.5; xamax=60.5 
        xmajorinterval=100.0; xminorinterval=25; xlabelinterval=-1
        xaloffset=0.005; xaxisfile="age01k.axs"
        xmin=-1100.0 ; xmax=60.0; wgx=1.0    
    case (7)
        xatype="E"; xorient="H"; xr=0.0; xg=0.0; xb=0.0; xamin=-2000.5; xamax=60.5 
        xmajorinterval=100.0; xminorinterval=-1; xlabelinterval=-1
        xaloffset=0.005; xaxisfile="age2kce.axs" ! xaxisfile="age2k.axs"
        xmin=-2000.0 ; xmax=60.0; wgx=1.0    
   
    case default
        write (*,*) "don't know timescale"
end select

xdecimalplaces=-1; xlwidth=0.5; xaoffset=0.0
xaxistitle="Year (CE)" ! "Age (yr BP 1950)" ! !"Age (ka)"

orient="P"
call psc_init(infofile,orient,1,0.0,0.0,1.0,datapath)


! charcoal z-scores =======================================================================================

wgy=1.0
xpanel=xorig+0*dxp; ypanel=yorig+0*dyp  
        
call psc_panel (xpanel,ypanel,xlen,ylen,xmin,xmax,ymin,ymax)

colorfile="zs05c1.clr"; nclr=1
call psc_symbol(1,1,nobs,datafile,nclr,colorfile,locfile)
colorfile="zs05c2.clr"; nclr=4
call psc_symbol(1,1,nobs,datafile,nclr,colorfile,locfile)
call psc_box(r,g,b,bwidth)

! legend
fmt=0.0; fsize=8.0; font="N"
colorfile="zs05c.clr"; nclr=5
ltype="S"; lorient="C"; xleg=xpanel+1.25; yleg=ypanel-0.35 ! ypanel+ylen-0.3
xlbox=(xlen*0.4*72.0)/nclr; ylbox=10.0
call psc_legend (fmt,fsize,font,ltype,lorient,xleg,yleg,xlbox,ylbox,nclr,colorfile)

! x-axis
fmt=0.0; fsize=8.0; font="H"
call psc_font(fmt,fsize,font)
call psc_panel (xpanel,ypanel-0.05,xlen,1.0,xmin,xmax,ymin,ymax)
!call psc_box(0.0,1.0,0.0,1.0)
call psc_axis(xatype,xorient,xr,xg,xb,xamin,xamax,xmajorinterval,xminorinterval,xlabelinterval,xdecimalplaces,xlwidth,xaoffset)

! x-axis label
call psc_panel (xpanel,ypanel-0.125,xlen,1.0,xamin,xamax,ymin,ymax)
call psc_axislabel (xaloffset,xaxisfile)

! x-axis title
fmt=0.0; fsize=10.0; font="H"
xtext=xpanel+xlen/2.0; ytext=ypanel-0.4; torient="H"; just="C"
text=xaxistitle
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,text)	

! y-axis
fmt=0.0; fsize=8.0; font="H"
call psc_font(fmt,fsize,font)
call psc_panel (xpanel,ypanel,xlen,ylen,xmin,xmax,yamin,yamax)
!call psc_box(0.0,0.0,1.0,1.0)
call psc_axis(yatype,yorient,yr,yg,yb,yamin,yamax,ymajorinterval,yminorinterval,ylabelinterval,ydecimalplaces,ylwidth,yaoffset)

! y-axis label	
call psc_panel (xpanel,ypanel,xlen,ylen,xmin,xmax,yamin,yamax)
call psc_axislabel (yaloffset,yaxisfile)	

! y-axis title
fmt=0.0; fsize=10.0; font="H"
xtext=xpanel-0.3; ytext=ypanel+(ylen/2); torient="V"; just="C"
text=yaxistitle
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,text)	

! plot title
fmt=0.0; fsize=10.0; font="H"
xtext=xpanel; ytext=ypanel+ylen+0.025; torient="H"; just="L"
text=plottitle
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,text)

! plot title
fmt=0.0; fsize=12.0; font="H"
xtext=xpanel; ytext=ypanel+ylen+0.2; torient="H"; just="L"
text=datatitle
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,text)	

! text
fmt=0.0; fsize=6.0; font="H"
xtext=xpanel+xlen; ytext=ypanel-0.4; torient="H"; just="R"
text="[base period="//trim(adjustl(basetxt))//"]"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,text)	

! text
fmt=0.0; fsize=8.0; font="H"
xtext=xpanel+xlen; ytext=ypanel-0.6; torient="H"; just="R"
text="Database query: "//trim(adjustl(querytxt))
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,text)	



call psc_close

call psc_ps (datapath,infofile,pmappath)

res=150; frwide=11.0; frhigh=8.5
pngfile=trim(baseout)//".png"
psfile=trim(baseout)//".ps"
write (*,*) pngfile
write (*,*) psfile
call psc_png (datapath,pngfile,psfile,frwide,frhigh,res)




stop
end
