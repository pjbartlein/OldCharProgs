program agescale

implicit none

integer				:: entrynum,npts,i
real				:: year

!open(2,file="e:\peaks\columns\scale.tic")
open(2,file="E:\Projects\wavelets\data\work01\xscale.tic")

npts=2
!write (2,'(" 0.0 0.0")')
!write (2,'(" 0.0 -17000.0")')
!write (2,'(" 1.0 -17000.0")')
!write (2,'(" 1.0 0.0")')
write (2,'("-17000.0 1.0 ")')
write (2,'("-17000.0 0.0 ")')
write (2,'(" 0.0 0.0")')
write (2,'(" 0.0 1.0")')

i=0
write (2,'(2i5)') i,npts
!write (2,'("0.0 0.0")') 
!write (2,'("0.0 -17000.0")') 
write (2,'("-17000.0 1.0 ")') 
write (2,'("0.0 1.0")') 

do i=0,17000,1000
	year=-1.0*i
	write (2,'(2i5)') i,npts
!	write (2,'("0.0 ",f9.1)') year
!	write (2,'("1.0 ",f9.1)') year
	write (2,'(f9.1," 0.0 ")') year
	write (2,'(f9.1," 1.0 ")') year
end do
	year=-1.0
	write (2,'(2i5)') i,npts
	write (2,'(f9.1," 0.0 ")') year
	write (2,'(f9.1," 1.0 ")') year
do i=0,17000,200
	year=-1.0*i
	write (2,'(2i5)') i,npts
!	write (2,'("0.0 ",f9.1)') year
!	write (2,'("0.5 ",f9.1)') year
	write (2,'(f9.1," 1.0 ")') year
	write (2,'(f9.1," 0.5 ")') year
end do

stop
end	
