select case (xst_level(1))
    case ("INFL") ! quant is influx, calculate concentration               
        do i=1,nsamples(j)
            influx(i)=quant(i)
            influx_source(i)="data"
            !influx2(i)=influx(i)
            !influx2_source(i)=influx_source(i)
            if (influx(i).ne.miss .and. unit_dep_time(i).ne.miss .and. sed_rate(i).ne.0.0) then
                conc(i)=influx(i)*unit_dep_time(i)
                conc_source(i)="calculated_from_influx"
            else
                conc(i)=quant(i)
                conc_source(i)="copied_from_quant"
            end if
        end do     
    case ("CONC") ! quant is conc, calculate influx               
        do i=1,nsamples(j)            
            conc(i)=quant(i)
            conc_source(i)="data"
            conc2(i)=conc(i)
            conc2_source(i)=conc_source(i)
            if (conc(i).ne.miss .and. sed_rate(i).ne.miss .and. sed_rate(i).ne.0.0) then
                influx(i)=conc(i)*sed_rate(i)
                influx_source(i)="calculated_from_conc"
            else
                influx(i)=quant(i)
                influx_source(i)="copied_from_quant" 
            end if
            !write (10,'(2i5,1x,a4,6f14.6)') site_num(j),i,xst_level(1),conc2(i),sed_rate(i),influx(i),influx2(i)
        end do        
    case ("C0P0") ! C0P0 assume quantity is concentration-like         
        do i=1,nsamples(j)
            conc(i)=quant(i)
            conc_source(i)="c0p0"
            conc2(i)=conc(i)
            conc2_source(i)=conc_source(i)
            if (sed_rate(i).ne.miss .and. sed_rate(i).ne.0.0) then
                influx(i)=quant(i)*sed_rate(i)
                influx_source(i)="calculated_from_c0p0(conc)"
            else
                influx(i)=quant(i)
                influx_source(i)="copied_from_quant" 
            end if       
        end do  
    case ("OTHE") ! just copy quant          
        do i=1,nsamples(j)               
            conc(i)=quant(i)
            conc_source(i)="copied_from_quant"
            influx(i)=quant(i)
            influx_source(i)="copied_from_quant"                
        end do   
    case default
        ! stop "xst" 
        ! just copy           
        do i=1,nsamples(j)               
            conc(i)=quant(i)
            conc_source(i)="copied_from_quant"
            influx(i)=quant(i)
            influx_source(i)="copied_from_quant"                
        end do   
end select