program lowess_boot
! fits a smooth lowess-type curve time-series data
! gets bootstrap estimates of confidence intervals of lowess curve

use lowess
use ifport

implicit none

integer, parameter  :: maxdata=100000, maxtarg=3000, maxreps=1000

real(4)         :: rdatein,varin1,varin2,varin3,varin4,varin5,var(maxdata),realdate(maxdata),varmiss

real(8)         :: xin(maxdata),yin(maxdata)

real(4)         :: begyr,endyr
real(8)         :: xtarg(maxtarg),yfit(maxtarg),yfitse(maxtarg),fit_cu95(maxtarg),fit_cl95(maxtarg),ypredse(maxtarg)
real(8)         :: param
real(8)         :: targbeg,targend,targstep
integer(4)      :: npfit(maxtarg),order,nrobust,ntarg,nnum
character(1)    :: wintype

real(8)         :: ranseed,randval
real(8)         :: yfit_reps(maxtarg,maxreps),temp(maxreps),sorttemp(maxreps)
real(8)         :: yfit_boot(maxtarg),yfit_boot_median(maxtarg),yfit_boot_stdev(maxtarg),yfit_boot_se(maxtarg)
real(8)         :: yfit_boot_cu95(maxtarg),yfit_boot_cl95(maxtarg)
integer         :: jsel(maxdata,maxreps),jmax,jmin,ncl95,ncu95,n50

integer         :: i,j,k,npts,nctrl,jsite,nsites,ii,nreps

character(32)   :: int_to_string2
character(256)  :: infilepath,infile,outfilepath,outfile,debugfile
character(80)   :: header
character(1)    :: dum
character(8)    :: variable,region,atype

infilepath="e:\Projects\drought\data_2008\derived_us_e\"
outfilepath=trim(infilepath)
infile= "us_e_ne_gridcells_drought.csv"
outfile="us_e_ne_gridcells_pdsi_sm_100.csv"

debugfile="debug_lowess.dat"

open (2,file=trim(adjustl(infilepath))//trim(adjustl(infile)))
open (3,file=trim(adjustl(outfilepath))//trim(adjustl(outfile)))
open (10,file=trim(adjustl(outfilepath))//trim(adjustl(debugfile)))

write (3,'(a)') "targ_year,  tsm_100, sefit, fitcu95, fitcl95, np, "// &
  "ts_100_boot, yfit_boot_median,yfit_boot_se, yfit_boot_cu95, yfit_boot_cl95"  ! ############

! lowess parameters
param=100.0d0; wintype='w'; order=1; nrobust=1     ! ############

! target point definitions

!targbeg=-1.0d0; targend=2003.0d0; targstep=1.0d0
targbeg=0.0d0; targend=2000.0d0; targstep=10.0d0

! overall age range of data
!begyr=-1.0; endyr=2003.0
begyr=0.0; endyr=2006.0


! number of bootstrap samples
nreps=1000

! random number seed
call srand(100)

! generate target points
ntarg=int((targend-targbeg)/targstep)+1
write (*,*) param,targstep,ntarg,order,nrobust,wintype
do i=1,ntarg
    xtarg(i)=targend-dble(i-1)*targstep
    !write (*,*) i,sngl(xtarg(i))
end do

varmiss=-9999.0

! read data
read (2,*) header
!write (*,*) header
i=0
do while (.not. eof(2))
    read (2,*) rdatein,varin1,varin2
    !read (2,*) rdatein,vardum,varin
    !read (2,*) varin1,varin2,rdatein,varin3,varin4
    !write (*,*) rdatein,varin1
    if (rdatein.ge.begyr .and. rdatein.le.endyr) then
        i=i+1
        realdate(i)=rdatein
        var(i)=varin1
        !write(*,*) i,realdate(i),var(i)
        !pause
    end if
end do
npts=i
close(2)

! bootstrap sampling and fitting

yfit_reps=0.0d0
!nreps=10

do k=1,nreps
    jmax=-99999; jmin=99999
    ii=0
    do j=1,npts

        ! select a point at random
        randval=rand(0)
        jsel(j,k)=int(randval*sngl(npts))+1
        if (jmax.lt.jsel(j,k)) jmax=jsel(j,k)
        if (jmin.gt.jsel(j,k)) jmin=jsel(j,k)
        !jsel(j,k)=j       
        
        ii=ii+1
        xin(ii)=realdate(jsel(j,k))
        yin(ii)=var(jsel(j,k))
        !write (2,'(4i6,2f14.6)') ii,j,idsite(jsel(j,k)),i,xin(ii),yin(ii)
    end do
    nctrl=ii
    
    !write (*,*) k,npts,ntarg
    !if (mod(k,100).eq.0) write (*,*) k
    yfit=0.0d0; yfitse=0.0d0; fit_cu95=0.0d0; fit_cl95=0.0d0
    call lowess_curve(nctrl,xin,yin,ntarg,xtarg,wintype,param,order,nrobust,yfit,yfitse,ypredse,npfit)
    
    ! save fitted values
    do i=1,ntarg
        yfit_reps(i,k)=yfit(i)
    end do
       
end do

200 continue

! one more fit to get standard (unresampled) values
ii=0
do j=1,npts
    ii=ii+1
    xin(ii)=realdate(j)
    yin(ii)=var(j)
end do
nctrl=ii
    
write (*,*) npts,ntarg
yfit=0.0d0; yfitse=0.0d0; fit_cu95=0.0d0; fit_cl95=0.0d0
call lowess_curve(nctrl,xin,yin,ntarg,xtarg,wintype,param,order,nrobust,yfit,yfitse,ypredse,npfit)

do i=1,ntarg
    if (.not. isnan(yfit(i))) then
        fit_cu95(i)=yfit(i)+2.0d0*yfitse(i)
        fit_cl95(i)=yfit(i)-2.0d0*yfitse(i)
    end if
end do

! get bootstrap estimates

ncl95=int(sngl(nreps)*0.025)
if (ncl95.le.0) ncl95=1
ncu95=int(sngl(nreps)*0.975)
if (ncu95.ge.nreps) ncu95=nreps
n50=int(sngl(nreps)/2.0)
write (*,*) ncl95,ncu95,n50

yfit_boot=0.0d0; yfit_boot_stdev=0.0d0; yfit_boot_se=0.0d0; yfit_boot_cu95=0.0d0; yfit_boot_cl95=0.0d0
do i=1,ntarg
    nnum=0
    do k=1,nreps
        if (.not. isnan(yfit_reps(i,k))) then
            yfit_boot(i)=yfit_boot(i)+yfit_reps(i,k)
            nnum=nnum+1
            !write (*,*) i,k,yfit_boot(i),yfit_reps(i,k)
        end if
    end do
    if (nnum.gt.0) yfit_boot(i)=yfit_boot(i)/dble(nnum)
    !write (*,*) i,yfit_boot(i)
    nnum=0
    do k=1,nreps
        if (.not. isnan(yfit_reps(i,k))) then
            yfit_boot_stdev(i)=yfit_boot_stdev(i)+(yfit_reps(i,k)-yfit_boot(i))*(yfit_reps(i,k)-yfit_boot(i))
            nnum=nnum+1
            !write (*,*) i,k,yfit_reps(i,k),yfit_boot_stdev(i)
        end if
    end do
    !write (*,*) i,yfit_boot_stdev(i)
    if (nnum.gt.1) yfit_boot_stdev(i)=dsqrt(yfit_boot_stdev(i)/dble(nreps-1))
    if (nnum.gt.0) yfit_boot_se(i)=yfit_boot_stdev(i)/dsqrt(dble(nreps))
    !write (*,*) i,yfit_boot_stdev(i),yfit_boot_se(i)
    temp(:)=yfit_reps(i,:)
    call sortx(nreps,temp,sorttemp)
    yfit_boot_cu95(i)=sorttemp(ncu95)
    yfit_boot_cl95(i)=sorttemp(ncl95)
    yfit_boot_median(i)=sorttemp(n50)
    
    write (3,'(f11.2,4(",",f14.6),", ",i6,5(",",f14.6))') & 
        xtarg(i),yfit(i),yfitse(i),fit_cu95(i),fit_cl95(i),npfit(i), &
        yfit_boot(i),yfit_boot_median(i),yfit_boot_se(i),yfit_boot_cu95(i),yfit_boot_cl95(i)
    
    !pause
  
end do
    
end

function int_to_string(inum)

	implicit none
	character(32)	:: int_to_string
	character(32)	:: buffer, str
	integer			:: inum

	write (buffer,*) inum
	read (buffer,*) str

	int_to_string=trim(adjustl(str))

end function int_to_string


function int_to_string2(inum,numlen)

	implicit none
	character(32)	:: int_to_string,int_to_string2
	character(32)	:: buffer, str
	character(8)	:: ifmt,iedit
	integer			:: inum,numlen

	iedit=int_to_string(numlen)
	ifmt="(i"//trim(adjustl(iedit))//"."//trim(adjustl(iedit))//")"

	write (buffer,ifmt) inum
	read (buffer,*) str

	int_to_string2=trim(adjustl(str))

end function int_to_string2

