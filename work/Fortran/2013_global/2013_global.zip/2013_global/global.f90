program global	
! maps of paleofire indicators

use psc_inf

implicit none

integer, parameter	:: maxpts=2000

real		:: vlat,vlon,vegtype
real		:: flat,flon,fire

integer		:: i,npts,nvars

datapath="E:\Projects\igbpfire\data\work02\"

baseout="gcdv4test"

infofile=trim(adjustl(baseout))//".inf"
write (*,'(a128)') infofile
call psc_init(infofile,'L',1,0.0,0.0,1.00,datapath)

xorig=0.5; yorig=2.0
xlen=10.0; ylen=5.0; xmin=-2.6662; xmax=2.6662; ymin=-1.3523 ; ymax=1.3523
xpanel=xorig; ypanel=yorig      
call psc_panel (xpanel,ypanel,xlen,ylen,xmin,xmax,ymin,ymax)


! frame
mr=0.95; mg=0.95; mb=0.95; fr=-1.0; fg=-1.0; fb=-1.0; lwidth=0.25
mapfile="gl_frmxy.dat"; cornerfile="rob_00k.cnr "
call psc_map (mr,mg,mb,fr,fg,fb,lwidth,mapfile,cornerfile)
mr=-1.0; mg=-1.0; mb=-1.0; fr=0.0; fg=0.0; fb=0.0; lwidth=0.25
mapfile="gl_grtxy.dat"; cornerfile="rob_00k.cnr "
call psc_map (mr,mg,mb,fr,fg,fb,lwidth,mapfile,cornerfile)

! polygons ice	
ipoly=1; nvars=1; nobs=7244; datafile="ice_00k.dat"
nclr=1; colorfile="ice.clr"; nvert=4; locfile="ice_00k.ply"
call psc_poly (ipoly,nvars,nobs,datafile,nclr,colorfile,nvert,locfile)

! polygons lc	
!ipoly=1; nvars=1; nobs=58920; datafile="veg05.dat"
!nclr=15; colorfile="sage_veg.clr"; nvert=4; locfile="veg05.ply"
!call psc_poly (ipoly,nvars,nobs,datafile,nclr,colorfile,nvert,locfile)

! polygons tree cover	
ipoly=1; nvars=1; nobs=84862; datafile="treehalf.dat"
nvert=4; locfile="treehalf.ply"
!nclr=15; colorfile="tree.clr"
nclr=1; colorfile="tree1.clr"
!ipoly=1; nvars=1; nobs=763920; datafile="tree10.dat"
!nclr=15; colorfile="tree.clr"; nvert=4; locfile="tree10.ply"
call psc_poly (ipoly,nvars,nobs,datafile,nclr,colorfile,nvert,locfile)

!ipoly=1; nvars=1; nobs=763920; datafile="tree10.dat"
!nclr=16; colorfile="tree_clr.clr"; nvert=4; locfile="tree10.ply"
!call psc_poly (ipoly,nvars,nobs,datafile,nclr,colorfile,nvert,locfile)

! basemaps
mr=-1.0; mg=-1.0; mb=-1.0; fr=0.0; fg=0.0; fb=0.0; lwidth=0.25; cornerfile="rob_00k.cnr"
mapfile="robcost.dat"
call psc_map (mr,mg,mb,fr,fg,fb,lwidth,mapfile,cornerfile)
mapfile="islnpoly.dat"
call psc_map (mr,mg,mb,fr,fg,fb,lwidth,mapfile,cornerfile)
mapfile="lakepoly.dat"
call psc_map (mr,mg,mb,fr,fg,fb,lwidth,mapfile,cornerfile)
mapfile="gl_frmxy.dat"
call psc_map (mr,mg,mb,fr,fg,fb,lwidth,mapfile,cornerfile)

! **********************************************************************
! symbols
isym=1; nvars=1; colorfile="gcdv4.clr"; nclr=4 
datafile="v4_sites.dat"; locfile="v4_sites.mxy"
nobs=1097
call psc_symbol (isym,nvars,nobs,datafile,nclr,colorfile,locfile)

! text	
fmt=0.0; fsize=14.0; font="H"
xtext=xorig; ytext=yorig+ylen+0.05; torient="H"; just="L"
text="Global Charcoal Databases (GCDv1 - GCDv4)"
!text="UMD GLCF AVHRR Tree-Cover Data"
call psc_text (fmt,fsize,font,xtext,ytext,torient,just,text)	


! legend
fmt=0.0; fsize=8.0; font="N"
ltype="S"; lorient="V"; xleg=xpanel+0.2; yleg=ypanel+0.5
xlbox=10.0; ylbox=10; ! nclr=4; colorfile="chg_dot.clr"
call psc_legend (fmt,fsize,font,ltype,lorient,xleg,yleg,xlbox,ylbox,nclr,colorfile)

! text	
!fmt=0.0; fsize=14.0; font="H"
!xtext=8.2; ytext=1.8; torient="H"; just="R"
!text="n="//int_to_string(nobs)
!call psc_text (fmt,fsize,font,xtext,ytext,torient,just,text)	

! text	
fmt=0.0; fsize=6.0; font="H"
xtext=2.85; ytext=1.9; torient="H"; just="L"
!text="Land Cover Data:  Ramankutty and Foley (1999) (http://www.sage.wisc.edu/download/crop1700/hist_croplands.html)"
text="Tree Cover Data:  DeFries et al. (2000) (http://glcf.umiacs.umd.edu/data/treecover/)"
!call psc_text (fmt,fsize,font,xtext,ytext,torient,just,text)

! text	
fmt=0.0; fsize=6.0; font="H"
xtext=2.85; ytext=1.8; torient="H"; just="L"
!text="Compilation:  Jenn Marlon, Dept. Geography, Univ. Oregon (http://geography.uoregon.edu/envchange/)"
!call psc_text (fmt,fsize,font,xtext,ytext,torient,just,text)		

call psc_close
call psc_ps (datapath,infofile,pmappath)

stop
end
