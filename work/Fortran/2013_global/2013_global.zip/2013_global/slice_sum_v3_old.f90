program slice_sum_v3
! summarizes transformed charcoal data for mapping

use summarize_subs

implicit none

integer,parameter   :: ns=44 !43
integer(4)      :: site_sample_in,id_sample_in
real(4)         :: depth_in,age_in,var_in,varmnx_in,tall_in,ztall_in,zt21k_in,zt4k_in,zt2k_in,ztpi2_in,ztpi4_in
real(4)         :: age(maxrec),quant(maxrec)
character(8)    :: site_num_label
character(4)    :: source_in

real(4)         :: qmiss,begbase,endbase,begyr,hw,step
real(4)         :: lastyr,firstyr
real(4)         :: begint(ns),midint(ns),endint(ns)
integer         :: tlabel(ns)
real(4)         :: qmeant(maxsites,ns),qstdevt(maxsites,ns),qmint(maxsites,ns),qmaxt(maxsites,ns),qrngt(maxsites,ns),anm(maxsites,ns)
real(4)         :: qpianm(maxsites)

integer         :: nin(maxsites,ns)

real(4)         :: lat(maxsites),lon(maxsites)
character(72)   :: site_name(maxsites)
character(80)   :: header
character(4)    :: site_num_char

integer         :: i,j,k,npts

character(256)  :: sitefile,transpath,transfile,meanfile,anomfile,pltmeanfile,pltanomfile,pltsumfile,mxyfile,debugfile,cutfile

sitefile="e:\Projects\GPWG\analysis\db_queries\v3d\v3d_sites.txt"
transpath="e:\Projects\GPWG\analysis\csv_files\v3d\v3d_trans\"
meanfile="e:\Projects\GPWG\analysis\maps\v3d_global\v3d_means.csv"
anomfile="e:\Projects\GPWG\analysis\maps\v3d_global\v3d_anoms.csv"
pltmeanfile="e:\Projects\GPWG\analysis\maps\v3d_global\mean.dat"
pltanomfile="e:\Projects\GPWG\analysis\maps\v3d_global\anom.dat"
pltsumfile="e:\Projects\GPWG\analysis\maps\v3d_global\v3d_sum.dat"
mxyfile="e:\Projects\GPWG\analysis\maps\v3d_global\1kptsll.dat"
debugfile="e:\Projects\GPWG\analysis\maps\v3d_global\v3d_debug.csv"
cutfile="e:\Projects\GPWG\analysis\maps\v3d_global\v3d_cutpts.csv"

open (3,file=meanfile); open (4,file=anomfile)
open (5,file=pltmeanfile); open (6,file=pltanomfile); open (7,file=mxyfile); open (8,file=pltsumfile)
open (10,file=debugfile)
open (11,file=cutfile)


! set summarization parameter values
qmiss=-9999.0       ! missing data code
begbase=200.0       ! begining of base period
endbase=4000.0      ! end of base period
begyr=21000.0       ! beginning of intervals
hw=250 !500              ! window half-width
step=500

! generate individual windows
do j=1,42 !41
    midint(j)=begyr-(j-1)*step
    begint(j)=begyr-(j-1)*step-hw
    endint(j)=begyr-(j-1)*step+hw
    tlabel(j)=int(midint(j))
    write (10,*) j,begint(j),midint(j),endint(j),tlabel(j)
end do
j=43 !42
begint(j)=200.0 !100.0
endint(j)=700.0 !1000.0
midint(j)=450.0 !500.0
tlabel(j)=int(midint(j))
write (10,*) j,begint(j),midint(j),endint(j),tlabel(j)
j=44 !43
begint(j)=-60.0 !100.0
endint(j)=200.0 !500.0
midint(j)=0.0   !500.0
tlabel(j)=0.0   !500.0
write (10,*) j,begint(j),midint(j),endint(j),tlabel(j)

! write headers
write (3,'("id_site,site_lat,site_lon  ",50(",     ",i5))') (tlabel(j),j=1,ns)
write (4,'("id_site,site_lat,site_lon  ",50(",     ",i5))') (tlabel(j),j=1,ns) 
write (11,'("Mean")')

! read site info
open (1,file=sitefile)
lat=-9999.0; lon=-9999.0; site_name=" "
do while (.not. eof(1))
    read (1,*) j,site_name(j),lat(j),lon(j)
    write (*,'(i5,2f10.4,2x,a32)') j,lat(j),lon(j),site_name(j)
end do

qpianm=qmiss
! loop over sites
do j=1,maxsites
    ! try to open a file
    site_num_char=int_to_string2(j,4)
    open (1,file=trim(transpath)//trim(adjustl(site_num_char))//"_trans_influx_zt21k.csv", status='old', err=100)
    
    i=0
    lastyr=-99999.0; firstyr=99999.0
    read (1,*) header
    do while (.not. eof(1))
        i=i+1
        read (1,*) site_num_label,site_sample_in,id_sample_in,age_in,depth_in,var_in,varmnx_in, &
            tall_in,zt21k_in      
        age(i)=age_in  
        quant(i)=zt21k_in ! ztpi4_in ! ######
        if (age(i).gt.lastyr) lastyr=age(i)
        if (age(i).lt.firstyr) firstyr=age(i)
    end do
    npts=i
    write (*,'(2i5,2f9.1,1x,a32)') j,npts,lastyr,firstyr,site_name(j)
    
    ! loop over times
    
    do k=1,ns 
        ! basic statistics for an interval from transformed values
        call stats(npts,age,quant,qmiss,begint(k),endint(k),nin(j,k),qmeant(j,k),qstdevt(j,k),qmint(j,k),qmaxt(j,k),qrngt(j,k))       
        !write (*,*) j,k,ndata,nin(j,k),meant(j,k)
        !pause
    end do
        
    do k=1,ns
        anm(j,k)=qmiss
        if (qmeant(j,k).ne.qmiss .and.qmeant(j,ns-1).ne.qmiss) then
            anm(j,k)=qmeant(j,k)-qmeant(j,ns-1)
        end if
    end do
    if (qmeant(j,44).ne.qmiss .and. qmeant(j,43).ne.qmiss) qpianm(j)=qmeant(j,44)-qmeant(j,43)
    !write (*,*) qmeant(j,43),qmeant(j,44),qpianm(j)
                
    write (3,'(i5,2(",",f10.4),50(",",f10.3))') j,lat(j),lon(j),(qmeant(j,k),k=1,ns)
    write (4,'(i5,2(",",f10.4),50(",",f10.3))') j,lat(j),lon(j),(anm(j,k),k=1,ns)
    write (5,'(2f10.4,50f10.3)') lat(j),lon(j),(qmeant(j,k),k=1,ns)
    write (6,'(2f10.4,50f10.3)') lat(j),lon(j),(anm(j,k),k=1,ns)
    write (7,'(4f10.4)') lat(j),lon(j),lon(j),lat(j)
    write (8,'(2f10.4,i5,7f10.3)') lat(j),lon(j),j,qmeant(j,43),qmeant(j,31),qmeant(j,1),anm(j,31),anm(j,1),qpianm(j)
    
    do k=1,ns
        if (qmeant(j,k).ne.qmiss) then
            write (11,'(2f10.3)') qmeant(j,k)
        end if
    end do

100 continue
end do

end


