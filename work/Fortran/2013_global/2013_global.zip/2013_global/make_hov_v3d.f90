program make_hov_all
! writes .dat and .mxy files for Hovmueller plots of charcoal data

implicit none

integer, parameter  :: maxdata=50000, maxsites=5000 

integer(4)      :: site_sample,id_sample,site_num,usesitenum,usesite(maxsites)
real(4)         :: age,depth,influx2,influx2mnx,tall,ztall,zt21k,zt4k,zt2k,ztpi2,ztpi4
real(4)         :: vage(maxdata),vout(maxdata),vmean,dev(maxdata)
real(4)         :: lat,lon,elev
!real(4)         :: latin,lonin,lat(maxsites),lon(maxsites),lonmin,lonmax
real(4)         :: agein,varin,varmiss,agemax
character(8)    :: site_num_label
character(32)   :: charlat,charlon
character(32)   :: region

real(4)         :: begyr,endyr

integer         :: i,j,npts,npts2

character(32)   :: int_to_string2,buffer2
character(256)  :: site_name
character(256)  :: sitefile,transpath,transfile,plotpath
character(256)  :: hovlatfile,hovlatmxyfile,hovlonfile,hovlonmxyfile,hovsitefile,hovsitemxyfile,regionfile
character(80)   :: header
character(1)    :: dum
character(4)    :: site_num_char,char_s1
character(32)   :: vname

vname="influx_zt2k"
region="v3d_globe_2k"

sitefile="e:\Projects\GPWG\analysis\regions\v3d\v3d_nsa_bylat.csv"
transpath="e:\Projects\GPWG\analysis\csv_files\v3d\v3d_trans\"
plotpath="e:\Projects\GPWG\analysis\maps\v3d_hov\"
hovlatfile="lat_"//trim(adjustl(region))//".dat"
hovlatmxyfile="lat_"//trim(adjustl(region))//".mxy"
hovlonfile="lon_"//trim(adjustl(region))//".dat"
hovlonmxyfile="lon_"//trim(adjustl(region))//".mxy"
hovsitefile="site_"//trim(adjustl(region))//".dat"
hovsitemxyfile="site_"//trim(adjustl(region))//".mxy"

open (9,file=sitefile)
read (9,*) header
open (2,file=trim(adjustl(plotpath))//hovlatfile)
open (3,file=trim(adjustl(plotpath))//hovlatmxyfile)
open (4,file=trim(adjustl(plotpath))//hovlonfile)
open (5,file=trim(adjustl(plotpath))//hovlonmxyfile)
open (6,file=trim(adjustl(plotpath))//hovsitefile)
open (7,file=trim(adjustl(plotpath))//hovsitemxyfile)

!! read the region site file
!usesite=0
!read (9,*) header
!do while (.not. eof(9))
!    read (9,*) usesitenum,latin,lonin
!    write (*,*) usesitenum,latin,lonin
!    usesite(usesitenum)=1
!    lat(usesitenum)=latin
!    lon(usesitenum)=lonin
!end do 

varmiss=-9999.0
agemax=22000.0
begyr=-60.0 !1800.0
endyr=1950.0 !1999.0

!lonmin=60.0
!lonmax=180.0

!! read site info
!lat=varmiss; lon=varmiss
!do while (.not. eof(4))
!    read (9,*) site_num,site_name,charlat,charlon
!    write (buffer2,*) trim(adjustl(charlat)); read(buffer2,*) latin
!    write (buffer2,*) trim(adjustl(charlon)); read(buffer2,*) lonin
!    lat(site_num)=latin; lon(site_num)=lonin
!    write (*,*) site_num,lat(site_num),lon(site_num)
!end do 

! loop over sites
!do j=1,maxsites
j=0
do while (.not. eof(9))
    read (9,*) site_num,lat,lon,elev
    j=j+1

    site_num_char=int_to_string2(site_num,4)
    transfile=trim(adjustl(transpath))//trim(adjustl(site_num_char))//"_trans_"//trim(adjustl(vname))//".csv"
    write (*,*) trim(transfile)
    !open (1,file=transfile, status='old', err=100)
    open (1,file=transfile)

    
!    ! if site file exists:
!    write (*,*) site_num_char
!    if (usesite(j).eq.1) then   
    
        ! read data, and save age and variable 
        read (1,*) header
        i=0
        do while (.not. eof(1))
            !read (1,*) site_num_label,site_sample,id_sample,age,depth,influx2,influx2mnx,tall,ztall,zt21k,zt4k,zt2k,ztpi2,ztpi4
            !varin=zt21k ! ztpi4
            read (1,*) site_num_label,site_sample,id_sample,age,depth,influx2,influx2mnx,tall,ztall
            varin=ztall
            agein=age

            !if (varin.ne.varmiss .and. agein.le.agemax .and. agein.ge.-100.0 .and. agein.ne.varmiss) then
            if (varin.ne.varmiss .and. agein.le.endyr .and. agein.ge.begyr .and. agein.ne.varmiss) then
                i=i+1
                vage(i)=-1.0*agein
                vout(i)=varin    
            end if
        end do
        npts=i
        write (*,'(i7," points")') npts
        
        if (npts.ne.0) then
            !npts2=0
            !do i=1,npts
            !    if (vage(i).ge.begyr .and. vage(i).le.endyr) then
            !        vmean=vmean+vout(i)
            !        npts2=npts2+1
            !    end if
            !end do
            !if (npts2.ne.0) vmean=vmean/sngl(npts2)
            
!            if (lon(j).gt.lonmin .and. lon(j).lt.lonmax) then
                do i=1,npts
                    !dev(i)=vout(i)-vmean
                    
                    write (2,'(f14.6,f14.2,f10.3)') lat,vage(i),vout(i)
                    write (3,'(f14.6,2f14.2,f14.6)') lat,vage(i),vage(i),lat
                    write (4,'(f14.6,f14.2,f10.3)') lon,vage(i),vout(i)
                    write (5,'(f14.6,2f14.2,f14.6)') lon,vage(i),vage(i),lon
                    write (6,'(f5.0,f14.2,f10.3)') sngl(j),vage(i),vout(i)
                    write (7,'(f5.0,2f14.2,f5.0)') sngl(j),vage(i),vage(i),sngl(j)
                  
                end do
!            end if
        end if
    
!    end if
    
100 continue

end do
write (*,'(i5," sites")') j

end

function int_to_string(inum)

	implicit none
	character(32)	:: int_to_string
	character(32)	:: buffer, str
	integer			:: inum

	write (buffer,*) inum
	read (buffer,*) str

	int_to_string=trim(adjustl(str))

end function int_to_string


function int_to_string2(inum,numlen)

	implicit none
	character(32)	:: int_to_string,int_to_string2
	character(32)	:: buffer, str
	character(8)	:: ifmt,iedit
	integer			:: inum,numlen

	iedit=int_to_string(numlen)
	ifmt="(i"//trim(adjustl(iedit))//"."//trim(adjustl(iedit))//")"

	write (buffer,ifmt) inum
	read (buffer,*) str

	int_to_string2=trim(adjustl(str))

end function int_to_string2

