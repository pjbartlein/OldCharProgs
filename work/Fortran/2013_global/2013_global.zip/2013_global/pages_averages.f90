program pages_averages
! computes area-weighted averages of PAGES2k temperatures

implicit none

integer, parameter  :: nv=7, ny=2003
real(4)             :: tmp(nv),tmiss,tave,area(nv-1),areatot,naave
integer(4)          :: year,i,j,np
character(80)       :: header

! Arctic,Asia,Australasia,Europe,South America,North America 
data area/34.4,31.3,37.9,13.0,20.0,12.5/

tmiss=-9999.0

open (1,file="e:\Projects\GPWG\work\feedback\Pages2k\PAGES2k_filled.csv")
read (1,*) header
open (2,file="e:\Projects\GPWG\work\feedback\Pages2k\PAGES2k_tave.csv")
write (2,'(a)') "Year, tave"
open (10,file="e:\Projects\GPWG\work\feedback\Pages2k\debug.dat")

do i=1,ny
    read (1,*) year,(tmp(j),j=1,nv)
    write (10,'(i4,7f9.2)') year,(tmp(j),j=1,nv)
    
    ! North American average
    np=0; tave=0.0
    do j=6,7
        if (tmp(j).ne.tmiss) then
            tave=tave+tmp(j)
            np=np+1
        end if
    end do
    if (np.ne.0) then
        tave=tave/sngl(np)
        tmp(6)=tave
    end if
    write (10,'(i4,2f9.3,i4)') year,tave,tmp(6),np
        
    ! weighted global average
    tave=0.0; areatot=0.0
    do j=1,6
        if (tmp(j).ne.tmiss) then
            tave=tave+tmp(j)*area(j)
            areatot=areatot+area(j)
            write (10,'(i2,4f9.3)') j,tmp(j),tave,area(j),areatot
        end if
    end do
    tave=tave/areatot
    
    write (2,'(i4,", ",f7.3)') year,tave
    write (10,'(i4,", ",f9.3)') year,tave
    
    
end do

end