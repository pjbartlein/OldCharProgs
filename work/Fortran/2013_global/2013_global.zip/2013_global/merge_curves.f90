program merge_curves
! merge a bunch of curves

implicit none

real(4)         :: targ_age,globe,nhemis,shemis,nextr,sextr,nd13c,sd13c,nsd13c,nsd13c_adj,ch4
character(1)    :: header

open (1,file="e:\Projects\GPWG\work\feedback\data\charcoal\v3h2\v3h2_nsa_locfit_zt2kb_bw20_200_1000.csv")
open (2,file="e:\Projects\GPWG\work\feedback\data\charcoal\v3h2\v3h2_nsa_nextr_locfit_zt2kb_bw20_200_1000.csv")
open (3,file="e:\Projects\GPWG\work\feedback\data\charcoal\v3h2\v3h2_nsa_nhemis_locfit_zt2kb_bw20_200_1000.csv")
open (4,file="e:\Projects\GPWG\work\feedback\data\charcoal\v3h2\v3h2_nsa_sextr_locfit_zt2kb_bw20_200_1000.csv")
open (5,file="e:\Projects\GPWG\work\feedback\data\charcoal\v3h2\v3h2_nsa_shemis_locfit_zt2kb_bw20_200_1000.csv")

!open (1,file="e:\Projects\GPWG\work\feedback\data\charcoal\v3h2\v3h2_nsa_boot_influx_zt2kb_sm10_0200.csv")
!open (2,file="e:\Projects\GPWG\work\feedback\data\charcoal\v3h2\v3h2_nsa_nextr_boot_influx_zt2kb_sm10_0200.csv")
!open (3,file="e:\Projects\GPWG\work\feedback\data\charcoal\v3h2\v3h2_nsa_nhemis_boot_influx_zt2kb_sm10_0200.csv")
!open (4,file="e:\Projects\GPWG\work\feedback\data\charcoal\v3h2\v3h2_nsa_sextr_boot_influx_zt2kb_sm10_0200.csv")
!open (5,file="e:\Projects\GPWG\work\feedback\data\charcoal\v3h2\v3h2_nsa_shemis_boot_influx_zt2kb_sm10_0200.csv")

open (6,file="e:\Projects\GPWG\work\feedback\data\ice_core\sapart_dc13_krcorr_span40.csv")
open (7,file="e:\Projects\GPWG\work\feedback\data\ice_core\southern_dc13_span40.csv")
open (8,file="e:\Projects\GPWG\work\feedback\data\ice_core\NS_dc13_span20.csv")
open (9,file="e:\Projects\GPWG\work\feedback\data\ice_core\NS_dc13_adjust_span20.csv")
open (10,file="e:\Projects\GPWG\work\feedback\data\ice_core\law2006_ch4_100.csv")

!open (11,file="e:\Projects\GPWG\work\feedback\data\ice_core\charice_v3h2_F.csv")
open (11,file="e:\Projects\GPWG\work\feedback\data\ice_core\charice_v3h2_R.csv")

read (1,'(a)') header
read (2,'(a)') header
read (3,'(a)') header
read (4,'(a)') header
read (5,'(a)') header
read (6,'(a)') header
read (7,'(a)') header
read (8,'(a)') header
read (9,'(a)') header
read (10,'(a)') header


write (11,'(a)') "targ_age, globe, nextr, nhemis, sextr, shemis, nd13c, sd13c, nsd13c, nsd13c_adj,ch4"

do while(.not.eof(1))

    read (1,*) targ_age,globe
    read (2,*) targ_age,nextr
    read (3,*) targ_age,nhemis
    read (4,*) targ_age,sextr
    read (5,*) targ_age,shemis
    read (6,*) targ_age,nd13c
    read (7,*) targ_age,sd13c
    read (8,*) targ_age,nsd13c
    read (9,*) targ_age,nsd13c_adj
    read (10,*) targ_age,ch4
    
    write (11,'(f6.1,10(", ",f11.6))') targ_age, globe, nextr, nhemis, sextr, shemis, nd13c, sd13c, nsd13c, nsd13c_adj, ch4

end do

end

