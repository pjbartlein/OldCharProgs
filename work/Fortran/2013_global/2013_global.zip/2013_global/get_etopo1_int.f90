program get_etopo1
! gets ETOPO1 elevations
! reads reformatted file (with real(8) lats and lons)

use netCDF_subs ! Bart's module of netCDF subroutines

implicit none

integer, parameter      :: nlat=10801, nlon=21601
real(8)                 :: lon(nlon),lat(nlat),tlat,tlon
integer(4), allocatable :: elev(:,:)
integer(4)              :: elev1,elev2,fillvalue
integer                 :: sitenum,biome,mega
character(1)            :: dum
character(80)           :: header
character(72)           :: site_name

integer                 :: j,k

open (1,file="e:\Projects\GPWG\GPWGv3\data\v3plus\v3plus_query\v3plus_sites.csv")
open (2,file="e:\Projects\GPWG\GPWGv3\data\v3plus\v3plus_query\v3plus_sites_elevs.csv")
write (2,*) "Site_num, Lat, Lon, Elev, ETOPO1_Elev, Site_name"

allocate(elev(nlon,nlat))

! get elevations from ETOPO1 file
nc_fname="u:\Data\ETOPO1\nc_files\etopo1_ig.nc"
call netcdf_open(nc_fname,0,ncid) 
call netcdf_get_1d_double(ncid,nlon,'lon',lon)
call netcdf_get_1d_double(ncid,nlat,'lat',lat)
call netcdf_get_2d_int(ncid,nlon,nlat,'elev',elev)
call netcdf_close(nc_fname,ncid)

read (1,*) header
do
    if (eof(1)) exit
    read (1,*) sitenum,tlat,tlon,elev1,site_name
    write (*,'(i5,2f12.6,i8,1x,a72)') sitenum,tlat,tlon,elev1,site_name
    
    ! find row and column of ETOPO1 the point lies in
    j=cell(tlon,nlon,lon)
    k=cell(tlat,nlat,lat)
    elev2=elev(j,k)
    !write (2,'(2f12.6,2i6,2f12.6,f8.0)') tlat,tlon,j,k,lat(k),lon(j),elev(j,k)
    
    !if (elev1.eq.0.0) elev1=elev2 ! fixup
    
    !write (2,'(i5,2(",",f12.6),2(",",f7.0),", ","""",a72,"""")') sitenum,tlat,tlon,elev1,elev2,site_name
    write (2,'(i5,2(",",f12.6),2(",",i6),", ",a72)') sitenum,tlat,tlon,elev1,elev2,site_name
    
end do

end
