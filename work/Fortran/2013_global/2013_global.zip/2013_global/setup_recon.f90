program setup_recon
! creates .csv files for individual sites (entities)

use uo_utils

implicit none

integer, parameter  :: maxdata=5000, maxsites=2000, ncols=181, nid=12, nvars=84 ! ncols=157 
integer(4)          :: site_num(maxsites),nsamples(maxsites),site_num_in,current
integer(4)          :: nsites
real(4)             :: entity(maxdata),depth(maxdata),calage(maxdata),agebp(maxdata),sumt(maxdata)
real(4)             :: PD34dID,recon(maxdata,nvars),sd(maxdata,nvars),calbp(maxdata),anm(maxdata,nvars)
real(4)             :: mean(nvars),begage,endage

integer             :: i,j,k,kk,l
integer             :: npts(nvars)
character(32)       :: taxon_name(ncols),id(maxdata,nid)
character(256)      :: csvpath,infile,namesfile
character(4)        :: site_num_char
character(32)       :: header(ncols)
character(8)        :: dum

begage=3000.0; endage=200.0
!infile="\Projects\igbpfire\nachar\data\na_pollen\anal125_.30_7NoAmb2.dat"
infile="e:\Projects\igbpfire\nachar\data\na_pollen\anal159.csv"
csvpath="\Projects\igbpfire\nachar\data\recon_csv\"

open (10,file="\Projects\igbpfire\nachar\data\recon_csv\debug.dat")
open (4,file=trim(csvpath)//"means_all.csv")
open (5,file=trim(csvpath)//"all_anm.csv")

! open the input data set, and count number of sites and number of samples for each site
write (*,'(a)') "Counting number of sites, and samples..."
open(1,file=infile)
read (1,*) header
write (*,'(a)') (trim(header(l)),l=1,ncols)

i=0; j=1
read (1,*) PD34dID,site_num_in  ! read first record
write (*,*) PD34dID,site_num_in
current=site_num_in
do
    if (eof(1)) then 
        nsamples(j)=i
        site_num(j)=int(current)
        exit    ! exit loop if at end of file
    end if
    read (1,*) PD34dID,site_num_in
        i=i+1
        if (site_num_in .ne. current) then    ! site number has changed
            nsamples(j)=i
            site_num(j)=int(current)
             current=site_num_in
            j=j+1
            i=0
        end if
end do
nsites=j

do j=1,nsites
    write (*,'(3i5)') j,site_num(j),nsamples(j)
end do

rewind(1)   ! rewind the input file
read (1,*) header      ! read header

write (4,'(a,92(", ",a))') (trim(header(l)),l=1,8),(trim(header(l)),l=14,97)
write (5,'(a,180(", ",a))') (trim(header(l)),l=1,ncols)
do j=1,nsites   ! loop over the sites

    ! read the data for the j-th site
    write (*,*) j,site_num(j),nsamples(j)
    do i=1,nsamples(j)
        read (1,*) (id(i,l),l=1,9),calbp(i),(id(i,l),l=10,nid),(recon(i,k),k=1,nvars),(sd(i,k),k=1,nvars)
    end do
    
    anm=-9999.0
    mean=0.0; npts=0
    do i=1,nsamples(j)
        if (calbp(i).ge.endage .and. calbp(i).le.begage) then
            do k=1,nvars
                if (recon(i,k).ne.-9999.0) then
                    mean(k)=mean(k)+recon(i,k)
                    npts(k)=npts(k)+1
                end if
            end do
        end if
    end do
    write (10,*) j,site_num(j),npts(1)
    if (npts(1).eq.0) cycle
    do k=1,nvars
        if (npts(k).gt.1) then
            mean(k)=mean(k)/real(npts(k))
        else
            mean(k)=-9999.0
        end if
    end do
    write (4,'(a,7(", ",a),84(", ",f10.4))') (trim(id(1,l)),l=1,8),(mean(k),k=1,nvars)
    do i=1,nsamples(j)
        do k=1,nvars
            if (recon(i,k).ne.-9999.0) then
                if (npts(k).gt.1) then
                    anm(i,k)=recon(i,k)-mean(k)
                else
                    anm(i,k)=-9999.0
                end if
            end if
        end do
    end do
   
    ! create the .csv file for j-th site and write out data
    if (mean(1).ne.-9999.0) then
        site_num_char=int_to_string2(site_num(j),4)
        open (3,file=trim(csvpath)//site_num_char//"_anm.csv")
        write (3,'(a,180(", ",a))') (trim(header(l)),l=1,ncols)
        do i=1,nsamples(j)
            if (anm(i,1).ne.-9999.) then
                write (3,'(a,8(", ",a),", ",f10.2,3(", ",a),168(", ",f10.4))') (trim(id(i,l)),l=1,9),calbp(i),(trim(id(i,l)),l=10,nid), &
                    (anm(i,k),k=1,nvars),(sd(i,k),k=1,nvars)
                write (5,'(a,8(", ",a),", ",f10.2,3(", ",a),168(", ",f10.4))') (trim(id(i,l)),l=1,9),calbp(i),(trim(id(i,l)),l=10,nid), &
                    (anm(i,k),k=1,nvars),(sd(i,k),k=1,nvars)
            end if

        end do
    end if
    close(3)  
end do 

end
