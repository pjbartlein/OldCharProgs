program stack_ncfile
! creates an nlon x nlat x nt .csv file

use netCDF_subs

implicit none

integer, parameter  :: nlon=72, nlat=36, nt=2006-500+1! Mann et al.
real(8)             :: lon(nlon),lat(nlat),t(nt)
real(8)             :: cft(nt),area(nlat)
real                :: var3d(nlon,nlat,nt),year
integer             :: seqnum,sitenum

integer             :: j,k,n

character(1024)     :: ncfile,ptsfile,outfile

ncfile="e:\Projects\GPWG\work\curves\data\ncfiles\Mann2009_tmp.nc"
outfile="e:\Projects\GPWG\work\curves\data\csvfiles\tmp2k\test_stack.csv"

! get tmp anomalies and grid-cell areas
call netcdf_open(ncfile,0,ncid)
call netcdf_get_1d_double(ncid,nlat,'lat',lat) 
call netcdf_get_1d_double(ncid,nlon,'lon',lon) 
call netcdf_get_1d_double(ncid,nt,'time',t)
call netcdf_get_3d_real(ncid,nlon,nlat,nt,'tmp_anm',var3d)   
call netcdf_get_1d_double(ncid,nlat,'area',area) 
call netcdf_close(ncfile,ncid)   

open (2,file=outfile)
write (2,'(a)') "seqnum, sitenum, year, tmp, area, lon, lat, t" 

seqnum=0; sitenum=0
do j=1,nlon
    write (*,*) j, lon(j)
    do k=1,nlat
        sitenum=sitenum+1
        do n=1,nt
            year=500.0+sngl(n)-1.0
            seqnum=seqnum+1
            write (2,'(i7,", ",i4,", ",f7.0,", ",f10.2,", ",f10.0,3(", ",f8.1))') & 
                seqnum,sitenum,year,var3d(j,k,n),area(k),lon(j),lat(k),t(n)
        end do
    end do
end do
        
 

end