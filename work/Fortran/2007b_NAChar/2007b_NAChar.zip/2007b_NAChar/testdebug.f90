program testdebug

implicit none

integer, parameter  :: n=100

real(4)             :: x(n)
integer(4)          :: i,j

j=0
do i=1,10
    x(i)=sngl(i)/0.0
    write (*,*) i,x(j)
end do

end