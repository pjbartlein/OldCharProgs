program setup_char
! setup files for decomposition from an all-sites, all-data query
! writes individual .csv files for sites, plus a sitelist file with parameters

implicit none

integer, parameter  :: maxdata=5000, maxsites=1000
integer(4)      :: site_num(maxsites)                   ! site id's
real(4)         :: current,site_num_in                  ! current and next site id's
integer(4)      :: nsamples(maxsites)                   ! sample id's
integer(4)      :: nsites                               ! number of sites
real(8)         :: lat,lon                              ! lat and lon
real(4)         :: depth(maxdata),est_age(maxdata)      ! ages
real(4)         :: quant(maxdata)                       ! charcoal quantity
real(4)         :: conc(maxdata)                        ! concentration
real(4)         :: span(maxdata)                        ! deposition time
real(4)         :: influx(maxdata)                      ! influx
character(72)   :: site_name                            ! site name
character(4)    :: pref_units, xst_level                ! pref_units, xst_level

integer         :: i,j
character(256)  :: csvpath,infile,sitelist,sitename
character(4)    :: site_num_char
character(80)    :: dum
character(32)   :: int_to_string2

real(4)         :: thresh,trans,shift,interval           ! decomp parameters

character(1)    :: bwintype                              ! lowess params background
real(4)         :: bwidth                                 
integer(4)      :: border,bnrobust

character(1)    :: cwintype                              ! lowess params counts
real(4)         :: cwidth                                 
integer(4)      :: corder,cnrobust

character(1)    :: fwintype                              ! lowess params freq
real(4)         :: fwidth                                 
integer(4)      :: forder,fnrobust

character(1)    :: mwintype                              ! lowess params mag
real(4)         :: mwidth                                 
integer(4)      :: morder,mnrobust

infile="\Projects\igbpfire\nachar\data\char_query_csv\BART_NA4add.csv"
csvpath="\Projects\igbpfire\nachar\data\char_site_csv\"
sitelist="\Projects\igbpfire\nachar\data\char_query_csv\sitelist2.csv"
sitename="\Projects\igbpfire\nachar\data\char_query_csv\sitename2.csv"

! decomposition parameters
thresh=1.1; trans=0.0; shift=1.0;  interval=1000.0

! lowess parameters
bwintype="w"; bwidth=0750.0; border=1; bnrobust=2 ! background
cwintype="w"; cwidth=2000.0; corder=2; cnrobust=1 ! counts
fwintype="w"; fwidth=2000.0; forder=2; fnrobust=1 ! freq
mwintype="w"; mwidth=2000.0; morder=1; mnrobust=1 ! mag

! open the input data set, and count number of sites and number of samples for each site
write (*,'(a)') "Counting number of sites, and samples..."
open(1,file=infile)
read (1,*) dum      ! read header
i=0; j=1
read (1,*) site_num_in  ! read first record
current=site_num_in
do
    if (eof(1)) then 
        nsamples(j)=i
        site_num(j)=int(current)
        exit    ! exit loop if at end of file
    end if
    read (1,*) site_num_in
        i=i+1
        if (site_num_in .ne. current) then    ! site number has changed
            nsamples(j)=i
            site_num(j)=int(current)
            current=site_num_in
            j=j+1
            i=0
        end if
end do
nsites=j

do j=1,nsites
    write (*,'(3i5)') j,site_num(j),nsamples(j)
end do

! create the sitelist file
open(2,file=sitelist) !,status='new') ! if file already exists, don't overwrite
! write header
write (2,'(a)') "site_num,lat,lon,pref_units,xst_level,nsamples,thresh,trans,shift,interval,"// &
    "bwintype,bwidth,border,bnrobust,cwintype,cwidth,corder,cnrobust,"// &
    "fwintype,fwidth,forder,fnrobust,mwintype,mwidth,morder,mnrobust,"// &
    "site_name"
! sitename file
open(4,file=sitename) !,status='new') ! if file already exists, don't overwrite
! write header
write (4,'(a)') "site_num,site_name"

rewind(1)   ! rewind the input file
read (1,*) dum
write (*,*) dum
do j=1,nsites   ! loop over the sites

    ! read the data for the j-th site
    depth=-9999.0; est_age=0.0; quant=0.0
    write (*,'(i5,1x,a72)') int(site_num_in),site_name
    do i=1,nsamples(j)
        read (1,*) site_num_in,site_name,lat,lon,depth(i),est_age(i),quant(i),pref_units,xst_level
 !       write (*,*) i,site_num_in,site_name,lat,lon,depth(i),est_age(i),quant(i),pref_units,xst_level
    end do
    
    ! if quantity is not influx, try to calculate it
    ! this makes no provision for skipping missing samples, etc.
    if (xst_level.ne."INFL") then
        write (*,'("not INFL, xst_level= ",a5)') xst_level
        if (depth(1).ne.-9999.0) then ! but can't do that if no depths
            influx=0.0; conc=quant
            do i=2,nsamples(j)
                span(i)=(est_age(i)-est_age(i-1))/((depth(i)-depth(i-1))*100.0)
                if (span(i).ne.0.0) influx(i)=conc(i)/span(i)
                quant(i)=influx(i)
                ! write (*,*) site_num(j),i,est_age(i)-est_age(i-1),depth(i)-depth(i-1),span(i),influx(i),quant(i)
            end do
            if (span(2).ne.0.0) influx(1)=conc(1)/span(2)
            quant(1)=influx(1)
        end if
    end if          
                        
    ! create the .csv file for j-th site and write out data
    site_num_char=int_to_string2(site_num(j),4)
    open (3,file=trim(csvpath)//site_num_char//".csv")
    write (3,'(a)') "site"//site_num_char//",depth,est_age,quant" ! first column label is site number
    do i=1,nsamples(j)
        write (3,'(i4,",",f10.4,",",f9.1,", ",f12.4)') i,depth(i),est_age(i),quant(i)
    end do
    close(3)     
    
    ! write a line in the sitelist.csv file
    write (2,'(i4,2(",",f10.5),2(",",a5),",",i5,4(",",f8.3), &
        4(",",a2,",",f7.1,2(",",i2)), &
        ", ","""",a72,"""" )') &
        site_num(j),lat,lon,pref_units,xst_level,nsamples(j),thresh,trans,shift,interval, & !   
        bwintype,bwidth,border,bnrobust,cwintype,cwidth,corder,cnrobust, &
        fwintype,fwidth,forder,fnrobust,mwintype,mwidth,morder,mnrobust, &
        site_name 
    write (4,'(i4,", ","""",a72,"""" )') site_num(j),site_name

end do

end program setup_char

function int_to_string(inum)

	implicit none
	character(32)	:: int_to_string
	character(32)	:: buffer, str
	integer			:: inum

	write (buffer,*) inum
	read (buffer,*) str

	int_to_string=trim(adjustl(str))

end function int_to_string

        
function int_to_string2(inum,numlen)

	implicit none
	character(32)	:: int_to_string,int_to_string2
	character(32)	:: buffer, str
	character(8)	:: ifmt,iedit
	integer			:: inum,numlen

	iedit=int_to_string(numlen)
	ifmt="(i"//trim(adjustl(iedit))//"."//trim(adjustl(iedit))//")"

	write (buffer,ifmt) inum
	read (buffer,*) str

	int_to_string2=trim(adjustl(str))

end function int_to_string2
  
    







            