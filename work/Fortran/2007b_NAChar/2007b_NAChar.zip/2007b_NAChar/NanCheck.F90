! check for NaN of fitted value 
    yfitnan=.false.
    if (isnan(yfit(ii))) then 
        yfitnan=.true.       
        write (*,'("yfit=NaN, ",i5,1x,g14.6,i6)') ii,xt(ii),nctrl
        write (10,'("yfit=NaN, ",i5,1x,g14.6,i6)') ii,xt(ii),nctrl
    end if
            
    ! if NaN, try expanding window first
    if (yfitnan) then
        if (wintype.eq.'s') then
            newparam=param*1.5d0
            if (newparam.gt.1.0d0) newparam=1.0d0
        else
            newparam=param*2.0d0
        end if      
        call localfit(nctrl,xs,ys,targ,wintype,newparam,order,nrobust,fitval,lwmean2)
        yfit(ii)=fitval
        write (*,'("window expanded, param= ",g14.6," yfit=",g14.6)') newparam,yfit(ii)
        write (10,'("window expanded, param= ",g14.6," yfit=",g14.6)') newparam,yfit(ii)
        ! check Nan
        if (isnan(yfit(ii))) then
            yfitnan=.true.
        else
            yfitnan=.false.
        end if    
    end if
        
    ! if still Nan, expand window again
    if (yfitnan) then  
        if (wintype.eq.'s') then
            newparam=param*2.0d0
            if (newparam.gt.1.0d0) newparam=1.0d0
        else
            newparam=param*4.0d0
        end if     
        call localfit(nctrl,xs,ys,targ,wintype,newparam,order,nrobust,fitval,lwmean2)
        yfit(ii)=fitval
        write (*,'("window expanded again, param= ",g14.6," yfit=",g14.6)') newparam,yfit(ii)
        write (10,'("window expanded again, param= ",g14.6," yfit=",g14.6)') newparam,yfit(ii)
        ! check Nan
        if (isnan(yfit(ii))) then
            yfitnan=.true.
        else
            yfitnan=.false.
        end if    
     end if       
        
    ! if still Nan, substitute locally-weighted mean
    if (yfitnan) then 
        if (.not. isnan(lwmean1)) then
            if (dabs(lwmean1).gt.0.000000001d0) then
                yfit(ii)=lwmean1
            else
                yfit(ii)=0.0d0
            end if
            write (*,'("locally-weighted mean substituted, yfit=",g14.6)') yfit(ii)
            write (10,'("locally-weighted mean substituted, yfit=",g14.6)') yfit(ii)
        end if
        ! check Nan
        if (isnan(yfit(ii))) then
            yfitnan=.true.
        else
            yfitnan=.false.
        end if    
    end if
      
    ! if yfit(ii) still NaN, then set equal to previous value (except if ii=1)
    if (yfitnan) then           
        if (ii.eq.1) then
            yfit(ii)=y0
        else
            yfit(ii)=yfit(ii-1)
        end if
        write (*,'("previous value or 0 substituted, yfit=",g14.6)') yfit(ii)
        write (10,'("previous value or 0 substituted, yfit=",g14.6)') yfit(ii)
    end if
    ! check Nan
    if (isnan(yfit(ii))) then
        yfitnan=.true.
    else
        yfitnan=.false.
    end if  
    
    ! if yfit(ii) is still NaN, give up
    if (isnan(yfit(ii))) yfit(ii)=0.0d0  
    
end do    