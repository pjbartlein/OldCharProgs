program summary_pollen
! summarizes decomp files for a set of sites

use summarize_subs  ! summarize_subs.f90
use chaps_subs      ! chaps_module.f90
use lwr             ! lwr_module.f90
use uo_utils        ! uo_utils.f90

implicit none

integer, parameter  :: maxtarg=2200, maxsum=70, maxtaxa=80, ntaxa=67, maxsitesum=1000
integer             :: nsites,sitenum(maxsitesum)
integer             :: nsum,ninsum(maxsum),sumtaxaid(maxsum,ntaxa)
real(4)             :: calbp(maxdata),polin(ntaxa),sumtaxa(maxdata,maxtaxa),qmiss
real(4)             :: begtarg,endtarg,targstep,tage(maxtarg)
real(4)             :: smsumtaxa(maxtarg,maxtaxa)

character(1)        :: wintype                              ! lowess params 
real(4)             :: width                                 
integer(4)          :: order,nrobust

integer             :: i,ii,j,k,n,npts,ntarg

character(256)      :: csvpath,csvfile,sumpath,sumspecs,sumfile,alldatfile,allhdr,smhdr
character(80)       :: title,sumtitle(maxsum)
character(4)        :: site_num_char
character(1)        :: header

csvpath="\Projects\igbpfire\nachar\data\pollen_site_csv\"
sumspecs="e:\Projects\igbpfire\nachar\data\pollen_sum_csv\StLaw\entity_list_StLaw_2.csv"
sumpath="\Projects\igbpfire\nachar\data\pollen_sum_csv\StLaw\"
sumfile="\Projects\igbpfire\nachar\data\pollen_sum_csv\StLaw\StLaw_sum_2.csv"
alldatfile="\Projects\igbpfire\nachar\data\pollen_sum_csv\StLaw\StLaw_all_2.csv"

wintype="w"
width=1000.0
order=2
nrobust=1

open (10,file=trim(adjustl(sumpath))//"debug.dat")

! target ages for summary lowess curves
begtarg=-50.0
endtarg=16500.0
targstep=50.0
ntarg=int((endtarg-begtarg)/targstep)+1
do i=1,ntarg
    tage(i)=-50+(i-1)*50.0
    write (*,*) i,tage(i)
end do

open (1,file=sumspecs)
open (2,file=alldatfile)
open (3,file=sumfile)

qmiss=-9999.0       ! missing data code -- not really implemented here yet

allhdr="calage "; smhdr="calage "

! read summary specifications
read (1,*) title
write (*,*) title
read (1,*) nsites,(sitenum(j),j=1,nsites)
write (*,*) nsites
write (*,*) (sitenum(j),j=1,nsites)
read (1,*) nsum
write (*,*) nsum
do k=1,nsum
    read (1,*) sumtitle(k)
    write (*,'(a)') sumtitle(k)
    read (1,*) ninsum(k),(sumtaxaid(k,n),n=1,ninsum(k))
    write (*,'(40i4)') k,ninsum(k),(sumtaxaid(k,n),n=1,ninsum(k))
    allhdr=trim(adjustl(allhdr))//","//trim(adjustl(sumtitle(k)))
    smhdr=trim(adjustl(smhdr))//",sm_"//trim(adjustl(sumtitle(k)))
end do
write (*,*) allhdr
write (*,*) smhdr
write (2,'(a)') allhdr
write (3,'(a)') smhdr

calbp=0.0; sumtaxa=0.0

! read and accumulate data
ii=0
do j=1,nsites

    ! open input .csv file
    site_num_char=int_to_string2(sitenum(j),4)
    write (*,*) j,site_num_char
    open (4,file=trim(csvpath)//site_num_char//".csv")
    read (4,*) header
    
    ! create the output .csv file
    open (5,file=trim(sumpath)//site_num_char//"_summary.csv")
    write (5,'(a)') allhdr
    
    do while (.not.eof(4))
        ii=ii+1
        read (4,*) calbp(ii),(polin(n),n=1,ntaxa)
        do k=1,nsum
            do n=1,ninsum(k)
                sumtaxa(ii,k)=sumtaxa(ii,k)+polin(sumtaxaid(k,n))
            end do
        end do
        write (5,'(f9.2,80(",",f6.2))') calbp(ii),(sumtaxa(ii,k),k=1,nsum)
    end do
    close(4)
    close(5)

end do
npts=ii

! write accumulated data
do i=1,npts
    write (2,'(f9.2,80(",",f6.2))') calbp(i),(sumtaxa(i,k),k=1,nsum)
end do

! lowess curves

! sqrt transformation first
sumtaxa=sqrt(sumtaxa)

do k=1,nsum
    write (*,'(i6,a80)') k,sumtitle(k)
    call fitlwr2(npts,sumtaxa(:,k),qmiss,calbp,ntarg,tage,wintype,width,order,nrobust,smsumtaxa(:,k))
    do i=1,ntarg
        if (isnan(smsumtaxa(i,k))) smsumtaxa(i,k)=0.0
    end do  
end do

! untransform smoothed values
smsumtaxa=smsumtaxa**2.0

! write smoothed data
do i=1,ntarg
    write (3,'(f9.2,80(",",f6.2))') tage(i),(smsumtaxa(i,k),k=1,nsum)
end do

end program summary_pollen

    


