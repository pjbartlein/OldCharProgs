program setup_pollen
! creates .csv files for individual sites (entities)

use uo_utils

implicit none

integer, parameter  :: maxdata=5000, maxsites=2000, ntaxa=67
integer(4)          :: site_num(maxsites),nsamples(maxsites),site_num_in,current
integer(4)          :: nsites
real(4)             :: entity(maxdata),depth(maxdata),calage(maxdata),agebp(maxdata),sumt(maxdata)
real(4)             :: pol(maxdata,ntaxa)

integer             :: i,j,k,kk
character(32)       :: taxon_name(ntaxa)
character(256)      :: csvpath,infile,namesfile
character(4)        :: site_num_char
character(8)        :: dum

infile="\Projects\igbpfire\nachar\data\na_pollen\PCnt2Prct32c2withTotals2.dat"
csvpath="\Projects\igbpfire\nachar\data\pollen_site_csv\"
namesfile="\Projects\igbpfire\nachar\data\na_pollen\taxon_names.dat"

open (10,file="\Projects\igbpfire\nachar\data\pollen_site_csv\debug.dat")

! open the input data set, and count number of sites and number of samples for each site
write (*,'(a)') "Counting number of sites, and samples..."
open(1,file=infile)
read (1,*) dum      ! read header
i=0; j=1
read (1,*) site_num_in  ! read first record
current=site_num_in
do
    if (eof(1)) then 
        nsamples(j)=i
        site_num(j)=int(current)
        exit    ! exit loop if at end of file
    end if
    read (1,*) site_num_in
        i=i+1
        if (site_num_in .ne. current) then    ! site number has changed
            nsamples(j)=i
            site_num(j)=int(current)
            current=site_num_in
            j=j+1
            i=0
        end if
end do
nsites=j

do j=1,nsites
    write (*,'(3i5)') j,site_num(j),nsamples(j)
end do

! read pollen taxon names
open (2,file=namesfile)
do k=1,ntaxa
    read (2,*) kk,taxon_name(k)
    write (*,'(i4,1x,a32)') k,taxon_name(k)
end do
close(2)

rewind(1)   ! rewind the input file
read (1,*) dum      ! read header

do j=1,nsites   ! loop over the sites

    ! read the data for the j-th site
    write (*,*) j,site_num(j),nsamples(j)
    do i=1,nsamples(j)
        read (1,*) entity(i),depth(i),calage(i),agebp(i),sumt(i),(pol(i,k),k=1,ntaxa)
    end do
    write (10,'(2i6,f6.0,2(f11.2,f6.2),i6)') j,site_num(j),entity(1),calage(1),pol(1,1),calage(nsamples(j)),pol(nsamples(j),1),nsamples(j)
                 
    ! create the .csv file for j-th site and write out data
    site_num_char=int_to_string2(site_num(j),4)
    open (3,file=trim(csvpath)//site_num_char//".csv")
    write (3,'("calage",a4,67(",",a32))') site_num_char,(taxon_name(k),k=1,ntaxa)
    do i=1,nsamples(j)
        write (3,'(f9.2,67(",",f6.2))') calage(i),(pol(i,k),k=1,ntaxa)
    end do
    close(3)  

end do 

end
