program summarize
! summarize charcoal data

use summarize_subs

implicit none

! declarations -- other declarations are in module summarize_subs

integer(4)      :: id_site(maxdata)                     ! site id's
integer(4)      :: id_sample(maxdata)                   ! sample id's
real(4)         :: age_in(maxdata),age(maxrec)          ! ages
character(4)    :: id_units(maxdata)                    ! units of measurement
character(4)    :: context_in(maxdata)
real(4)         :: quant_in(maxdata),quant(maxrec)      ! quantity
real(4)         :: lat(maxdata),lon(maxdata)            ! decimal lat and lon
real(4)         :: site_lat(maxsites)
real(4)         :: site_lon(maxsites)            ! decimal lat and lon
real(4)         :: qmiss                                ! quantity missing data code

integer(4)      :: site(maxsites), npts(maxsites)       ! site id's and number of points in block
integer(4)      :: bstart(maxsites),bend(maxsites)      ! block start and end obs numbers
character(4)    :: units(maxsites)                      ! units of measurement for block 
character(4)    :: context(maxsites)

real(4)         :: trans,tquant(maxrec)                 ! transformation parameter and series

real(4)         :: begbase,endbase                      ! beginning and end of base period for stats
real(4)         :: mean,stdev,qmin,qmax,qrng            ! basic stats for an interval (no trans)
real(4)         :: meant,stdevt,qmint,qmaxt,qrngt       ! basic stats for an interval (transformed)

real(4)         :: z(maxrec),zt(maxrec)                 ! zscores
real(4)         :: qmnx(maxrec),qmnxt(maxrec)            ! minimax transformed

real(4)         :: agetarg1,agetarg2                    ! target ages
real(4)         :: qclose1,qclose2,zqclose1,zqclose2    ! values at points closest to target ages
real(4)         :: qage1,qage2                          ! ages at points closest to target ages

real(4)         :: begrng1,endrng1,begrng2,endrng2      ! beginnings and ends of two age ranges
real(4)         :: mean1,stdev1,qmin1,qmax1,qrng1       ! interval stats, untransformed
real(4)         :: mean2,stdev2,qmin2,qmax2,qrng2       ! interval stats, untransformed
real(4)         :: intdiff,zintdiff                     ! plain and standardized interval differences
real(4)         :: mean1t,stdev1t,qmin1t,qmax1t,qrng1t  ! interval stats, transformed
real(4)         :: mean2t,stdev2t,qmin2t,qmax2t,qrng2t  ! interval stats, transformed
real(4)         :: intdifft,zintdifft                   ! plain and standardized interval differences
real(4)         :: targdiff,targdifft                   ! differences between to target ages

real(4)         :: modernz1,modernz2                    ! modern approximations
integer(4)      :: modnbase1,modnbase2
real(4)         :: modmeanz1,modmeanz2
real(4)         :: modstdevz1,modstdevz2
real(4)         :: modqmintz1,modqmintz2
real(4)         :: modqmaxtz1,modqmaxtz2
real(4)         :: modqrngz1,modqrngz2

integer(4)      :: nvars                                ! number of variables
character(8)    :: varname(maxvars)                     ! varname
character(72)   :: vartitle(maxvars)                    ! variable title

 
integer(4)      :: i,ii,j,k,ndata,nsites,nbase

!open (1,file="E:\Projects\igbpfire\charsum\data\Test1.csv")
!open (2,file="E:\Projects\igbpfire\charsum\data\Test1_samples.csv")
!open (3,file="E:\Projects\igbpfire\charsum\data\Test1_sites.csv")
open (1,file="E:\Projects\igbpfire\charsum\data\xls\b6.txt")
open (2,file="E:\Projects\igbpfire\charsum\data\xls\b6_samples.csv")
open (3,file="E:\Projects\igbpfire\charsum\data\xls\b6_site.csv")
open (4,file="E:\Projects\igbpfire\charsum\data\work01\b6_site.dat")
open (5,file="E:\Projects\igbpfire\charsum\data\work01\varlist.dat")

! set summarization parameter values
qmiss=-9999.0       ! missing data code
begbase=-80.0       ! begining of base period
endbase=4000.0      ! end of base period
agetarg1=-60.0      ! target age
agetarg2=6000.0     ! target age
begrng1=-60.0       ! beginning of interval averaging period 1
endrng1=500.0       ! end of interval averaging period 1
begrng2=5500.0      ! beginning of interval averaging period 2
endrng2=6500.0      ! end of interval averaging period 2

! read all data and determine number of blocks
call read_data(ndata,lat,lon,id_site,id_sample,id_units,age_in,quant_in,context_in, &
                nsites,site_lat,site_lon,site,units,context,bstart,bend,npts)
                
i=0
do while(.not.eof(5))
    i=i+1
    read (5,'(a8,5x,a72)') varname(i)
end do
nvars=i

! write headers
write (2,'(a)') 'lat,lon,id_site, id_sample, age, id_units, quant, z, qmxn, tquant, zt, qmnxt' 
write (3,'(30(a8,", "))') (varname(i),i=1,nvars)


! loop over site id/units blocks

do j=1,nsites
    write (*,*) j,site_lat(j),site_lon(j),site(j)
    
    ! load arrays
    ii=0
    do i=bstart(j),bend(j)
        ii=ii+1
        age(ii)=age_in(i)
        quant(ii)=quant_in(i)
    end do  
    
    ! call summarization subroutines for this block
    
    ! log10 transform charcoal quantities
    trans=0.0
    call transform(npts(j),trans,quant,qmiss,tquant)   
    
    ! basic statistics for an interval, no transformation
    call stats(npts(j),age,quant,qmiss,begbase,endbase,nbase,mean,stdev,qmin,qmax,qrng)
    
    ! basic statistics for an interval from transformed values
    call stats(npts(j),age,tquant,qmiss,begbase,endbase,nbase,meant,stdevt,qmint,qmaxt,qrngt)
    
    ! z-scores of untransformed values
    call zscores(npts(j),quant,qmiss,mean,stdev,z)
    
    ! z-scores of transformed values
    call zscores(npts(j),tquant,qmiss,meant,stdevt,zt)
    
    ! minimax transformation -- raw values
    call minimax(npts(j),age,quant,qmiss,qmin,qmax,qmnx)
    
    ! minimax transformation -- log transformed values
    call minimax(npts(j),age,tquant,qmiss,qmint,qmaxt,qmnxt)
    
    ! values at points closest to target ages
    call closest(npts(j),age,quant,qmiss,agetarg1,qclose1,qage1)
    call closest(npts(j),age,quant,qmiss,agetarg2,qclose2,qage2)
    
    ! difference between points closest to two target ages
    call binarydiff(qclose1,qclose2,qmiss,targdiff)
    
    ! difference between two intervals, untransformed values
    call stats(npts(j),age,quant,qmiss,begrng1,endrng1,nbase,mean1,stdev1,qmin1,qmax1,qrng1)
    call stats(npts(j),age,quant,qmiss,begrng2,endrng2,nbase,mean2,stdev2,qmin2,qmax2,qrng2)
    call diff(mean1,mean2,qmiss,intdiff)
    
    ! difference between two intervals, z-scores of transformed values
    call stats(npts(j),age,zt,qmiss,begrng1,endrng1,nbase,mean1t,stdev1t,qmin1t,qmax1t,qrng1t)
    call stats(npts(j),age,zt,qmiss,begrng2,endrng2,nbase,mean2t,stdev2t,qmin2t,qmax2t,qrng2t)
    call diff(mean1t,mean2t,qmiss,intdifft)
    
    ! basic statistics for an interval from transformed values
    call stats(npts(j),age,zt,qmiss,100.,500.,modnbase1,modmeanz1,modstdevz1,modqmintz1,modqmaxtz1,modqrngz1)
    call stats(npts(j),age,zt,qmiss,250.,750.,modnbase2,modmeanz2,modstdevz2,modqmintz2,modqmaxtz2,modqrngz2)

    ii=0
    do i=bstart(j),bend(j)
        ii=ii+1
        write (2,'(f10.4,",",f10.4,",",i5,",",i6,",",f6.0," ," "",a4,"" ",",10(f14.4,","))') &
            lat(i),lon(i),id_site(i),id_sample(i),age_in(i),id_units(i),quant_in(i), &  
            z(ii),qmnx(ii),tquant(ii),zt(ii),qmnxt(ii)
    end do
    write (3,'(f10.4,",",f10.4,",",i5,",",a4,",",a4,",",2(i6,","),20(f14.2,","))') &
        site_lat(j),site_lon(j),site(j),units(j),context(j),npts(j),nbase,mean,stdev,meant,stdevt,qmin,qmax, &
        qclose1,qage1,qclose2,qage2,targdiff,mean1,mean2,intdiff,mean1t,mean2t,intdifft, &
        modmeanz1,modmeanz2,modqrngz1,modqrngz2      
    write (4,'(f10.4,f10.4,i5,2(1x,"""",a4"""")2i6,30f14.2)') &
        site_lat(j),site_lon(j),site(j),units(j),context(j),npts(j),nbase,mean,stdev,meant,stdevt,qmin,qmax, &
        qclose1,qage1,qclose2,qage2,targdiff,mean1,mean2,intdiff,mean1t,mean2t,intdifft, &
        modmeanz1,modmeanz2,modqrngz1,modqrngz2    
    
end do
close(2)
close(3)
           
end
    
