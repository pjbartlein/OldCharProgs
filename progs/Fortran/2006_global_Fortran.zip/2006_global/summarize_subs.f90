module summarize_subs

    integer, parameter  :: maxdata=50000, maxrec=5000, maxsites=500

contains

subroutine read_data(ndata,lat_in,lon_in,id_site_in,id_sample_in,id_units_in,age_in, quant_in, &
                        nsites,site,units,bstart,bend,npts)    

    implicit none

    integer(4)          :: id_site_in(maxdata),id_sample_in(maxdata)
    real(4)             :: age_in(maxdata),quant_in(maxdata)
    real(4)             :: lat_in(maxdata),lon_in(maxdata)
    character(4)        :: id_units_in(maxdata)
    
    integer(4)          :: site(maxsites), npts(maxsites)
    integer(4)          :: bstart(maxsites),bend(maxsites)     
    character(4)        :: units(maxsites)
    integer(4)          :: ndata,nsites
    
    integer(4)          :: i,ii,j,k
    character(1)        :: dum

    site=0; npts=0

    read (1,*) dum  ! read old header
     
    ! read first record
    i=1
!    read (1,*) id_site_in(i),id_sample_in(i),est_age_in(i),id_units_in(i),quant_in(i)
    read (1,*) id_site_in(i),id_units_in(i),id_sample_in(i),age_in(i),quant_in(i),lat_in(i),lon_in(i)

    !write (*,'(f10.4,",",f10.4","i5,",",i6,",",f6.0," ,",a4,",",f11.2)') &
    !        lat_in(i),lon_in(i),id_site_in(i),id_sample_in(i),age_in(i),id_units_in(i),quant_in(i)

    ! read remaining records
    ii=0; j=1
    bstart(j)=1
    do while(.not. eof(1))
        i=i+1
!        read (1,*) id_site_in(i),id_sample_in(i),age_in(i),id_units_in(i),quant_in(i)
        read (1,*) id_site_in(i),id_units_in(i),id_sample_in(i),age_in(i),quant_in(i),lat_in(i),lon_in(i)
    !    write (2,'(i5,",",i6,",",f6.0," ,",a4,",",f10.2)') &
    !            id_site_in(i),id_sample_in(i),age_in(i),id_units_in(i),quant_in(i)
        !write (*,'(f10.4,",",f10.4","i5,",",i6,",",f6.0," ,",a4,",",f11.2)') &
        !    lat_in(i),lon_in(i),id_site_in(i),id_sample_in(i),age_in(i),id_units_in(i),quant_in(i)

        ! check to see if id_site is the same as previous sample
        
        if (id_site_in(i) .eq. id_site_in(i-1) .and. id_units_in(i) .eq. id_units_in(i-1)) then
            ii=ii+1     ! same site and/or data type: count number of pts for site j
        else ! new site and/or data type, save number of observations          
            site(j)=id_site_in(i-1)     ! id of jth site
            units(j)=id_units_in(i-1)
            npts(j)=ii+1               ! number of observations jth site
            bend(j)=bstart(j)+npts(j)-1
            bstart(j+1)=bend(j)+1
            j=j+1
            ii=0
        end if
            
    end do
    ndata=i; nsites=j
    
    ! last block
    site(j)=id_site_in(i-1)
    units(j)=id_units_in(i-1)
    npts(j)=ii+1
    bend(j)=bend(j-1)+npts(j)
    
end subroutine read_data

subroutine transform(n,trans,quant,qmiss,tquant)

    implicit none

    integer, intent(in)     :: n
    real(4), intent(in)     :: trans
    real(4), intent(in)     :: quant(n),qmiss
    real(4), intent(out)    :: tquant(n)
    real(4)                 :: qmin,qadd

    integer(4)              :: i

! transformation
    
    tquant=qmiss
    if (trans .eq. 1.0) then        ! no transformation
        do i=1,n
            if (quant(i).ne.qmiss) tquant(i)=quant(i)
        end do
        
    elseif (trans .eq. 0.5) then    ! square-root transformation
        do i=1,n
            if (quant(i).ne.qmiss) tquant(i)=sqrt(quant(i))
        end do 
        
    elseif (trans .eq. 0.0) then    ! log10 transformation
        !qmin=9999999.0
        !do i=1,n
        !    if (quant(i).ne.qmiss) then
        !        if (quant(i) .le. qmin) qmin=quant(i)
        !    end if
        !end do
        !if (qmin.ne.0.0) then
        !    qadd=1.05*qmin
        !else
        !    qadd=0.1
        !end if
        !write (*,*) qmin,qadd
        qadd=0.1
        do i=1,n
            if (quant(i) .ne. qmiss) tquant(i)=log10(quant(i)+qadd)
        end do
    
    else                            ! other transformation
        stop "don't know transformation"
    end if
    
end subroutine transform

subroutine stats(n,age,q,qmiss,begbase,endbase,nvals,mean,stdev,qmin,qmax,qrng)

    implicit none

    integer, intent(in)     :: n
    real(4), intent(in)     :: age(n),q(n),qmiss
    real(4), intent(in)     :: begbase,endbase
    real(4), intent(out)    :: mean,stdev,qmax,qmin,qrng
    integer, intent(out)    :: nvals

    integer(4)              :: i    
    
    ! mean
    nvals=0; mean=0.0
    do i=1,n
        if (q(i).ne.qmiss .and. age(i).ge.begbase .and. age(i).le.endbase) then
            mean=mean+q(i)
            nvals=nvals+1
        end if
    end do
    if (nvals.ne.0) then
        mean=mean/real(nvals)
    else
        mean=qmiss
    end if
    
    ! standard deviation
    stdev=0.0
    do i=1,n
        if (q(i).ne.qmiss .and. age(i).ge.begbase .and. age(i).le.endbase) then
            stdev=stdev+(q(i)-mean)*(q(i)-mean)
        end if
    end do
    if (nvals.gt.1) then
        stdev=sqrt((stdev)/real(nvals-1))
    else
        stdev=qmiss
    end if
    
    ! min, max, range
    qmin=9999999.0; qmax=-9999999.0
    do i=1,n
        if (q(i).ne.qmiss .and. age(i).ge.begbase .and. age(i).le.endbase) then
            if (q(i) .le. qmin) qmin=q(i)
            if (q(i) .ge. qmax) qmax=q(i)
        end if
    end do
    qrng=qmax-qmin

end subroutine stats

subroutine zscores(n,quant,qmiss,mean,stdev,z)

    implicit none

    integer, intent(in)     :: n
    real(4), intent(in)     :: quant(n),qmiss
    real(4), intent(in)     :: mean,stdev
    real(4), intent(out)    :: z(n)

    integer(4)              :: i
    
    ! zscores
    z=qmiss
    if (mean.ne.qmiss .and. stdev.ne.qmiss .and. stdev.ne.0.0) then
        do i=1,n
            if (quant(i).ne.qmiss) z(i)=(quant(i)-mean)/stdev
        end do
    end if
    
end subroutine zscores

subroutine minimax(n,age,q,qmiss,qmin,qmax,qmnx)

implicit none

    integer, intent(in)     :: n
    real(4), intent(in)     :: age(n),q(n),qmiss
    real(4), intent(in)     :: qmin,qmax
    real(4), intent(out)    :: qmnx(n)

    integer(4)              :: i
       
    qmnx=qmiss
    do i=1,n
        if (q(i).ne.qmiss) then
            qmnx(i)=(q(i)-qmin)/(qmax-qmin)
        end if
    end do
    
end subroutine minimax       

subroutine closest(n,age,q,qmiss,agetarg,qclose,ageclose)

    implicit none

    integer, intent(in)     :: n
    real(4), intent(in)     :: age(n),q(n),qmiss
    real(4), intent(in)     :: agetarg
    real(4), intent(out)    :: qclose,ageclose
    
    real(4)                 :: agediff,mindiff
    integer(4)              :: i,imin
    
    mindiff=9999999.0
    do i=1,n
        if (q(i).ne.qmiss) then
            agediff=abs(agetarg-age(i))
            if (agediff.lt.mindiff) then
                mindiff=agediff
                imin=i
            end if
        end if
    end do
    qclose=q(imin)
    ageclose=age(imin)
    
end subroutine closest

subroutine difference(mean1,mean2,qmiss,mean,stdev,intdiff,zintdiff)

    implicit none
    
    real(4), intent(in)     :: qmiss,mean1,mean2
    real(4), intent(in)     :: mean,stdev
    real(4), intent(out)    :: intdiff,zintdiff
    
    intdiff=qmiss; zintdiff=qmiss
    if (mean1.ne.qmiss .and. mean2.ne.qmiss) then
        intdiff=mean2-mean1
        zintdiff=(mean2-mean1)/stdev
    end if

end subroutine difference

end module summarize_subs