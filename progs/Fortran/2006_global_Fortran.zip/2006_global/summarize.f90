program summarize
! summarize charcoal data

use summarize_subs

implicit none

! declarations -- other declarations are in module summarize_subs

integer(4)      :: id_site(maxdata)                     ! site id's
integer(4)      :: id_sample(maxdata)                   ! sample id's
real(4)         :: age_in(maxdata),age(maxrec)          ! ages
character(4)    :: id_units(maxdata)                    ! units of measurement
real(4)         :: quant_in(maxdata),quant(maxrec)      ! quantity
real(4)         :: lat(maxdata),lon(maxdata)            ! decimal lat and lon
real(4)         :: qmiss                                ! quantity missing data code

integer(4)      :: site(maxsites), npts(maxsites)       ! site id's and number of points in block
integer(4)      :: bstart(maxsites),bend(maxsites)      ! block start and end obs numbers
character(4)    :: units(maxsites)                      ! units of measurement for block 

real(4)         :: trans,tquant(maxrec)                 ! transformation parameter and series

real(4)         :: begbase,endbase                      ! beginning and end of base period for stats
real(4)         :: mean,stdev,qmin,qmax,qrng            ! basic stats for an interval (no trans)
real(4)         :: meant,stdevt,qmint,qmaxt,qrngt       ! basic stats for an interval (transformed)

real(4)         :: z(maxrec),zt(maxrec)                 ! zscores
real(4)         :: qmnx(maxrec)                         ! minimax transformed

real(4)         :: agetarg1,agetarg2                    ! target ages
real(4)         :: qclose1,qclose2,zqclose1,zqclose2    ! values at points closest to target ages
real(4)         :: qage1,qage2                          ! ages at points closest to target ages

real(4)         :: begrng1,endrng1,begrng2,endrng2      ! beginnings and ends of two age ranges
real(4)         :: mean1,stdev1,qmin1,qmax1,qrng1       ! interval stats, untransformed
real(4)         :: mean2,stdev2,qmin2,qmax2,qrng2       ! interval stats, untransformed
real(4)         :: intdiff,zintdiff                     ! plain and standardized interval differences
real(4)         :: mean1t,stdev1t,qmin1t,qmax1t,qrng1t  ! interval stats, transformed
real(4)         :: mean2t,stdev2t,qmin2t,qmax2t,qrng2t  ! interval stats, transformed
real(4)         :: intdifft,zintdifft                     ! plain and standardized interval differences

 
integer(4)      :: i,ii,j,k,ndata,nsites,nvals

!open (1,file="E:\Projects\igbpfire\charsum\data\Test1.csv")
!open (2,file="E:\Projects\igbpfire\charsum\data\Test1_samples.csv")
!open (3,file="E:\Projects\igbpfire\charsum\data\Test1_sites.csv")
open (1,file="E:\Projects\igbpfire\charsum\data\DirtyDataSorted.csv")
open (2,file="E:\Projects\igbpfire\charsum\data\DirtyDataSorted_samples.csv")
open (3,file="E:\Projects\igbpfire\charsum\data\DirtyDataSorted_sites.csv")

! set summarization parameter values
qmiss=-9999.0       ! missing data code
begbase=-80.0       ! begining of base period
endbase=4000.0      ! end of base period
agetarg1=-60.0      ! target age
agetarg2=6000.0     ! target age
begrng1=-60.0       ! beginning of interval averaging period 1
endrng1=500.0       ! end of interval averaging period 1
begrng2=5500.0      ! beginning of interval averaging period 2
endrng2=6500.0      ! end of interval averaging period 2

! read all data and determine number of blocks
call read_data(ndata,lat,lon,id_site,id_sample,id_units,age_in,quant_in, &
                nsites,site,units,bstart,bend,npts)

! write headers
write (2,'(a)') 'lat,lon,id_site, id_sample, age, id_units, quant, z, zt, qmnx' 
write (3,'(a)') 'lat,lon,id_site, id_units, npts, nvals, mean, stdev, meant, stdevt, qmin, qmax, '// &
                    'q0, age_q0, q6, age_q6, meanint1, meanint2, intdiff, zintdiff, '// &
                    'meanint1t, meanint2t, intdifft, zintdifft'
! loop over site id/units blocks

do j=1,nsites
    
    ! load arrays
    ii=0
    do i=bstart(j),bend(j)
        ii=ii+1
        age(ii)=age_in(i)
        quant(ii)=quant_in(i)
    end do  
    
    ! call summarization subroutines for this block
    
    ! log10 transform charcoal quantities
    trans=0.0
    call transform(npts(j),trans,quant,qmiss,tquant)   
    
    ! basic statistics for an interval, no transformation
    call stats(npts(j),age,quant,qmiss,begbase,endbase,nvals,mean,stdev,qmin,qmax,qrng)
    
    ! basic statistics for an interval from transformed values
    call stats(npts(j),age,tquant,qmiss,begbase,endbase,nvals,meant,stdevt,qmint,qmaxt,qrngt)
    
    ! z-scores of untransformed values
    call zscores(npts(j),quant,qmiss,mean,stdev,z)
    
    ! z-scores of transformed values
    call zscores(npts(j),tquant,qmiss,meant,stdevt,zt)
    
    ! minimax transformation
    call minimax(npts(j),age,quant,qmiss,qmin,qmax,qmnx)
    
    ! values at points closest to target ages
    call closest(npts(j),age,quant,qmiss,agetarg1,qclose1,qage1)
    call closest(npts(j),age,quant,qmiss,agetarg2,qclose2,qage2)
    
    ! difference between two intervals, untransformed values
    call stats(npts(j),age,quant,qmiss,begrng1,endrng1,nvals,mean1,stdev1,qmin1,qmax1,qrng1)
    call stats(npts(j),age,quant,qmiss,begrng2,endrng2,nvals,mean2,stdev2,qmin2,qmax2,qrng2)
    call difference(mean1,mean2,qmiss,mean,stdev,intdiff,zintdiff)
    
    ! difference between two intervals, transformed values
    call stats(npts(j),age,tquant,qmiss,begrng1,endrng1,nvals,mean1t,stdev1t,qmin1t,qmax1t,qrng1t)
    call stats(npts(j),age,tquant,qmiss,begrng2,endrng2,nvals,mean2t,stdev2t,qmin2t,qmax2t,qrng2t)
    call difference(mean1t,mean2t,qmiss,meant,stdevt,intdifft,zintdifft)

    ii=0
    do i=bstart(j),bend(j)
        ii=ii+1
        write (2,'(f10.4,",",f10.4,",",i5,",",i6,",",f6.0," ,",a4,",",10(f13.4,","))') &
            lat(i),lon(i),id_site(i),id_sample(i),age_in(i),id_units(i),quant_in(i), &  
            z(ii),zt(ii),qmnx(ii)
    end do
    write (3,'(f10.4,",",f10.4,",",i5," ,",a4,", ",2(i6,","),20(f13.4,","))') &
        lat(i),lon(i),site(j),units(j),npts(j),nvals,mean,stdev,meant,stdevt,qmin,qmax, &
        qclose1,qage1,qclose2,qage2,mean1,mean2,intdiff,zintdiff,mean1t,mean2t,intdifft,zintdifft  
    
end do
close(2)
close(3)
           
end
    
