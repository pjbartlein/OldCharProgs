program peak_concat
! concatentates peak records

implicit none

integer, parameter  :: nv=33, maxsites=2000
real(4)         :: age,peaks,invar(nv)
real(4)         :: begage,endage
integer         :: i,j,k,jj

character(80)   :: header
character(4)    :: site_num_char
character(8)    :: site_num_label
character(32)   :: int_to_string2
character(256)  :: datapath,outpath,allsamplesfile

datapath="e:\Projects\GPWG\work\wus\data\csv_files\"
outpath="e:\Projects\GPWG\work\wus\data\files\"  ! ######
allsamplesfile="wus_peaks_ts.csv" 

begage=-100.0; endage=3200.0

open (4,file=trim(outpath)//trim(allsamplesfile))
write (4,'(a)') "site,age,peaks" 

jj=0
do j=1,maxsites
    ! try to open a file
    site_num_char=int_to_string2(j,4)
    !write (*,'(a)') site_num_char
    open (1,file=trim(datapath)//trim(adjustl(site_num_char))//"_charResults.csv", status='old', err=100)
    
    jj=jj+1
    read (1,*) header
    write (*,'(2i5,2(1x,a8))') jj,j,site_num_char,site_num_label

    do while (.not. eof(1))
        i=i+1
        read (1,*) (invar(k),k=1,nv)
        age=invar(2); peaks=invar(19)
        if (age.gt.begage .and. age.lt.endage) then
            write (4,'(i4,",",f8.1,",",f4.1)') j,age,peaks
        end if
    end do
    close(1)
   
100 continue
    
end do

end

function int_to_string(inum)

	implicit none
	character(32)	:: int_to_string
	character(32)	:: buffer, str
	integer			:: inum

	write (buffer,*) inum
	read (buffer,*) str

	int_to_string=trim(adjustl(str))

end function int_to_string


function int_to_string2(inum,numlen)

	implicit none
	character(32)	:: int_to_string2,int_to_string
	character(32)	:: buffer, str
	character(8)	:: ifmt,iedit
	integer			:: inum,numlen

	iedit=int_to_string(numlen)
	ifmt="(i"//trim(adjustl(iedit))//"."//trim(adjustl(iedit))//")"

	write (buffer,ifmt) inum
	read (buffer,*) str

	int_to_string2=trim(adjustl(str))

end function int_to_string2
