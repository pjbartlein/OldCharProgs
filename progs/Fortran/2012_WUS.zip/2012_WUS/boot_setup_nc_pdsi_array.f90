program boot_setup_nc_pdsi_array
! writes out data for bootstrap-by-group curve fitting

use netCDF_subs

implicit none

integer, parameter  :: nlon=33, nlat=19, nt=2007, fyr=0, npts=56 ! Cook et al.
real(8)             :: lon(nlon),lat(nlat)
real(8)             :: cft(nt),area(nlat)
real                :: var3d(nlon,nlat,nt),array(nt,npts)
integer             :: col,row,seqnum,sitenum

integer             :: j,k,l,n

character(1024)     :: ncfile,ptsfile,outfile,areafile
character(80)       :: header

ncfile="e:\Projects\drought\data_2008\distrib\NADAv2-2008.nc"
areafile="e:\Projects\drought\data_2008\derived\grid_lat_area.dat"
ptsfile="e:\Projects\GPWG\work\wus\data\climate\wus_pdsi_pts.csv"
outfile="e:\Projects\GPWG\work\wus\data\climate\wus_pdsi_array.dat"

! get tmp anomalies and grid-cell areas
call netcdf_open(ncfile,0,ncid)
call netcdf_get_1d_double(ncid,nlat,'lat',lat) 
call netcdf_get_1d_double(ncid,nlon,'lon',lon) 
call netcdf_get_1d_double(ncid,nt,'time',cft) 
call netcdf_get_3d_real(ncid,nlon,nlat,nt,'PDSI',var3d)   
call netcdf_close(ncfile,ncid)   
open (3,file=trim(areafile))
read (3,'(a)') header
do k=1,nlat
    read (3,*) lat(k),area(k)
end do

go to 10
open (1,file=ptsfile)
write (1,'(a)') "col, row, lon, lat, area"
do j=1,nlon
    do k=1,nlat
        write (1,'(i3,", ",i3,2(", ",f8.1),", ",f10.2)') j,k,lon(j),lat(k),area(k)
    end do
end do
close (1)
stop
10 continue

open (1,file=ptsfile)
read (1,'(a)') header
open (2,file=outfile)

array=-9999.0
do l=1,npts
    read (1,*) j,k
    do n=1,nt
        if (isnan(var3d(j,k,n))) then
            array(n,l)=-9999.0
        else
            array(n,l)=var3d(j,k,n)
        end if
    end do
end do

do n=nt,1,-1
    write (2,'(f6.0,1x,300f10.3)') cft(n),(array(n,l),l=1,npts)
end do
        
end