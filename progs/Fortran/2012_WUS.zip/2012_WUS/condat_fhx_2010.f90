program concat_fhx_2010

implicit none

integer, parameter	:: ny=1001, maxtr=500, maxsites=500
integer, parameter	:: begyr=1000, endyr=2010, begdec=1, enddec=101

integer				:: fs(begyr:endyr,maxsites) !,fs_dec(maxsites)
!integer             :: nreportsyr(begyr:endyr),nscaryr(begyr:endyr)
!integer             :: nreportsdec(begdec:enddec),nscardec(begdec:enddec)
real				:: declat,declon,lat(maxsites),lon(maxsites),ulat,ulon
real                :: propscaryr(begyr:endyr),propscardec(begdec:enddec)

integer				:: i,j,k,l,m,mm,d,n,nsites,firstyr,ntr,nid,year,nnull,nrec,nscar,ndecrec,ndecscar

character(128)		:: datapath,sitefile,sitename(maxsites)
character(32)		:: llbuffer,utmeastbuffer,utmnorthbuffer
character(16)		:: prefix,region
character(12)		:: fs_file(maxsites)
character(32)		:: ch_year
character(5)		:: fmt,dum
character(1)		:: fs_buffer(maxtr+6),fs_char(begyr:endyr,maxtr+6),header

logical				:: found

region="w104"

datapath="e:\Projects\IMPD\2010\data\fhx\"

open (2,file="e:\Projects\IMPD\2010\data\fhx_loc_"//trim(region)//".csv")
!open (3,file="e:\Projects\IMPD\2010\data\scar_"//trim(region)//".dat")
!open (5,file="e:\Projects\IMPD\2010\data\scar_dec_"//trim(region)//".dat")
!open (6,file="e:\Projects\IMPD\2010\data\prop_scar_ann_"//trim(region)//".csv")
!open (7,file="e:\Projects\IMPD\2010\data\prop_scar_dec_"//trim(region)//".csv")
open (8,file="e:\Projects\IMPD\2010\data\pts_"//trim(region)//".csv")
!open (9,file="e:\Projects\IMPD\2010\data\pts_scar_"//trim(region)//".csv")

read (2,*) header
!write (6,'(a)') "Year,NReport,NScar,PropScar"
!write (7,'(a)') "Year,NReport,NScar,PropScar"
write (8,'(a)') "seqnum, sitenum, age, scar, lat, lon" ! "Site,lat,lon,Year"
!write (9,'(a)') "Site,lat,lon,Year"

fs=-9

i=0
do while (.not.eof(2))
	i=i+1
	read (2,*) lat(i),lon(i),fs_file(i)
	write (*,'(/"Site:")')
	write (*,*) fs_file(i)
	sitefile=trim(adjustl(datapath))//trim(adjustl(fs_file(i)))
	write (*,*) sitefile
	open (4,file=sitefile)

	! scan for "FHX2" or "FIRE2"
	do 
		read (4,'(a5)') fmt
		if (fmt.eq.'FHX2 ' .or. fmt.eq.'FIRE2') exit
	end do

	read (4,*) firstyr,ntr,nid
!	write (2,*) i,firstyr,fs_file(i),ntr,nid

	! skip nid lines
	do l=1,nid; read(4,*) dum; end do

	! read firescar data
	do while (.not. eof(4))
		read (4,'(221a1)') (fs_buffer(j),j=1,ntr+5)
		write (ch_year,'(5a1)') (fs_buffer(j),j=ntr+1,ntr+5)
!		write (*,*) ch_year
		read (ch_year,'(i5)') year
!		write (*,*) year
		if (year.ge.firstyr .and. year.ne.0) then
			do j=1,ntr
				fs_char(year,j)=fs_buffer(j)
			end do
		end if

		if (year.ge.firstyr) then
			nnull=0; nrec=0; nscar=0
			do j=1,ntr
!				write (*,'(2i6,a1)') l,year,fs_char(year,j)
!				pause
				select case (fs_char(year,j))
					case ('.')
						nnull=nnull+1
					case ('D','d','E','e','M','m','L','l','A','a','U','u')
						nscar=nscar+1
						nrec=nrec+1
					case default
						nrec=nrec+1
				end select
			end do
			if (nrec.gt.0) fs(year,i)=0
			if (nscar.gt.0) fs(year,i)=1
			if (fs(year,i).eq.0 .or. fs(year,i).eq.1) write (8,'(4(i5,","),f12.6,",",f12.6)') i,i,year,fs(year,i),lat(i),lon(i)


!			write (3,'(2i6,4i4,1x,230a1)') i,year,nnull,nrec,nscar,fs(year,i),(fs_char(year,j),j=1,ntr), &
!				(fs_buffer(j),j=ntr+1,ntr+5)
		end if

	end do 

!	if (year.ne.0) write (*,'(2i6,1x,221a1)') i,year,(fs_char(year,j),j=1,ntr)

	close (4)
	
	do m=begyr,endyr
	    
	end do
!	pause

end do
nsites=i
write (*,'("nsites = ",i5)') nsites


end
	
