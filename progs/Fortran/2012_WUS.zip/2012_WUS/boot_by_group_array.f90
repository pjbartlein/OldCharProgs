program boot_by_group
! fits a smooth lowess-type curve to transformed/standardized charcoal data
! gets bootstrap estimates of confidence intervals of lowess curve

use lowess
use ifport

implicit none

integer, parameter  :: maxdata=20000, maxtarg=10000, maxreps=5000
real(8), allocatable    :: xin(:),yinput(:,:),yin(:),area(:),areasum(:)

!integer         :: selgroup

real(8)         :: varmiss,lat,lon

real(4)         :: begyr,endyr
real(8)         :: xtarg(maxtarg),yfit(maxtarg),yfitse(maxtarg),fit_cu95(maxtarg),fit_cl95(maxtarg),ypredse(maxtarg)
real(8)         :: param,xspan(maxtarg)
real(8)         :: targbeg,targend,targstep
integer(4)      :: npfit(maxtarg),minpts,order,nrobust,ntarg
character(1)    :: wintype

real(8)         :: ranseed,randval
real(8)         :: yfit_reps(maxtarg,maxreps),temp(maxreps),sorttemp(maxreps)
real(8)         :: yfit_boot(maxtarg),yfit_boot_median(maxtarg),yfit_boot_stdev(maxtarg),yfit_boot_se(maxtarg)
real(8)         :: yfit_boot_cu95(maxtarg),yfit_boot_cl95(maxtarg)
integer         :: jmax,jmin,ncl95,ncu95,n50

integer         :: i,j,k,l,npts,row,col,nctrl,nreps,intype,ngroups,selgroup

character(256)  :: inpath,infile,ptsfile,outpath,outfile

character(80)   :: header

logical         :: yfitnan,nan 

intype=2

select case (intype)
    case (1)
        ! Mann et al. temperature
        inpath="e:\Projects\GPWG\work\wus\data\climate\"
        outpath=inpath
        infile="wus_tmp2k_array.dat"
        ptsfile="wus_tmp2k_pts.csv"
        outfile="wus_tann_array_100.csv"
        ngroups=14; nctrl=1507
        targbeg=500; targend=2000; targstep=10
    case (2)
        ! Cook et al. PDSI
        inpath="e:\Projects\GPWG\work\wus\data\climate\"
        outpath=inpath
        infile="wus_pdsi_array.dat"
        ptsfile="wus_pdsi_pts.csv"
        outfile="wus_pdsi_array_100.csv"
        ngroups=56; nctrl=2007
        targbeg=0; targend=2000; targstep=10
    case (3)
        ! Cook et al. PDSI
        inpath="e:\Projects\GPWG\work\wus\data\climate\"
        outpath=inpath
        infile="wus_pdsi_array.dat"
        ptsfile="wus_pdsi_pts.csv"
        outfile="wus_dai_array_100.csv"
        ngroups=56; nctrl=2007
        targbeg=0; targend=2000; targstep=10
end select 
varmiss=-9999.0

! lowess parameters
param=100.0d0
wintype='w'; minpts=30; order=1; nrobust=1     ! ############

! number of replications
nreps=1000

! data range
! begyr=targbeg; endyear=2006

! open files
open (1,file=trim(inpath)//trim(infile))
open (2,file=trim(inpath)//trim(ptsfile))
read (2,*) header
open (7,file=trim(outpath)//trim(outfile))
write (7,'("targ_age, fit_",i4.4,"_boot, sefit, fitcu95, fitcl95, np, " &
    "yfit_boot_mean, yfit_boot_median, yfit_boot_se, yfit_boot_cu95, yfit_boot_cl95, npts")') int(param)  ! ############
open (10,file=trim(outpath)//"debug.dat")

! allocate arrays
allocate(xin(nctrl),yinput(nctrl,ngroups),yin(nctrl),area(ngroups),areasum(nctrl))

! read data
do i=1,nctrl
    read (1,*) xin(i),(yinput(i,l),l=1,ngroups)
end do
! read areas
do l=1,ngroups
    read (2,*) col,row,lon,lat,area(l)
end do

! random number seed
call srand(100)

! generate target points
ntarg=int((targend-targbeg)/targstep)+1
write (*,*) param,targstep,ntarg,order,nrobust,wintype
!write (10,*) param,targstep,ntarg,order,nrobust,wintype
do i=1,ntarg
    xtarg(i)=targbeg+dble(i-1)*targstep
    !write (10,*) i,sngl(xtarg(i))
end do

varmiss=-9999.0

! bootstrap sampling and fitting

yfit_reps=0.0d0

do k=1,nreps

    areasum=0.0d0
    yin=0.0d0
    do j=1,ngroups

        ! select a group at random
        randval=rand(0)
        selgroup=int(randval*sngl(ngroups))+1
        write (10,'(3i6,f10.4)') k,j,selgroup,randval

        ! accumulate values
        do i=1,nctrl
            if (yinput(i,selgroup).ne.varmiss) then
                select case (intype)
                    case (1,2)
                        yin(i)=yin(i)+yinput(i,selgroup)*area(selgroup)
                    case (3)
                        if (yinput(i,selgroup).lt.-1.0) yin(i)=yin(i)+area(selgroup)
                    case default
                        stop "accumulate"
                end select
                areasum(i)=areasum(i)+area(selgroup)
                !write (10,'(4i6,4g14.4)') k,j,selgroup,i,yinput(i,selgroup),area(selgroup),yin(i),areasum(i)
            end if
        end do      
    end do
    
    do i=1,nctrl
        !write (10,'(2i6,4g14.4)') k,i,xin(i),yin(i),areasum(i),yin(i)/areasum(i)
        if (areasum(i).ne.0.0d0) then
            yin(i)=yin(i)/areasum(i)
        end if
    end do
    
    write (*,'(i5,\)') k !,npts,ntarg
    yfit=0.0d0; yfitse=0.0d0; fit_cu95=0.0d0; fit_cl95=0.0d0; npfit=0
    call lowess_curve(nctrl,xin,yin,ntarg,xtarg,wintype,param,minpts,order,nrobust,yfit,yfitse,ypredse,npfit,xspan)
    
    ! save fitted values
    do i=1,ntarg
        yfit_reps(i,k)=yfit(i)
        !write (10,'(2i6,2g14.4)') k,i,xin(i),yfit(i)
    end do

end do

! one more fit to get standard (unresampled) values
areasum=0.0d0
yin=0.0d0
do j=1,ngroups
    do i=1,nctrl
        if (yinput(i,j).ne.varmiss) then
            select case (intype)
                case (1,2)
                    yin(i)=yin(i)+yinput(i,j)*area(j)
                case (3)
                    if (yinput(i,j).lt.-1.0) yin(i)=yin(i)+area(j)
                case default
                    stop "unresampled"
            end select
            areasum(i)=areasum(i)+area(j)
            !write (10,'(4i6,4g14.6)') k,j,j,i,yinput(i,j),area(j),yin(i),areasum(i)
        end if
    end do
end do
        
do i=1,nctrl
    if (areasum(i).ne.0.0d0) then
        yin(i)=yin(i)/areasum(i)
    end if
end do
    
write (*,*) npts,ntarg
yfit=0.0d0; yfitse=0.0d0; fit_cu95=0.0d0; fit_cl95=0.0d0; npfit=0
call lowess_curve(nctrl,xin,yin,ntarg,xtarg,wintype,param,minpts,order,nrobust,yfit,yfitse,ypredse,npfit,xspan)

do i=1,ntarg
    if (.not. isnan(yfit(i))) then
        fit_cu95(i)=yfit(i)+2.0d0*yfitse(i)
        fit_cl95(i)=yfit(i)-2.0d0*yfitse(i)
    end if
end do

! get bootstrap estimates

ncl95=int(sngl(nreps)*0.025)
if (ncl95.le.0) ncl95=1
ncu95=int(sngl(nreps)*0.975)
if (ncu95.ge.nreps .or. ncu95.le.0) ncu95=nreps
n50=int(sngl(nreps)/2.0)
if (n50.ge.nreps .or. n50.le.0) n50=nreps
write (*,*) ncl95,ncu95,n50

yfit_boot=0.0d0; yfit_boot_stdev=0.0d0; yfit_boot_se=0.0d0; yfit_boot_cu95=0.0d0; yfit_boot_cl95=0.0d0
do i=1,ntarg
    do k=1,nreps
        yfit_boot(i)=yfit_boot(i)+yfit_reps(i,k)
    end do
    yfit_boot(i)=yfit_boot(i)/dble(nreps)
    !write (*,*) i,yfit_boot(i)
    do k=1,nreps
        yfit_boot_stdev(i)=yfit_boot_stdev(i)+(yfit_reps(i,k)-yfit_boot(i))*(yfit_reps(i,k)-yfit_boot(i))
        !write (*,*) i,k,yfit_reps(i,k),yfit_boot_stdev(i)
    end do
    !write (*,*) i,yfit_boot_stdev(i)
    yfit_boot_stdev(i)=dsqrt(yfit_boot_stdev(i)/dble(nreps-1))
    !write (*,*) i,yfit_boot_stdev(i)
    yfit_boot_se(i)=yfit_boot_stdev(i)/dsqrt(dble(nreps))
    temp(:)=yfit_reps(i,:)
    call sortx(nreps,temp,sorttemp)
    yfit_boot_cu95(i)=sorttemp(ncu95)
    yfit_boot_cl95(i)=sorttemp(ncl95)
    yfit_boot_median(i)=sorttemp(n50)
    
    ! replace Nan's 
    if (isnan(yfit(i))) then 
        yfit(i)=varmiss
        yfitse(i)=varmiss
        fit_cu95(i)=varmiss
        fit_cl95(i)=varmiss
    end if
    if (isnan(yfit_boot(i)))        yfit_boot(i)=varmiss
    if (isnan(yfit_boot_median(i))) yfit_boot_median(i)=varmiss
    if (isnan(yfit_boot_se(i)))     yfit_boot_se(i)=varmiss
    if (isnan(yfit_boot_cu95(i)))   yfit_boot_cu95(i)=varmiss
    if (isnan(yfit_boot_cl95(i)))   yfit_boot_cl95(i)=varmiss

    write (7,'(f10.2,4(",",f14.6),", ",i8,5(",",f14.6),",",f10.2)') & 
        xtarg(i),yfit(i),yfitse(i),fit_cu95(i),fit_cl95(i),npfit(i), &
        yfit_boot(i),yfit_boot_median(i),yfit_boot_se(i),yfit_boot_cu95(i),yfit_boot_cl95(i),xspan(i)
        
end do


close(7)

    
end



