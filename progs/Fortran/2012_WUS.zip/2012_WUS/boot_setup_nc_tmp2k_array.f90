program boot_setup_nc_tmp2k_array
! writes out data for bootstrap-by-group curve fitting

use netCDF_subs

implicit none

integer, parameter  :: nlon=72, nlat=36, nt=2006-500+1, fyr=500, npts=14 ! Mann et al.
real(8)             :: lon(nlon),lat(nlat)
real(8)             :: cft(nt),area(nlat)
real                :: var3d(nlon,nlat,nt),array(nt,npts)
integer             :: col,row,seqnum,sitenum

integer             :: j,k,l,n

character(1024)     :: ncfile,ptsfile,outfile
character(80)       :: header

ncfile="e:\Projects\tmp_2k\data\ncfiles\Mann2009_tmp.nc"
ptsfile="e:\Projects\GPWG\work\wus\data\climate\wus_tmp2k_pts.csv"
outfile="e:\Projects\GPWG\work\wus\data\climate\wus_tmp2k_array.dat"

! get tmp anomalies and grid-cell areas
call netcdf_open(ncfile,0,ncid)
call netcdf_get_1d_double(ncid,nlat,'lat',lat) 
call netcdf_get_1d_double(ncid,nlon,'lon',lon) 
call netcdf_get_1d_double(ncid,nt,'time',cft) 
call netcdf_get_3d_real(ncid,nlon,nlat,nt,'tmp_anm',var3d)   
call netcdf_get_1d_double(ncid,nlat,'area',area) 
call netcdf_close(ncfile,ncid)   

go to 10
open (1,file=ptsfile)
write (1,'(a)') "col, row, lon, lat, area"
do j=1,nlon
    do k=1,nlat
        write (1,'(i3,", ",i3,2(", ",f8.1),", ",f10.2)') j,k,lon(j),lat(k),area(k)
    end do
end do
close (1)
stop
10 continue

open (1,file=ptsfile)
read (1,'(a)') header
open (2,file=outfile)

array=-9999.0
do l=1,npts
    read (1,*) j,k
    array(:,l)=var3d(j,k,:)
end do

do n=1,nt
    write (2,'(f6.0,1x,300f10.3)') cft(n)+1901,(array(n,l),l=1,npts)
end do
        
end