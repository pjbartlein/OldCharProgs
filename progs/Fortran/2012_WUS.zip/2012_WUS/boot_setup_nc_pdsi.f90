program boot_setup_nc_pdsi
! writes out data for bootstrap-by-group curve fitting

use netCDF_subs

implicit none

integer, parameter  :: nlon=33, nlat=19, nt=2006-1+1, fyr=1 ! Cook et al.
real(8)             :: lon(nlon),lat(nlat)
real(8)             :: cft(nt),area(nlat)
real                :: var3d(nlon,nlat,nt)
integer             :: col,row,seqnum,sitenum

integer             :: j,k,l,n,jj,kk,iyr,nonmiss

character(1024)     :: ncfile,ptsfile,outfile

ncfile="e:\Projects\drought\data_2008\distrib\NADAv2-2008.nc"
outfile="e:\Projects\tmp_2k\data\boot_data\wus_boot.csv"

! get tmp anomalies and grid-cell areas
call netcdf_open(ncfile,0,ncid)
call netcdf_get_1d_double(ncid,nlat,'lat',lat) 
call netcdf_get_1d_double(ncid,nlon,'lon',lon) 
call netcdf_get_3d_real(ncid,nlon,nlat,nt,'PDSI',var3d)   
call netcdf_close(ncfile,ncid)   

open (2,file=outfile)
write (2,'(a)') "seqnum, sitenum, year, tmp, lon, lat" 

seqnum=0; sitenum=0
do j=6,14
    do k=6,14
        do n=1,nt
            if (isnan(pdsi(j,k,n))) nonmiss=nonmiss+1
        end do
        
! not done yet       
        
        
        do l=1,npts
            read (1,*) col,row
            sitenum=l
            do n=1,nt
                seqnum=seqnum+1
                iyr=(n-1)+fyr
                write (2,'(3(i6,","),f10.4,", ",2f10.2)') seqnum,sitenum,iyr,var3d(col,row,n),lon(j),lat(k)
            end do
        end do
    
    end do
end do
        
 

end