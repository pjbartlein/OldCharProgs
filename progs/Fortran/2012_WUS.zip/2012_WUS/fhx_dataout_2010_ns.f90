program fhx_dataout_2010_ns

implicit none

integer, parameter	:: ny=1001, maxtr=500, maxsites=500
integer, parameter	:: begyr=1000, endyr=2010, begdec=1, enddec=101

integer				:: fs(begyr:endyr,maxsites),fs_dec(maxsites)
integer             :: nreportsyr(begyr:endyr),nscaryr(begyr:endyr)
integer             :: nreportsdec(begdec:enddec),nscardec(begdec:enddec)
real				:: declat,declon,lat(maxsites),lon(maxsites),ulat,ulon
real                :: propscaryr(begyr:endyr),propscardec(begdec:enddec)

integer				:: i,j,k,l,m,mm,d,n,nsites,firstyr,ntr,nid,year,nnull,nrec,nscar,ndecrec,ndecscar,scarcut

character(128)		:: datapath,sitefile,sitename(maxsites)
character(32)		:: llbuffer,utmeastbuffer,utmnorthbuffer
character(16)		:: prefix,region,outstr
character(12)		:: fs_file(maxsites)
character(32)		:: ch_year
character(5)		:: fmt,dum
character(1)		:: fs_buffer(maxtr+6),fs_char(begyr:endyr,maxtr+6),header

logical				:: found

region="s42n"
scarcut=1
outstr="fs1"

datapath="e:\Projects\IMPD\2010\data\fhx\"

open (2,file="e:\Projects\IMPD\2010\data\fhx_loc_"//trim(region)//".csv")
open (3,file="e:\Projects\IMPD\2010\data\scar_"//trim(region)//"_"//trim(outstr)//".dat")
open (5,file="e:\Projects\IMPD\2010\data\scar_dec_"//trim(region)//"_"//trim(outstr)//".dat")
open (6,file="e:\Projects\IMPD\2010\data\prop_scar_ann_"//trim(region)//"_"//trim(outstr)//".csv")
open (7,file="e:\Projects\IMPD\2010\data\prop_scar_dec_"//trim(region)//"_"//trim(outstr)//".csv")
open (8,file="e:\Projects\IMPD\2010\data\pts_noscar_"//trim(region)//"_"//trim(outstr)//".csv")
open (9,file="e:\Projects\IMPD\2010\data\pts_scar_"//trim(region)//"_"//trim(outstr)//".csv")

read (2,*) header
write (6,'(a)') "Year,NReport,NScar,PropScar"
write (7,'(a)') "Year,NReport,NScar,PropScar"
write (8,'(a)') "Site,lat,lon,Year"
write (9,'(a)') "Site,lat,lon,Year"

fs=-9

i=0
do while (.not.eof(2))
	i=i+1
	read (2,*) lat(i),lon(i),fs_file(i)
	write (*,'(/"Site:")')
	write (*,*) fs_file(i)
	sitefile=trim(adjustl(datapath))//trim(adjustl(fs_file(i)))
	write (*,*) sitefile
	open (4,file=sitefile)

	! scan for "FHX2" or "FIRE2"
	do 
		read (4,'(a5)') fmt
		if (fmt.eq.'FHX2 ' .or. fmt.eq.'FIRE2') exit
	end do

	read (4,*) firstyr,ntr,nid
!	write (2,*) i,firstyr,fs_file(i),ntr,nid

	! skip nid lines
	do l=1,nid; read(4,*) dum; end do

	! read firescar data
	do while (.not. eof(4))
		read (4,'(221a1)') (fs_buffer(j),j=1,ntr+5)
		write (ch_year,'(5a1)') (fs_buffer(j),j=ntr+1,ntr+5)
!		write (*,*) ch_year
		read (ch_year,'(i5)') year
!		write (*,*) year
		if (year.ge.firstyr .and. year.ne.0) then
			do j=1,ntr
				fs_char(year,j)=fs_buffer(j)
			end do
		end if

		if (year.ge.firstyr) then
			nnull=0; nrec=0; nscar=0
			do j=1,ntr
!				write (*,'(2i6,a1)') l,year,fs_char(year,j)
!				pause
				select case (fs_char(year,j))
					case ('.')
						nnull=nnull+1
					case ('D','E','M','L','A','U')
					!! case ('D','d','E','e','M','m','L','l','A','a','U','u')
					! firescars are upper case, injuries lower case
						nscar=nscar+1
						nrec=nrec+1
					case default
						nrec=nrec+1
				end select
			end do
			if (nrec.gt.0) fs(year,i)=0
			if (nscar.ge.scarcut) fs(year,i)=1


!			write (3,'(2i6,4i4,1x,230a1)') i,year,nnull,nrec,nscar,fs(year,i),(fs_char(year,j),j=1,ntr), &
!				(fs_buffer(j),j=ntr+1,ntr+5)
		end if

	end do 

!	if (year.ne.0) write (*,'(2i6,1x,221a1)') i,year,(fs_char(year,j),j=1,ntr)

	close (4)
!	pause

end do
nsites=i
write (*,'("nsites = ",i5)') nsites

nreportsyr=0; nscaryr=0; propscaryr=0.0
do m=begyr,endyr
	write (3,'(i4,600i3)') m,(fs(m,n),n=1,nsites)
	
	do n=1,nsites
	    if (fs(m,n).ne.-9.0) nreportsyr(m)=nreportsyr(m)+1
	    if (fs(m,n).eq.1) nscaryr(m)=nscaryr(m)+1
    end do
    if (nreportsyr(m).gt.0) then
        propscaryr(m)=sngl(nscaryr(m))/sngl(nreportsyr(m))
        write (6,'(3(i5,","),f8.4)') m,nreportsyr(m),nscaryr(m),propscaryr(m)
    end if
    
    do n=1,nsites
        if (fs(m,n).eq.0) write (8,'(i5,",",2(f12.6,","),i5)') n,lat(n),lon(n),m
        if (fs(m,n).eq.1) write (9,'(i5,",",2(f12.6,","),i5)') n,lat(n),lon(n),m
    end do
	
end do

nreportsdec=0; nscardec=0; propscardec=0.0
!do m=begyr+1,endyr-10,10
do k=begdec,enddec-1
    m=begyr+1+(k-1)*10
	fs_dec=-9
	do n=1,nsites
		ndecrec=0
		ndecscar=0
		do mm=0,9
			if (fs(m+mm,n).ne.-9) then
			    fs_dec(n)=0
			    nreportsdec(k)=nreportsdec(k)+1
			end if
		end do
		do mm=0,9
			if (fs(m+mm,n).eq.1) then
			    fs_dec(n)=1
			    nscardec(k)=nscardec(k)+1
			end if
		end do
	end do
	write (5,'(i4,600i3)') m+9,(fs_dec(n),n=1,nsites)
	
	!do n=1,nsites
	!    if (fs_dec(n).ne.-9.0) nreportsdec(k)=nreportsdec(k)+1
	!    if (fs_dec(n).eq.1) nscardec(k)=nscardec(k)+1
	!end do
	if (nreportsdec(k).gt.0) then
	    propscardec(k)=sngl(nscardec(k))/sngl(nreportsdec(k))
        write (7,'(3(i5,","),f8.4)') m,nreportsdec(k),nscardec(k),propscardec(k)
    end if
end do

stop
end
	
