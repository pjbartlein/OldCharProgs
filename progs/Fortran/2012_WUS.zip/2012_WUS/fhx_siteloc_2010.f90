program fhx_siteloc_2010

implicit none

integer, parameter  :: maxsites=1000
real				:: declat,declon,lat(maxsites),lon(maxsites),ulat,ulon,lowelev,highelev,aveelev

integer				:: i,l !i,j,k,l,m,mm,d,n,nsites !,firstyr,ntr,nid,year,nnull,nrec,nscar,ndecrec,ndecscar

character(128)		:: datapath,sitefile,sitename(maxsites)
character(32)		:: llbuffer,utmeastbuffer,utmnorthbuffer
character(16)		:: prefix
character(12)		:: fs_file(maxsites)
character(5)        :: lowelevstr, highelevstr

!logical				:: found

datapath="e:\Projects\IMPD\2010\data\fhx\"

open (1,file="e:\Projects\IMPD\2010\data\fhx_files.dat")
open (2,file="e:\Projects\IMPD\2010\data\fhx_loc_elev_all.csv")

write (2,'(a)') "lat, lon, lowelev, highelev, aveelev, fhxname, sitename"

i=0
do while (.not.eof(1))
	i=i+1
	read (1,*) fs_file(i)
	write (*,'(/"Site:")')
	write (*,*) fs_file(i)
	sitefile=trim(adjustl(datapath))//trim(adjustl(fs_file(i)))
	write (*,*) trim(sitefile)
	open (4,file=sitefile)

	! read sitename
	read (4,'(17x,a128)') sitename(i)
	write (*,*) sitename(i)

	! skip 18 lines
	do l=1,18; read(4,*) prefix; end do
	
	! get utm easting and northing
    read (4,'(a16,a32)') prefix,utmeastbuffer
	write (*,*) prefix,utmeastbuffer
	read (4,'(a16,a32)') prefix,utmnorthbuffer
	write (*,*) prefix,utmnorthbuffer
	call utmget(utmeastbuffer,utmnorthbuffer,ulat,ulon)
    
	! get lat and lon
	read (4,'(a16,a32)') prefix,llbuffer
	write (*,*) prefix,llbuffer
	call llget(llbuffer,declat)
	read (4,'(a16,a32)') prefix,llbuffer  
    write (*,*) prefix,llbuffer
	call llget(llbuffer,declon)
	if (declon.gt.0.0) declon=declon*-1.0
	
	if (ulat.ne.-999.0) then
	    lat(i)=ulat
	    lon(i)=ulon
	else
	    lat(i)=declat
	    lon(i)=declon
	end if
	
	! skip a line
	read (4,*) prefix
	
	! get lowelev and highelev strings
	read (4,'(a16,a5)') prefix,lowelevstr
	write (*,*) trim(prefix),trim(lowelevstr)
	read (4,'(a16,a5)') prefix,highelevstr
	write (*,*) trim(prefix),trim(highelevstr)

	call elevget(lowelevstr,highelevstr,lowelev,highelev,aveelev)
	
	! get lowelev and highelev strings

	write(2,'(f12.6,", ",f12.6,3(", ",f7.0),", ",a16,", ",a)')  &
	    lat(i),lon(i),lowelev,highelev,aveelev,fs_file(i),trim(sitename(i))

end do

end
	
subroutine llget(llbuffer,decll)

    implicit none

	real			:: decll
	real			:: lldeg,llmin,llsec
	character(32)	:: llbuffer
	
	lldeg=-999.0; llmin=0.0; llsec=0.0
	! try to read deg, min, sec
	read (llbuffer,*,err=101,end=101) lldeg,llmin,llsec
	go to 104 ! no error
101	continue
	!write (*,'("read error, no llmin, llsec: ",a32)') llbuffer
	! try to read deg, min
	read (llbuffer,*,err=102,end=102) lldeg,llmin
	go to 104 ! no error
102	continue
	!write (*,'("read error, no llmin: ",a32)') llbuffer
	! try to read deg
	read (llbuffer,*,err=103,end=103) lldeg
	go to 104 ! no error
103	continue	
	!write (*,'("read error, no lldeg: ",a32)') llbuffer
104	continue
	write (*,*) lldeg,llmin,llsec
	decll=lldeg+llmin/60.0+llsec/3600.0

end subroutine llget


subroutine utmget(utmeastbuffer,utmnorthbuffer,declat,declon)

    implicit none

    real(8)         :: rdeclat,rdeclon,east,north
    real            :: declat,declon
    character(32)   :: utmeastbuffer,utmnorthbuffer
    integer         :: zone(2),datum
    character(6)    :: chardatum
    
    write (*,*) utmeastbuffer
    write (*,*) utmnorthbuffer
    
    datum=999
    declon=-999.0; declat=-999.0; rdeclon=-999.0d0; rdeclat=-999.0d0
    read (utmeastbuffer,'(f8.0,2x,a5,2x,i2)',err=101,end=100) east,chardatum,zone(1)
    go to 102
101 continue
    read (utmeastbuffer,'(f7.0,2x,a5,2x,i2)',err=100,end=100) east,chardatum,zone(1)
102 continue
    read (utmnorthbuffer,'(f8.0,2x,a5,2x,i2)',end=100) north,chardatum,zone(2)       
100 continue
    
    if (chardatum .eq. 'NAD83') datum=2
    if (chardatum .eq. 'NAD27') datum=1
    
    if (datum.ne.999) then 
        call utm2ll (east, north, rdeclon, rdeclat, zone, datum)   ! http://sbcx.mit.edu/saic_software.html 
        declon=sngl(rdeclon); declat=sngl(rdeclat)

        write (*,'(2f9.0,1x,a6,2i3)') east,north,chardatum,zone(1),zone(2)
        write (*,*) rdeclon,rdeclat
        !pause
    end if 

end subroutine utmget


subroutine elevget(lowelevstr,highelevstr,lowelev,highelev,aveelev)

    implicit none
    
    real            :: lowelev,highelev,aveelev
    character(5)    :: lowelevstr,highelevstr
    
    if (lowelevstr.eq.'     ') then
        lowelev=-9999.0d0
    else
        read (lowelevstr,'(f5.0)') lowelev
    end if
    if (highelevstr.eq.'     ') then
        highelev=-9999.0d0
    else
        read (highelevstr,'(f5.0)') highelev
    end if
    
    aveelev=(lowelev+highelev)/2.0d0
    if (lowelev.eq.-9999.0d0) aveelev=highelev
    if (highelev.eq.-9999.0d0) aveelev=lowelev
    
end subroutine elevget


   
    

