program boot_setup_nc_interp
! writes out data for bootstrap-by-group curve fitting

use netCDF_subs

implicit none

!integer, parameter  :: nlon=72, nlat=36, fyr=500, nt=2006-500+1 ! Mann et al.
integer, parameter  :: nlon=33, nlat=19, fyr=1, lyr=2006, nt=2006-0+1 ! Cook et al.
integer, parameter  :: npts=24 ! 45 ! 69
real(8)             :: lon(nlon),lat(nlat),tlon,tlat
real(8)             :: cft(nt)
real                :: var3d(nlon,nlat,nt),vmiss,vinterp(nt)
integer             :: col,row,seqnum,sitenum,id_site

integer             :: j,k,l,n,jj,kk,iyr

character(80)       :: header
character(1024)     :: ncfile,ptsfile,outfile

!ncfile="e:\Projects\tmp_2k\data\ncfiles\Mann2009_tmp.nc"
!outfile="e:\Projects\tmp_2k\data\boot_data\wus_n41_tann_interp.csv"
ncfile="e:\Projects\drought\data_2008\distrib\NADAv2-2008.nc"
outfile="e:\Projects\drought\data_2008\boot_data\wus_s41_pdsi_interp.csv"
ptsfile="e:\Projects\GPWG\work\wus\data\regions\wus_s41.csv"

open (1,file=ptsfile)
read (1,'(a)') header
open (2,file=outfile)
!write (2,'(a)') "seqnum, sitenum, year, tmp, lon, lat" 
write (2,'(a)') "seqnum, sitenum, year, PDSI, lon, lat" 

! get tmp anomalies and grid-cell areas
call netcdf_open(ncfile,0,ncid)
call netcdf_get_1d_double(ncid,nlat,'lat',lat) 
call netcdf_get_1d_double(ncid,nlon,'lon',lon) 
!call netcdf_get_3d_real(ncid,nlon,nlat,nt,'tmp_anm',var3d)   
call netcdf_get_3d_real(ncid,nlon,nlat,nt,'PDSI',var3d)   
call netcdf_close(ncfile,ncid)   
vmiss=-9999.0

where (isnan(var3d)) var3d=vmiss

seqnum=0; sitenum=0
do l=1,npts
    read (1,*) id_site,tlat,tlon
    sitenum=l
    call bilinear(nlon,nlat,nt,lon,lat,var3d,vmiss,tlon,tlat,vinterp)
    do n=1,nt
        seqnum=seqnum+1
        !iyr=(n-1)+fyr ! tann
        iyr=lyr-(n-1) ! pdsi
        if (vinterp(n).ne.vmiss) &
            write (2,'(3(i7,","),f10.4,", ",f10.2,2(",",f12.6))') seqnum,sitenum,iyr,vinterp(n),tlon,tlat
    end do
end do

end

subroutine bilinear(nclon,nclat,nt,clon,clat,c,cmiss,tlon,tlat,tval)
! does bilinear interpolation of monthly data
!------------------------------------------------------------------------------

implicit none

integer			:: nclat,nclon,nt
real*8			:: clat(nclat), clon(nclon) ! control lat and lon
real			:: c(nclon,nclat,nt)        ! control data 
real            :: cmiss                    ! missing data code
real*8			:: tlat, tlon				! target point lat and lon
real			:: tval(nt)					! interpolated value
integer			:: j,k,jj,kk,n
real			:: t,t1,u,u1,wtot

! find control points that surround target point

if (clat(1).lt.clat(nclat)) then
	do k=1,nclat-1
		if (tlat.ge.clat(k) .and. tlat.lt.clat(k+1)) exit
	end do
	if (tlat.lt.clat(1)) k=1
	if (tlat.gt.clat(nclat)) k=nclat
	kk=k+1
	if (kk.gt.nclat) kk=nclat
else
	do k=1,nclat-1
		if (tlat.lt.clat(k) .and. tlat.ge.clat(k+1)) exit
	end do
	if (tlat.gt.clat(1)) k=1
	if (tlat.lt.clat(nclat)) k=nclat
	kk=k+1
	if (kk.lt.1) kk=nclat
end if

do j=1,nclon-1
	if (tlon.ge.clon(j) .and. tlon.lt.clon(j+1)) exit
end do
if (tlon.lt.clon(1)) j=1
if (tlon.gt.clon(nclon)) j=nclon
jj=j+1
if (jj.gt.nclon) jj=nclon

! bilinear weights
t=(tlon-clon(j))/(clon(jj)-clon(j))
t1=1.0-t
u=(clat(k)-tlat)/(clat(k)-clat(kk))
u1=1.0-u
!write (*,'(4f10.4)') t,t1,u,u1

! bilinear interpolation
do n=1,nt
    wtot=0.0
    tval(n)=0.0
    if (c(j,k,n).ne.cmiss) then
        tval(n)=tval(n)+t1*u1*c(j,k,n)
        wtot=wtot+t1*u1
!        write (*,*) tval(n),wtot
    end if
    if (c(jj,k,n).ne.cmiss) then
        tval(n)=tval(n)+t*u1*c(jj,k,n)
        wtot=wtot+t*u1
!        write (*,*) tval(n),wtot
    end if
    if (c(jj,kk,n).ne.cmiss) then
        tval(n)=tval(n)+t*u*c(jj,kk,n)
        wtot=wtot+t*u
!        write (*,*) tval(n),wtot
    end if
    if (c(j,kk,n).ne.cmiss) then
        tval(n)=tval(n)+t1*u*c(j,kk,n)
        wtot=wtot+t1*u
!        write (*,*) tval(n),wtot
    end if
    if (wtot.ne.0.0) then
        tval(n)=tval(n)/wtot
    else
        tval(n)=cmiss
    end if    
!    write (*,*) tval(n),wtot
!    pause

end do

end subroutine bilinear
