program concat_influx

implicit none

integer, parameter  :: maxdata=50000
real(4)             :: lat,lon
integer(4)          :: siteid,site_sample,id_sample,site_num
real(4)             :: agein,depth,influx2,influx2mnx,tall,ztall,ztin,zmiss
real(4)             :: age(maxdata),zt(maxdata)
real(4)             :: begage,endage

integer             :: i,j,npts

character(16)       :: region,filetype
character(80)       :: header
character(128)		:: csvpath,regionpath,outpath,regionfile,outfile,csvfile
character(32)       :: int_to_string2,buffer2
character(8)        :: siteid_char
character(4)        :: site_num_char

zmiss=-9999.0
region="wus_lat"
filetype="trans"
begage=-100.0; endage=3200.0

regionpath="e:\Projects\GPWG\work\wus\data\regions\"
regionfile=trim(regionpath)//trim(region)//".csv"
outpath="e:\Projects\GPWG\work\wus\data\files\"
outfile=trim(outpath)//trim(region)//"_"//trim(filetype)//".csv"
select case(filetype)
    case ("trans")
        csvpath="e:\Projects\GPWG\work\wus\data\influx\csv_files\wus2\wus2_trans\"
    case ("presamp")
        csvpath="e:\Projects\GPWG\work\wus\data\influx\csv_files\wus2\wus2_presamp\"
end select

open (2,file=trim(regionfile))
open (3,file=trim(outfile))
write (3,'(a)') "seqnum, sitenum, age, ztinflux, lat, lon"

read (2,*) header

i=0
do while (.not.eof(2))

	read (2,*) site_num, lat, lon
	write (*,'(/"Site:")')
	site_num_char=int_to_string2(site_num,4)
	
	select case(filetype)
	    case ("trans")
            csvfile=trim(adjustl(csvpath))//trim(adjustl(site_num_char))//"_trans_influx_zt2k.csv"
        case ("presamp")
            csvfile=trim(adjustl(csvpath))//trim(adjustl(site_num_char))//"_presamp_influx_zt2k_sm10.csv"
    end select

	write (*,*) csvfile
	open (4,file=csvfile)
	read (4,*) header
	
	j=0
    do
        if (eof(4)) exit
        select case (filetype)
            case ("trans")
                read (4,*) siteid_char, site_sample, id_sample, agein, depth, influx2, influx2mnx, tall, ztin
            case ("presamp")
                read (4,*) siteid, agein, ztin
        end select
        if (agein.gt.begage .and. agein.lt.endage) then
            if (ztin.ne.zmiss) then
                j=j+1
                age(j)=agein; zt(j)=ztin
            end if
        end if
    end do
    npts=j
    
    if (npts.gt.0) then
        i=i+1
        do j=1,npts
            write (3,'(i4,", ",i4,", ",f10.2,", ",f10.4,2(",",f12.6))') i,site_num,age(j),zt(j),lat,lon
        end do
    end if
    close (4)

end do
write (*,'("nsites = ",i5)') i


end
	
function int_to_string(inum)

	implicit none
	character(32)	:: int_to_string
	character(32)	:: buffer, str
	integer			:: inum

	write (buffer,*) inum
	read (buffer,*) str

	int_to_string=trim(adjustl(str))

end function int_to_string


function int_to_string2(inum,numlen)

	implicit none
	character(32)	:: int_to_string,int_to_string2
	character(32)	:: buffer, str
	character(8)	:: ifmt,iedit
	integer			:: inum,numlen

	iedit=int_to_string(numlen)
	ifmt="(i"//trim(adjustl(iedit))//"."//trim(adjustl(iedit))//")"

	write (buffer,ifmt) inum
	read (buffer,*) str

	int_to_string2=trim(adjustl(str))

end function int_to_string2


