program utmlltst
!
! Test program for converting between UTM and Lat/Lon coordinates.
!

IMPLICIT NONE

integer latdeg, latmin, latsec
integer londeg, lonmin, lonsec

real (kind=8) latitude, longitude
real (kind=8) utm_x, utm_y
real (kind=8) lambda0

integer       utm_grid_zone(2)

integer WGS_84_DATUM
parameter (WGS_84_DATUM = 3)

!-------------------------------------------------------------------------

!  FFP array location

latitude = 34.0 + (6.0 / 60.0) + (41.03 / 3600.0)
longitude = -(119 + (19.0 / 60.0) + (49.90 / 3600.0))

open (10, 'utmlltst.in')
read (10,*) latdeg, latmin, latsec
read (10,*) londeg, lonmin, lonsec

latitude = float (latdeg) + (float (latmin) / 60.0) + (float (latsec) / 3600.0)
if (londeg .LT. 0) then
   longitude = float (londeg) - (float (lonmin) / 60.0) - (float (lonsec) / 3600.0)
else
   longitude = float (londeg) + (float (lonmin) / 60.0) + (float (lonsec) / 3600.0)
endif

! Initialize the UTM zone number based on the entering lat/lon

CALL Get_Grid_Zone (longitude, latitude, utm_grid_zone, lambda0)

! Convert lat/lon to UTM coordinates

utm_x = 0.0
utm_y = 0.0
call ll2utm (longitude, latitude, utm_x, utm_y, utm_grid_zone, WGS_84_DATUM)

write (*,*) 'lon, lat, utm_grid_zone, utm_x, utm_y = ', &
            longitude, latitude, utm_grid_zone(1), utm_grid_zone(2), utm_x, utm_y

! Convert back to lat and lon from UTM coordinates

call utm2ll (utm_x, utm_y, longitude, latitude, utm_grid_zone, WGS_84_DATUM)

write (*,*) 'lon, lat, utm_grid_zone, utm_x, utm_y = ', &
            longitude, latitude, utm_grid_zone(1), utm_grid_zone(2), utm_x, utm_y

!write (*,*) ' Use Herb Freese UTM coordinates for the center of the FFP array:'

!utm_x = 285009.0
!utm_y = 3776850.0
read (10,*) utm_x
read (10,*) utm_y

call utm2ll (utm_x, utm_y, longitude, latitude, utm_grid_zone, WGS_84_DATUM)

write (*,*) 'lon, lat, utm_grid_zone, utm_x, utm_y = ', &
            longitude, latitude, utm_grid_zone(1), utm_grid_zone(2), utm_x, utm_y
stop
end
