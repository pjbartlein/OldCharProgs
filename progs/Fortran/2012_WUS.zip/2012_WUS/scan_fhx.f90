program scan_fhx

implicit none

integer, parameter	:: ny=1000, maxtr=500, maxsites=500
integer, parameter	:: begyr=1001, endyr=2010

integer				:: fs(begyr:endyr,maxsites),fs_dec(maxsites)
integer             :: nreportsyr(begyr:endyr),nscaryr(begyr:endyr)
real				:: declat,declon,lat(maxsites),lon(maxsites),ulat,ulon
real                :: propscaryr(begyr:endyr)

integer				:: i,j,l,m,mm,n,nsites,firstyr,ntr,nid,year,nnull,nrec,nscar,ndecrec,ndecscar

character(128)		:: datapath,sitefile,sitename(maxsites)
character(32)		:: llbuffer,utmeastbuffer,utmnorthbuffer
character(16)		:: prefix
character(12)		:: fs_file(maxsites)
character(32)		:: ch_year
character(5)		:: fmt,dum
character(1)		:: fs_buffer(maxtr+6),fs_char(begyr:endyr,maxtr+6)

logical				:: found

datapath="E:\Projects\IMPD\data\fhx\"

open (1,file="e:\Projects\IMPD\data\fhx_files.dat")
open (2,file="e:\Projects\IMPD\data\site_loc.dat")
open (3,file="e:\Projects\IMPD\data\scar.dat")
open (5,file="e:\Projects\IMPD\data\scar_dec.dat")
open (7,file="e:\Projects\IMPD\data\prop_scar.csv")
open (8,file="e:\Projects\IMPD\data\pts_noscar.csv")
open (9,file="e:\Projects\IMPD\data\pts_scar.csv")

write (7,'(a)') "Year,NReport,NScar,PropScar"
write (8,'(a)') "Site,lat,lon,Year"
write (9,'(a)') "Site,lat,lon,Year"


fs=-9

i=0
do while (.not.eof(1))
	i=i+1
	read (1,*) fs_file(i)
	write (*,'(/"Site:")')
	write (*,*) fs_file(i)
	sitefile=trim(adjustl(datapath))//trim(adjustl(fs_file(i)))
	write (*,*) sitefile
	open (4,file=sitefile)

	! read sitename
	read (4,'(17x,a128)') sitename(i)
	write (*,*) sitename(i)

	! skip 18 lines
	do l=1,18; read(4,*) prefix; end do
	
	! get utm easting and northing
    read (4,'(a16,a32)') prefix,utmeastbuffer
	write (*,*) prefix,utmeastbuffer
	read (4,'(a16,a32)') prefix,utmnorthbuffer
	write (*,*) prefix,utmnorthbuffer
	call utmget(utmeastbuffer,utmnorthbuffer,ulat,ulon)
    
	! get lat and lon
	read (4,'(a16,a32)') prefix,llbuffer
	write (*,*) prefix,llbuffer
	call llget(llbuffer,declat)
	read (4,'(a16,a32)') prefix,llbuffer
    write (*,*) prefix,llbuffer
	call llget(llbuffer,declon)
	if (declon.gt.0.0) declon=declon*-1.0
	
	if (ulat.ne.-999.0) then
	    lat(i)=ulat
	    lon(i)=ulon
	else
	    lat(i)=declat
	    lon(i)=declon
	end if

	write(2,'(2f12.6,1x,a16,1x,a128)') lat(i),lon(i),fs_file(i),sitename(i)

	! scan for "FHX2" or "FIRE2"
	do 
		read (4,'(a5)') fmt
		if (fmt.eq.'FHX2 ' .or. fmt.eq.'FIRE2') exit
	end do

	read (4,*) firstyr,ntr,nid
!	write (2,*) i,firstyr,fs_file(i),ntr,nid

	! skip nid lines
	do l=1,nid; read(4,*) dum; end do

	! read firescar data
	do while (.not. eof(4))
		read (4,'(221a1)') (fs_buffer(j),j=1,ntr+5)
		write (ch_year,'(5a1)') (fs_buffer(j),j=ntr+1,ntr+5)
!		write (*,*) ch_year
		read (ch_year,'(i5)') year
!		write (*,*) year
		if (year.ge.firstyr .and. year.ne.0) then
			do j=1,ntr
				fs_char(year,j)=fs_buffer(j)
			end do
		end if

		if (year.ge.firstyr) then
			nnull=0; nrec=0; nscar=0
			do j=1,ntr
!				write (*,'(2i6,a1)') l,year,fs_char(year,j)
!				pause
				select case (fs_char(year,j))
					case ('.')
						nnull=nnull+1
					case ('D','d','E','e','M','m','L','l','A','a','U','u')
						nscar=nscar+1
						nrec=nrec+1
					case default
						nrec=nrec+1
				end select
			end do
			if (nrec.gt.0) fs(year,i)=0
			if (nscar.gt.0) fs(year,i)=1


!			write (3,'(2i6,4i4,1x,230a1)') i,year,nnull,nrec,nscar,fs(year,i),(fs_char(year,j),j=1,ntr), &
!				(fs_buffer(j),j=ntr+1,ntr+5)
		end if

	end do 

!	if (year.ne.0) write (*,'(2i6,1x,221a1)') i,year,(fs_char(year,j),j=1,ntr)

	close (4)
!	pause

end do
nsites=i

nreportsyr=0; nscaryr=0; propscaryr=0.0
do m=begyr,endyr
	write (3,'(i4,600i3)') m,(fs(m,n),n=1,nsites)
	
	do n=1,nsites
	    if (fs(m,n).ne.-9.0) nreportsyr(m)=nreportsyr(m)+1
	    if (fs(m,n).eq.1) nscaryr(m)=nscaryr(m)+1
    end do
    if (nreportsyr(m).gt.0) then
        propscaryr(m)=sngl(nscaryr(m))/sngl(nreportsyr(m))
        write (7,'(3(i5,","),f8.4)') m,nreportsyr(m),nscaryr(m),propscaryr(m)
    end if
    
    do n=1,nsites
        if (fs(m,n).eq.0) write (8,'(i5,",",2(f12.6,","),i5)') n,lat(n),lon(n),m
        if (fs(m,n).eq.1) write (9,'(i5,",",2(f12.6,","),i5)') n,lat(n),lon(n),m
    end do
	
end do

do m=begyr+1,endyr-10,10
	fs_dec=-9
	do n=1,nsites
		ndecrec=0
		ndecscar=0
		do mm=0,9
			if (fs(m+mm,n).ne.-9) fs_dec(n)=0
		end do
		do mm=0,9
			if (fs(m+mm,n).eq.1) fs_dec(n)=1
		end do
	end do
	write (5,'(i4,600i3)') m+9,(fs_dec(n),n=1,nsites)
end do


!do i=1,nsites
!	write(2,'(i4,1x,a12,1x,2f10.4,1x,a128)') i,fs_file(i),lat(i),lon(i),sitename(i)
!end do

stop
end
	
subroutine llget(llbuffer,decll)

implicit none

	real			:: decll
	real			:: lldeg,llmin,llsec
	character(32)	:: llbuffer
	
	lldeg=-999.0; llmin=0.0; llsec=0.0
	! try to read deg, min, sec
	read (llbuffer,*,err=101,end=101) lldeg,llmin,llsec
	go to 104 ! no error
101	continue
	!write (*,'("read error, no llmin, llsec: ",a32)') llbuffer
	! try to read deg, min
	read (llbuffer,*,err=102,end=102) lldeg,llmin
	go to 104 ! no error
102	continue
	!write (*,'("read error, no llmin: ",a32)') llbuffer
	! try to read deg
	read (llbuffer,*,err=103,end=103) lldeg
	go to 104 ! no error
103	continue	
	!write (*,'("read error, no lldeg: ",a32)') llbuffer
104	continue
	write (*,*) lldeg,llmin,llsec
	decll=lldeg+llmin/60.0+llsec/3600.0

return
end


subroutine utmget(utmeastbuffer,utmnorthbuffer,declat,declon)

implicit none

    real(8)         :: rdeclat,rdeclon,east,north
    real            :: declat,declon
    character(32)   :: utmeastbuffer,utmnorthbuffer
    integer         :: zone(2),datum
    character(6)    :: chardatum
    
    write (*,*) utmeastbuffer
    write (*,*) utmnorthbuffer
    
    datum=999
    declon=-999.0; declat=-999.0; rdeclon=-999.0d0; rdeclat=-999.0d0
    read (utmeastbuffer,'(f8.0,2x,a5,2x,i2)',err=101,end=100) east,chardatum,zone(1)
    go to 102
101 continue
    read (utmeastbuffer,'(f7.0,2x,a5,2x,i2)',err=100,end=100) east,chardatum,zone(1)
102 continue
    read (utmnorthbuffer,'(f8.0,2x,a5,2x,i2)',end=100) north,chardatum,zone(2)       
100 continue
    
    if (chardatum .eq. 'NAD83') datum=2
    if (chardatum .eq. 'NAD27') datum=1
    
    if (datum.ne.999) then 
        call utm2ll (east, north, rdeclon, rdeclat, zone, datum)   ! http://sbcx.mit.edu/saic_software.html 
        declon=sngl(rdeclon); declat=sngl(rdeclat)

        write (*,'(2f9.0,1x,a6,2i3)') east,north,chardatum,zone(1),zone(2)
        write (*,*) rdeclon,rdeclat
        !pause
    end if 
return
end
   
    

