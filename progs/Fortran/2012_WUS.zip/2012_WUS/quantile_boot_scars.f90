program quantile_boot_scars
! fits a smooth local quantile curve to tree-ring fire-scar data
! gets bootstrap estimates of confidence intervals of curve

use loquant
use lowess
use ifport

implicit none

integer, parameter  :: maxdata=1200, maxsitedata=1200, maxsites=1000, maxtarg=2200, maxreps=1000
integer, parameter	:: begyr=1000, endyr=2010, nyrs=endyr-begyr+1

integer			:: fs(begyr:endyr,maxsites),iyear,fsamp(begyr:endyr,maxsites)
integer         :: nreportsyr(begyr:endyr),nscaryr(begyr:endyr)
real            :: propscaryr(begyr:endyr),varmiss
real(8)         :: xin(maxdata),yin(maxdata)

real(4)         :: rbegyr,rendyr
real(8)         :: xtarg(maxtarg),yfit(maxtarg),yfitse(maxtarg),fit_cu95(maxtarg),fit_cl95(maxtarg),ypredse(maxtarg)
real(8)         :: param,xspan(maxtarg),lwr_mult
real(8)         :: targbeg,targend,targstep
integer(4)      :: npfit(maxtarg),minpts,order,nrobust,ntarg
character(1)    :: wintype

integer         :: nsel(maxsites)
real(8)         :: ranseed,randval
real(8)         :: yfit_reps(maxtarg,maxreps),temp(maxreps),sorttemp(maxreps)
real(8)         :: yfit_boot(maxtarg),yfit_boot_median(maxtarg),yfit_boot_stdev(maxtarg),yfit_boot_se(maxtarg)
real(8)         :: yfit_boot_cu95(maxtarg),yfit_boot_cl95(maxtarg)
integer         :: jsel(maxsites,maxreps),jmax,jmin,ncl95,ncu95,n50

integer         :: i,j,k,m,n,npts,nctrl,jsite,nsites,ii,nreps,nnum

!character(32)   :: int_to_string2
character(256)  :: infilepath,infile,datapath,plotpath,ptsfile,quantfile,cufile,clfile,labelfile,regionfile
character(80)   :: header
character(1)    :: dum

infilepath="e:\Projects\IMPD\2010\data\"
infile="scar_w104.dat" ! "scar_s42n.dat" ! "scar_n42n.dat" ! 
datapath="e:\Projects\IMPD\2010\data\"
quantfile="lq_scar_w104_q95_boot_050b.csv" ! "lq_scar_s42n_q95_boot_050.csv" ! "lq_scar_n42n_q50_boot_050.csv" ! 

open (6,file=trim(adjustl(infilepath))//trim(adjustl(infile)))
open (7,file=trim(adjustl(datapath))//trim(adjustl(quantfile)))
open (10,file=trim(adjustl(datapath))//"debug_boot.dat")
!open (11,file=trim(adjustl(datapath))//"yfit_scar_95_boot_050.dat") ! ############

nsites=359 ! 240 ! 119 ! 

write (7,'(a)') "targ_age,  lq_scar_ts_q50_050, np, "// &
  "lq_scar_w104_q95_boot_050, yfit_boot_median, yfit_boot_se, yfit_boot_cu95, yfit_boot_cl95"  ! ############

! smoothing parameters
param=050.0d0
lwr_mult=1.0d0
wintype='w'; minpts=10; order=2; nrobust=1  

! target point definitions
targend=2010.0d0; targbeg=1250.0d0; targstep=10.0d0

! overall age range of data
rbegyr=1250.0; rendyr=2010.0

! number of bootstrap samples
nreps=1000

! random number seed
call srand(100)

! generate target points
ntarg=int((targend-targbeg)/targstep)+1
write (*,*) param
do i=1,ntarg
    xtarg(i)=targend-dble(i-1)*targstep
    !write (*,*) i,sngl(xtarg(i))
end do

varmiss=-9999.0

! read the data
do while (.not. eof(6))
    read (6,*) iyear,(fs(iyear,j),j=1,nsites)
end do


! bootstrap sampling and fitting

yfit_reps=0.0d0; nsel=0
!nreps=20

do k=1,nreps
    jmax=-99999; jmin=99999
    ii=0
    do j=1,nsites

        ! select a site at random
        randval=rand(0)
        jsel(j,k)=int(randval*sngl(nsites))+1
        nsel(jsel(j,k))=nsel(jsel(j,k))+1
        if (jmax.lt.jsel(j,k)) jmax=jsel(j,k)
        if (jmin.gt.jsel(j,k)) jmin=jsel(j,k)
        !jsel(j,k)=j        
        fsamp(:,j)=fs(:,jsel(j,k))
    end do
    
    nreportsyr=0; nscaryr=0; propscaryr=varmiss
    do m=begyr,endyr   	
	    do j=1,nsites
	        if (fsamp(m,j).ne.-9.0) nreportsyr(m)=nreportsyr(m)+1
	        if (fsamp(m,j).eq.1) nscaryr(m)=nscaryr(m)+1
        end do
        if (nreportsyr(m).gt.0) then
            propscaryr(m)=sngl(nscaryr(m))/sngl(nreportsyr(m))
        end if      
    end do
    
    ! load xin and yin
    ii=0; npts=0
    do m=begyr,endyr
        if (propscaryr(m).ne.varmiss .and. propscaryr(m).ne.0.0) then
        if (dble(m).ge.rbegyr .and. dble(m).le.rendyr) then
            ii=ii+1
            xin(ii)=dble(m)
            !yin(ii)=propscaryr(m)
            yin(ii)=dble(asin(sqrt(propscaryr(m))))
        end if
        end if
    end do
    npts=ii
    
    !write (*,*) k,npts,ntarg
    write (10,*) k,npts,ntarg
    if (mod(k,10).eq.0) write (*,'(i5,\)') k
    yfit=0.0d0; yfitse=0.0d0; fit_cu95=0.0d0; fit_cl95=0.0d0
    call quantile_curve(npts,xin,yin,ntarg,xtarg,param,npfit,yfit)
    call lowess_curve(ntarg,xtarg,yfit,ntarg,xtarg,wintype,param*lwr_mult,minpts,order,nrobust,yfit,yfitse,ypredse,npfit,xspan)
    
    ! save fitted values
    do i=1,ntarg
        yfit_reps(i,k)=yfit(i)
    end do
       
    !write (10,*) k,jmin,jmax
    !write (10,'(20i4)') (jsel(j,k),j=1,nsites)
    
    !write (10,'(i6)') k
    write (10,'(10f8.3)') (yfit(i),i=1,ntarg,10)
    
    !write (*,'(i6)') k
    !write (*,'(10f8.3)') (yfit(i),i=1,ntarg)
    
end do

200 continue

! one more fit to get standard (unresampled) values
nreportsyr=0; nscaryr=0; propscaryr=varmiss
do m=begyr,endyr   	
    do j=1,nsites
        if (fs(m,j).ne.-9.0) nreportsyr(m)=nreportsyr(m)+1
        if (fs(m,j).eq.1) nscaryr(m)=nscaryr(m)+1
    end do
    if (nreportsyr(m).gt.0) then
        propscaryr(m)=sngl(nscaryr(m))/sngl(nreportsyr(m))
    end if      
end do

! load xin and yin
ii=0
do m=begyr,endyr
    if (propscaryr(m).ne.varmiss .and. propscaryr(m).ne.0.0) then
    if (dble(m).ge.rbegyr .and. dble(m).le.rendyr) then
        ii=ii+1
        xin(ii)=dble(m)
        !yin(ii)=propscaryr(m)
        yin(ii)=dble(asin(sqrt(propscaryr(m))))
    end if
    end if
end do
npts=ii
    
!write (*,*) npts,ntarg
yfit=0.0d0 !##; yfitse=0.0d0; fit_cu95=0.0d0; fit_cl95=0.0d0
call quantile_curve(npts,xin,yin,ntarg,xtarg,param,npfit,yfit)
call lowess_curve(ntarg,xtarg,yfit,ntarg,xtarg,wintype,param*lwr_mult,minpts,order,nrobust,yfit,yfitse,ypredse,npfit,xspan)

!write (*,*) yfitse

!do i=1,ntarg
!    if (.not. isnan(yfit(i))) then
!        fit_cu95(i)=yfit(i)+2.0d0*yfitse(i)
!        fit_cl95(i)=yfit(i)-2.0d0*yfitse(i)
!    end if
!end do

! get bootstrap estimates

ncl95=int(sngl(nreps)*0.025)
if (ncl95.le.0) ncl95=1
ncu95=int(sngl(nreps)*0.975)
if (ncu95.ge.nreps .or. ncu95.le.0) ncu95=nreps
n50=int(sngl(nreps)/2.0)
if (n50.ge.nreps .or. n50.le.0) n50=nreps
write (*,*) ncl95,ncu95,n50

yfit_boot=0.0d0; yfit_boot_stdev=0.0d0; yfit_boot_se=0.0d0; yfit_boot_cu95=0.0d0; yfit_boot_cl95=0.0d0
do i=1,ntarg
    nnum=0
    do k=1,nreps
        if (.not. isnan(yfit_reps(i,k))) then
            yfit_boot(i)=yfit_boot(i)+yfit_reps(i,k)
            nnum=nnum+1
        end if
    end do
    if (nnum.gt.0) then
        yfit_boot(i)=yfit_boot(i)/dble(nreps)
    end if
    !write (*,*) i,yfit_boot(i)
    nnum=0
    do k=1,nreps
        if (.not. isnan(yfit_reps(i,k))) then
            yfit_boot_stdev(i)=yfit_boot_stdev(i)+(yfit_reps(i,k)-yfit_boot(i))*(yfit_reps(i,k)-yfit_boot(i))
            nnum=nnum+1
        end if
        !write (*,*) i,k,yfit_reps(i,k),yfit_boot_stdev(i)
    end do
    !write (*,*) i,yfit_boot_stdev(i)
    if (nnum.gt.1) then
        yfit_boot_stdev(i)=dsqrt(yfit_boot_stdev(i)/dble(nnum-1))
        !write (*,*) i,yfit_boot_stdev(i)
        yfit_boot_se(i)=yfit_boot_stdev(i)/dsqrt(dble(nnum))
    end if
    temp(:)=yfit_reps(i,:)
    call sortx(nreps,temp,sorttemp)
    yfit_boot_cu95(i)=sorttemp(ncu95)
    yfit_boot_cl95(i)=sorttemp(ncl95)
    yfit_boot_median(i)=sorttemp(n50)
    
    !write (7,'(f10.2,",",f14.6,", ",i6,5(",",f14.6))') & 
    !    xtarg(i),yfit(i),npfit(i), &
    !    yfit_boot(i),yfit_boot_median(i),yfit_boot_se(i),yfit_boot_cu95(i),yfit_boot_cl95(i)
    write (7,'(f10.2,",",f14.6,", ",i6,5(",",f14.6))') & 
        xtarg(i),dsin(yfit(i))**2.0d0,& 
        npfit(i), &
        dsin(yfit_boot(i))**2.0d0,dsin(yfit_boot_median(i))**2.0d0, & 
        yfit_boot_se(i), &
        dsin(yfit_boot_cu95(i))**2.0d0,dsin(yfit_boot_cl95(i))**2.0d0
  
end do

do j=1,nsites
    write (10,*) j,nsel(j)
end do

!do i=1,ntarg
!    write (11,'(i5,f10.1,200f8.3)') i,xtarg(i),(yfit_reps(i,k),k=1,50)
!end do
    
end

function int_to_string(inum)

	implicit none
	character(32)	:: int_to_string
	character(32)	:: buffer, str
	integer			:: inum

	write (buffer,*) inum
	read (buffer,*) str

	int_to_string=trim(adjustl(str))

end function int_to_string


function int_to_string2(inum,numlen)

	implicit none
	character(32)	:: int_to_string,int_to_string2
	character(32)	:: buffer, str
	character(8)	:: ifmt,iedit
	integer			:: inum,numlen

	iedit=int_to_string(numlen)
	ifmt="(i"//trim(adjustl(iedit))//"."//trim(adjustl(iedit))//")"

	write (buffer,ifmt) inum
	read (buffer,*) str

	int_to_string2=trim(adjustl(str))

end function int_to_string2

