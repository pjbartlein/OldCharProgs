program boot_setup_nc
! writes out data for bootstrap-by-group curve fitting

use netCDF_subs

implicit none

integer, parameter  :: nlon=72, nlat=36, nt=2006-500+1, npts=7, fyr=500 ! Mann et al.
real(8)             :: lon(nlon),lat(nlat)
real(8)             :: cft(nt),area(nlat)
real                :: var3d(nlon,nlat,nt)
integer             :: col,row,seqnum,sitenum

integer             :: j,k,l,n,jj,kk,iyr

character(1024)     :: ncfile,ptsfile,outfile

ncfile="e:\Projects\tmp_2k\data\ncfiles\Mann2009_tmp.nc"
ptsfile="e:\Projects\tmp_2k\data\boot_data\wus_pts.dat"
outfile="e:\Projects\tmp_2k\data\boot_data\wus_boot.csv"

! get tmp anomalies and grid-cell areas
call netcdf_open(ncfile,0,ncid)
call netcdf_get_1d_double(ncid,nlat,'lat',lat) 
call netcdf_get_1d_double(ncid,nlon,'lon',lon) 
call netcdf_get_3d_real(ncid,nlon,nlat,nt,'tmp_anm',var3d)   
call netcdf_get_1d_double(ncid,nlat,'area',area) 
call netcdf_close(ncfile,ncid)   

open (1,file=ptsfile)
open (2,file=outfile)
write (2,'(a)') "seqnum, sitenum, year, tmp, area" 

seqnum=0; sitenum=0
do l=1,npts
    read (1,*) col,row
    sitenum=l
    do n=1,nt
        seqnum=seqnum+1
        iyr=(n-1)+fyr
        write (2,'(3(i6,","),f10.4,", ",f10.2)') seqnum,sitenum,iyr,var3d(col,row,n),area(row)
    end do
end do
        
 

end