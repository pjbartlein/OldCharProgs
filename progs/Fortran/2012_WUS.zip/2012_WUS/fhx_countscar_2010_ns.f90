program fhx_dataout_2010_ns

implicit none

integer, parameter	:: ny=1001, maxtr=500, maxsites=500, nsym=14
integer, parameter	:: begyr=1000, endyr=2010, begdec=1, enddec=101

integer				:: fs(begyr:endyr,maxsites),fs_dec(maxsites)
integer             :: nreportsyr(begyr:endyr),nscaryr(begyr:endyr)
integer             :: nreportsdec(begdec:enddec),nscardec(begdec:enddec)
integer             :: cnt(nsym)
real				:: declat,declon,lat(maxsites),lon(maxsites),ulat,ulon
real                :: propscaryr(begyr:endyr),propscardec(begdec:enddec)

integer				:: i,j,k,l,m,mm,d,n,nsites,firstyr,ntr,nid,year,nnull,nrec,nscar,ndecrec,ndecscar,scarcut

character(128)		:: datapath,sitefile,sitename(maxsites)
character(32)		:: llbuffer,utmeastbuffer,utmnorthbuffer
character(16)		:: prefix,region,outstr
character(12)		:: fs_file(maxsites)
character(32)		:: ch_year
character(5)		:: fmt,dum
character(1)		:: fs_buffer(maxtr+6),fs_char(begyr:endyr,maxtr+6),header,symbol(nsym)

logical				:: found

data symbol /'.','|','D','d','E','e','M','m','L','l','A','a','U','u'/
region="s42n"
scarcut=1
outstr="fs1"

datapath="e:\Projects\IMPD\2010\data\fhx\"

open (2,file="e:\Projects\IMPD\2010\data\fhx_loc_"//trim(region)//".csv")
open (3,file="e:\Projects\IMPD\2010\data\scar_"//trim(region)//"_"//"scarcount.csv")
read (2,*) header
write (3,'(a)') "ScarSymbol, count"

fs=-9
cnt=0

i=0
do while (.not.eof(2))
	i=i+1
	read (2,*) lat(i),lon(i),fs_file(i)
	write (*,'(/"Site:")')
	write (*,*) fs_file(i)
	sitefile=trim(adjustl(datapath))//trim(adjustl(fs_file(i)))
	write (*,*) sitefile
	open (4,file=sitefile)

	! scan for "FHX2" or "FIRE2"
	do 
		read (4,'(a5)') fmt
		if (fmt.eq.'FHX2 ' .or. fmt.eq.'FIRE2') exit
	end do

	read (4,*) firstyr,ntr,nid
!	write (2,*) i,firstyr,fs_file(i),ntr,nid

	! skip nid lines
	do l=1,nid; read(4,*) dum; end do

	! read firescar data
	do while (.not. eof(4))
		read (4,'(221a1)') (fs_buffer(j),j=1,ntr+5)
		write (ch_year,'(5a1)') (fs_buffer(j),j=ntr+1,ntr+5)
!		write (*,*) ch_year
		read (ch_year,'(i5)') year
!		write (*,*) year
		if (year.ge.firstyr .and. year.ne.0) then
			do j=1,ntr
				fs_char(year,j)=fs_buffer(j)
			end do
		end if

		if (year.ge.firstyr) then
			nnull=0; nrec=0; nscar=0
			do j=1,ntr
			    do n=1,nsym
				    if (trim(fs_char(year,j)).eq.symbol(n)) cnt(n)=cnt(n)+1
				end do
			end do
		end if

	end do 


	close (4)
!	pause

end do
nsites=i
write (*,'("nsites = ",i5)') nsites

do n=1,nsym
    write (3,'(a1,", ",i8)') symbol(n),cnt(n)
end do

end
	
