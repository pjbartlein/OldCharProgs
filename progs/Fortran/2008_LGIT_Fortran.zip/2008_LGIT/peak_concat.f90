program peak_concat
! concatentates peak records

use summarize_subs

implicit none

real(4)         :: depth,age,conc,influx,bkg,finalpks,pkmag,pkfreq
real(4)         :: begage,endage
integer         :: i,j

character(80)   :: header
character(4)    :: site_num_char
character(8)    :: site_num_label
character(256)  :: datapath,outpath,allsamplesfile

datapath="\Projects\igbpfire\yd\data\peaks_site_csv\"
outpath="\Projects\igbpfire\yd\data\files\"  ! ######
allsamplesfile="\Projects\igbpfire\yd\data\files\yd_peaks_ts.csv" 

begage=10000.0; endage=15000.0

open (4,file=allsamplesfile)
write (4,'(a)') "site,depth,age,conc,influx,bkg,finalpks,pkmag,pkfreq" 

do j=1,maxsites
    ! try to open a file
    site_num_char=int_to_string2(j,4)
    !write (*,'(a)') site_num_char
    open (1,file=trim(datapath)//trim(adjustl(site_num_char))//"_peak.csv", status='old', err=100)
    
    
    read (1,*) header
    write (*,'(i4,2(1x,a8))') j,site_num_char,site_num_label

    do while (.not. eof(1))
        i=i+1
        read (1,*) depth,age,conc,influx,bkg,finalpks,pkmag,pkfreq
        if (age.gt.begage .and. age.lt.endage) then
            write (4,'(i4,",",f8.1,",",f8.1,3(",",f8.2),",",f4.0,",",f9.4,",",f5.2)') &
                j,depth,age,conc,influx,bkg,finalpks,pkmag,pkfreq
        end if
    end do
    close(1)
   
100 continue
    
end do

end


