program transform_yd
! transforms and z-scores of individual charcoal records

use summarize_subs

implicit none

integer(4)      :: site_sample(maxdata),id_sample(maxdata)
real(4)         :: depth(maxdata),age(maxdata),influx(maxdata),mxninflux(maxdata)
real(4)         :: tinflux(maxdata)
real(4)         :: ztinflux(maxdata)
real(4)         :: influx_in
real(4)         :: vartemp(maxdata),sage(maxdata),svar(maxdata),varmiss

real(4)         :: begbase,endbase
real(4)         :: firstyr,lastyr

real(4)         :: lambda,shift,lhmax
real(4)         :: vmean,vstdev,vmin,vmax,vrng 

integer(4)      :: i,j,npts,npts_all,npts_base

character(4)    :: site_num_char
character(8)    :: site_num_label
character(256)  :: datapath,transpath,lambdafile,allsamplesfile,debugfile 

datapath="\Projects\igbpfire\yd\data\site_csv\"
transpath="\Projects\igbpfire\yd\data\trans_influx_zts_csv\"  ! ######
lambdafile="\Projects\igbpfire\yd\data\files\lambda.dat" ! ###### 
allsamplesfile="\Projects\igbpfire\yd\data\files\yd_influx_zts.csv" ! ######
debugfile="\Projects\igbpfire\yd\data\files\debug_transform.dat"

begbase=10000.0; endbase=15000.0
varmiss=-9999.0 
shift=0.01

open (3,file=lambdafile)
write (3,'(a)') "site, npts, npts, lambda, shift, lhmax"
open (4,file=allsamplesfile)
write (4,'(a)') "site, site_sample, id_sample, depth, est_age, influx, mxninflux, tinflux, ztinflux" ! #####
open (10,file=debugfile)

do j=1,maxsites
    ! try to open a file
    site_num_char=int_to_string2(j,4)
    open (1,file=trim(datapath)//trim(adjustl(site_num_char))//".csv", status='old', err=100)
    open (2,file=trim(transpath)//trim(adjustl(site_num_char))//"_yd_trans_influx_zts.csv") ! ######
    write (2,'(a)') "site, site_sample, id_sample, depth, est_age, influx, mxninflux, tinflux, ztinflux" ! #####
    
    read (1,*) site_num_label
    write (*,'(i4,2(1x,a8))') j,site_num_char,site_num_label
    
    ! initialize 
    depth=0.0; age=0.0; influx=varmiss; mxninflux=varmiss
    vmean=varmiss; vstdev=varmiss; vmin=varmiss; vmax=varmiss; vrng=varmiss
    npts=0; tinflux=varmiss; lambda=-9.0; lhmax=-99999.0
    
    i=0
    lastyr=-99999.0; firstyr=99999.0
    do while (.not. eof(1))
        i=i+1
        read (1,*) site_sample(i),id_sample(i),depth(i),age(i),influx_in  ! #######
        influx(i)=influx_in  ! ######
        if (age(i).gt.lastyr) lastyr=age(i)
        if (age(i).lt.firstyr) firstyr=age(i)
    end do
    npts=i
    write (*,*) npts,lastyr,firstyr
    
    write (10,'(i5,1x,a4,1x,a8,1x,i4,2f10.2)') j,site_num_char,site_num_label,npts,firstyr,lastyr
    write (*,'(i5,1x,a4,1x,a8,1x,i4,2f10.2)') j,site_num_char,site_num_label,npts,firstyr,lastyr
    
    ! transformations 
    
    ! stats for whole record
    call stats(npts,age,influx,varmiss,firstyr,lastyr,npts_all,vmean,vstdev,vmin,vmax,vrng)
    write (*,*) npts,npts_all,vmin,vmax
    
    ! mxinflux -- minimax transformation of influx for whole record
    call minimax(npts,influx,varmiss,vmin,vmax,mxninflux)   
    
    ! select points in the range begbase to endbase
    call selectage(npts,begbase,endbase,age,influx,npts_base,sage,svar)
    write (*,*) npts,begbase,endbase,npts_base
       
    ! get Box-Cox parameters for selection of points
    if (npts_base.gt.0) then
        call boxcox_lambda(npts_base,svar,varmiss,shift,lambda,lhmax)   
        ! transform whole record with base period parameters  
        call boxcox_trans(npts,lambda,shift,influx,varmiss,vartemp)
        ! minimax of transformed data using base period parameters
        call stats(npts,age,vartemp,varmiss,begbase,endbase,npts_all,vmean,vstdev,vmin,vmax,vrng)
        call minimax(npts,vartemp,varmiss,vmin,vmax,tinflux)
        ! z-scores -- base period parameters
        call zscores(npts,vartemp,varmiss,vmean,vstdev,ztinflux)
    end if   

    do i=1,npts
        write (2,'(a8,",",i8,",",i8,",",f10.2,",",f10.2,5(",",f14.3),", ","""",a4,"""" )') &
            site_num_label,site_sample(i),id_sample(i),depth(i),age(i),influx(i),mxninflux(i), &
            tinflux(i),ztinflux(i)
        write (4,'(a8,",",i8,",",i8,",",f10.2,",",f10.2,5(",",f14.3),", ","""",a4,"""" )') &
            site_num_label,site_sample(i),id_sample(i),depth(i),age(i),influx(i),mxninflux(i), &
            tinflux(i),ztinflux(i)
    end do
    
    write (3,'(a8,1x,i5,1x,3(i5,2f8.2,f10.2))') &
        site_num_label,npts,npts_base,lambda,shift,lhmax
            
    close(1)
    close(2)
   
100 continue
    
end do

end


