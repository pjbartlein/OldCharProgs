program transform_poll
! (arcsine) transforms and z-scores of individual pollen records

use summarize_subs

implicit none

integer(4)      :: site_sample(maxdata),id_sample(maxdata)
real(4)         :: depth(maxdata),age(maxdata),apnap(maxdata),mxnapnap(maxdata)
real(4)         :: tapnap(maxdata)
real(4)         :: ztapnap(maxdata)
real(4)         :: apnap_in,ap_in,nap_in,apnap100_in
real(4)         :: vartemp(maxdata),sage(maxdata),svar(maxdata),varmiss

real(4)         :: begbase,endbase
real(4)         :: firstyr,lastyr

real(4)         :: pi
real(4)         :: vmean,vstdev,vmin,vmax,vrng 

integer(4)      :: i,j,npts,npts_all,npts_base,isitesample,isample

character(4)    :: site_num_char
character(8)    :: site_num_label
character(80)   :: header
character(256)  :: datapath,transpath,lambdafile,allsamplesfile,debugfile 

datapath="\PROJECTS\igbpfire\yd\data\pollen_site_csv\"
transpath="\PROJECTS\igbpfire\yd\data\pollen_trans_apnap_zts_csv\"  ! ######
allsamplesfile="\Projects\igbpfire\yd\data\files\yd_poll_zts.csv" ! ######
debugfile="\Projects\igbpfire\yd\data\files\debug_transform_poll.dat"

begbase=10000.0; endbase=15000.0
varmiss=-9999.0 
pi=3.141592654

open (4,file=allsamplesfile)
write (4,'(a)') "site, site_sample, id_sample, depth, est_age, apnap, mxnapnap, tapnap, ztapnap" ! #####
open (10,file=debugfile)

isample=0
do j=1,maxsites
    ! try to open a file
    site_num_char=int_to_string2(j,4)
    open (1,file=trim(datapath)//trim(adjustl(site_num_char))//"_pollen.csv", status='old', err=100)
    open (2,file=trim(transpath)//trim(adjustl(site_num_char))//"_yd_trans_apnap_zts.csv") ! ######
    write (2,'(a)') "site, site_sample, id_sample, depth, est_age, apnap, mxnapnap, tapnap, ztapnap" ! #####
    
    read (1,*) header
    write (*,'(i4,2(1x,a8))') j,site_num_char
    
    ! initialize 
    depth=0.0; age=0.0; apnap=varmiss; mxnapnap=varmiss
    vmean=varmiss; vstdev=varmiss; vmin=varmiss; vmax=varmiss; vrng=varmiss
    npts=0; tapnap=varmiss
    
    i=0
    lastyr=-99999.0; firstyr=99999.0
    isitesample=0
    do while (.not. eof(1))
        i=i+1
        isample=isample+1
        isitesample=isitesample+1
        read (1,*) depth(i),age(i),ap_in,nap_in,apnap_in,apnap100_in
        write (*,*) age(i),apnap_in
        apnap(i)=apnap_in  ! ######
        if (age(i).gt.lastyr) lastyr=age(i)
        if (age(i).lt.firstyr) firstyr=age(i)
        id_sample(i)=isample
        site_sample(i)=isitesample
    end do
    npts=i
    write (*,*) npts,lastyr,firstyr
    
    write (10,'(i5,1x,a4,1x,a8,1x,i4,2f10.2)') j,site_num_char,site_num_label,npts,firstyr,lastyr
    write (*,'(i5,1x,a4,1x,a8,1x,i4,2f10.2)') j,site_num_char,site_num_label,npts,firstyr,lastyr
    
    ! transformations 
    
    ! stats for whole record
    call stats(npts,age,apnap,varmiss,firstyr,lastyr,npts_all,vmean,vstdev,vmin,vmax,vrng)
    write (*,*) npts,npts_all,vmin,vmax
    
    ! mxapnap -- minimax transformation of apnap for whole record
    call minimax(npts,apnap,varmiss,vmin,vmax,mxnapnap)   
    
    ! select points in the range begbase to endbase
    call selectage(npts,begbase,endbase,age,apnap,npts_base,sage,svar)
    write (*,*) npts,begbase,endbase,npts_base
       
    ! transformation
    if (npts_base.gt.0) then
        do i=1,npts
            tapnap(i)=asin(sqrt(apnap(i)))/(pi/2.0)
        end do       
        call stats(npts,age,tapnap,varmiss,begbase,endbase,npts_all,vmean,vstdev,vmin,vmax,vrng)
        ! z-scores -- base period parameters
        call zscores(npts,tapnap,varmiss,vmean,vstdev,ztapnap)
    end if   

    do i=1,npts
        write (2,'(a8,",",i8,",",i8,",",f10.2,",",f10.2,5(",",f14.3),", ","""",a4,"""" )') &
            site_num_char,site_sample(i),id_sample(i),depth(i),age(i),apnap(i),mxnapnap(i), &
            tapnap(i),ztapnap(i)
        write (4,'(a8,",",i8,",",i8,",",f10.2,",",f10.2,5(",",f14.3),", ","""",a4,"""" )') &
            site_num_char,site_sample(i),id_sample(i),depth(i),age(i),apnap(i),mxnapnap(i), &
            tapnap(i),ztapnap(i)
    end do
            
    close(1)
    close(2)
   
100 continue
    
end do

end


