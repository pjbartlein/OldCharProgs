program transpose
! transposes an "all" file

implicit none

integer, parameter  :: maxsites=1000, nt=105
real            :: yfit
integer         :: site,siteage

real            :: lat_in,lon_in,lat(maxsites),lon(maxsites)
integer         :: id_site_in,id_site(maxsites),usesite(maxsites)
character(256)  :: sitename,header

real            :: zts(maxsites,nt),vmiss
integer         :: age(nt),agemax,agemin,agestep
integer         :: i,j,k

open (1,file="\Projects\igbpfire\charsum\data\current_hs6\files\HS_6b_sites.txt")
open (2,file="\Projects\igbpfire\charsum\data\current_hs6\files\hs6b_all_influx2_zts_sm10.csv")
open (3,file="\Projects\igbpfire\charsum\data\current_hs6\files\hs6b_all_influx2_zts_sm10_matrix.csv")

agemax=2020; agemin=-60; agestep=20
vmiss=-9999.0

do j=1,nt
    age(j)=agemax-(j-1)*agestep
    write (*,*) j,age(j)
end do

usesite=0; id_site=-9; lat=-9999.0; lon=-9999.0
do while (.not. eof(1))
    read (1,*) id_site_in,sitename,lat_in,lon_in
    id_site(id_site_in)=id_site_in
    lat(id_site_in)=lat_in
    lon(id_site_in)=lon_in
    usesite(id_site_in)=1
end do

!do k=1,maxsites
!    write (*,'(i3,i3,2f14.6)') usesite(k),id_site(k),lat(k),lon(k)
!end do

zts=vmiss
read (2,*) header
do while (.not. eof(2))
    read (2,'(4x,i4,4x,i4,8x,f14.6)') site,siteage,yfit
    if (siteage.le.agemax) then
        j=(agemax-siteage)/agestep + 1
        zts(site,j)=yfit
    end if
end do

write (3,'("site, lat, lon", 105(", ",i5.4,"BP"))') (age(j),j=1,nt)
do k=1,maxsites
    if (usesite(k).eq.1) then
        write (3,'(i4,2(", ",f14.6),105(", ",f14.6))') id_site(k),lat(k),lon(k),(zts(k,j),j=1,nt)
    end if
end do



end


