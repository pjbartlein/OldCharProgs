program poll_concat
! concatentates pollen records

use summarize_subs

implicit none

real(4)         :: depthm,calage,ap,nap,apnap,apnap100

integer         :: i,j

character(80)   :: header
character(4)    :: site_num_char
character(8)    :: site_num_label
character(256)  :: datapath,outpath,allsamplesfile


datapath="\Projects\igbpfire\yd\data\pollen_site_csv\"
outpath="\Projects\igbpfire\yd\data\files\"  ! ######
allsamplesfile="\Projects\igbpfire\yd\data\files\yd_poll_ts.csv" 

open (4,file=allsamplesfile)
write (4,'(a)') "depthm,calage,ap,nap,apnap,apnap100" 

do j=1,maxsites
    ! try to open a file
    site_num_char=int_to_string2(j,4)
    open (1,file=trim(datapath)//trim(adjustl(site_num_char))//"_pollen.csv", status='old', err=100)
    
    read (1,*) header
    write (*,'(i4,2(1x,a8))') j,site_num_char,site_num_label

    do while (.not. eof(1))
        i=i+1
        read (1,*) depthm,calage,ap,nap,apnap,apnap100
        write (4,'(f8.1,",",f8.1,2(",",f7.1),",",f6.2,",",f6.1)') &
            depthm,calage,ap,nap,apnap,apnap100   
    end do
    close(1)
   
100 continue
    
end do

end


