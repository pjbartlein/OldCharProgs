module lowess

contains

subroutine lowess_curve(nctrl,xin,yin,ntarg,xt,wintype,param,order,nrobust,yfit,yfitse,ypredse,npfit)
! manages computation of a lowess "curve"

    implicit none

    integer             :: nctrl,ntarg
    real(8)             :: xin(nctrl),yin(nctrl),xt(ntarg),param,yfit(ntarg),yfitse(ntarg),ypredse(ntarg),y0
    real(8)             :: xs(nctrl),ys(nctrl),targ,fitval,sefit,sepred,lwmean1,lwmean2,newparam
    integer             :: order,nrobust
    integer             :: np,npfit(ntarg) 
    character(1)        :: wintype
    logical             :: monotonic,yfitnan

    integer             :: i,ii,iii,j,k

    y0=0.0d0

    xs=xin; ys=yin
    !write (*,*) nctrl,ntarg
    !write (*,'(8f10.2)') xs
    !write (*,'(8f10.4)') ys
    !write (*,'(8f10.2)') xt
    !pause
    
    ! sort the input data by x-values if necessary
    monotonic=.true.
    do i=2,nctrl
        if (xs(i).lt.xs(i-1)) then
            monotonic=.false.
            ! write (*,'("xs(i),xs(i-1) non-monotonic: ",i6,2f14.6)') i,xs(i),xs(i-1)
        end if
    end do
    if (.not. monotonic) then
        ! write (*,'(a)') "Note:  input x's were not monotonic"
        ! write (10,'(a)') "Note:  input x's were not monotonic"
        call sortxy(nctrl,xin,yin,xs,ys)
    end if

    ! loop over target points, calling localfit for each target point
    do ii=1,ntarg      
        targ=xt(ii)    
        call localfit(nctrl,xs,ys,targ,wintype,param,order,nrobust,fitval,sefit,sepred,lwmean1,np)
        yfit(ii)=fitval
        yfitse(ii)=sefit
        ypredse(ii)=sepred
        npfit(ii)=np
        
        !write (*,*) ii,targ,yfit(ii),yfitse(ii),lwmean1,np     
    end do  
   
end subroutine lowess_curve


subroutine localfit(nctrl,xs,ys,targval,wintype,param,order,nrobust,fitval,sefit,sepred,lwmean,np)
! gets a lowess-type fitted value at a particular target point

    implicit none

    integer             :: nctrl
    real(8)             :: targval,param,fitval,sefit,sepred,lwmean
    real(8)             :: xs(nctrl),ys(nctrl),x(nctrl),y(nctrl)
    real(8)             :: w(nctrl),wsum,ywm,ym,ystdev,ymse
    real(8)             :: b0,b1,b2,yhat(nctrl),resid(nctrl),mse,stderr,rsq,xm,sxx
    real(8)             :: dmax,diff,u,ul,ll
    real(8)             :: r(nctrl),median,rmedx6,ru,rw(nctrl)
    integer             :: order,nrobust
    integer             :: np,np2,npts,low,high,nonzero
    character(1)        :: wintype
    integer             :: i,ii,iii,j
    
    !write (*,*) nctrl
    !write (*,'(8f10.2)') xs
    !write (*,'(8f10.4)') ys
    !write (*,'(8f10.2)') targval
    !pause
    
    ! select data to use for a specific fitted value
    if (wintype.eq.'s') then 
     
        ! find observations in param proportion of data
        npts=int(param*nctrl)
        np2=npts/2
        low=ii-np2
        high=ii+np2
        if (low.lt.1) then
            low=1
            high=low+npts
        end if
        if (high.gt.nctrl) then
            high=nctrl
            low=nctrl-npts
        end if
        np=high-low+1
        i=0
        do iii=low,high
            i=i+1
            x(i)=xs(iii)
            y(i)=ys(iii)
        end do
        
        ! get distance weights
        dmax=0.0d0
        do i=1,np
            diff=x(i)-targval
            if (dabs(diff).gt.dmax) dmax=dabs(diff)
        end do
        do i=1,np
            u=dabs(x(i)-targval)/dmax
            if (u.gt.1.0d0) u=1.0d0
            w(i)=(1.0d0-u**3.0d0)**3.0d0
        end do
        
    else if (wintype.eq.'w') then

        ! find observations within plus or minus window half-width (param)
        ul=targval+param
        ll=targval-param
        i=0
        do iii=1,nctrl
            if (xs(iii).ge.ll .and. xs(iii).le.ul) then
                i=i+1
                x(i)=xs(iii)
                y(i)=ys(iii)
                ! write (*,*) i,x(i),y(i)
            end if
        end do
        np=i   
        
        !write (*,*) np
        
        ! get distance weights
        dmax=param
        do i=1,np
            u=dabs(x(i)-targval)/dmax
            if (u.gt.1.0d0) u=1.0d0
            w(i)=(1.0d0-u**3.0d0)**3.0d0
        end do         
    end if

    ! get a locally weighted mean
    call wm(np,y,w,lwmean,ystdev,ymse,resid)

    fitval=0.0d0/0.0d0 ! set to NaN initially

    ! set initial robustness weights equal to distance weights
    nonzero=0
    do i=1,np
        rw(i)=w(i)
        if (rw(i).ne.0.0d0) nonzero=nonzero+1
        !write (*,*) i,w(i),rw(i)
    end do

    ! robustness iterations
    do j=0,nrobust

        ! lowess regressions
        select case (order)
            
            case (0)
                ! (distance) weighted mean
                call wm(np,y,rw,ywm,ystdev,ymse,resid)
                fitval=ywm
                sefit=ymse

            case (1)       
                ! distance-weighted linear regression
                if (nonzero.gt.3) then
                    call fitline(np,x,y,rw,b0,b1,yhat,resid,mse,stderr,rsq,xm,sxx,wsum)
                    fitval=b0+b1*targval
                    sefit=0.0d0
                    if (wsum.gt.0.0 .and. sxx.ne.0.0d0) then
                        sefit=stderr*dsqrt(((1.0d0/wsum)+(((targval-xm)*(targval-xm))/(sxx*1.0d0))))
                        sepred=stderr*dsqrt((1.0d0+(1.0d0/wsum)+(((targval-xm)*(targval-xm))/(sxx*1.0d0))))
                    elseif (np.gt.0 .and. sxx.ne.0.0d0) then
                        sefit=stderr*dsqrt(((1.0d0/dble(np))+(((targval-xm)*(targval-xm))/(sxx*1.0d0)))) 
                        sepred=stderr*dsqrt((1.0d0+(1.0d0/dble(np))+(((targval-xm)*(targval-xm))/(sxx*1.0d0)))) 
                    end if
                    !write (*,'(7f14.6)') targval,fitval,stderr,sefit
                end if
                
            case (2)
                ! distance-weighted quadratic regression
                if (nonzero.gt.8) then
                    call fitquad(np,x,y,rw,b0,b1,b2,yhat,resid,mse,stderr,rsq,wsum)
                    fitval=b0+b1*targval+b2*targval*targval
                    sefit=0.0d0
                    if (wsum.gt.0.0) then
                        sefit=stderr*dsqrt(((1.0d0/wsum)))
                        sepred=stderr*dsqrt((1.0d0+(1.0d0/wsum)))
                    elseif (np.gt.0) then
                        sefit=stderr*dsqrt(((1.0d0/dble(np))))
                        sepred=stderr*dsqrt((1.0d0+(1.0d0/dble(np))))
                    end if
                    !write (*,'(7f14.6)') targval,fitval,stderr,sefit
                end if
       
            case default
                write (*,*) "Polynomial order not supported...."
                stop 
                
        end select
        
        ! robustness weights
        if (nrobust.ne.0 .and. j.lt.nrobust) then
        
            ! median of absolute values of current residuals
            call medianx(np,dabs(resid),median)
            rmedx6=median*6.0d0
        
            ! bisquare weights (r) and new robustness weights (rw)
            nonzero=0
            do i=1,np
                ru=dabs(resid(i)/rmedx6)    
                if (ru.gt.1.0d0) ru=1.0d0
                r(i)=(1.0d0-ru**2.0d0)**2.0d0
                rw(i)=w(i)*r(i)
                if (rw(i).ne.0.0d0) nonzero=nonzero+1
            end do
          
        end if      
        
    end do
    
    !write (*,*) lwmean,fitval
    !pause

end subroutine localfit


subroutine wm(npts,y,w,ywm,ystdev,ymse,dev)
! weighted mean

    implicit none

    integer     :: npts
    real(8)     :: y(npts),w(npts),dev(npts)
    real(8)     :: wsum,ywm,ym,ystdev,ymse
    integer     :: i

    ym=0.0d0
    ywm=0.0d0
    wsum=0.0d0
    do i=1,npts
        ym=ym+y(i)
        ywm=ywm+y(i)*w(i)
        wsum=wsum+w(i)
    end do
    if (wsum.gt.0.0d0) then
        ywm=ywm/wsum
    else
        ywm=ym/dble(npts)
    end if
    
    ystdev=0.0d0
    do i=1,npts
        ystdev=ystdev+(y(i)-ywm)*(y(i)-ywm)*w(i)
    end do
    if (wsum.gt.0.0d0) then
        ystdev=dsqrt(ystdev/(dble(npts-1)*(wsum/dble(npts))))
    else 
        ystdev=0.0d0
    end if
    
    ymse=0.0d0
    if (npts.gt.2) then
        ymse=ystdev/dsqrt(dble(npts))
    end if

    do i=1,npts
        dev(i)=y(i)-ywm
    end do

end subroutine wm


subroutine fitline(npts,x,y,w,b0,b1,yhat,resid,mse,stderr,rsq,xm,sxx,wsum)
! simple weighted linear regression
 
    implicit none

    integer         :: npts
    real(8)         :: x(npts),y(npts),w(npts),b0,b1,yhat(npts),resid(npts)
    real(8)         :: xm,ym,wsum,sxx,sxy,sse,sst,mse,stderr,sratio,rsq
    integer         :: i

    xm=0.0d0; ym=0.0d0; wsum=0.0d0; sxx=0.0d0; sxy=0.0d0

    do i=1,npts
        wsum=wsum+w(i)
        xm=xm+x(i)*w(i)
        ym=ym+y(i)*w(i)
        !write (*,'(i4,3f14.6)') i,x(i),y(i),w(i)
    end do
    
    xm=xm/wsum
    ym=ym/wsum
    !write (*,*) xm,ym,wsum

    do i=1,npts
        sxx=sxx+((x(i)-xm)**2.0d0)*w(i)
        sxy=sxy+(x(i)-xm)*(y(i)-ym)*w(i)
    end do

    b1=sxy/sxx
    b0=ym-(b1*xm)

    sse=0.0d0; sst=0.0d0
    do i=1,npts
        yhat(i)=b0+b1*x(i)
        resid(i)=y(i)-yhat(i)
        sse=sse+(resid(i)*dsqrt(w(i)))**2.0d0
        sst=sst+((y(i)-ym)*dsqrt(w(i)))**2.0d0
        !write (*,'(i5,5f14.6)') i,b0,b1,x(i),y(i),yhat(i)
    end do

    mse=sse/dble(npts-2)
    stderr=dsqrt(mse)
    rsq=-1.0d0
    sratio=sse/sst
    if (sratio.le.1.0d0 .and. sratio.ge.0.0d0) rsq=1.0d0-sratio
    !write (*,'(5f14.6)') b1,b0,mse,stderr,rsq

end subroutine fitline


subroutine fitquad(npts,x1,y,w,b0,b1,b2,yhat,resid,mse,stderr,rsq,wsum)
! simple weighted quadratic regression

    implicit none

    integer         :: npts
    real(8)         :: x1(npts),x2(npts),y(npts),w(npts),b0,b1,b2,yhat(npts),resid(npts)
    real(8)         :: x1m,x2m,ym,wsum,sx1x1,sx2x2,sx1x2,sx1y,sx2y,sse,sst,mse,stderr,sratio,rsq
    real(8)         :: bx1y,bx2y,bx2x1,bx1x2
    integer         :: i

    x1m=0.0d0; x2m=0.0d0; ym=0.0d0; wsum=0.0d0
    sx1x1=0.0d0; sx2x2=0.0d0; sx1x2=0.0d0; sx1y=0.0d0; sx2y=0.0d0

    do i=1,npts
        x2(i)=x1(i)**2.0d0
        wsum=wsum+w(i)
        x1m=x1m+x1(i)*w(i)
        x2m=x2m+x2(i)*w(i)
        ym=ym+y(i)*w(i)
    end do
    x1m=x1m/wsum
    x2m=x2m/wsum
    ym=ym/wsum

    do i=1,npts
        sx1x1=sx1x1+((x1(i)-x1m)**2.0d0)*w(i)
        sx2x2=sx2x2+((x2(i)-x2m)**2.0d0)*w(i)
        sx1x2=sx1x2+(x1(i)-x1m)*(x2(i)-x2m)*w(i)
        sx1y=sx1y+(x1(i)-x1m)*(y(i)-ym)*w(i)
        sx2y=sx2y+(x2(i)-x2m)*(y(i)-ym)*w(i)
    end do

    bx1y=sx1y/sx1x1    ! b12
    bx2y=sx2y/sx2x2    ! b13
    bx2x1=sx1x2/sx2x2  ! b32
    bx1x2=sx1x2/sx1x1  ! b23

    b1=(bx1y-bx2y*bx1x2)/(1.0d0-bx1x2*bx2x1)
    b2=(bx2y-bx1y*bx2x1)/(1.0d0-bx1x2*bx2x1)

    b0=ym-(b1*x1m)-(b2*x2m)

    sse=0.0d0; sst=0.0d0
    do i=1,npts
        yhat(i)=b0+b1*x1(i)+b2*x2(i)
        resid(i)=y(i)-yhat(i)
        sse=sse+(resid(i)*dsqrt(w(i)))**2.0d0
        sst=sst+((y(i)-ym)*dsqrt(w(i)))**2.0d0
    end do

    mse=sse/dble(npts-2)
    stderr=dsqrt(mse)
    rsq=-1.0d0
    sratio=sse/sst
    if (sratio.le.1.0d0 .and. sratio.ge.0.0d0) rsq=1.0d0-sratio
    
    !write (*,'(6f14.6)') b1,b2,b0,mse,stderr,rsq

end subroutine fitquad


subroutine sortxy(npts,x,y,xs,ys)
! sorts x,y pairs by values of x

    implicit none

    integer         :: npts
    real(8)         :: x(npts),y(npts),xs(npts+1),ys(npts+1),tx,ty
    integer         :: i,j,k,kp1
    logical         :: flag

    do i=1,npts
        xs(i)=x(i)
        ys(i)=y(i)
    end do

    i=0
    flag=.true.
    do 
        i=i+1
        j=npts-i
        flag=.false.
        do k=1,j
            kp1=k+1
            if (xs(k).gt.xs(kp1)) then
                tx=xs(kp1)
                ty=ys(kp1)
                xs(kp1)=xs(k)
                ys(kp1)=ys(k)
                xs(k)=tx
                ys(k)=ty
                flag=.true.
            end if
        end do
        if (.not.flag) exit
    end do

end subroutine sortxy

subroutine sortx(npts,x,xs)
! sorts x

    implicit none

    integer         :: npts
    real(8)         :: x(npts),xs(npts+1),tx
    integer         :: i,j,k,kp1
    logical         :: flag

    do i=1,npts
        xs(i)=x(i)
    end do

    i=0
    flag=.true.
    do 
        i=i+1
        j=npts-i
        flag=.false.
        do k=1,j
            kp1=k+1
            if (xs(k).gt.xs(kp1)) then
                tx=xs(kp1)
                xs(kp1)=xs(k)
                xs(k)=tx
                flag=.true.
            end if
        end do
        if (.not.flag) exit
    end do

end subroutine sortx


subroutine medianx(npts,x,median)
! finds median of x

    implicit none

    integer         :: npts
    real(8)         :: x(npts),xs(npts+1),tx,median
    integer         :: i,j,k,kp1
    logical         :: flag

    do i=1,npts
        xs(i)=x(i)
    end do

    i=0
    flag=.true.
    do 
        i=i+1
        j=npts-i
        flag=.false.
        do k=1,j
            kp1=k+1
            if (xs(k).gt.xs(kp1)) then
                tx=xs(kp1)
                xs(kp1)=xs(k)
                xs(k)=tx
                flag=.true.
            end if
        end do
        if (.not.flag) exit
    end do

    ! xs contains sorted values of x

    select case (npts)
        case (0)
            median=0.0d0
        case (1)
            median=xs(1)
        case (2)
            ! crude definition
            median=xs(int(npts/2))
        case default
            ! statistical definition
            median=(xs(int(npts/2)+1) + xs(npts - int(npts/2) +2))/2.0d0
    end select

end subroutine medianx


subroutine desc(npts,y,mean,stdev)
! mean and standard deviation of a variable

    implicit none

    integer     :: npts
    real(8)     :: y(npts),mean,stdev
    integer     :: i

    mean=0.0d0
    do i=1,npts
        mean=mean+y(i)
    end do
    if (npts.gt.0) mean=mean/dble(npts)
    stdev=0.0d0
    do i=1,npts
        stdev=stdev+(y(i)-mean)*(y(i)-mean)
    end do
    if (stdev.gt.0.0d0) stdev=(sqrt(stdev/dble(npts-1)))

end subroutine desc

end module lowess