program smooth_boot_peaks
! fits a smooth lowess-type curve to charcoal peaks data
! gets bootstrap estimates of confidence intervals of lowess curve

use lowess
use ifport

implicit none

integer, parameter  :: maxdata=100000, maxsitedata=3000, maxsites=1000, maxtarg=2200, maxreps=1000

integer(4)      :: site_num,site_sample,id_sample,usesitenum,usesite(maxsites)
real(4)         :: depth,age,conc,influx,bkg,finalpks,pkmag,pkfreq
real(4)         :: var,varmnx,vart,varzt
real(4)         :: varin,varmiss
character(8)    :: site_num_label
character(4)    :: site_num_char
character(32)   :: region

real(8)         :: xsite(maxsitedata,maxsites),ysite(maxsitedata,maxsites)
integer         :: nrecs(maxsites),idsite(maxsites),nsel(maxsites)

real(8)         :: xin(maxdata),yin(maxdata)

real(4)         :: begyr,endyr
real(8)         :: xtarg(maxtarg),yfit(maxtarg),yfitse(maxtarg),fit_cu95(maxtarg),fit_cl95(maxtarg),ypredse(maxtarg)
real(8)         :: param
real(8)         :: targbeg,targend,targstep
integer(4)      :: npfit(maxtarg),order,nrobust,ntarg
character(1)    :: wintype

real(8)         :: ranseed,randval
real(8)         :: yfit_reps(maxtarg,maxreps),temp(maxreps),sorttemp(maxreps)
real(8)         :: yfit_boot(maxtarg),yfit_boot_median(maxtarg),yfit_boot_stdev(maxtarg),yfit_boot_se(maxtarg)
real(8)         :: yfit_boot_cu95(maxtarg),yfit_boot_cl95(maxtarg)
integer         :: jsel(maxsites,maxreps),jmax,jmin,ncl95,ncu95,n50

integer         :: i,j,k,npts,nctrl,jsite,nsites,ii,nreps,nnum

character(32)   :: int_to_string2
character(256)  :: infilepath,infile,datapath,plotpath,ptsfile,lowfile,lowcsvfile,cufile,clfile,labelfile,regionfile
character(80)   :: header
character(1)    :: dum

region="all_sites"

infilepath="d:\PROJECTS\igbpfire\yd\data\peaks_site_csv\"
datapath="\Projects\igbpfire\yd\data\files\"
lowcsvfile="yd_peaks_ts_400_boot_"//trim(adjustl(region))//".csv"
regionfile=trim(adjustl(datapath))//trim(adjustl(region))//".csv"

open (7,file=trim(adjustl(datapath))//trim(adjustl(lowcsvfile)))
open (10,file=trim(adjustl(datapath))//"debug_boot.dat")
open (11,file=trim(adjustl(datapath))//"yfit_pol_400_boot.dat") ! ############
open (8,file=regionfile)

write (7,'(a)') "targ_age,  yd_peaks_ts_400, sefit, fitcu95, fitcl95, np, "// &
  "yd_peaks_ts_400_boot, yfit_boot_median,yfit_boot_se, yfit_boot_cu95, yfit_boot_cl95"  ! ############

! lowess parameters
param=400.0d0; wintype='w'; order=1; nrobust=0     ! ############

! target point definitions
targend=15000.0d0; targbeg=10000.0d0; targstep=50.0d0

! overall age range of data
begyr=21000.0; endyr=-60.0

! number of bootstrap samples
nreps=1000

! random number seed
call srand(100)

! generate target points
ntarg=int((targend-targbeg)/targstep)+1
write (*,*) param,targstep,ntarg,order,nrobust,wintype
do i=1,ntarg
    xtarg(i)=targend-dble(i-1)*targstep
    write (*,*) i,sngl(xtarg(i))
end do

varmiss=-9999.0

! read the region site file
usesite=0
read (8,*) header
do while (.not. eof(8))
    read (8,*) usesitenum
    !write (*,*) usesitenum
    usesite(usesitenum)=1
end do 

! read data, store individual sites in array

nsel=0
jsite=0
xsite=0.0; ysite=0.0
do j=1,1000

    site_num_char=int_to_string2(j,4)
    
    ! try to open a file
    site_num_char=int_to_string2(j,4)   ! ############
    infile=trim(adjustl(infilepath))//trim(adjustl(site_num_char))//"_peak.csv"
   
    open (1,file=infile, status='old', err=100)
    ! if site file exists:
    !write (*,*) infile
    !write (*,*) site_num_char
    if (usesite(j).eq.1) then    
        jsite=jsite+1
        idsite(jsite)=j
         
        ! read data, and save age and variable to be smoothed
        read (1,*) header
        i=0
        do while (.not. eof(1))   ! ############
            read (1,*) depth,age,conc,influx,bkg,finalpks,pkmag,pkfreq
            varin=finalpks
            if (age.le.begyr .and. age.ge.endyr .and. varin.ne.varmiss) then
                i=i+1
                xsite(i,jsite)=age
                ysite(i,jsite)=varin        
                write (10,'(i6,f10.2,f14.6)') i,age,varin
            end if
        end do
        nrecs(jsite)=i
        close(1)
        !write (10,'("j,jsite,idsite,nrecs,site_num_char:",4i5,1x,a4)') j,jsite,idsite(jsite),nrecs(jsite),site_num_char
    end if
    
100 continue

end do
nsites=jsite

! bootstrap sampling and fitting

yfit_reps=0.0d0; nsel=0
!nreps=20

do k=1,nreps
    jmax=-99999; jmin=99999
    ii=0
    do j=1,nsites

        ! select a site at random
        randval=rand(0)
        jsel(j,k)=int(randval*sngl(nsites))+1
        nsel(jsel(j,k))=nsel(jsel(j,k))+1
        if (jmax.lt.jsel(j,k)) jmax=jsel(j,k)
        if (jmin.gt.jsel(j,k)) jmin=jsel(j,k)
        !jsel(j,k)=j
        
        ! concatenate records
        if (nrecs(jsel(j,k)).gt.1) then
            do i=1,nrecs(jsel(j,k))
                ii=ii+1
                xin(ii)=xsite(i,jsel(j,k))
                yin(ii)=ysite(i,jsel(j,k))
                !write (2,'(4i6,2f14.6)') ii,j,idsite(jsel(j,k)),i,xin(ii),yin(ii)
            end do
        end if
    end do
    npts=ii
    
    write (*,*) k,npts,ntarg
    write (10,*) k,npts,ntarg
    if (mod(k,1).eq.0) write (*,*) k,npts
    yfit=0.0d0; yfitse=0.0d0; fit_cu95=0.0d0; fit_cl95=0.0d0
    call lowess_curve(npts,xin,yin,ntarg,xtarg,wintype,param,order,nrobust,yfit,yfitse,ypredse,npfit)
    
    ! save fitted values
    do i=1,ntarg
        yfit_reps(i,k)=yfit(i)
    end do
       
    !write (10,*) k,jmin,jmax
    !write (10,'(20i4)') (jsel(j,k),j=1,nsites)
    
    write (10,'(i6)') k
    write (10,'(10f8.3)') (yfit(i),i=1,ntarg,10)
    
    !write (*,'(i6)') k
    !write (*,'(10f8.3)') (yfit(i),i=1,ntarg)
    
end do

200 continue

! one more fit to get standard (unresampled) values
ii=0
do j=1,nsites
    ! concatenate records
    if (nrecs(j).gt.1) then
        do i=1,nrecs(j)
            ii=ii+1
            xin(ii)=xsite(i,j)
            yin(ii)=ysite(i,j)
            !write (2,'(4i6,2f14.6)') ii,j,idsite(j),i,xin(ii),yin(ii)
        end do
    end if
end do
npts=ii
    
write (*,*) npts,ntarg
yfit=0.0d0; yfitse=0.0d0; fit_cu95=0.0d0; fit_cl95=0.0d0
call lowess_curve(npts,xin,yin,ntarg,xtarg,wintype,param,order,nrobust,yfit,yfitse,ypredse,npfit)
!write (*,*) yfitse

do i=1,ntarg
    if (.not. isnan(yfit(i))) then
        fit_cu95(i)=yfit(i)+2.0d0*yfitse(i)
        fit_cl95(i)=yfit(i)-2.0d0*yfitse(i)
    end if
end do

! get bootstrap estimates

ncl95=int(sngl(nreps)*0.025)
if (ncl95.le.0) ncl95=1
ncu95=int(sngl(nreps)*0.975)
if (ncu95.ge.nreps) ncu95=nreps
n50=int(sngl(nreps)/2.0)
write (*,*) ncl95,ncu95,n50

yfit_boot=0.0d0; yfit_boot_stdev=0.0d0; yfit_boot_se=0.0d0; yfit_boot_cu95=0.0d0; yfit_boot_cl95=0.0d0
do i=1,ntarg
    nnum=0
    do k=1,nreps
        if (.not. isnan(yfit_reps(i,k))) then
            yfit_boot(i)=yfit_boot(i)+yfit_reps(i,k)
            nnum=nnum+1
        end if
    end do
    if (nnum.gt.0) then
        yfit_boot(i)=yfit_boot(i)/dble(nreps)
    end if
    !write (*,*) i,yfit_boot(i)
    nnum=0
    do k=1,nreps
        if (.not. isnan(yfit_reps(i,k))) then
            yfit_boot_stdev(i)=yfit_boot_stdev(i)+(yfit_reps(i,k)-yfit_boot(i))*(yfit_reps(i,k)-yfit_boot(i))
            nnum=nnum+1
        end if
        !write (*,*) i,k,yfit_reps(i,k),yfit_boot_stdev(i)
    end do
    !write (*,*) i,yfit_boot_stdev(i)
    if (nnum.gt.1) then
        yfit_boot_stdev(i)=dsqrt(yfit_boot_stdev(i)/dble(nnum-1))
        !write (*,*) i,yfit_boot_stdev(i)
        yfit_boot_se(i)=yfit_boot_stdev(i)/dsqrt(dble(nnum))
    end if
    temp(:)=yfit_reps(i,:)
    call sortx(nreps,temp,sorttemp)
    yfit_boot_cu95(i)=sorttemp(ncu95)
    yfit_boot_cl95(i)=sorttemp(ncl95)
    yfit_boot_median(i)=sorttemp(n50)
    
    write (7,'(f10.2,4(",",f14.6),", ",i6,5(",",f14.6))') & 
        xtarg(i),yfit(i),yfitse(i),fit_cu95(i),fit_cl95(i),npfit(i), &
        yfit_boot(i),yfit_boot_median(i),yfit_boot_se(i),yfit_boot_cu95(i),yfit_boot_cl95(i)
  
end do

do j=1,nsites
    write (10,*) j,nsel(j)
end do

do i=1,ntarg
    write (11,'(i5,f10.1,200f8.3)') i,xtarg(i),(yfit_reps(i,k),k=1,50)
end do
    
end

function int_to_string(inum)

	implicit none
	character(32)	:: int_to_string
	character(32)	:: buffer, str
	integer			:: inum

	write (buffer,*) inum
	read (buffer,*) str

	int_to_string=trim(adjustl(str))

end function int_to_string


function int_to_string2(inum,numlen)

	implicit none
	character(32)	:: int_to_string,int_to_string2
	character(32)	:: buffer, str
	character(8)	:: ifmt,iedit
	integer			:: inum,numlen

	iedit=int_to_string(numlen)
	ifmt="(i"//trim(adjustl(iedit))//"."//trim(adjustl(iedit))//")"

	write (buffer,ifmt) inum
	read (buffer,*) str

	int_to_string2=trim(adjustl(str))

end function int_to_string2

