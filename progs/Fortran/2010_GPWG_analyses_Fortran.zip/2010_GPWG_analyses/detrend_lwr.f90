program detrend_lwr
! detrend a time series by locally weighted regression (lowess)

use lowess

implicit none

integer, parameter  :: maxdata=100000, maxtarg=100000
real(8)             :: age(maxdata),y(maxdata)
real(8)             :: agebp,depth,yin1,yin2,d1,d2,d3
real(8)             :: param
real(8)             :: xtarg(maxtarg),resid(maxtarg)
real(8)             :: yfit(maxtarg),yfitse(maxtarg),ypredse(maxtarg),xspan(maxtarg)
real(8)             :: resyfit(maxtarg),resyfitse(maxtarg),resypredse(maxtarg),resxspan(maxtarg)
integer             :: nctrl,ntarg,npfit(maxtarg),resnpfit(maxtarg),minpts,order,nrobust

integer             :: i,k

character(1)        :: wintype
character(1028)     :: workpath,seriesfile,outfile,debugfile
character(256)       :: seriesname,paramstr
character(80)       :: header

! input description
seriesname="v2n_nextr_boot_influx2_zt21k_10_250"
! "yd_peakden" ! "yd_influx_050" ! "NGRIP_WC" ! "Combined_N2O" ! "Combined_CH4" ! "NGRIP_dust" ! "Byrd_CO2" ! "ByrdEDC_CO2" ! "conc_400" ! 
workpath="e:\Projects\GPWG\data\files\v2n\curves\"
param=3000.0d0 ! 5000.0d0
wintype="w"; minpts=30; order=1; nrobust=1
paramstr=int_to_string2(int(param),4)

seriesfile=trim(workpath)//"\"//trim(seriesname)//".csv"
outfile=trim(workpath)//"\"//trim(seriesname)//"_detr_"//trim(paramstr)//".csv"
debugfile=trim(workpath)//"\detr_debug.dat"

open (1,file=seriesfile); open (2,file=outfile); open (10,file=debugfile)
write (2,'(a)') "age, "//trim(seriesname)//", trend, resid, residtrend"
! read the series
select case (seriesname)
    case ("NGRIP_WC")   
        ! read data 
        read (1,'(a)') header
        i=0
        do while(.not. eof(1))
            i=i+1
            read (1,*) age(i),d1,d2,y(i) ! 
            !write (10,*) i,age(i),y(i)
        end do
        nctrl=i
    case ("Combined_N2O", "Combined_CH4", "NGRIP_dust", "Byrd_CO2", "conc_400", "ByrdEDC_CO2", &
            "yd_influx_050", "yd_peakden", "v2n_nextr_boot_influx2_zt21k_10_250")   
!e:\Projects\GPWG\data\files\v2n\curves\v2n_nextr_boot_influx2_zt21k_10_250.csv
!e:\Projects\GPWG\data\files\v2n\curves\v2n_sextr_boot_influx2_zt21k_10_250.csv
        ! read data 
        read (1,'(a)') header
        i=0
        do while(.not. eof(1))
            i=i+1
            read (1,*) age(i),y(i) ! 
            !write (10,*) age(i),y(i)
        end do
        nctrl=i
    case default
        write (*,'(a)') seriesname
        stop "series not found"
end select
write (*,'("Number of samples: ",i5)') nctrl

xtarg=age
ntarg=nctrl

! fit the curve

write (*,'(a)') "Fitting curve..."
call lowess_curve(nctrl,age,y,ntarg,xtarg,wintype,param,minpts,order,nrobust,yfit,yfitse,ypredse,npfit,xspan)

!do i=1,nctrl
!    resid(i)=y(i)-yfit(i)
!    write (10,*) age(i),npfit(i),xspan(i)
!end do

! second pass

write (*,'(a)') "Second pass..."
call lowess_curve(nctrl,age,yfit,ntarg,xtarg,wintype,param,minpts,order,nrobust,yfit,yfitse,ypredse,npfit,xspan)

do i=1,nctrl
    resid(i)=y(i)-yfit(i)
    write (10,*) age(i),npfit(i),xspan(i)
end do

! fit a curve to the residuals

write (*,'(a)') "Fitting curve to residuals..."
call lowess_curve(nctrl,age,resid,ntarg,xtarg,wintype,param*2.0d0,minpts,order,nrobust,resyfit,resyfitse,resypredse,resnpfit,resxspan)

do i=1,nctrl
    ! write (2,'(f10.2,6(","f10.4),",",i6)') age(i),y(i),yfit(i),resid(i),resyfit(i)
    write (2,'(f10.2,6(","f10.7),",",i6)') age(i),y(i),yfit(i),resid(i),resyfit(i)
end do

end




