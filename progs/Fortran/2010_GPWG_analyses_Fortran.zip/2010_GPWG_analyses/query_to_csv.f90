program query_to_csv
! reads an all-sites, all-data query and
! writes individual .csv files for sites

use ifport

implicit none

integer, parameter  :: maxsamples=9000,maxsites=2000
integer(4)      :: site_num(maxsites),sitenum2(maxsites)! site id's
integer(4)      :: current,site_num_in                  ! current and next site id's
integer(4)      :: nsamples(maxsites),nsamp             ! number of samples at each site
integer(4)      :: nsamples2(maxsites)                  ! 
integer(8)      :: id_sample(maxsamples)                ! sample id's
integer(4)      :: nsites                               ! number of sites
real(8)         :: lat(maxsites),lon(maxsites)          ! lat and lon
real(4)         :: elev(maxsites)
real(4)         :: depth(maxsamples),age(maxsamples)    ! depth and age
real(4)         :: quant(maxsamples)                    ! charcoal quantity
real(4)         :: thickness(maxsamples)                ! sample thickness (cm)
real(4)         :: dep_time(maxsamples)                 ! sample deposition time (yr)
real(4)         :: unit_dep_time(maxsamples)            ! unit depositional time or inverse dep rate (yr cm-1)
real(4)         :: sed_rate(maxsamples)                 ! sample sed rate (cm yr-1)
real(4)         :: conc(maxsamples)                     ! concentration (c cm-3) 
real(4)         :: influx(maxsamples)                   ! influx (c cm-2 yr-1)
real(4)         :: conc2(maxsamples)                    ! concentration plus other
real(4)         :: influx2(maxsamples)                  ! influx plus other
real(4)         :: miss                                 ! missing value
character(72)   :: site_name(maxsites),site_name2       ! site name
character(4)    :: pref_units,id_status,dep_env         ! pref_units, id_status
character(64)    :: xst_level(maxsamples)               ! xst_level (influx, concentration, etc.) 
character(64)    :: conc_source(maxsamples)             ! source of concentration data  
character(64)    :: influx_source(maxsamples)           ! source of influx data    
character(64)    :: conc2_source(maxsamples)            ! source of concentration plus other data    
character(64)    :: influx2_source(maxsamples)          ! source of influx plus other data    
  
integer         :: i,j,jj,k,outflag,nzero,maxnsamples
integer         :: depthcount,agecount,quantcount,sedratecount,depthreversal,agereversal,sedrateflag,sedratezeroneg,nonmissquant

character(80)   :: header
character(256)  :: csvpath,queryfile,sitelist,sitelistcsv,xstfile,debugfile,missinginfofile
character(256)  :: infofile
character(4)    :: site_num_char
character(80)   :: dum
character(32)   :: int_to_string2

integer             :: pathlen
character(3)        :: drive
character(256)      :: dir,name,ext,file
logical             :: fileexists, direxists, fileresult

! read the info file
call get_command_argument(1,infofile)
open (99,file=trim(adjustl(infofile)))
    read (99,*) queryfile
    read (99,*) sitelist
    read (99,*) csvpath
    read (99,*) sitelistcsv
    read (99,*) debugfile
close (99)

miss=-9999.0
maxnsamples=0
site_name=""; xst_level=""; conc_source=""; influx_source=""; conc2_source=""; influx2_source=""

! open the input data sets
write (*,'(a)') queryfile
inquire (file=queryfile, exist=fileexists)
if (.not. fileexists) stop "query file does not exist, stopping..." 
open (1,file=queryfile)

inquire (file=sitelist, exist=fileexists)
if (.not. fileexists) stop "sitelist file does not exist, stopping..."
open (2,file=sitelist)

! open output files
pathlen=splitpathqq(sitelistcsv, drive, dir, name, ext)
inquire (directory=dir, exist=direxists)
if (.not. direxists) then
    write (*,'(a)') "sitelistcsv directory does not exist, creating..."
    fileresult=system("mkdir "//trim(dir))
end if
open (5,file=sitelistcsv)
write (5,*) "ID_SI, Lat, Lon, Elev, Sitename"

pathlen=splitpathqq(debugfile, drive, dir, name, ext)
inquire (directory=dir, exist=direxists)
if (.not. direxists) then
    write (*,'(a)') "debugfile directory does not exist, creating..."
    fileresult=system("mkdir "//trim(dir))
end if
open (10,file=debugfile)

! check for existence ouf output .csv folder
pathlen=splitpathqq(csvpath, drive, dir, name, ext)
inquire (directory=dir, exist=direxists)
if (.not. direxists) then
    write (*,'(a)') "output folder for .csv files does not exist, creating..."
    fileresult=system("mkdir "//trim(dir))
end if

! count number of sites and number of samples for each site
write (*,'(a)') "Counting number of sites, and samples..."
nsamples2=0
write (10,'(a)') "j, site_num(j), nsamples(j)"
i=0; j=1
read (1,*) site_num_in  ! read first record
current=site_num_in
do while (.not.eof(1))
    read (1,*) site_num_in ! read next record
    if (site_num_in .eq. current) then 
        ! same site
        i=i+1
    else
        ! new site
        site_num(j)=current
        nsamples(j)=i+1
        nsamples2(current)=nsamples(j)
        current=site_num_in
        write (10,'(2i5,i10)') j,site_num(j),nsamples(j)
        i=0
        j=j+1
    end if
end do
nsites=j; site_num(j)=current; nsamples(j)=i+1; nsamples2(current)=nsamples(j)
write (10,'(2i5,i10)') j,site_num(j),nsamples(j)
!write (*,*) j,site_num(j),nsamples(j)
write (*,'("nsites=",i5)') nsites
write (10,'("Total number of site in query=",i5)') nsites
!write (4,'("site_num,xst_level,conc_source,influx_source,conc2_source,influx2_source,sedrateflag,site_name")')

! open the site file and read site numbers and names
write (10,'(a)') "site_num, site_name"
sitenum2=-9
!read (2,*) header
do while (.not.eof(2))
    read (2,*) k,site_name(k),lat(k),lon(k),elev(k)
    write (*,*) k,site_name(k)
    sitenum2(k)=k   
end do
do k=1,site_num(nsites)
    write (*,'(i5,1x,a80)') sitenum2(k),site_name(k)
    write (10,'(i5,1x,a80)') sitenum2(k),site_name(k)
end do

! read the data again, and write individual .csv files
rewind(1)   ! rewind the input file

!read (1,*) header

write (10,'(a)') " "
write (10,'(a)') "j, site_num(j), site_num_in, k, sitenum2(k),site_name(k)"
write (10,'(a)') "----- from query file -----  ----- from sites file -----"
do j=1,nsites   ! loop over the sites

    ! read the data for the j-th site
    depth=miss; age=miss; quant=miss; conc=miss; influx=miss
    do i=1,nsamples(j)
        read (1,*) site_num_in,pref_units,id_sample(i),depth(i),age(i),quant(i),dep_env,id_status,xst_level(i) ! v2i
        !write (*,*) site_num_in,pref_units,id_sample(i),depth(i),age(i),quant(i),id_status,dep_env,xst_level(i) 
    end do
    if (nsamples(j).gt.maxnsamples) maxnsamples=nsamples(j)
    
    ! check to see if there is site data
    k=site_num(j)
    write (*,'(5i5,1x,a60)') j,site_num(j),site_num_in,k,sitenum2(k),site_name(k)
    write (10,'(5i5,1x,a60)') j,site_num(j),site_num_in,k,sitenum2(k),site_name(k)
    
    !write (*,*) j,site_num(j),site_num_in
    if (sitenum2(k).ne.site_num_in) then
        write (*,'(2x,i5," is missing site info")') site_num_in
        write (10,'(2x,i5," is missing site info")') site_num_in
        !write (11,'(2x,i5," is missing site info")') site_num_in
    else        
    
        !write (*,*) j,site_num(j),depth(1)
        
        ! sample thickness, sed rate, and unit_dep_time -- used to convert quantities
        thickness=miss; dep_time=miss; sed_rate=miss; unit_dep_time=miss
        
        ! fixups for first (top) sample
        if (depth(1).ne.miss .and. depth(2).ne.miss) then
            thickness(1)=(depth(2)-depth(1))*100.0 ! depths are in meters, concentrations and influx in cm
            dep_time(1)=age(2)-age(1)
            if (dep_time(1).gt.0.0) sed_rate(1)=thickness(1)/dep_time(1)
            if (sed_rate(1).ne.miss) unit_dep_time(1)=1.0/sed_rate(1)
        end if 
        do i=2,nsamples(j)-1
            if (depth(i).ne.miss .and. depth(i+1).ne.miss) then 
                thickness(i)=(depth(i+1)-depth(i))*100.0
                dep_time(i)=((age(i+1)+age(i))/2.0)-((age(i)+age(i-1))/2.0)  ! no ages should be missing
                if (dep_time(i).gt.0.0) sed_rate(i)=thickness(i)/dep_time(i)
                if (sed_rate(i).ne.miss) unit_dep_time(i)=1.0/sed_rate(i)           
            end if     
        end do
        ! fixups for last (bottom) sample
        if (depth(nsamples(j)).ne.miss .and. depth(nsamples(j)-1).ne.miss) then
            thickness(nsamples(j))=thickness(nsamples(j)-1)
            dep_time(nsamples(j))=age(nsamples(j))-age(nsamples(j)-1)
            sed_rate(nsamples(j))=sed_rate(nsamples(j)-1)
            unit_dep_time(nsamples(j))=unit_dep_time(nsamples(j)-1)
        end if
        
        ! count number of nonissing values 
        depthcount=0; agecount=0; quantcount=0; sedratecount=0; sedrateflag=1
        do i=1,nsamples(j)
            if (depth(i).ne.miss) depthcount=depthcount+1
            if (age(i).ne.miss) agecount=agecount+1
            if (quant(i).ne.miss) quantcount=quantcount+1
            if (sed_rate(i).ne.miss) sedratecount=sedratecount+1
            if (sed_rate(i).eq.miss) sedrateflag=0
        end do
        !write (10,'(7i5)') j,nsamples(j),depthcount,agecount,quantcount,sedratecount,sedrateflag
        
        ! check for age or depth reversals, and zero or negative sed rates (in nonmissing data)
        depthreversal=0; agereversal=0; sedratezeroneg=0         
        do i=2,nsamples(j)
            if (age(i).ne.miss .and. age(i-1).ne.miss .and. age(i).le.age(i-1)) agereversal=1
            if (depth(i).ne.miss .and. depth(i-1).ne.miss .and. depth(i).le.depth(i-1)) depthreversal=1
        end do
        do i=1,nsamples(j)
            if (sed_rate(i).ne.miss .and. sed_rate(i).le.0.0) sedratezeroneg=1
        end do
        
        ! write out various flags
        if (depthcount.ne.0 .and. depthcount.ne.nsamples(j)) then
            write (*,'(2x,i5, " has a missing depth when some are nonmissing ")') site_num(j) 
            write (10,'(2x,i5, " has a missing depth when some are nonmissing ")') site_num(j)  
        end if   
        if (agecount.ne.0 .and. agecount.ne.nsamples(j)) then
            write (*,'(2x,i5, " has a missing age when some are nonmissing ")') site_num(j) 
            write (10,'(2x,i5, " has a missing age when some are nonmissing ")') site_num(j)  
        end if   
        if (quantcount.ne.0 .and. quantcount.ne.nsamples(j)) then
            write (*,'(2x,i5, " has a missing quant when some are nonmissing ")') site_num(j) 
            write (10,'(2x,i5, " has a missing quant when some are nonmissing ")') site_num(j)  
        end if   
        if (sedratecount.ne.0 .and. sedratecount.ne.nsamples(j)) then
            write (*,'(2x,i5, " has a missing sedrate when some are nonmissing ")') site_num(j) 
            write (10,'(2x,i5, " has a missing sedrate when some are nonmissing ")') site_num(j)  
        end if   
        if (depthreversal.eq.1) then
            write (*,'(2x,i5, " has a depth reversal")') site_num(j) 
            write (10,'(2x,i5, " has a depth reversal")') site_num(j) 
        end if
        if (agereversal.eq.1) then
            write (*,'(2x,i5, " has an age reversal")') site_num(j) 
            write (10,'(2x,i5, " has an age reversal")') site_num(j) 
        end if
        if (sedratezeroneg.eq.1) then
            write (*,'(2x,i5, " has zero or negative sedrates")') site_num(j) 
            write (10,'(2x,i5, " has zero or negative sedrates")') site_num(j) 
        end if

        ! calculate alternative quantities
        conc=miss; influx=miss
        influx_source="none"; conc_source="none"; influx2_source="none"; conc2_source="none"
        
        !if (sedrateflag.eq.1) then
            
            select case (xst_level(1))
                case ("INFL") ! quant is influx, calculate concentration               
                    do i=1,nsamples(j)
                        influx(i)=quant(i)
                        influx_source(i)="data"
                        !influx2(i)=influx(i)
                        !influx2_source(i)=influx_source(i)
                        if (influx(i).ne.miss .and. unit_dep_time(i).ne.miss .and. sed_rate(i).ne.0.0) then
                            conc(i)=influx(i)*unit_dep_time(i)
                            conc_source(i)="calculated_from_influx"
                        else
                            conc(i)=quant(i)
                            conc_source(i)="copied_from_quant"
                        end if
                    end do     
                case ("CONC") ! quant is conc, calculate influx               
                    do i=1,nsamples(j)            
                        conc(i)=quant(i)
                        conc_source(i)="data"
                        conc2(i)=conc(i)
                        conc2_source(i)=conc_source(i)
                        if (conc(i).ne.miss .and. sed_rate(i).ne.miss .and. sed_rate(i).ne.0.0) then
                            influx(i)=conc(i)*sed_rate(i)
                            influx_source(i)="calculated_from_conc"
                        else
                            influx(i)=quant(i)
                            influx_source(i)="copied_from_quant" 
                        end if
                        !write (10,'(2i5,1x,a4,6f14.6)') site_num(j),i,xst_level(1),conc2(i),sed_rate(i),influx(i),influx2(i)
                    end do        
                case ("C0P0") ! C0P0 assume quantity is concentration-like         
                    do i=1,nsamples(j)
                        conc(i)=quant(i)
                        conc_source(i)="c0p0"
                        conc2(i)=conc(i)
                        conc2_source(i)=conc_source(i)
                        if (sed_rate(i).ne.miss .and. sed_rate(i).ne.0.0) then
                            influx(i)=quant(i)*sed_rate(i)
                            influx_source(i)="calculated_from_c0p0(conc)"
                        else
                            influx(i)=quant(i)
                            influx_source(i)="copied_from_quant" 
                        end if       
                    end do  
                case ("OTHE") ! just copy quant          
                    do i=1,nsamples(j)               
                        conc(i)=quant(i)
                        conc_source(i)="copied_from_quant"
                        influx(i)=quant(i)
                        influx_source(i)="copied_from_quant"                
                    end do   
                case default
                    ! stop "xst" 
                    ! just copy           
                    do i=1,nsamples(j)               
                        conc(i)=quant(i)
                        conc_source(i)="copied_from_quant"
                        influx(i)=quant(i)
                        influx_source(i)="copied_from_quant"                
                    end do   
            end select
        
        ! check for all zeros in influx
        nzero=0
        do i=1,nsamples(j)
            if (influx(i).eq.0.0) nzero=nzero+1
        end do
        
        if (nzero.ne.nsamples(j)) then
                
            !write (4,'(i4,",",5("""",a4,"""",","),i2,", ",a72)') &
            !    site_num(j),xst_level(1),conc_source(1),influx_source(1),conc2_source(1),influx2_source(1),sedrateflag,(adjustl(site_name(site_num(j))))
                                    
            ! create the .csv file for j-th site and write out data
            site_num_char=int_to_string2(site_num(j),4)
            open (3,file=trim(csvpath)//trim(adjustl(site_num_char))//"_data.csv")
            ! first column label is site number:
            write (3,'(a)') "site"//site_num_char//",id_sample,depth,est_age,sed_rate,quant,conc,influx," &
                //"xst_level,conc_source,influx_source"
                !//"conc2,influx2,xst_level,conc_source,influx_source,conc2_source,influx2_source"
            do i=1,nsamples(j)
                if (quant(i).ne.miss) then
                    write (3,'(i4,",",i10,",",f10.4,",",f10.3,", ",f10.3,3(", ",g12.6),1(","1x,"""",a4,""""),2(","1x,"""",a26,""""))') &
                        i,id_sample(i),depth(i),age(i),sed_rate(i),quant(i),conc(i),influx(i), & ! conc2(i),influx2(i), &
                        xst_level(i),conc_source(i),influx_source(i) !,conc2_source(i),influx2_source(i)
                end if
            end do
            close(3)   
            
            site_name2=""""//trim(adjustl(site_name(site_num(j))))//""""
            write (5,'(i4,2(",",f12.6),",",f6.0,", ",a72)') site_num(j),lat(site_num(j)),lon(site_num(j)),elev(site_num(j)),site_name2
        else
            write (*,'(2x,i5," has all zeros in influx2 ********")')  site_num(j)
            write (10,'(2x,i5," has all zeros in influx2 ********")')  site_num(j)
        end if
    end if      
end do

write (*,'("nsites, maxnsamples: ",2i6)') nsites,maxnsamples

!write (11,*) "site number, nsamples, site_name"
!do j=1,maxsites
!    if (nsamples2(j).ne.0) then
!        write (11,'(2i5,2x,a72)') j,nsamples2(j),site_name(j)
!    else
!        write (11,'(2i5,2x,a72)') j,nsamples2(j)
!    end if
!end do

end program query_to_csv

function int_to_string(inum)

	implicit none
	character(32)	:: int_to_string
	character(32)	:: buffer, str
	integer			:: inum

	write (buffer,*) inum
	read (buffer,*) str

	int_to_string=trim(adjustl(str))

end function int_to_string

        
function int_to_string2(inum,numlen)

	implicit none
	character(32)	:: int_to_string,int_to_string2
	character(32)	:: buffer, str
	character(8)	:: ifmt,iedit
	integer			:: inum,numlen

	iedit=int_to_string(numlen)
	ifmt="(i"//trim(adjustl(iedit))//"."//trim(adjustl(iedit))//")"

	write (buffer,ifmt) inum
	read (buffer,*) str

	int_to_string2=trim(adjustl(str))

end function int_to_string2
  
    







            