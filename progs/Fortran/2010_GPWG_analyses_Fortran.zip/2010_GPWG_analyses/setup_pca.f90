program setup_pca
! builds matrices of fitted values and missing-data flags for PCA

use lowess
use ifport

implicit none

integer, parameter  :: maxdata=300000, maxsites=5000, maxtarg=4000 

! sitelist
real(8)             :: lat(maxsites),lon(maxsites),subset_lat(maxsites),subset_lon(maxsites)
integer             :: site_num(maxsites),subset_site_num(maxsites),nsites,nsubset
character(4)        :: site_num_char(maxsites),subset_site_char(maxsites)

! data, fitted values
real(4)             :: varin,varmiss,age,depth,var,varmnx,tall,zt
integer(4)          :: site_sample
integer(8)          :: id_sample
character(8)        :: site_num_label

real(8)             :: xin(maxdata),yin(maxdata),xtarg(maxdata),yfit(maxdata)
real(8)             :: yfitse(maxdata),fitcu_95(maxdata),fitcl_95(maxdata),ypredse(maxdata),xspan(maxdata)
real(8)             :: xtemp(maxdata),vartemp(maxdata),vartemp2(maxdata),vmean,vstdev,vmin,vmax,vrng
integer             :: ntarg,npfit(maxdata),nctrl,npts2
character(8)        :: str_age,str_val(maxsites),str_nmiss,str_pmiss

! lowess parameters etc.
real(8)             :: targbeg,targend,targstep,param,pnmiss,begbase,endbase
character(32)       :: param_str,pnmiss_str
integer(4)          :: minpts,order,nrobust
character(1)        :: wintype

! output matrices
real(8)             :: allfits(maxtarg,maxsites),subset(maxtarg,maxsites),pmiss,psmiss(maxsites),ptmiss(maxtarg)
integer             :: flag(maxtarg,maxsites),nmiss,nsmiss(maxsites),ntmiss(maxtarg)

! paths, filenames
character(1024)     :: infofile,aname,regionpath,regionname,regionfile,transpath,transname,transfile
character(1024)     :: outpath,flagfile,fitsfile,subsetfile,statsfile,debugpath,debugfile,mappath,mapdatfile,mapmxyfile
character(1024)     :: fmt,fmt1,fmt2
character(8000)     :: buffer
character(80)       :: header

integer             :: i,j,jj

! read the info file
call get_command_argument(1,infofile)
open (99,file=trim(adjustl(infofile)))
    read (99,*) aname
    read (99,*) regionpath
    read (99,*) regionname
    read (99,*) transpath
    read (99,*) transname
    read (99,*) outpath
    read (99,*) mappath
    read (99,*) targbeg
    read (99,*) targend
    read (99,*) targstep
    read (99,*) param
    read (99,*) pnmiss
close (99)

! filenames
write (*,'(a)') trim(aname)
regionfile=trim(regionpath)//trim(regionname)//".csv"
write (*,'(a)') trim(regionfile)
write (*,'(a)') trim(transpath)
write (*,'(a)') trim(outpath)
write (*,*) targbeg,targend,targstep
write (*,*) param,pnmiss
param_str=int_to_string2(int(param),4)
pnmiss_str=int_to_string2(int(pnmiss),2)
flagfile=trim(outpath)//trim(aname)//"_"//trim(param_str)//"_"//trim(pnmiss_str)//"_flag.csv"
fitsfile=trim(outpath)//trim(aname)//"_"//trim(param_str)//"_"//trim(pnmiss_str)//"_fits.csv"
subsetfile=trim(outpath)//trim(aname)//"_"//trim(param_str)//"_"//trim(pnmiss_str)//"_subset.csv"
!statstfile=trim(outpath)//trim(aname)//"_"//trim(param_str)//"_"//trim(pnmiss_str)//"_stats.csv"
mapdatfile=trim(mappath)//trim(aname)//"_"//trim(param_str)//"_"//trim(pnmiss_str)//".dat"
mapmxyfile=trim(mappath)//trim(aname)//"_"//trim(param_str)//"_"//trim(pnmiss_str)//".mxy"
debugfile=trim(outpath)//trim(aname)//"_"//trim(param_str)//"_"//trim(pnmiss_str)//"_debug.dat"
write (*,'(a)') trim(flagfile)
write (*,'(a)') trim(fitsfile)
!write (*,'(a)') trim(fits2file)
write (*,'(a)') trim(subsetfile)
write (*,'(a)') trim(mapdatfile)
write (*,'(a)') trim(mapmxyfile)
write (*,'(a)') trim(debugfile)
open (10,file=trim(debugfile))

! lowess parameters
minpts=0; wintype='w'; order=0; nrobust=1

! restandardization
begbase=200.0d0; endbase=21000.0d0 ! zt21k

! missing data value
varmiss=-9999.0

! generate target points
ntarg=int((targend-targbeg)/targstep)+1
write (10,*) param,targstep,ntarg
do i=1,ntarg
    xtarg(i)=targbeg+dble(i-1)*targstep  
    write (10,*) i,sngl(xtarg(i))
end do

! read sitelist
open (1,file=trim(regionfile))
read (1,*) header
j=0
do
    if (eof(1)) exit
    j=j+1
    read (1,*) site_num(j),lat(j),lon(j)
    site_num_char(j)=int_to_string2(site_num(j),4)
    write (10,*) site_num(j),lat(j),lon(j),site_num_char(j)
end do
nsites=j
write (10,'("nsites: ",i5)') nsites
close(1)

flag=0; allfits=0.0d0/0.0d0; subset=0.0d0/0.0d0

! main loop
do j=1,nsites
    transfile=trim(transpath)//trim(int_to_string2(site_num(j),4))//"_trans_"//trim(transname)//".csv"
    write (*,'(a)') trim(transfile)
    write (10,'(a)') trim(transfile)
    
    ! read a site trans file
    open (2,file=trim(transfile))
    
    ! read data, and save age and variable to be smoothed
    read (2,*) header
    i=0
    do while (.not. eof(2))
        read (2,*) site_num_label,site_sample,id_sample,age,depth,var,varmnx,tall,zt
        varin=zt      
        if (varin.ne.varmiss) then
            i=i+1
            xin(i)=age
            yin(i)=varin
            write (10,'(i5," ,",a8," ,",i4,2(",",f14.6))') i,site_num_label,site_sample,xin(i),yin(i)         
        end if
    end do
    nctrl=i
    close (2)
    
    yfit=0.0d0; yfitse=0.0d0; fitcu_95=0.0d0; fitcl_95=0.0d0
    
    call lowess_curve(nctrl,xin,yin,ntarg,xtarg,wintype,param,minpts,order,nrobust,yfit,yfitse,ypredse,npfit,xspan)

    do i=1,ntarg
        if (.not. isnan(yfit(i))) then
            fitcu_95(i)=yfit(i)+2.0d0*yfitse(i)
            fitcl_95(i)=yfit(i)-2.0d0*yfitse(i)
            write (10,'(i4,1x,a8,5(",",f14.6),", ",i6)') i,site_num_label,xtarg(i),yfit(i),yfitse(i),fitcu_95(i),fitcl_95(i),npfit(i)
        else    
            !yfit(i)=varmiss
        end if
    end do
       
    ! restandardize
    vartemp=yfit; xtemp=xtarg
    call stats(ntarg,xtemp,vartemp,dble(varmiss),targbeg,targend,npts2,vmean,vstdev,vmin,vmax,vrng)
    write (10,'("before restandardizing: ",i5,2f14.6)') j,vmean,vstdev
    call zscores(ntarg,vartemp,dble(varmiss),vmean,vstdev,vartemp2)
    !do i=1,ntarg
    !    write (10,'(i4,3f14.6)') i,xtarg(i),yfit(i),vartemp2(i)
    !end do
    call stats(ntarg,xtemp,vartemp2,dble(varmiss),targbeg,targend,npts2,vmean,vstdev,vmin,vmax,vrng)
    write (10,'(" after restandardizing: ",i5,2f14.6)') j,vmean,vstdev
    
    ! write/store values
    do i=1,ntarg
        allfits(i,j)=vartemp2(i) 
    end do
     
end do

! get subset of sites where nmissing > pnmiss (proportion nonmissing)
jj=0; nsmiss=0; psmiss=0.0d0
do j=1,nsites
    nmiss=0; pmiss=0.0d0
    do i=1,ntarg
        if (isnan(allfits(i,j))) nmiss=nmiss+1
    end do
    pmiss=real(nmiss)/real(ntarg)
    if (pmiss.le.(1.0d0-(pnmiss/100.0d0))) then
        jj=jj+1
        nsmiss(jj)=nmiss
        psmiss(jj)=pmiss
        subset_site_num(jj)=site_num(j)
        subset_site_char(jj)=site_num_char(j)
        subset_lat(jj)=lat(j)
        subset_lon(jj)=lon(j)
        do i=1,ntarg
            subset(i,jj)=allfits(i,j)
            if (.not. isnan(allfits(i,j))) flag(i,jj)=1
        end do
    end if
end do
nsubset=jj
write (*,'("ntarg, nsites, nsubset: ", 3i5)') ntarg,nsites,nsubset

! count number missing by time
ntmiss=0; ptmiss=0.0d0
do i=1,ntarg
    do j=1,nsubset
        if (isnan(subset(i,j))) ntmiss(i)=ntmiss(i)+1
    end do
    if (ntmiss(i).gt.0) ptmiss(i)=real(ntmiss(i))/real(nsubset)
end do

! fits file
open (3,file=trim(fitsfile))
write (3,'(a)') "i, j, site_num, lat, lon, age, flag, fit"
do j=1,nsubset
    do i=1,ntarg
        write (3,'(i4,2(", ",i4),2(", ",f12.6),", ",f7.0,", ",i1,", ",f14.6)') & 
            i,j,subset_site_num(j),subset_lat(j),subset_lon(j),xtarg(i),flag(i,j),subset(i,j)
    end do
end do
close (3)

! flag file
open (2,file=trim(flagfile))
fmt='("site ",'//trim(int_to_string(ntarg))//'(", ",'//'""""i6.5""""'//'),", nsmiss, psmiss")'
!write (*,'(a)') trim(fmt)
write (2,fmt) (int(xtarg(i)),i=1,ntarg)
fmt='(a4,'//trim(int_to_string(ntarg))//'(",",i1),", ",i6,", ",f6.3))'
do j=1,nsubset
    write (2,fmt) subset_site_char(j),(flag(i,j),i=1,ntarg),nsmiss(j),psmiss(j)
end do
close(2)

! subset file, replace NaN's with blanks
open (4,file=trim(subsetfile))
fmt='("age     ",'//trim(int_to_string(nsubset))//'(", ",'//'""""a5""""'//'),",   nsmiss,   psmiss")'
!write (*,'(a)') trim(fmt)
write (4,fmt) ("z"//trim(subset_site_char(j)),j=1,nsubset)
fmt1='(f8.0,'//trim(int_to_string(nsubset))//'(",",f8.3),", ",i8,", ",f8.3))'
fmt2='(a8,'//trim(int_to_string(nsubset))//'(",",a8),", ",a8,", ",a8))'
do i=1,ntarg
    write (buffer,fmt1) xtarg(i),(subset(i,j),j=1,nsubset),ntmiss(i),ptmiss(i)
    read (buffer,*) str_age,(str_val(j),j=1,nsubset),str_nmiss,str_pmiss
    !write (*,'(a)') trim(buffer)
    !write (*,*) str_age,(str_val(j),j=1,nsubset),str_nmiss,str_pmiss
    do j=1,nsubset
        if (adjustr(str_val(j)).eq."     NaN") str_val(j)="        "
    end do
    write (4,fmt2) adjustr(str_age),(adjustr(str_val(j)),j=1,nsubset),adjustr(str_nmiss),adjustr(str_pmiss)
end do
close(4)

! mapping files
open (5,file=trim(mapdatfile))
open (6,file=trim(mapmxyfile))
do j=1,nsubset
    write (5,'(2f12.6,i5,f6.3,i5)') subset_lat(j),subset_lon(j),nsmiss(j),psmiss(j),subset_site_num(j)
    write (6,'(4f12.6)') subset_lat(j),subset_lon(j),subset_lon(j),subset_lat(j)
end do

end

subroutine stats(n,age,q,qmiss,begbase,endbase,nbase,mean,stdev,qmin,qmax,qrng)

    implicit none

    integer, intent(in)     :: n
    real(8), intent(in)     :: age(n),q(n),qmiss
    real(8), intent(in)     :: begbase,endbase
    real(8), intent(out)    :: mean,stdev,qmax,qmin,qrng
    real(8)                 :: nan
    integer(4), intent(out) :: nbase

    integer(4)              :: i    
        
    nan=0.0d0/0.0d0    
        
    ! mean
    nbase=0; mean=0.0d0
    do i=1,n
        if (.not. isnan(q(i))) then
            if (q(i).ne.qmiss .and. age(i).ge.begbase .and. age(i).le.endbase) then
                mean=mean+q(i)
                nbase=nbase+1
            end if
        end if
    end do
    if (nbase.ne.0) then
        mean=mean/dble(nbase)
    else
        mean=qmiss
    end if
    
    ! standard deviation
    stdev=0.0
    do i=1,n
        if (.not. isnan(q(i))) then
            if (q(i).ne.qmiss .and. age(i).ge.begbase .and. age(i).le.endbase) then
                stdev=stdev+(q(i)-mean)*(q(i)-mean)
            end if
        end if
    end do
    if (nbase.gt.1) then
        stdev=dsqrt((stdev)/dble(nbase-1))
    else
        stdev=qmiss
    end if
    
    ! min, max, range
    qmin=9999999.0d0; qmax=-9999999.0d0
    do i=1,n
        if (.not. isnan(q(i))) then
            if (q(i).ne.qmiss .and. age(i).ge.begbase .and. age(i).le.endbase) then
                if (q(i) .le. qmin) qmin=q(i)
                if (q(i) .ge. qmax) qmax=q(i)
            end if
        end if
    end do
    qrng=qmax-qmin

end subroutine stats


subroutine zscores(n,quant,qmiss,mean,stdev,z)

    implicit none

    integer, intent(in)     :: n
    real(8), intent(in)     :: quant(n),qmiss
    real(8), intent(in)     :: mean,stdev
    real(8)                 :: nan
    real(8), intent(out)    :: z(n)

    integer(4)              :: i
    
    nan=0.0d0/0.0d0 
    
    ! zscores
    z=0.0d0/0.0d0
    if (mean.ne.qmiss .and. stdev.ne.qmiss .and. stdev.ne.0.0d0) then
        do i=1,n
            if (.not. isnan(quant(i))) then
                if (quant(i).ne.qmiss .and. quant(i).ne.nan) then 
                    z(i)=(quant(i)-mean)/stdev 
                end if
            end if
        end do
    end if
    
end subroutine zscores




