program smooth_curve_ninwin
! fits a smooth lowess-type curve to transformed/standardized charcoal data
! gets bootstrap estimates of confidence intervals of lowess curve

use lowess
use ifport

implicit none

integer, parameter  :: maxdata=100000, maxsitedata=9000, maxsites=2000, maxtarg=10000, maxreps=5000

integer(4)      :: site_sample
integer(8)      :: id_sample
real(4)         :: age,depth,var,varmnx,tall,zt

real(4)         :: varin,varmiss
integer         :: site_num,usesitenum,usesite(maxsites)
character(16)   :: site_num_label,timeprefix,ww
character(4)    :: site_num_char

character(32)   :: vname

real(8)         :: xsite(maxsitedata,maxsites),ysite(maxsitedata,maxsites)
integer         :: nrecs(maxsites),idsite(maxsites),nsel(maxsites),ndec(maxtarg,maxsites),ndec_tot(maxtarg)
integer         :: ninwin(maxtarg,maxsites), ninwintot(maxtarg)

real(8)         :: xin(maxdata),yin(maxdata)

real(4)         :: begyr,endyr
real(8)         :: xtarg(maxtarg),yfit(maxtarg),yfitse(maxtarg),fit_cu95(maxtarg),fit_cl95(maxtarg),ypredse(maxtarg)
real(8)         :: param,xspan(maxtarg)
real(8)         :: targbeg,targend,targstep
integer(4)      :: npfit(maxtarg),minpts,order,nrobust,ntarg
character(1)    :: wintype

real(8)         :: ranseed,randval
real(8)         :: yfit_reps(maxtarg,maxreps),temp(maxreps),sorttemp(maxreps)
real(8)         :: yfit_boot(maxtarg),yfit_boot_median(maxtarg),yfit_boot_stdev(maxtarg),yfit_boot_se(maxtarg)
real(8)         :: yfit_boot_cu95(maxtarg),yfit_boot_cl95(maxtarg)
integer         :: jsel(maxsites,maxreps),jmax,jmin,ncl95,ncu95,n50

integer         :: i,j,k,npts,nctrl,jsite,nsites,ii,nreps,intype

!character(32)   :: int_to_string2,int_to_string
character(256)  :: infofile
character(256)  :: infilepath,infile,outpath,infileroot,lowfile,lowcsvfile,cufile,clfile
character(256)  :: region,regionpath,regionfile,debugfile,infiletype
character(16)   :: base, queryname, sww

character(80)   :: header
character(1)    :: dum

logical         :: yfitnan,nan 

integer             :: pathlen
character(3)        :: drive
character(256)      :: dir,name,ext,file
logical             :: fileexists, direxists, fileresult

! read the info file
call get_command_argument(1,infofile)
open (99,file=trim(adjustl(infofile)))

do while (.not. eof(99))
    read (99,*) infilepath
    read (99,*) infileroot
    read (99,*) outpath
    read (99,*) regionpath
    read (99,*) region
    read (99,*) debugfile
    read (99,*) infiletype
    read (99,*) param
    read (99,*) targbeg
    read (99,*) targend
    read (99,*) targstep
    read (99,*) nreps
!close (99)

! check for existence of input data path (.csv files)
pathlen=splitpathqq(infilepath, drive, dir, name, ext)
inquire (directory=dir, exist=direxists)
if (.not. direxists) stop "Input .csv file directory does not exist, or is specified wrong, stopping..."

! check for existence of an output folder
pathlen=splitpathqq(outpath, drive, dir, name, ext)
inquire (directory=dir, exist=direxists)
if (.not. direxists) then
    write (*,'(a)') "Output folder for presampled .csv files does not exist, creating..."
    fileresult=makedirqq(dir)
end if

! check for existence of a regions folder
pathlen=splitpathqq(regionpath, drive, dir, name, ext)
inquire (directory=dir, exist=direxists)
if (.not. direxists) stop "Folder for region definition files does not exist, or is specified wrong, stopping..."
regionfile=trim(adjustl(regionpath))//trim(adjustl(region))//".csv"

! check for existence of region definition file
inquire (file=regionfile, exist=fileexists)
if (.not. fileexists) stop "Region definition file does not exist, stopping..." 
open (8,file=regionfile) 

! debug file folder
pathlen=splitpathqq(debugfile, drive, dir, name, ext)
inquire (directory=dir, exist=direxists)
if (.not. direxists) then
    write (*,'(a)') "debugfile directory does not exist, creating..."
    fileresult=makedirqq(dir)
end if
open (10,file=debugfile)


ww=int_to_string2(int(int(param)),4)
lowcsvfile=trim(adjustl(region))//"_boot_"//trim(adjustl(infileroot))// &
            "_"//trim(adjustl(ww))//".csv" 

write (*,'("infilepath:"/a80)') infilepath;     write (10,'("infilepath:"/a80)') infilepath
write (*,'("infileroot:"/a80)') infileroot;     write (10,'("infileroot:"/a80)') infileroot
write (*,'("outpath:"/a80)') outpath;           write (10,'("outpath:"/a80)') outpath
write (*,'("regionpath:"/a80)') regionpath;     write (10,'("regionpath:"/a80)') regionpath
write (*,'("region:"/a80)') region;             write (10,'("region:"/a80)') region 
write (*,'("regionfile:"/a80)') regionfile;     write (10,'("regionfile:"/a80)') regionfile
write (*,'("lowcsvfile:"/a80)') lowcsvfile;     write (10,'("lowcsvfile:"/a80)') lowcsvfile

open (7,file=trim(adjustl(outpath))//trim(adjustl(lowcsvfile)))
write (7,'(a)') "targ_age,  "//trim(region)//"_"//trim(adjustl(infileroot))//"_"//trim(adjustl(ww))//", sefit, fitcu95, fitcl95, np, "// &
    trim(adjustl(infileroot))//"_"//trim(adjustl(ww))//"_boot, yfit_boot_median,yfit_boot_se, yfit_boot_cu95, yfit_boot_cl95, nsites, window, ninwin"  ! ############

!open (11,file=trim(adjustl(outpath))//"yfit_"//trim(adjustl(ww))//"_boot.dat") ! ############

! lowess parameters
!##param=100.0d0
wintype='w'; minpts=30; order=1; nrobust=1     ! ############

begyr=targbeg-4.0*param; endyr=targend+4.0*param
write (*,'("begyr, endyr: ",2f12.0)') begyr,endyr
write (10,'("begyr, endyr: ",2f12.0)') begyr,endyr

! random number seed
call srand(100)

! generate target points
ntarg=int((targend-targbeg)/targstep)+1
write (*,*) param,targstep,ntarg,order,nrobust,wintype
write (10,*) param,targstep,ntarg,order,nrobust,wintype
do i=1,ntarg
    xtarg(i)=targbeg+dble(i-1)*targstep
    write (10,*) i,sngl(xtarg(i))
end do

varmiss=-9999.0

! read the region site file
usesite=0
read (8,*) header
do while (.not. eof(8))
    read (8,*) usesitenum
    !write (*,*) usesitenum
    usesite(usesitenum)=1
end do 
!write (*,'(20i5)') usesite
!pause

! read data, store individual sites in array

nsel=0
jsite=0
xsite=0.0; ysite=0.0
ndec=0; ndec_tot=0
do j=1,maxsites

    site_num_char=int_to_string2(j,4)
    
    ! try to open a file
    site_num_char=int_to_string2(j,4)   
    select case (infiletype)
        case ("trans") ! trans input
            infile=trim(adjustl(infilepath))//trim(adjustl(site_num_char))//"_trans_"//trim(adjustl(infileroot))//".csv"
        case ("presamp") ! trans input
            infile=trim(adjustl(infilepath))//trim(adjustl(site_num_char))//"_presamp_"//trim(adjustl(infileroot))//".csv"
    end select
    !write (10,'(a)') infile 
        
    if (usesite(j).eq.1) then
        write (*,*) site_num_char, usesite(j)
        write (10,*) site_num_char, usesite(j)
        write (*,'(a256)') infile
    end if
    
    open (1,file=infile, status='old', err=100)
    ! if site file exists:
     
    if (usesite(j).eq.1) then    
        write (10,'(a)') infile
        jsite=jsite+1
        idsite(jsite)=j    
        
        !write (*,*) site_num_char, usesite(j)
        !write (*,'(a96)') infile
        
        ! read data, and save age and variable to be smoothed
        read (1,*) header
        i=0
        do while (.not. eof(1))   
            select case (infiletype)
                case ("trans") ! trans input
                    read (1,*) site_num_label,site_sample, id_sample, age, depth, var, varmnx, tall, varin
                case ("presamp") ! 1st stage smoothing file
                    read (1,*) site_sample,age,varin
            end select
            !write (10,*) site_sample,age,varin
            if (age.ge.begyr .and. age.le.endyr .and. varin.ne.varmiss) then
                i=i+1
                xsite(i,jsite)=age
                ysite(i,jsite)=varin        
                !write (*,*) i,age,varin
                ii=(age-xtarg(1))/targstep + 1
                if (ii.gt.0 .and. ii.le.ntarg) ndec(ii,jsite)=1
                ! write (10,*) age,varin,ii,jsite,ndec(ii,jsite)
            end if
        end do
        nrecs(jsite)=i
        close(1)
        
        
        write (10,'("j,jsite,idsite,nrecs,site_num_char:",4i5,1x,a4)') j,jsite,idsite(jsite),nrecs(jsite),site_num_char
        !write (*,'("j,jsite,idsite,nrecs,site_num_char:",4i5,1x,a4)') j,jsite,idsite(jsite),nrecs(jsite),site_num_char
        !write (10,'(i4,1x,3000i1)') jsite,(ndec(i,jsite),i=1,ntarg)
        !write (*,'(i4,1x,3000i1)') jsite,(ndec(i,jsite),i=1,ntarg)

    end if
    go to 101
    
100 continue
!write (*,'(a)') "file not found"

101 continue

end do
nsites=jsite

! bootstrap sampling and fitting

yfit_reps=0.0d0; nsel=0
!nreps=20

do k=1,nreps

    jmax=-99999; jmin=99999
    ii=0
    do j=1,nsites

        ! select a site at random
        randval=rand(0)
        jsel(j,k)=int(randval*sngl(nsites))+1
        nsel(jsel(j,k))=nsel(jsel(j,k))+1
        if (jmax.lt.jsel(j,k)) jmax=jsel(j,k)
        if (jmin.gt.jsel(j,k)) jmin=jsel(j,k)
        
        ! for debugging ########
        !jsel(j,k)=j   ! no sample

        
        ! concatenate records
        if (nrecs(jsel(j,k)).gt.1) then
            do i=1,nrecs(jsel(j,k))
                ii=ii+1
                xin(ii)=xsite(i,jsel(j,k))
                yin(ii)=ysite(i,jsel(j,k))
                write (10,'(4i6,2f14.6)') ii,j,idsite(jsel(j,k)),i,xin(ii),yin(ii)
            end do
        end if
    end do
    npts=ii
    
    write (*,'(i5,\)') k !,npts,ntarg
    yfit=0.0d0; yfitse=0.0d0; fit_cu95=0.0d0; fit_cl95=0.0d0; npfit=0
    call lowess_curve(npts,xin,yin,ntarg,xtarg,wintype,param,minpts,order,nrobust,yfit,yfitse,ypredse,npfit,xspan)
    
    ! save fitted values
    do i=1,ntarg
        yfit_reps(i,k)=yfit(i)
    end do
       
    !write (10,*) k,jmin,jmax
    !write (10,'(20i4)') (jsel(j,k),j=1,nsites)
    
end do

!do i=1,ntarg
!    write (*,'(i5,100f6.3)') i,(yfit_reps(i,k),k=1,nreps)
!end do

200 continue

! one more fit to get standard (unresampled) values
ii=0
do j=1,nsites
    ! concatenate records
    if (nrecs(j).gt.1) then
        do i=1,nrecs(j)
            ii=ii+1
            xin(ii)=xsite(i,j)
            yin(ii)=ysite(i,j)
            !write (2,'(4i6,2f14.6)') ii,j,idsite(j),i,xin(ii),yin(ii)
        end do
    end if
end do
npts=ii
    
write (*,*) npts,ntarg
yfit=0.0d0; yfitse=0.0d0; fit_cu95=0.0d0; fit_cl95=0.0d0; npfit=0
call lowess_curve(npts,xin,yin,ntarg,xtarg,wintype,param,minpts,order,nrobust,yfit,yfitse,ypredse,npfit,xspan)

do i=1,ntarg
    if (.not. isnan(yfit(i))) then
        fit_cu95(i)=yfit(i)+2.0d0*yfitse(i)
        fit_cl95(i)=yfit(i)-2.0d0*yfitse(i)
    end if
end do

! get bootstrap estimates

ncl95=int(sngl(nreps)*0.025)
if (ncl95.le.0) ncl95=1
ncu95=int(sngl(nreps)*0.975)
if (ncu95.ge.nreps .or. ncu95.le.0) ncu95=nreps
n50=int(sngl(nreps)/2.0)
if (n50.ge.nreps .or. n50.le.0) n50=nreps
write (*,*) ncl95,ncu95,n50

! count number of sites that contributed to each fitted value
ninwin=0; ninwintot=0
do ii=1,ntarg
do j=1,nsites
        do i=1,nrecs(j)
            if (xsite(i,j).ge.xtarg(ii)-param .and. xsite(i,j).lt.xtarg(ii)+param) ninwin(ii,j)=1
        end do
    end do
end do

yfit_boot=0.0d0; yfit_boot_stdev=0.0d0; yfit_boot_se=0.0d0; yfit_boot_cu95=0.0d0; yfit_boot_cl95=0.0d0
do i=1,ntarg
    do k=1,nreps
        yfit_boot(i)=yfit_boot(i)+yfit_reps(i,k)
    end do
    yfit_boot(i)=yfit_boot(i)/dble(nreps)
    !write (*,*) i,yfit_boot(i)
    do k=1,nreps
        yfit_boot_stdev(i)=yfit_boot_stdev(i)+(yfit_reps(i,k)-yfit_boot(i))*(yfit_reps(i,k)-yfit_boot(i))
        !write (*,*) i,k,yfit_reps(i,k),yfit_boot_stdev(i)
    end do
    !write (*,*) i,yfit_boot_stdev(i)
    yfit_boot_stdev(i)=dsqrt(yfit_boot_stdev(i)/dble(nreps-1))
    !write (*,*) i,yfit_boot_stdev(i)
    yfit_boot_se(i)=yfit_boot_stdev(i)/dsqrt(dble(nreps))
    temp(:)=yfit_reps(i,:)
    call sortx(nreps,temp,sorttemp)
    yfit_boot_cu95(i)=sorttemp(ncu95)
    yfit_boot_cl95(i)=sorttemp(ncl95)
    yfit_boot_median(i)=sorttemp(n50)
    
    !write (10,'(i4,1x,100i1)') i,(ndec(i,j),j=1,nsites)
    do j=1,nsites
        ndec_tot(i)=ndec_tot(i)+ndec(i,j)
        ninwintot(i)=ninwintot(i)+ninwin(i,j)
        ! write (10,*) i,j,ndec_tot(i),ndec(i,j),idsite(j)
    end do
    
    ! replace Nan's 
    if (isnan(yfit(i))) then 
        yfit(i)=varmiss
        yfitse(i)=varmiss
        fit_cu95(i)=varmiss
        fit_cl95(i)=varmiss
    end if
    if (isnan(yfit_boot(i)))        yfit_boot(i)=varmiss
    if (isnan(yfit_boot_median(i))) yfit_boot_median(i)=varmiss
    if (isnan(yfit_boot_se(i)))     yfit_boot_se(i)=varmiss
    if (isnan(yfit_boot_cu95(i)))   yfit_boot_cu95(i)=varmiss
    if (isnan(yfit_boot_cl95(i)))   yfit_boot_cl95(i)=varmiss

!    write (5,'(f10.2,4f14.6,i6,5f14.6,i6)') & 
!        xtarg(i),yfit(i),yfitse(i),fit_cu95(i),fit_cl95(i),npfit(i), &
!        yfit_boot(i),yfit_boot_median(i),yfit_boot_se(i),yfit_boot_cu95(i),yfit_boot_cl95(i),ndec_tot(i)
    write (7,'(f10.2,4(",",f14.6),", ",i8,5(",",f14.6),",",i6,",",f10.2,",",i6)') & 
        xtarg(i),yfit(i),yfitse(i),fit_cu95(i),fit_cl95(i),npfit(i), &
        yfit_boot(i),yfit_boot_median(i),yfit_boot_se(i),yfit_boot_cu95(i),yfit_boot_cl95(i),ndec_tot(i),xspan(i),ninwintot(i)
    !write (10,*) i,xtarg(i),npfit(i)
    
end do

!write (6,'("""",a24,"; bootstrap estimates param=",f5.1,"; wintype=",a1,"; order=",i1,"; nrobust=",i1,"""")') &
!    trim(adjustl(lowfile)),param,wintype,order,nrobust

!do j=1,nsites
!    write (10,*) j,nsel(j)
!end do

!do i=1,ntarg
!    write (11,'(i5,f10.1,200f8.4)') i,xtarg(i),(yfit_reps(i,k),k=1,50)
!end do

close(7); close(8) !; close(10); close(11)

end do
    
end



