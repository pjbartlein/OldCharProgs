      subroutine desc(w,x,n,mean,stddev,ar1) 
      implicit none
      integer wmax
      parameter (wmax=3000)
      real x(wmax),w(wmax),wsum
      real mean,var,stddev,ar1
      integer i,n
c     
      wsum=0.0
      mean=0.0
      do 10 i=1,n
          mean=mean+x(i)*w(i)
          wsum=wsum+w(i)
   10 continue
c            
      mean=mean/wsum
c
      var=0.0
      do 12 i=1,n
          var=var+w(i)*(x(i)-mean)*(x(i)-mean)
   12 continue
      var=var/(float(n-1)*wsum/float(n))
      stddev=sqrt(var)
c     
      ar1=0.0
      do 13 i=2,n-1
          ar1=ar1+w(i)*(x(i+1)-mean)*(x(i)-mean)
   13 continue 
      ar1=ar1/(var*(n-1))
c
      return
      end                