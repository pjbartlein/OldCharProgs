      program decomp
      implicit none
      integer nmax,wmax
      parameter (nmax=3000,wmax=500)
      real obs(nmax),date(nmax),data(nmax) 
      real long(nmax),medium(nmax),short(nmax),irreg(nmax),cusum(0:nmax)
      real dist,w(wmax),wsum,x(wmax)
      real mean,stddev,ar1,med,p25,p75,iqr,peaks       
      integer n,nh,nobs,i,t,beg,end,ii,step
c
      open(1,file='cyg10.dat')
      open(2,file='cygdecmp.dat')      
c
      nobs=1215
      do 10 t=1,nobs
          read (1,*) obs(t),date(t),data(t)
          data(t)=log(data(t)+0.001)
          date(t)=-1.0*date(t)
c          data(t)=data(t)**0.33333
   10 continue                      
c
      n=101
      nh=50 
      beg=51
      end=1164
      step=1
c     
      do 11 i=1,n
          dist=float((abs((nh+1)-i)))/float(nh)
          w(i)=(1.0-dist**3.0)**3.0
          wsum=wsum+w(i)
          write (*,*) i,dist,w(i)
   11 continue  
c
      do 12 t=beg,end,step
          ii=0
          do 13 i=t-nh,t+nh
              ii=ii+1
              x(ii)=data(i)
   13      continue
c
      call desc(w,x,n,mean,stddev,ar1,med,p25,p75,iqr,peaks) 
c     
      long(t)=mean
c
   12 continue 
c     
      do 14 t=1,beg-1
          long(t)=long(beg)      
   14 continue
      do 15 t=end+1,nobs
          long(t)=long(end)
   15 continue        
c
      n=31
      nh=(n-1)/2 
      beg=nh+1
      end=1215-nh-1
      step=1
c     
      do 21 i=1,n
          dist=float((abs((nh+1)-i)))/float(nh)
          w(i)=(1.0-dist**3.0)**3.0
          wsum=wsum+w(i)
          write (*,*) i,dist,w(i)
   21 continue  
c
      do 22 t=beg,end,step
          ii=0
          do 23 i=t-nh,t+nh
              ii=ii+1
              x(ii)=data(i)-long(i)
   23      continue
c
      call desc(w,x,n,mean,stddev,ar1,med,p25,p75,iqr,peaks) 
c     
      medium(t)=mean
c
   22 continue 
c     
      do 24 t=1,beg-1
          medium(t)=medium(beg)
   24 continue
      do 25 t=end+1,nobs
          medium(t)=medium(end)
   25 continue        
c      
      n=5
      nh=(n-1)/2 
      beg=nh+1
      end=1215-nh-1
      step=1
c     
      do 31 i=1,n
          dist=float((abs((nh+1)-i)))/float(nh)
          w(i)=(1.0-dist**3.0)**3.0
          wsum=wsum+w(i)
          write (*,*) i,dist,w(i)
   31 continue  
c
      do 32 t=beg,end,step
          ii=0
          do 33 i=t-nh,t+nh
              ii=ii+1
              x(ii)=data(i)-long(i)-medium(i)
   33      continue
c
      call desc(w,x,n,mean,stddev,ar1,med,p25,p75,iqr,peaks) 
c     
      short(t)=mean
c
   32 continue 
c     
      do 34 t=1,beg-1
          short(t)=short(beg)
   34 continue
      do 35 t=end+1,nobs
          short(t)=short(end)
   35 continue        
      cusum(0)=0.0
      do 36 t=1,nobs
c          data(t)=exp(data(t)-.001) 
c          long(t)=exp(long(t)-.001) 
c          medium(t)=exp(medium(t)-.001)
c          short(t)=exp(short(t)-.001)
          irreg(t)=data(t)-long(t)-medium(t)-short(t) 
          cusum(t)=cusum(t-1)+irreg(t)*irreg(t)
          write (2,902) t,date(t),data(t),
     +     long(t),medium(t),short(t),irreg(t),cusum(t)
          write (*,902) t,date(t),data(t),
     +     long(t),medium(t),short(t),irreg(t),cusum(t)
  902 format (i5,f8.0,5f10.4,g14.6) 
   36 continue
c                    
      end       