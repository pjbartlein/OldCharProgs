      program evenage 
      implicit none
      integer n,nmax
      parameter (n=678,nmax=1500)
      real x,xx(n),yy(n),y  
      real xstart,xstep
      integer i,j,ji,id
      integer nsteps
c
      open (1,file='cygraw.dat')
      open (2,file='cyg10.dat')    
c
      do 10 i=1,n
          read (1,*) id,xx(i),yy(i)        
   10 continue
c     
      xstart=-12140.0
      xstep=10.0
      nsteps=1215
c
      j=1
      ji=j
      do 20 i=1,nsteps
          x=xstart+(i-1)*xstep
          call hunt(xx,n,x,j)
          if (j.eq.0) then
              y=yy(1)
c              write (2,902) i,x,ji,j,'lower limit'
c  902         format (' i,x,ji,j ',i5,f10.2,2i5,a12) 
              write (2,905) i,x,y
          else if (j.eq.n) then
              y=yy(n)
c              write (2,903) i,x,ji,j,'upper limit'
c  903         format (' i,x,ji,j ',i5,f10.2,2i5,a12) 
              write (2,905) i,x,y
          else
              y=yy(j)+((x-xx(j))/(xx(j+1)-xx(j)))*(yy(j+1)-yy(j))
c              write (2,904) i,x,ji,j,xx(j),xx(j+1)
c  904         format (' i,x,ji,j ',i5,f10.2,2i5,2f10.2)
              write (2,905) i,x,y
  905         format (i5,f10.2,f6.2)        
          endif
   20 continue
      stop
      end    